"""369 Data Brain: POST /predict {columns, rows, target} -> {predictions, engine}. Port 3691 (or $PORT)."""
import json, os
from http.server import BaseHTTPRequestHandler, HTTPServer
def num(v):
    try: return float(v)
    except (TypeError, ValueError): return 0.0
def predict(cols, rows, target):
    ti = cols.index(target)
    tr = [r for r in rows if r[ti] != '']; te = [r for r in rows if r[ti] == '']
    X = [[num(v) for i, v in enumerate(r) if i != ti] for r in tr]
    Xt = [[num(v) for i, v in enumerate(r) if i != ti] for r in te]
    y = [r[ti] for r in tr]
    try:
        from tabpfn import TabPFNRegressor, TabPFNClassifier
        try:
            yy = [float(v) for v in y]; m = TabPFNRegressor(); m.fit(X, yy)
            return [round(float(p), 2) for p in m.predict(Xt)], 'TabPFN'
        except ValueError:
            m = TabPFNClassifier(); m.fit(X, y); return [str(p) for p in m.predict(Xt)], 'TabPFN'
    except ImportError:
        out = []
        for x in Xt:
            d = sorted((sum((a - b) ** 2 for a, b in zip(x, z)), v) for z, v in zip(X, y))[:3]
            try: out.append(round(sum(float(v) for _, v in d) / len(d), 2))
            except ValueError: out.append(d[0][1])
        return out, 'kNN (pip install tabpfn for real TabPFN)'
class H(BaseHTTPRequestHandler):
    def _h(self, c=200):
        self.send_response(c); self.send_header('content-type', 'application/json')
        self.send_header('access-control-allow-origin', '*'); self.send_header('access-control-allow-headers', 'content-type'); self.end_headers()
    def do_OPTIONS(self): self._h()
    def do_POST(self):
        try:
            j = json.loads(self.rfile.read(int(self.headers['content-length'])))
            p, e = predict(j['columns'], j['rows'], j['target']); self._h(); self.wfile.write(json.dumps({'predictions': p, 'engine': e}).encode())
        except Exception as ex:
            self._h(400); self.wfile.write(json.dumps({'error': str(ex)}).encode())
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 3691)); print('369 Data Brain on :%d' % port)
    HTTPServer(('0.0.0.0', port), H).serve_forever()
