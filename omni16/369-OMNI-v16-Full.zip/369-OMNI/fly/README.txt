Put the Gateway and Data Brain online with Fly.io (needs a Fly.io account with billing):
1. Install flyctl (https://fly.io/docs/flyctl/install/), then: fly auth login
2. In the 369-OMNI folder: fly launch --config fly/fly.gateway.toml --no-deploy
3. Keys go in secrets, never files: fly secrets set OPENROUTER_API_KEY=... --config fly/fly.gateway.toml
4. fly deploy --config fly/fly.gateway.toml  -> paste https://<app>.fly.dev into OMNI Keys > Gateway URL
5. Same with fly/fly.databrain.toml -> paste its URL into Keys > TabPFN server
