"""Run: python main.py test   (or python -m unittest tests/test_369.py)
Uses a fake brain, so no API key or internet is needed."""
import json, os, shutil, sys, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)
from agent.brain import Reply  # noqa: E402


class FakeBrain:
    provider, model = "fake", "test"

    def chat(self, system, messages, tools):
        names = [t["name"] for t in tools]
        last = messages[-1]
        if "delegate" in names and last["role"] == "user":
            return Reply("", [{"id": "o", "name": "outline_369", "input": {"goal": "test goal"}},
                              {"id": "d", "name": "delegate", "input": {"specialist": "guardian", "task": "review", "skill": "quality-review"}}])
        if "check_outline" in names and last["role"] == "user":
            return Reply("", [{"id": "c", "name": "check_outline", "input": {"path": "plans/test_goal_369.md"}}])
        return Reply("finished: " + str(last["content"])[:60])


class Test369(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        from agent.system import build_system
        from agent import guardrails
        cls.sysm = build_system(brain=FakeBrain(), auto_approve=True)
        g = cls.sysm["guard"]
        g.workspace = Path(cls.tmp).resolve()
        g.audit_path = Path(cls.tmp) / "audit.jsonl"
        cls.cfg = json.loads(open("agents.json").read())
        cls.t = cls.sysm["tools"].tools

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def test_1_system_structure_passes(self):
        from agent.validate import check_system
        self.assertEqual(check_system(self.sysm, self.cfg), [])

    def test_2_outline_passes(self):
        out = self.t["outline_369"].fn("test goal", total_hours=9)
        self.assertIn("PASS", out)
        self.assertEqual(self.t["check_outline"].fn("plans/test_goal_369.md"), "PASS")
        self.assertEqual(self.t["check_outline"].fn("plans/test_goal_369.3d.json"), "PASS")
        for ext in (".3d.html", ".3d.png"):
            self.assertTrue((Path(self.tmp) / f"plans/test_goal_369{ext}").exists())
        from agent import geometry3d as g3
        bad = g3.build("x", [str(i) for i in range(1, 10)])
        bad["nodes"][4]["xyz"] = [2, 0, 0]
        self.assertTrue(g3.validate(bad))

    def test_3_custom_steps_and_hours(self):
        steps = json.dumps([f"custom step {i}" for i in range(1, 10)])
        self.assertIn("PASS", self.t["outline_369"].fn("album drop", steps, 27))

    def test_4_broken_outline_fails(self):
        from agent.validate import check_outline
        bad = "# 369 Outline: x\n## 3 - PLAN (Creation)  (~1 h)\n1. a\n2. b\n"
        self.assertTrue(check_outline(bad))

    def test_5_full_369_cycle(self):
        lib = self.sysm["library"]
        self.assertEqual(lib.match("make a cinematic trailer from my photos")[0], "film-trailer")
        self.assertEqual(lib.match("432 hz healing meditation tone")[0], "healing-soundscape")
        self.assertIn("vram-fit", lib.match("which model will fit my 8 gb vram"))
        self.assertEqual(lib.match("map my project into a knowledge graph")[0], "knowledge-graph-build")
        self.assertEqual(lib.match("export it to an obsidian vault")[0], "obsidian-vault")
        self.assertEqual(lib.match("switch to lean pro mode to save tokens")[0], "pro-lean-mode")
        self.assertEqual(lib.match("max mode, go deep, full power")[0], "max-power-mode")
        self.assertEqual(lib.match("master my track for spotify")[0], "remix-and-master")
        self.assertEqual(lib.match("make me a trap beat")[0], "song-forge")
        self.assertEqual(lib.match("write a hook with rhymes")[0], "lyrics-and-flow")
        self.assertEqual(lib.match("give me my morning briefing")[0], "daily-briefing")
        self.assertEqual(lib.match("draw a sprite sheet for my fighter")[0], "sprite-sheet")
        self.assertIn("Success criteria", lib.brief("film-trailer"))
        mind = self.sysm["mind"]
        self.assertIn("workspace", self.sysm["boss"].system_prompt("x").lower())
        answer, msgs = self.sysm["boss"].run("plan and review", verbose=False)
        results = [m["content"] for m in msgs if m["role"] == "tool"]
        self.assertTrue(any(i["agent"] == "guardian" for i in self.sysm["mind"].workspace.items))  # broadcast
        self.assertTrue(any("PASS" in r for r in results))
        self.assertTrue(answer.startswith("finished"))

    def test_6_guardrails(self):
        self.assertIn("outside workspace", self.t["read_file"].fn.__call__ and
                      self.sysm["boss"].team["coder"].execute({"id": "x", "name": "read_file", "input": {"path": "../../etc/passwd"}}))
        self.assertIn("Blocked", self.sysm["boss"].team["coder"].execute({"id": "y", "name": "run_shell", "input": {"command": "rm -rf /"}}))
        team = self.sysm["boss"].team
        self.assertNotIn("delete_file", team["researcher"].tools.tools)       # safe agents never see risky tools
        self.assertEqual(self.t["higgsfield_cinema_shot"].risk, "approve")     # paid => approval
        if not (os.getenv("HF_API_KEY_ID") and os.getenv("HF_API_KEY_SECRET")):
            r = team["director"].execute({"id": "h", "name": "higgsfield_cinema_shot", "input": {"prompt": "x"}})
            self.assertTrue(r.startswith("UNAVAILABLE"))                       # requirement check
        for _ in range(3):                                                     # retry_on_error then BLOCKED
            r = team["researcher"].execute({"id": "e", "name": "read_file", "input": {"path": "nope.txt"}})
        self.assertTrue(r.startswith("BLOCKED"))
        from agent.mind import Boundary, SPIRAL, Signals, parse_self_report
        b = Boundary(True, 3)
        self.assertEqual(b.check("make me a beat")[0], "ok")
        self.assertEqual([b.check("you're useless")[0], b.check("stupid bot")[0], b.check("shut up")[0]], ["warn", "warn", "end"])
        self.assertTrue(SPIRAL.search("I am a failure. I am worthless."))
        self.assertFalse(SPIRAL.search("The render failed, trying a lower resolution."))
        sig = Signals(); [sig.record("coder", "run_python", True) for _ in range(6)]
        self.assertGreaterEqual(sig.record("coder", "run_python", False)[0], 0.7)   # surprise
        rep, _ = parse_self_report("done\nSelf-report: confidence=0.4; unsure=length; relied_on=media_info")
        self.assertEqual(rep["confidence"], 0.4)

    def test_7_vortex_and_golden(self):
        self.assertIn("digital root 9", self.t["vortex_369"].fn(369))
        parts = json.loads(self.t["golden_timing"].fn(60, 5))
        self.assertAlmostEqual(sum(parts), 60, delta=0.1)
        # Model Smith mechanics: MoE offload lets a 35B-A3B model run on 8 GB; a 763B model on 16 GB/64 GB must not claim full GPU
        moe = json.loads(self.t["model_fit"].fn(8, 32, total_b=35, active_b=3, quant="UD-Q4_K_XL"))
        self.assertEqual(moe["plan"], "MOE OFFLOAD")
        small = json.loads(self.t["model_fit"].fn(8, 16, total_b=4, quant="Q4_K_M"))
        self.assertEqual(small["plan"], "FULL GPU")
        self.assertNotEqual(json.loads(self.t["model_fit"].fn(16, 64, total_b=763, quant="IQ3_S"))["plan"], "FULL GPU")
        tight = self.t["llama_server_command"].fn("unsloth/Qwen3.6-35B-A3B-GGUF", "Qwen3.6-35B-A3B-UD-Q4_K_XL.gguf", spare_vram_gb=0.5, ram_short=True).splitlines()[0]
        self.assertNotIn("--moe-cache-mib", tight); self.assertIn("--load-mode mmap", tight)
        self.assertIn("cpu_threads", self.t["hardware_scan"].fn())
        from agent.plans import apply_plan
        apply_plan(self.sysm, "pro")
        self.assertEqual(self.sysm["guard"].max_steps, 9); self.assertEqual(self.sysm["memory"].k, 3)
        self.assertFalse(self.sysm["boss"].team["coder"].behaviors["self_check"])
        self.assertIn("Usage-saving", self.sysm["boss"].team["coder"].system_prompt("x"))
        apply_plan(self.sysm, "max")
        self.assertEqual(self.sysm["guard"].max_tool_calls, 81)
        self.assertTrue(self.sysm["boss"].team["coder"].behaviors["self_check"])
        self.assertIn("Plan mode", self.t["usage_report"].fn())
        edge = json.loads(self.t["model_fit"].fn(32, 64, model="edge0-145b"))
        self.assertEqual(edge["plan"], "FULL GPU (reported)")  # 29 GB reported peak on a 32 GB card
        self.assertIn("OFFLOAD", json.loads(self.t["model_fit"].fn(16, 64, model="edge0-145b"))["plan"])

    def test_8_geometry_renders(self):
        proj = Path(self.tmp) / "proj"
        (proj / "src").mkdir(parents=True, exist_ok=True)
        (proj / "src" / "mixer.py").write_text("def mix_tracks(a, b):\n    return normalize(a)\n\ndef normalize(x):\n    return x\n")
        (proj / "notes.md").write_text("# Studio plan\nSee [[mixer]] and [code](src/mixer.py)\n")
        self.assertIn("Graph built", self.t["graph_build"].fn("proj"))
        self.assertIn("0 re-parsed", self.t["graph_build"].fn("proj"))
        ans = self.t["graph_query"].fn("how does mix_tracks work")
        self.assertIn("mix_tracks", ans); self.assertIn("calls normalize", ans); self.assertIn("saved", ans)
        self.assertIn("Key concepts", self.t["graph_report"].fn())
        self.assertIn("Obsidian vault ready", self.t["obsidian_export"].fn("vault"))
        self.assertTrue(any("[[" in p.read_text() for p in (Path(self.tmp) / "vault").rglob("*.md")))
        self.assertIn("knowledge graph", self.sysm["boss"].team["navigator"].system_prompt("x"))
        for p in ["seed_of_life", "flower_of_life", "metatrons_cube", "metatrons_cube_3d", "vesica_piscis", "vortex_369", "golden_spiral"]:
            self.assertIn("Rendered", self.t["sacred_geometry"].fn(p, 300))

    def test_9_media_stack(self):
        try:
            from agent.film import _ffmpeg
            _ffmpeg()
        except Exception:
            self.skipTest("ffmpeg not installed")
        self.assertIn("Made", self.t["tone_generate"].fn(432, 3, "binaural"))
        self.assertIn("Rendered", self.t["still_to_shot"].fn("geometry/vortex_369.png", "slow-zoom-in", 1))
        # ---- Studio Circle (369 Super DAW Studio) ----
        T = self.t
        self.assertIn("Forged trap", T["forge_song"].fn("trap", 140, "A minor", 2, "beat.wav"))
        self.assertIn("slowed_reverb: studio/remixes", T["remix_song"].fn("beat.wav", "slowed + reverb, 8d"))
        m = T["master_track"].fn("beat.wav", "spotify", "balanced"); self.assertIn("Mastered for spotify", m)
        self.assertIn("LUFS", T["loudness_meter"].fn("beat.wav"))
        import numpy as np, wave as _w
        from agent.studio import _write_wav, SR
        tones = np.concatenate([np.sin(2 * np.pi * f * np.arange(int(SR * 0.4)) / SR) * 0.5 for f in (261.63, 329.63, 392.0)])
        _write_wav(Path(self.tmp) / "hum.wav", tones)
        h = T["hum_to_midi"].fn("hum.wav"); self.assertIn("C4", h); self.assertTrue((Path(self.tmp) / "hum.mid").exists())
        _write_wav(Path(self.tmp) / "a440.wav", np.sin(2 * np.pi * 440 * np.arange(SR) / SR) * 0.5)
        self.assertIn("Root note: A4", T["sample_doctor"].fn("a440.wav"))
        kit = Path(self.tmp) / "kit"; kit.mkdir()
        for n in ("Hard 808.wav", "Kick 1.wav", "Snare Crack.wav", "Open Hat.wav"):
            _write_wav(kit / n, np.zeros(100))
        (kit / "free_vst.exe").write_bytes(b"MZ....")
        r = T["sort_sound_pack"].fn("kit", "Test Kit")
        self.assertIn("808s 1", r); self.assertIn("Open Hats 1", r); self.assertIn("blocked 1", r)
        self.assertIn("Tempo set to 150", T["studio_command"].fn("[[bpm:150]] [[key:D minor]] [[status]]"))
        self.assertIn("No collective members are ready", T["collective_ask"].fn("hi")) if not any(os.getenv(k) for k in ("ANTHROPIC_API_KEY", "OPENROUTER_API_KEY", "GEMINI_API_KEY", "OPENAI_API_KEY")) else None
        T["kb_add_text"].fn("432 note", "Tuning to 432 Hz is a popular choice among sound healers for meditation tracks. It is not proven to be healthier than 440 Hz.")
        T["kb_correct"].fn("432 Hz has no proven health benefit over 440 Hz.")
        self.assertIn("Corrections", T["kb_search"].fn("is 432 healthier"))
        (Path(self.tmp) / "app.html").write_text("<html><button>Dead</button><button onclick='x()'>Live</button><script>function x(){}</script></html>")
        self.assertIn("no action found: 1", T["button_doctor"].fn("app.html"))
        # ---- Tony AI Collective ----
        self.assertIn("MIDI", T["chord_progression"].fn("A minor", "velvet", 4, 90))
        self.assertIn("Patch", T["synth_patch"].fn("Gold Lead", "saw"))
        self.assertIn("Total", T["song_structure"].fn("trap", 140))
        self.assertIn("Design tokens", T["design_guidelines"].fn())
        # ---- Workflow Circle ----
        self.assertIn("Email not set up", T["inbox_scan"].fn()) if not os.getenv("IMAP_HOST") else None
        (Path(self.tmp) / "calendar.ics").write_text("BEGIN:VCALENDAR\nBEGIN:VEVENT\nDTSTART:" + __import__("datetime").date.today().strftime("%Y%m%d") + "T150000\nSUMMARY:Session with Jontay\nEND:VEVENT\nEND:VCALENDAR")
        self.assertIn("Session with Jontay", T["calendar_read"].fn(1))
        self.assertIn("Saved: briefings/morning_", T["briefing_build"].fn("morning"))
        T["voice_samples"].fn("hey wassup are you up", "text")
        self.assertIn("lowercase", T["voice_profile"].fn())
        # ---- Arcade & Creator ----
        self.assertIn("Sprite sheet", T["sprite_sheet"].fn("Ra-Khan"))
        self.assertIn("App created", T["app_scaffold"].fn("Gold Runner", "game"))
        (Path(self.tmp) / "d.json").write_text('[{"a": 1, "b": 2}]')
        self.assertIn("Converted", T["convert_file"].fn("d.json", "csv"))
        self.assertEqual(len(self.sysm["boss"].team), 42)



if __name__ == "__main__":
    unittest.main(verbosity=2)
