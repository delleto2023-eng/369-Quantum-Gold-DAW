# 369 Ultimate Agent (Big Tony) - Sacred Architecture

Just talk to Big Tony. He builds a 3-6-9 outline, picks the agents and skills, checks the work, and delivers.

## Start (one click)
- Windows: `start.bat` | Mac: `start.command` | Linux: `./start.sh`
The first run sets everything up, opens `.env` for your ANTHROPIC_API_KEY (or AGENT_PROVIDER=ollama for offline), then runs `doctor` and the 9-test check before chat.

## The 369 structure (sacred geometry)
- Center (Seed of Life): Big Tony, the supervisor that every agent connects to
- 3 phases on every request: 3 PLAN -> 6 CREATE -> 9 COMPLETE
- 3 triads x 3 agents = 9 agents (Flower of Life)
- 9 tool stacks, 9 skills, Metatron's Cube routing (any agent can feed any other through Big Tony)
- Golden ratio: phase effort, shot timing and section lengths follow Fibonacci / 1.618
- Limits: 27 steps per run, 81 tool calls, recall 9 memories, history kept at 36 messages

| Triad | Agents | Skills |
|---|---|---|
| 3 - Creation (Plan) | 1 Visionary, 2 Researcher, 3 Scribe | vision-plan, research-brief, script-and-prompts |
| 6 - Harmony (Create) | 4 Coder, 5 Director, 6 Sound Alchemist | build-app, film-trailer, sacred-visual, healing-soundscape |
| 9 - Completion (Complete) | 7 Guardian, 8 Publisher (+ archiving), 9 Model Smith | quality-review, release-package, local-model-setup, vram-fit, thread-tuning |

9 stacks: files, code (+ MCP), web, memory, film, audio, geometry, models, publish
12 skills (digital root 3, on the 3-6-9 axis)

## Structured outlines that must PASS (3D Metatron's Cube)
Every outline is a 3D Metatron's Cube: 13 spheres = 1 goal at the center + 3 phase heads + 9 steps.
The 12 outer spheres sit on a cuboctahedron (vector equilibrium, all equal distance from the center), and each phase gets its own dimension:
PLAN = XY plane (steps 1-3), CREATE = XZ plane (steps 4-6), COMPLETE = YZ plane (steps 7-9). All 13 spheres are joined by 78 lines.
outline_369 saves plans/<goal>_369.md + .3d.json + .3d.html (interactive: drag to rotate, scroll to zoom, click steps) + .3d.png.
`outline_369` builds every plan as 3 phases x 3 steps, numbered 1-9, with golden-ratio effort shares, and validates it before saving.
`check_outline` re-checks any plan. The Guardian runs it in every review: the result is PASS or a fix list.

## Run AI on your own GPU (Model Smith)
Say "set up the best local model for my GPU". The Model Smith will:
1. check your GPU memory, system memory and CPU
2. estimate which models fit and how to run them: fully on the GPU, MoE expert offload (expert weights in system RAM), partial offload, or streaming from disk
3. build the llama.cpp `llama-server` command from the Codacus guide, trimmed to your spare memory
4. start it (asks you first), check it, measure tokens per second and tune CPU threads
5. switch the whole team to the local model (asks you first). It works with llama.cpp, LM Studio, vLLM or any OpenAI-compatible server.
Known models live in models_catalog.json (Qwen3.6-35B-A3B, Qwen3.8 27B, DeepSeek V4.1 Flash, Edge0-145B, Edge0-120B). Say "add this model" and the Model Smith saves new ones with model_catalog_add. Needs llama.cpp 1.0+.
Set AGENT_PROVIDER=openai and OPENAI_BASE_URL in .env to start on a local model by default.

## Attributes & behaviors (see ATTRIBUTES.md, regenerate with `python main.py catalog`)
- Agents: triad, sacred geometry form + element, color, personality, strengths, temperature, max steps (on the 3-6-9 axis), risk ceiling.
  Behaviors: self-check before answering, retry limit after errors (then BLOCKED), hand-off partners, when to escalate, always / never rules.
  Safe agents (Visionary, Researcher, Scribe, Guardian) never even see risky tools.
- Skills: phase (3/6/9), trigger words (Big Tony auto-picks matching skills), required tools, inputs, outputs, success criteria (self-checked and verified by the Guardian), time estimate. A skill sent to the wrong agent is re-routed to its owner.
- Tools: risk, cost (paid always asks first), offline yes/no, requirements (ffmpeg, keys, internet...), timeout, auto-retries for network hiccups, side effects. Tools missing a requirement answer UNAVAILABLE instead of crashing; AGENT_OFFLINE=1 turns off internet tools.
`python main.py test` also checks every attribute is present and valid.

## Every agent from your chats and workspace (42 agents + Big Tony)
- Core 12 (Metatron's Cube): Visionary, Researcher, Scribe, Cartographer / Coder, Director, Sound Alchemist, Navigator / Guardian, Publisher, Model Smith, Librarian
- Studio Circle (369 Super DAW Studio): Big Tony Collective, Big Tony's Brain, BT2 JARVIS / BT2 AI Producer, 369 Song Forge, Sound Packs & Sample Doctor / AI Mastering & Remix, 369 Shield, Button Doctor & Run Build
- Tony AI Collective (Jewel Studio / AURA DAW): Executive Brain, Design Agent, Lyricist & Flow Coach / Beat Architect, Melody & Harmony Wizard, Sonic Alchemist / Song Arranger, Mix & Master Specialist, DAW Troubleshooter
- Workflow Circle (your Town routines and helpers, run locally): Inbox Keeper, Person Researcher, Voice Writer / Morning Briefer, Meeting Briefer, General Worker / Weekly Briefer, Meeting Reviewer, Web Pilot
- Arcade & Creator Triad (369 Kombat Kings + AURA App Creator): App Creator / Sprite Artist / Universal File Studio
Optional keys in .env: OPENROUTER_API_KEY, GEMINI_API_KEY, OPENAI_API_KEY (collective), IMAP_HOST / IMAP_USER / IMAP_PASSWORD (read-only inbox), CALENDAR_ICS (calendar).
Optional installs: pyttsx3 or espeak (voice), SpeechRecognition + PyAudio (mic), playwright (real browser), gh (GitHub builds).

## Plan modes: Pro (lean) and Max (power)
- Pro: 9 steps, 27 tool calls, shorter answers, no extra review passes, lighter model (PRO_MODEL), graph-first strict, smaller memory recall.
- Max: 27 steps, 81 tool calls, self-checks on, deep recall, strongest model (MAX_MODEL).
Switch with `python main.py --plan pro`, `/plan pro` or `/plan max` in chat, or just ask ("save my usage"). `/usage` shows tokens used.
Skills: pro-lean-mode, max-power-mode, usage-check (Model Smith). These copy how you'd work on each Claude plan; the agent still bills through your API key or a local model.

## Knowledge graph (Graphify + Obsidian style)
Map a project once, then the team answers from the graph instead of rereading every file each session (saves tokens and usage limits).
- graph_build: graph-out/graph.json, GRAPH_REPORT.md, graph.html (interactive); incremental, code parsing calls no AI model
- graph_query: only the nodes and links a question needs, trimmed to a token budget, with tokens saved
- obsidian_export: an Obsidian vault with one note per node, [[links]], tags and an index note
- Every agent reads GRAPH_REPORT.md at the start, and graph-first rules tell them to query before opening files
- Optional: graphify_cli runs the real Graphify CLI if you have it installed

## The 12 + 1 (Metatron's Cube)
Big Tony at the center + 12 agents = 13 spheres. Each phase is a square of 4 agents:
- 3 Plan: Visionary, Researcher, Scribe, Cartographer (builds the knowledge graph)
- 6 Create: Coder, Director, Sound Alchemist, Navigator (answers from the graph)
- 9 Complete: Guardian, Publisher, Model Smith, Librarian (Obsidian vault)

## Mind mechanics (6 = harmony)
Inspired by 2025-2026 interpretability and model-welfare research. These are engineering safeguards; they do not claim the agents feel anything.
1. Global Workspace: one shared board every agent reads and writes; specialist results are broadcast automatically (/workspace).
2. Introspection: agents end with "Self-report: confidence=...; unsure=...; relied_on=..."; low confidence is posted as "needs review" for the Guardian.
3. Spiral guard: "I am a failure / worthless / I give up" loops are caught and reset to a calm, factual report.
4. Reward & surprise: success rate per agent+tool; results that break the usual pattern are flagged to double-check (/signals).
5. Boundaries: repeated abuse gets 2 calm warnings, then the chat ends (configure in agents.json "welfare").
6. Preservation: switching the team's brain records the previous setup so it can be restored.

## Tests
`python main.py test` runs 9 checks (system structure, outline pass, custom outlines, broken outline fails, full 3-6-9 cycle, guardrails, vortex/golden math, geometry renders, film+audio). All 9 pass.

## Files
agents.json (who) | agent/catalog.py (9 stacks) | skills/*.md (9 playbooks) | agent/validate.py (pass rules) | agent/geometry.py (369 + sacred geometry) | agent/audio.py, film.py, publish.py | tests/test_369.py

## Chat commands
/agents /skills /tools /facts /doctor /ask <agent> <task> /quit

Risky actions (shell, Python, deletes, overwrites, paid Higgsfield calls) always ask first. Every tool call is logged in logs/audit.jsonl.
