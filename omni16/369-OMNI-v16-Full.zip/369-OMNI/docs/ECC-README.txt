Everything Claude Code pack for 369 OMNI v11
1. Copy ecc-pack.js next to index.html in 369-OMNI-v11.
2. In index.html, add before </body>:  <script src="ecc-pack.js"></script>
3. Each agent/skill/helper links to its full original instructions (src).
For real Claude Code / Cursor / Codex use: git clone https://github.com/affaan-m/everything-claude-code
