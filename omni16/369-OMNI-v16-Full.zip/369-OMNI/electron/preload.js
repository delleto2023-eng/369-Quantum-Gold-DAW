// Points the UI at the built-in local gateway the first time it runs.
try { if (!localStorage.getItem('og_gw')) localStorage.setItem('og_gw', 'http://127.0.0.1:3690'); } catch (e) {}
