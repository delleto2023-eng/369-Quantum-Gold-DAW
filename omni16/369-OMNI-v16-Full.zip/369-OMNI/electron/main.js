const { app, BrowserWindow, Menu, shell, dialog } = require('electron');
const { fork, spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const packaged = app.isPackaged;
const RES = packaged ? process.resourcesPath : path.join(__dirname, '..');
const GATEWAY = path.join(RES, 'gateway', 'gateway.mjs');
const AGENT = path.join(RES, 'agent');
const DOCS = path.join(RES, 'docs');
let win, gw;

if (!app.requestSingleInstanceLock()) { app.quit(); }
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

function dataDir() { return app.getPath('userData'); }

function ensureKeys() {
  const dir = path.join(dataDir(), 'keys');
  fs.mkdirSync(dir, { recursive: true });
  const f = path.join(dir, '.env');
  if (!fs.existsSync(f)) {
    fs.writeFileSync(f, [
      '# 369 OMNI gateway keys. Add only the ones you use, save, done (no restart needed).',
      '# Lines starting with # are ignored.',
      'OPENROUTER_API_KEY=',
      'ANTHROPIC_API_KEY=',
      'OPENAI_API_KEY=',
      'GEMINI_API_KEY=',
      'XAI_API_KEY=',
      'DEEPSEEK_API_KEY=',
      'DASHSCOPE_API_KEY=',
      'GROQ_API_KEY=',
      'MOONSHOT_API_KEY=',
      '# Local models (Ollama):',
      'OLLAMA_URL=http://localhost:11434',
      '# Optional: require a token from other devices that call the gateway',
      'OMNI_GATEWAY_TOKEN=',
      ''
    ].join('\n'));
  }
  return f;
}

function startGateway() {
  // Local only by default. Create a file named "lan" in the data folder to let phones/laptops on your network connect.
  const lan = fs.existsSync(path.join(dataDir(), 'lan'));
  gw = fork(GATEWAY, [], {
    env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', OMNI_DATA: dataDir(), HOST: lan ? '0.0.0.0' : '127.0.0.1' },
    stdio: 'ignore'
  });
  gw.on('exit', () => { gw = null; });
}

function createWindow() {
  win = new BrowserWindow({
    width: 1280, height: 860, backgroundColor: '#0b0b0e', title: '369 OMNI',
    icon: path.join(__dirname, '..', 'build', 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: false }
  });
  win.loadFile(path.join(packaged ? app.getAppPath() : path.join(__dirname, '..'), 'app', 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file:')) { e.preventDefault(); shell.openExternal(url); } });
}

function launchAgent() {
  if (process.platform !== 'win32') { shell.openPath(AGENT); return; }
  // Big Tony (Python agent) runs from a writable per-user copy so its venv, .env, memory and workspace persist across updates.
  const dest = path.join(dataDir(), 'agent');
  if (!fs.existsSync(dest)) fs.cpSync(AGENT, dest, { recursive: true });
  spawn('cmd.exe', ['/c', 'start', '"Big Tony"', 'cmd', '/k', 'start.bat'], { cwd: dest, detached: true, stdio: 'ignore', windowsVerbatimArguments: true }).unref();
}

function buildMenu() {
  const keysFile = ensureKeys();
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: 'OMNI', submenu: [
      { label: 'Edit API keys (opens keys file)', click: () => shell.openPath(keysFile) },
      { label: 'Open data folder', click: () => shell.openPath(dataDir()) },
      { label: 'Launch Big Tony (Python agent)', click: () => launchAgent() },
      { label: 'Open docs folder', click: () => shell.openPath(DOCS) },
      { type: 'separator' },
      { label: 'Restart gateway', click: () => { if (gw) gw.kill(); setTimeout(startGateway, 400); } },
      { type: 'separator' }, { role: 'quit' }
    ] },
    { label: 'View', submenu: [{ role: 'reload' }, { role: 'togglefullscreen' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { role: 'resetZoom' }, { role: 'toggleDevTools' }] },
    { label: 'Edit', submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }] }
  ]));
}

app.whenReady().then(() => { buildMenu(); startGateway(); createWindow(); });
app.on('window-all-closed', () => app.quit());
app.on('before-quit', () => { if (gw) gw.kill(); });
