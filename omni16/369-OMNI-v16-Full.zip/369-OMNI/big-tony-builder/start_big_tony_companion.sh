#!/usr/bin/env bash
cd "$(dirname "$0")"
./.venv/bin/python -m big_tony_builder.companion "$@"
