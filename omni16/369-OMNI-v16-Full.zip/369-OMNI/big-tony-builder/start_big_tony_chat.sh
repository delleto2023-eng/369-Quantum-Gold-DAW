#!/usr/bin/env bash
cd "$(dirname "$0")"
(sleep 2; (xdg-open http://localhost:3080 || open http://localhost:3080) >/dev/null 2>&1) &
./.venv/bin/python -m big_tony_builder.chat serve "$@"
