@echo off
cd /d "%~dp0"
set /p PIN="Mesh PIN (same on every machine): "
".venv\Scripts\python.exe" -m big_tony_builder.peerium --pin %PIN%
pause
