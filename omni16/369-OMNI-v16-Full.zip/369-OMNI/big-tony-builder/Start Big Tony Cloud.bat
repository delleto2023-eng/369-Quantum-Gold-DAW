@echo off
set /p ROOT="Drive folder for your cloud (e.g. E:\BigTonyCloud): "
set /p PIN="Choose your PIN: "
python -m big_tony_builder.cloud setup --root "%ROOT%" --stacks 2 --size 300 --pin %PIN% --reserve
python -m big_tony_builder.cloud serve --root "%ROOT%"
pause
