#!/bin/sh
printf "Drive folder for your cloud: "; read ROOT
printf "Choose your PIN: "; read PIN
python3 -m big_tony_builder.cloud setup --root "$ROOT" --stacks 2 --size 300 --pin "$PIN" --reserve
python3 -m big_tony_builder.cloud serve --root "$ROOT"
