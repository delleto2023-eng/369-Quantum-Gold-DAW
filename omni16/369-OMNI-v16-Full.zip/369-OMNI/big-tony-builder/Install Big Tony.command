#!/usr/bin/env bash
# Big Tony Builder - one-click setup for Mac and Linux
# Installs Python 3.12, FFmpeg, LM Studio (+ lms CLI), a private Python environment, Big Tony's packages,
# starts the LM Studio server and makes a launcher.   Options: --no-model  --model NAME  --full
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"; cd "$HERE"
MODEL="qwen2.5-coder-7b-instruct"; NOMODEL=0; FULL=0
while [ $# -gt 0 ]; do case "$1" in --no-model) NOMODEL=1;; --model) MODEL="$2"; shift;; --full) FULL=1;; esac; shift; done
say(){ printf '\n\033[33m== %s\033[0m\n' "$1"; }
have(){ command -v "$1" >/dev/null 2>&1; }
OS="$(uname -s)"
SUDO=""; [ "$(id -u)" -ne 0 ] && have sudo && SUDO="sudo"
pkg_install(){
  if [ "$OS" = "Darwin" ]; then have brew && brew install "$@"; return; fi
  if have apt-get; then $SUDO apt-get update -y && $SUDO apt-get install -y "$@"
  elif have dnf; then $SUDO dnf install -y "$@"
  elif have pacman; then $SUDO pacman -Sy --noconfirm "$@"
  elif have zypper; then $SUDO zypper install -y "$@"; fi
}
find_py(){ for c in python3.13 python3.12 python3.11 python3.10 python3; do
  if have "$c" && "$c" -c 'import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)' 2>/dev/null; then echo "$c"; return; fi; done; }

# ---------- 1. Python ----------
say "Checking Python"
PY="$(find_py)"
if [ -z "$PY" ]; then
  say "Installing Python 3.12"
  if [ "$OS" = "Darwin" ]; then
    if have brew; then brew install python@3.12
    else curl -fsSL -o /tmp/python.pkg https://www.python.org/ftp/python/3.12.10/python-3.12.10-macos11.pkg && sudo installer -pkg /tmp/python.pkg -target /; fi
  else
    pkg_install python3 python3-venv python3-pip || pkg_install python python-pip
  fi
  PY="$(find_py)"
fi
[ -z "$PY" ] && { echo "Python could not be installed. Get it from https://www.python.org/downloads/ and run this again."; exit 1; }
echo "Python: $($PY --version)"
if [ "$OS" != "Darwin" ] && ! "$PY" -m venv --help >/dev/null 2>&1; then pkg_install python3-venv; fi

# ---------- 2. FFmpeg ----------
say "Checking FFmpeg"
have ffmpeg || pkg_install ffmpeg || echo "FFmpeg not installed system-wide; Big Tony will use the bundled imageio-ffmpeg copy."

# ---------- 3. Private Python environment ----------
say "Setting up Big Tony's Python environment"
[ -x "$HERE/.venv/bin/python" ] || "$PY" -m venv "$HERE/.venv" || { pkg_install python3-venv; "$PY" -m venv "$HERE/.venv"; }
VPY="$HERE/.venv/bin/python"
"$VPY" -m pip install --upgrade pip
"$VPY" -m pip install -r "$HERE/requirements.txt"
if [ "$FULL" = 1 ]; then "$VPY" -m pip install -r "$HERE/requirements-optional.txt"; "$VPY" -m playwright install chromium || true; fi

# ---------- 4. LM Studio ----------
say "Checking LM Studio"
find_lms(){ if have lms; then echo lms; elif [ -x "$HOME/.lmstudio/bin/lms" ]; then echo "$HOME/.lmstudio/bin/lms"; fi; }
LMS="$(find_lms)"
if [ -z "$LMS" ]; then
  if [ "$OS" = "Darwin" ] && have brew && [ ! -d "/Applications/LM Studio.app" ]; then
    say "Installing LM Studio app"; brew install --cask lm-studio && { open -a "LM Studio"; sleep 20; }
  fi
  LMS="$(find_lms)"
  if [ -z "$LMS" ]; then say "Installing LM Studio engine (llmster)"; curl -fsSL https://lmstudio.ai/install.sh | bash; fi
  LMS="$(find_lms)"
fi
if [ -n "$LMS" ]; then
  "$LMS" bootstrap >/dev/null 2>&1 || true
  [ "$OS" = "Linux" ] && ! "$LMS" server status >/dev/null 2>&1 && ("$LMS" daemon up >/dev/null 2>&1 || true)
  say "Starting LM Studio server on http://localhost:1234"; "$LMS" server start || true
  if [ "$NOMODEL" = 0 ]; then
    read -r -p "Download starter model '$MODEL' (about 4-5 GB)? [Y/n] " a
    case "$a" in n|N) ;; *) "$LMS" get "$MODEL" -y && "$LMS" load "$MODEL" -y --gpu max ;; esac
  fi
else echo "LM Studio isn't ready yet. Open LM Studio once (or get it from https://lmstudio.ai), then run this again."; fi

# ---------- 5. Launchers ----------
say "Making launchers"
printf '#!/usr/bin/env bash\ncd "$(dirname "$0")"\n./.venv/bin/python -m big_tony_builder.harness "$@"\n' > "$HERE/big_tony.sh"
printf '#!/usr/bin/env bash\ncd "$(dirname "$0")"\n./.venv/bin/python -m big_tony_builder.doctor\n' > "$HERE/big_tony_doctor.sh"
chmod +x "$HERE/big_tony.sh" "$HERE/big_tony_doctor.sh"
if [ "$OS" = "Darwin" ]; then cp "$HERE/big_tony.sh" "$HERE/Big Tony.command"; chmod +x "$HERE/Big Tony.command"
elif [ -d "$HOME/.local/share/applications" ] || mkdir -p "$HOME/.local/share/applications"; then
  printf '[Desktop Entry]\nName=Big Tony\nExec=%s\nTerminal=true\nType=Application\n' "$HERE/big_tony.sh" > "$HOME/.local/share/applications/big-tony.desktop"
fi

say "Checking everything"
"$VPY" -m big_tony_builder.doctor
echo; echo "Done. Start Big Tony with ./big_tony.sh (Mac: double-click 'Big Tony.command')."
