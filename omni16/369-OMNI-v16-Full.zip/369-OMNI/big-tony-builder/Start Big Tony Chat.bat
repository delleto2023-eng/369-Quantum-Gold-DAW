@echo off
cd /d "%~dp0"
start "" http://localhost:3080
".venv\Scripts\python.exe" -m big_tony_builder.chat serve
pause
