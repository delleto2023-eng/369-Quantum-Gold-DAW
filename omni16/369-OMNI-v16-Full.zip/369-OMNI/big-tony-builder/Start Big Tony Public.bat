@echo off
cd /d "%~dp0"
set /p ROOT="Cloud folder (e.g. E:\BigTonyCloud): "
".venv\Scripts\python.exe" -m big_tony_builder.cloud serve --root "%ROOT%" --public
pause
