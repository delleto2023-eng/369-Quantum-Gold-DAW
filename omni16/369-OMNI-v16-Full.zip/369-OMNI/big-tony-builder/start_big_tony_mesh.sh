#!/usr/bin/env bash
cd "$(dirname "$0")"
read -r -p "Mesh PIN: " P
./.venv/bin/python -m big_tony_builder.peerium --pin "$P"
