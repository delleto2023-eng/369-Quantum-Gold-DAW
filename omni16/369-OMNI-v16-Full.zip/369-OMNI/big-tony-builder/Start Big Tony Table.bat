@echo off
cd /d "%~dp0"
start "" http://localhost:3690
".venv\Scripts\python.exe" -m big_tony_builder.tabletop serve
pause
