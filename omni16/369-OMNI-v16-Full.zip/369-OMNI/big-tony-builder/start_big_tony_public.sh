#!/usr/bin/env bash
cd "$(dirname "$0")"
read -r -p "Cloud folder (e.g. ~/BigTonyCloud): " R
./.venv/bin/python -m big_tony_builder.cloud serve --root "${R:-$HOME/BigTonyCloud}" --public
