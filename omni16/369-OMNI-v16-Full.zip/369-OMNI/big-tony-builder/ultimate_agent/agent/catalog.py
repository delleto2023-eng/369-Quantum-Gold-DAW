"""9 tool stacks (the 9 of completion). Every agent also gets the skills tools automatically.
Agents are given stacks, not loose tools: upgrade a stack and every agent using it levels up.
"""
STACKS = {
    "files":    ("Read, write, list and delete workspace files", ["list_files", "read_file", "write_file", "delete_file"]),
    "code":     ("Run Python and shell commands, MCP tools, Button Doctor and Run Build", ["run_python", "run_shell", "button_doctor", "run_build", "@mcp"]),
    "web":      ("Fetch and read web pages", ["fetch_url"]),
    "memory":   ("Long-term notes, facts, shared global workspace and the project knowledge graph (Graphify/Obsidian style)",
                 ["remember", "recall", "set_fact", "workspace_post", "workspace_read", "agent_signals",
                  "graph_build", "graph_query", "graph_report", "obsidian_export", "graphify_cli"]),
    "film":     ("Camera moves, shot lists, still-to-shot, grades, assembly, Higgsfield",
                 ["camera_guide", "film_options", "film_prompt", "make_shot_list", "still_to_shot",
                  "film_look", "assemble_sequence", "media_info", "higgsfield_cinema_shot", "higgsfield_check"]),
    "audio":    ("Healing tones, mixing, mastering, conversion", ["tone_generate", "audio_mix", "audio_normalize", "audio_convert", "media_info"]),
    "geometry": ("3-6-9 outlines, sacred geometry art, golden-ratio timing, 3-6-9 vortex math", ["outline_369", "check_outline", "sacred_geometry", "golden_timing", "vortex_369"]),
    "models":   ("Local open-weight models: hardware scan, VRAM fit, MoE offload, llama.cpp server, benchmarks, brain switch",
                 ["hardware_scan", "model_catalog", "model_catalog_add", "model_fit", "llama_server_command", "llama_server_start",
                  "llama_server_status", "llama_server_stop", "model_benchmark", "use_local_brain",
                  "set_plan", "usage_report"]),
    "studio":   ("369 Super DAW Studio tools: Song Forge, Hum to MIDI, Remix, AI Mastering, meters, Sound Packs, Sample Doctor, Shield, BT2 commands",
                 ["forge_song", "hum_to_midi", "remix_song", "master_track", "loudness_meter", "sort_sound_pack", "sample_doctor",
                  "shield_scan", "studio_command"]),
    "collective": ("Big Tony's AI collective and learning brain", ["collective_ask", "collective_members", "collective_toggle",
                   "kb_add_link", "kb_add_text", "kb_refresh", "kb_search", "kb_correct", "kb_export"]),
    "voice":    ("JARVIS mode: speak, listen, live alerts", ["speak", "listen", "alert"]),
    "tony":     ("Tony AI Collective tools: chord progressions, JewelSynth patches, song structure, 24K design tokens",
                 ["chord_progression", "synth_patch", "song_structure", "design_guidelines"]),
    "workflow": ("Workspace routines run locally: inbox, calendar, briefings, user voice, real browser",
                 ["inbox_scan", "calendar_read", "briefing_build", "voice_samples", "voice_profile", "browse_page"]),
    "arcade":   ("Arcade & Creator: fighter sprite sheets, app scaffolds, file conversion", ["sprite_sheet", "app_scaffold", "convert_file"]),
    "omni":     ("369 OMNI: one-voice answers, auto skill + model picking, Council mode", ["omni_answer", "council_run", "model_pick"]),
    "data":     ("Data Brain: offline CSV loading, reports and predictions", ["data_load", "data_predict", "data_report"]),
    "gateway":  ("OMNI gateway: OpenRouter key or Ollama URL", ["gateway_route", "gateway_status"]),
    "publish":  ("Package and document finished work", ["package_zip", "release_notes"]),
}
ALWAYS = ["list_skills", "load_skill"]


def tools_for(stacks, registry):
    names = []
    for s in stacks:
        if s not in STACKS:
            raise ValueError(f"Unknown stack '{s}'. Stacks: {', '.join(STACKS)}")
        for n in STACKS[s][1]:
            names += [m for m in registry.tools if "__" in m] if n == "@mcp" else [n]
    return registry.subset(dict.fromkeys(names + ALWAYS))


def describe():
    return "\n".join(f"{i}. {k}: {v[0]}" for i, (k, v) in enumerate(STACKS.items(), 1))


# ---------------- tool attributes ----------------
SIDE_EFFECTS = {"none", "writes_files", "writes_memory", "runs_code", "network", "spends_money", "changes_brain"}
REQUIREMENTS = {"playwright", "numpy", "voice", "mic", "gh", "graphify", "ffmpeg", "internet", "pillow", "hf_keys", "anthropic_key", "local_server", "mcp"}
STACK_DEFAULTS = {
    "files": {}, "code": {"side_effects": "runs_code", "timeout": 120},
    "web": {"offline": False, "requires": ("internet",), "retries": 2, "timeout": 45, "side_effects": "network"},
    "memory": {"side_effects": "writes_memory"},
    "film": {"requires": ("ffmpeg",), "timeout": 600, "side_effects": "writes_files"},
    "audio": {"requires": ("ffmpeg",), "timeout": 300, "side_effects": "writes_files"},
    "geometry": {}, "models": {}, "publish": {"side_effects": "writes_files"},
}
TOOL_ATTRS = {
    "list_files": {}, "read_file": {}, "write_file": {"side_effects": "writes_files"},
    "delete_file": {"side_effects": "writes_files"}, "recall": {"side_effects": "none"},
    "camera_guide": {"requires": (), "side_effects": "none"}, "film_options": {"requires": (), "side_effects": "none"},
    "film_prompt": {"requires": (), "side_effects": "none"}, "make_shot_list": {"requires": ()},
    "media_info": {"side_effects": "none", "timeout": 60},
    "higgsfield_cinema_shot": {"cost": "paid", "offline": False, "requires": ("internet", "hf_keys"), "retries": 1,
                               "timeout": 90, "side_effects": "spends_money"},
    "higgsfield_check": {"offline": False, "requires": ("internet", "hf_keys"), "retries": 2, "timeout": 45, "side_effects": "network"},
    "outline_369": {"side_effects": "writes_files"}, "check_outline": {},
    "sacred_geometry": {"requires": ("pillow",), "side_effects": "writes_files"},
    "hardware_scan": {"timeout": 30}, "model_catalog_add": {"side_effects": "writes_files"},
    "workspace_read": {"side_effects": "none"}, "agent_signals": {"side_effects": "none"},
    "graph_build": {"side_effects": "writes_files", "timeout": 600}, "graph_query": {"side_effects": "none"},
    "graph_report": {"side_effects": "none"}, "obsidian_export": {"side_effects": "writes_files", "timeout": 300},
    "graphify_cli": {"side_effects": "runs_code", "timeout": 900, "requires": ("graphify",)},
    "set_plan": {"side_effects": "changes_brain"}, "usage_report": {"side_effects": "none"},
    "forge_song": {"requires": ("numpy",), "timeout": 300, "side_effects": "writes_files"},
    "hum_to_midi": {"requires": ("numpy",), "timeout": 300, "side_effects": "writes_files"},
    "sample_doctor": {"requires": ("numpy",), "timeout": 120, "side_effects": "writes_files"},
    "remix_song": {"requires": ("ffmpeg",), "timeout": 900, "side_effects": "writes_files"},
    "master_track": {"requires": ("ffmpeg",), "timeout": 900, "side_effects": "writes_files"},
    "loudness_meter": {"requires": ("ffmpeg",), "timeout": 300, "side_effects": "none"},
    "sort_sound_pack": {"timeout": 600, "side_effects": "writes_files"}, "shield_scan": {"timeout": 600, "side_effects": "writes_files"},
    "studio_command": {"requires": ("numpy",), "timeout": 300, "side_effects": "writes_files"},
    "collective_ask": {"offline": False, "timeout": 180, "side_effects": "network"},
    "collective_members": {"side_effects": "none"}, "collective_toggle": {"side_effects": "writes_files"},
    "kb_add_link": {"offline": False, "requires": ("internet",), "retries": 1, "timeout": 90, "side_effects": "writes_memory"},
    "kb_refresh": {"offline": False, "requires": ("internet",), "timeout": 600, "side_effects": "writes_memory"},
    "kb_add_text": {"side_effects": "writes_memory"}, "kb_correct": {"side_effects": "writes_memory"},
    "kb_search": {"side_effects": "none"}, "kb_export": {"side_effects": "writes_files"},
    "speak": {"requires": ("voice",), "timeout": 300}, "listen": {"requires": ("mic",), "timeout": 60}, "alert": {},
    "button_doctor": {"side_effects": "none", "timeout": 120},
    "run_build": {"requires": ("gh",), "offline": False, "side_effects": "runs_code", "timeout": 180},
    "chord_progression": {"side_effects": "writes_files"}, "synth_patch": {"requires": ("numpy",), "side_effects": "writes_files"},
    "song_structure": {"side_effects": "none"}, "design_guidelines": {"side_effects": "writes_files"},
    "inbox_scan": {"offline": False, "side_effects": "network", "timeout": 60, "retries": 1},
    "calendar_read": {"side_effects": "network", "timeout": 60}, "briefing_build": {"side_effects": "writes_files", "timeout": 120},
    "voice_samples": {"side_effects": "writes_memory"}, "voice_profile": {"side_effects": "none"},
    "browse_page": {"requires": ("playwright", "internet"), "offline": False, "side_effects": "network", "timeout": 90, "retries": 1},
    "sprite_sheet": {"requires": ("pillow",), "side_effects": "writes_files"}, "app_scaffold": {"side_effects": "writes_files"},
    "convert_file": {"side_effects": "writes_files", "timeout": 900},
    "omni_answer": {"side_effects": "none"}, "council_run": {"side_effects": "none", "timeout": 180}, "model_pick": {"side_effects": "none"},
    "data_load": {"side_effects": "none"}, "data_predict": {"side_effects": "none"}, "data_report": {"side_effects": "writes_files"},
    "gateway_route": {"risk": "approve", "side_effects": "writes_files"}, "gateway_status": {"side_effects": "none"},
    "llama_server_command": {}, "llama_server_start": {"side_effects": "runs_code", "timeout": 30},
    "llama_server_status": {"retries": 1, "timeout": 15}, "llama_server_stop": {"side_effects": "runs_code"},
    "model_benchmark": {"requires": ("local_server",), "timeout": 600, "retries": 1},
    "use_local_brain": {"side_effects": "changes_brain"},
}


def apply_tool_attributes(registry):
    stack_of = {n: s for s, (_, names) in STACKS.items() for n in names}
    for name, tool in registry.tools.items():
        attrs = {}
        if "__" in name:
            attrs = {"offline": False, "side_effects": "network", "requires": ("mcp",), "timeout": 120}
        attrs.update(STACK_DEFAULTS.get(stack_of.get(name, ""), {}))
        attrs.update(TOOL_ATTRS.get(name, {}))
        for k, v in attrs.items():
            setattr(tool, k, tuple(v) if k == "requires" else v)
        if tool.cost == "paid":
            tool.risk = "approve"  # behavior: anything that spends money always asks first
    return registry


def requirement_ok(req):
    import os, shutil
    if req == "internet":
        return os.getenv("AGENT_OFFLINE", "0") != "1"
    if req == "ffmpeg":
        if shutil.which("ffmpeg"):
            return True
        try:
            import imageio_ffmpeg; imageio_ffmpeg.get_ffmpeg_exe(); return True
        except Exception:
            return False
    if req == "pillow":
        try:
            import PIL; return True  # noqa
        except Exception:
            return False
    if req == "hf_keys":
        return bool(os.getenv("HF_API_KEY_ID") and os.getenv("HF_API_KEY_SECRET"))
    if req == "anthropic_key":
        return bool(os.getenv("ANTHROPIC_API_KEY"))
    if req == "playwright":
        try:
            import playwright  # noqa
            return True
        except Exception:
            return False
    if req == "numpy":
        try:
            import numpy; return True  # noqa
        except Exception:
            return False
    if req == "voice":
        from .voice import tts_engine
        return tts_engine() is not None
    if req == "mic":
        try:
            import speech_recognition  # noqa
            return True
        except Exception:
            return False
    if req == "gh":
        return bool(shutil.which("gh"))
    if req == "graphify":
        return bool(shutil.which("graphify"))
    if req == "mcp":
        try:
            import mcp; return True  # noqa
        except Exception:
            return False
    return True  # local_server is checked by the tool itself


def missing_requirements(tool):
    return [r for r in tool.requires if not requirement_ok(r)]
