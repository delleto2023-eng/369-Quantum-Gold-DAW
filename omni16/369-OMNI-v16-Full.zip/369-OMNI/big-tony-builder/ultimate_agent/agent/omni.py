"""369 OMNI: the Big Tony Command Center agents answering as one voice.
omni_answer   picks the right skills + best model for a message and answers in one voice
council_run   Council mode: 3 matched skills each write a draft, then the drafts are merged into one answer
model_pick    picks the best model for a task (code, music, data, writing, vision, fast, deep)
gateway_route writes the gateway config (OpenRouter key or Ollama URL) used by OMNI
gateway_status shows which gateway is configured and which model would be used
data_load     Data Brain: load a CSV and describe its columns
data_predict  Data Brain: offline prediction from a CSV (linear trend or x->y regression, no internet)
data_report   Data Brain: min / max / mean / trend for every number column, saved as markdown
"""
import csv, json, os, re, statistics
from pathlib import Path

MODELS = {"code": ("deepseek/deepseek-v4.1-flash", "qwen2.5-coder"), "music": ("anthropic/claude-sonnet", "llama3.1"),
          "data": ("openai/gpt-4o-mini", "llama3.1"), "writing": ("anthropic/claude-opus", "mistral"),
          "vision": ("google/gemini-flash", "llava"), "fast": ("z-ai/glm-5.3-flash", "llama3.2"),
          "deep": ("anthropic/claude-opus", "deepseek-r1")}
WORDS = {"code": "code bug app build script error fix python html js", "music": "beat song mix master 808 chord melody lyrics bpm",
         "data": "csv data predict forecast numbers chart stats", "writing": "write email post story caption reply",
         "vision": "image picture photo sprite video look", "deep": "plan strategy research explain why architecture"}


def pick(task):
    t = task.lower()
    best = max(WORDS, key=lambda k: sum(w in t for w in WORDS[k].split()))
    return best if any(w in t for w in WORDS[best].split()) else "fast"


def _rows(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _num(v):
    try:
        return float(str(v).replace(",", "").replace("$", ""))
    except Exception:
        return None


def _fit(xs, ys):
    mx, my = statistics.mean(xs), statistics.mean(ys)
    den = sum((x - mx) ** 2 for x in xs) or 1e-9
    b = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / den
    a = my - b * mx
    ss = sum((y - my) ** 2 for y in ys) or 1e-9
    r2 = 1 - sum((y - (a + b * x)) ** 2 for x, y in zip(xs, ys)) / ss
    return a, b, r2


def build_omni_tools(reg, guard):
    S, I = {"type": "string"}, {"type": "integer"}

    def gw_file():
        return guard.safe_path("omni/gateway.json")

    def gateway():
        p = gw_file()
        cfg = json.loads(p.read_text()) if p.exists() else {}
        if not cfg.get("openrouter_key") and os.getenv("OPENROUTER_API_KEY"):
            cfg["openrouter_key"] = "env"
        cfg.setdefault("ollama_url", os.getenv("OLLAMA_URL", ""))
        return cfg

    @reg.add("model_pick", "Pick the best model for a task (code, music, data, writing, vision, fast, deep).", {"task": S}, ["task"])
    def model_pick(task):
        kind = pick(task); g = gateway()
        cloud, local = MODELS[kind]
        use = cloud if g.get("openrouter_key") else (local if g.get("ollama_url") else cloud + " (no gateway set yet)")
        return f"Task type: {kind}\nModel: {use}\nCloud pick: {cloud} | Local pick: {local}"

    @reg.add("gateway_route", "Set OMNI's gateway: an OpenRouter key or an Ollama URL.", {"openrouter_key": S, "ollama_url": S}, [])
    def gateway_route(openrouter_key="", ollama_url=""):
        g = gateway()
        if openrouter_key: g["openrouter_key"] = openrouter_key
        if ollama_url: g["ollama_url"] = ollama_url.rstrip("/")
        p = gw_file(); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(g, indent=2))
        return "Gateway saved: " + ", ".join(k for k in ("openrouter_key", "ollama_url") if g.get(k)) or "nothing set"

    @reg.add("gateway_status", "Show which gateway OMNI will use.", {}, [])
    def gateway_status():
        g = gateway()
        return (f"OpenRouter: {'set' if g.get('openrouter_key') else 'not set'}\n"
                f"Ollama: {g.get('ollama_url') or 'not set'}\n"
                + ("Ready." if g.get("openrouter_key") or g.get("ollama_url") else "Add a key or URL with gateway_route (Keys tab)."))

    def drafts_for(question, n=3):
        from .skills import SkillLibrary
        lib = SkillLibrary("skills")
        names = lib.match(question, top=n) or ["general"]
        out = []
        for name in names[:n]:
            sk = lib.get(name) or {}
            steps = [l.strip() for l in str(sk.get("body", "")).splitlines() if re.match(r"\s*\d+\.", l)]
            out.append((name, steps or [f"Handle: {question}"]))
        return out

    def merge(drafts):
        seen, lines = set(), []
        for _, steps in drafts:
            for s in steps:
                k = re.sub(r"^\d+\.\s*", "", s).lower()
                if k not in seen:
                    seen.add(k); lines.append(re.sub(r"^\d+\.\s*", "", s))
        return "\n".join(f"{i}. {l}" for i, l in enumerate(lines, 1))

    @reg.add("council_run", "Council mode: 3 matched skills each write a draft, then OMNI merges them into one answer.", {"question": S}, ["question"])
    def council_run(question):
        d = drafts_for(question, 3)
        body = "\n\n".join(f"Draft from {n}:\n" + "\n".join(s) for n, s in d)
        return f"Council of {len(d)}: {', '.join(n for n, _ in d)}\n\n{body}\n\nOMNI merged answer:\n{merge(d)}"

    @reg.add("omni_answer", "369 OMNI: pick skills + model for a message and answer as one voice (mode auto or council).",
             {"message": S, "mode": S}, ["message"])
    def omni_answer(message, mode="auto"):
        d = drafts_for(message, 3 if mode == "council" else 1)
        return (f"OMNI (one voice of the Big Tony Command Center)\n{model_pick(message)}\n"
                f"Skills: {', '.join(n for n, _ in d)}\nMode: {mode}\n\nPlan:\n{merge(d)}")

    @reg.add("data_load", "Data Brain: load a CSV and describe its columns.", {"path": S}, ["path"])
    def data_load(path):
        rows = _rows(guard.safe_path(path))
        if not rows: return "Empty CSV."
        cols = []
        for c in rows[0]:
            nums = [v for v in (_num(r[c]) for r in rows) if v is not None]
            cols.append(f"- {c}: {'number' if len(nums) >= len(rows) * 0.8 else 'text'}")
        return f"{len(rows)} rows, {len(rows[0])} columns\n" + "\n".join(cols)

    @reg.add("data_predict", "Data Brain: offline prediction from a CSV. Give y column, and either x column + x value, or steps ahead for a trend.",
             {"path": S, "y": S, "x": S, "x_value": {"type": "number"}, "steps": I}, ["path", "y"])
    def data_predict(path, y, x="", x_value=None, steps=3):
        rows = _rows(guard.safe_path(path))
        pts = [(_num(r[x]) if x else float(i), _num(r[y])) for i, r in enumerate(rows)]
        pts = [(a, b) for a, b in pts if a is not None and b is not None]
        if len(pts) < 3: return "Need at least 3 rows with numbers."
        a, b, r2 = _fit(*zip(*pts))
        conf = "strong" if r2 > 0.8 else "moderate" if r2 > 0.5 else "weak"
        if x and x_value is not None:
            return f"Predicted {y} at {x}={x_value:g}: {a + b * x_value:.2f}\nFit: {y} = {a:.3f} + {b:.3f}*{x} (R2 {r2:.2f}, {conf})"
        n = len(pts)
        fut = [f"row {n + k}: {a + b * (n - 1 + k):.2f}" for k in range(1, int(steps) + 1)]
        return f"Trend for {y}: {'+' if b >= 0 else ''}{b:.3f} per row (R2 {r2:.2f}, {conf})\nNext {steps}:\n" + "\n".join(fut)

    @reg.add("data_report", "Data Brain: min, max, mean and trend for every number column, saved as markdown.", {"path": S}, ["path"])
    def data_report(path):
        rows = _rows(guard.safe_path(path)); out = [f"# Data Brain report: {path}", ""]
        for c in rows[0]:
            v = [n for n in (_num(r[c]) for r in rows) if n is not None]
            if len(v) >= 3:
                _, b, _ = _fit(list(map(float, range(len(v)))), v)
                out.append(f"- {c}: min {min(v):g}, max {max(v):g}, mean {statistics.mean(v):.2f}, trend {'up' if b > 0 else 'down' if b < 0 else 'flat'}")
        p = guard.safe_path("data/" + Path(path).stem + "_report.md"); p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("\n".join(out)); return "\n".join(out) + f"\nSaved: data/{p.name}"
