@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" -c "from big_tony_builder import images; images.gradio(profile='auto')"
pause
