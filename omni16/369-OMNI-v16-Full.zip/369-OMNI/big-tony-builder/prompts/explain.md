---
description: explain
---
Explain $ARGUMENTS in plain words, short and casual, with the file paths involved.
