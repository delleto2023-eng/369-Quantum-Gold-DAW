---
description: fix
---
Use the debug skill to find and fix: $ARGUMENTS. Add a regression test.
