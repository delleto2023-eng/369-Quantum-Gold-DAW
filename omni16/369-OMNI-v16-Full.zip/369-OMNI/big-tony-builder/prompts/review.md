---
description: review
---
Review the current changes for bugs and simplicity. Use the review skill. Focus: $ARGUMENTS
