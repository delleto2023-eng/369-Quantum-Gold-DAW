---
description: ship
---
Run tests and lints, fix what fails, then build the desktop ZIP and single HTML for: $ARGUMENTS
