@echo off
cd /d "%~dp0"
echo Installing Big Tony Builder (Python, FFmpeg, LM Studio)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_big_tony.ps1" %*
