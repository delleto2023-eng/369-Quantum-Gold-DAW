# BIG TONY BUILDER v16.0.0
Every real tool from Filmora's AI video editing page and its sale page, plus the AI All-Access, Privacy+,
AI Builder and AI Receptionist features you pasted. All rebuilt as your own code, all unlocked.
No pricing, credits, plans, conversation caps or watermarks anywhere.

## Install
1. Install Python 3.10+ and FFmpeg (Windows: `winget install Gyan.FFmpeg`, Mac: `brew install ffmpeg`, Linux: `apt install ffmpeg`).
2. Run install.bat (Windows) or install.sh (Mac/Linux). It installs numpy, cryptography and the optional AI extras.
3. Optional API keys for AI features (set as environment variables): OPENAI_API_KEY, ANTHROPIC_API_KEY, GEMINI_API_KEY, XAI_API_KEY,
   or LOCAL_LLM_URL / LOCAL_LLM_MODEL for a private local model (Ollama, LM Studio).

## Plug into 369 OMNI
Copy the `big_tony_builder` folder next to the OMNI agent, copy `skills/*` into OMNI's skills folder, then in the agent startup:
    import big_tony_builder
    big_tony_builder.register(agent, llm_fn=agent.ask_models)   # llm_fn optional
`big_tony_builder._schemas()` returns JSON tool schemas for function-calling.

## Use from the command line
    python -m big_tony_builder list
    python -m big_tony_builder auto_reframe video=clip.mp4 ratio=9:16
    python -m big_tony_builder smart_short_clips video=long.mp4 count=3

## What runs where
Fully offline (FFmpeg/Python): reframe, camera/motion tracking, 360 reframe, scene cut, short clips, enhancer/4K upscale, denoise, color palette,
color mask, LUTs, portrait, object removal, green screen, effects, 40 transitions, titles, keyframes, speed ramps, stabilization, split screen,
beat sync, silence removal, audio stretch, voice enhancer, sound effects, music generator, audio visualizer, dynamic subtitles, caption fixing,
media analysis, thumbnails, export (4K, ProRes, HEVC, WebM, GIF, MP3, WAV), multi-source recording, asset library, encryption, PIN vault,
privacy sanitizer, website builder with forms/bookings/accounts/admin panel.
Uses your AI models when connected (falls back to offline versions where possible): text/idea to video scripts, copywriting, AI Mate answers,
speech-to-text (or install faster-whisper), multi-model compare, research agent, article writer, presentation builder, app builder,
receptionist. True generative video, voice cloning and lip re-animation need a connected model (hook: gen_video_fn); offline they use
the closest local method and say so.

## New in v2 (Filmora full feature list)
Prompt Video Editing, AI Text-Based Editing, Instant Mode, Instant Cutter, Social Content Planner (.ics calendar), AI Smart Search,
AI Relight, AI Frame Interpolation, AI Eye Contact (model hook), AI Image Enhancer, AI Beauty Filter, AI Face Mosaic, Lens Correction,
Motion Blur, Video Mask / Pen Tool / Smart Masking, Adjustment Layer / Multi-Clip Editing, Image Sequence to Video, Animated Charts,
Text Path, Music Beat Text Animation, Video Chapters, Subtitle Extractor, Preset Templates, Image to Prompt, AI Sticker Generator,
AI Video Translator, Text-to-Sound-Effect, Smart BGM, AI Audio Extender, Voice Changer (13 voices incl. Big Tony), Audio Adjustment,
Auto Synchronization, Video Compressor, Auto Resize for every platform, Keyboard Shortcut Presets (Premiere/FCP/CapCut/FL Studio),
Assets Backup & Sync (encrypted option), Dual-Monitor Preview. Optional: pip install matplotlib pillow opencv-python for charts, pen masks, face detection.

## New in v3: Big Tony Vault
Our own asset library replacing Filmora's stock assets and licensed music: 16 music genres x 10 moods, 30 SFX types, 36 LUT looks, 20 sticker shapes x 7 jewel palettes, 12 motion backgrounds, 6 overlays, 120 title and 60 caption templates. Seed-based, so it can generate millions of distinct assets.

## New in v4: Big Tony Cloud
Two 300 GB storage stacks on any drive you own, hard quotas, PIN login, optional encryption, reserved space, share links, folder sync and a gold web UI (port 3691, phone works on the same Wi-Fi). Double-click 'Start Big Tony Cloud.bat'.

## New in v5: Big Tony Cloud tab for 369 OMNI
omni-cloud-tab/big-tony-cloud-tab.js adds a BIG TONY CLOUD tab with bling, sun rays and crystal-diamond clicks. See omni-cloud-tab/README.txt.

## New in v6: every skill and behavior
- skills/ultimate-agent: all 45 playbooks from the 369 Ultimate Agent
- skills/tools: one skill for every Big Tony Builder tool
- skills/big-tony-*: grouped skills
- BEHAVIORS.md: every behavior (51 Ultimate Agent agents, 369 OMNI UI, Big Tony Builder rules)
- ultimate_agent/: the full 369 Ultimate Agent v12 bundled (python ultimate_agent/main.py)
- big_tony_builder.skills: match(), brief(), catalog(), system_prompt() so Big Tony auto-picks skills

## New in v7: Pi harness, Pi skills, Cursor tools
- big_tony_builder/harness.py: Pi-style agent harness. Run: python -m big_tony_builder.harness  (or -p "task", --mode json, --mode rpc)
  core tools read/write/edit/bash/grep/find/ls, AGENTS.md + SYSTEM.md, on-demand skills (/skill:name), prompt templates (/name),
  tree sessions (/tree, /branch, /label, /export), auto compaction, steering + follow-ups, 11 providers (OpenAI, Claude, Gemini, Grok,
  Groq, Mistral, OpenRouter, DeepSeek, Cerebras, Ollama, LM Studio), /model switching, extensions (.bigtony/extensions/*.py)
- big_tony_builder/cursor_tools.py: list_dir, file_search, grep_search, codebase_search, read_file (images too), edit_file,
  delete_file, run_terminal_cmd (auto-review / allowlist / run-everything), web_search, web_fetch, fetch_rules (.cursor/rules),
  browser, generate_image, ask_question, todo_write, read_lints, explore subagent
- big_tony_builder/pi_skills.py: brave_search, browser_tools, gccli, gdcli, gmcli, transcribe, vscode, youtube_transcript
- skills/pi-skills, skills/pi-workflow (plan, build, review, debug, investigate-bug, git-ops, scaffold, spike, grill, branch-hygiene, gardening),
  skills/cursor, skills/harness; prompts/ (review, fix, ship, explain)

### Also in v7: Cursor editing tools + LM Studio engine
- Editing: multi_edit, insert_lines, replace_lines, apply_patch, rename_symbol, move_file, inline_edit (Cmd+K), smart_apply/reapply,
  tab_complete, edit_notebook, checkpoint, list_checkpoints, restore_checkpoint/undo, review_changes (every edit is checkpointed)
- big_tony_builder/lmstudio.py: status, list/load/unload/download models (lms CLI), start_server, chat (tools + JSON schema), stream,
  complete, embed, ask. The harness picks LM Studio automatically when its server is running. Set LMSTUDIO_URL to use another PC.

## New in v8: one-click install of Python and LM Studio
- Windows: double-click "Install Big Tony.bat"
- Mac: double-click "Install Big Tony.command" (right-click > Open the first time)
- Linux: ./install_big_tony.sh
Each one: installs Python 3.12 if missing (winget / python.org / brew / apt-dnf-pacman), FFmpeg, makes a private .venv and installs
requirements.txt, installs LM Studio (desktop app via winget/brew, or the headless llmster engine from lmstudio.ai), sets up the lms
command, starts the server on http://localhost:1234, offers to download + load a starter model (qwen2.5-coder-7b-instruct, ~4-5 GB),
makes a "Big Tony" launcher/desktop shortcut, then runs the Doctor.
Options: --no-model, --model NAME, --full (adds whisper, OpenCV, Playwright browser etc.)  [PowerShell: -NoModel -Model NAME -Full]
Doctor: python -m big_tony_builder.doctor  (add --fix to start the LM Studio server)

## New in v9: Big Tony Table (Google Tabletop-style group space)
Start Big Tony Table.bat / start_big_tony_table.sh -> http://localhost:3690. Create a space, share the invite link, everyone edits live.
@tony builds polls, itineraries, expense splitter (who-owes-who), brackets with byes, drag-and-drop seating, chore points game, spinner wheel,
checklists/rosters/sign-ups, notes and Pong -> Pickle Pong with a live scoreboard; change any tool in plain words. 9 starter templates.
Others join from your Wi-Fi at http://<your-PC-IP>:3690/s/<space>; for people outside your network, publish through Big Tony Cloud or a tunnel.

## New in v10: Table on Cloud + public links, and Big Tony Voice (Gladia)
- Big Tony Cloud now hosts Big Tony Table at /table/ (spaces saved in your cloud folder). Guests join by invite link; only you make new spaces.
- Public links: --public on cloud or tabletop opens a free https link (Cloudflare quick tunnel, falls back to localhost.run). Start Big Tony Public.bat / start_big_tony_public.sh
- big_tony_builder/gladia.py: Gladia speech-to-text for files, URLs and YouTube (speakers, translation, summary, sentiment, entities, chapters,
  subtitles, PII redaction, custom vocabulary, audio-to-LLM), live mic, insights with Claude / LM Studio, offline faster-whisper fallback.

## New in v11: Big Tony Chat (LibreChat-style, self-hosted)
Start Big Tony Chat.bat / start_big_tony_chat.sh -> http://localhost:3080 (add --public for a link anyone can open).
11 providers + custom OpenAI-compatible endpoints, switch mid-chat; Agent Builder + 8 built-in agents + import/export/share; MCP servers;
code interpreter; web search; artifacts (HTML, React, Mermaid); image generation; chat with files (RAG, LM Studio embeddings when loaded);
mic + read aloud; conversation search, fork, regenerate, export, share links; multi-user email/password login; admin panel.

## New in v12: video ads, reverse engineering, anti-slop web design, local voice studio, OpenCode
- frames.py (HyperFrames-style): HTML compositions -> MP4 (Playwright + FFmpeg), browser-free scene renderer, make_ad (storyboard + voiceover + render), catalog blocks, lint
- rea.py (REA-style): JS/Electron/.asar, websites, HAR -> API map + generated client, PE/ELF/APK/model/SQLite, strings, rizin/objdump handoff, study_feature with evidence
- design.py (Hallmark-style): 12 themes, job-first page builder, sloplint (floor/reflex/finish), audit, content-safe redesign, 8-width screenshots
- voice.py (VoiceStudio-style): speak, design voices, clone with consent, dub videos, dictation, audiobooks (M4B chapters), multi-voice stories; Kokoro/Piper/XTTS/F5/espeak/OS engines
- opencode.py: opencode.json (LM Studio, Ollama, NVIDIA free models), every skill exported, AGENTS.md, Big Tony MCP server for OpenCode/Claude Code/Cursor
- Big Tony Chat: 4 new agents (Video Ad Maker, Reverse Engineer, Web Designer, Voice Studio); harness + chat gain the NVIDIA provider

## New in v13: Big Tony gets a body (Brahma SOL-style)
- Start Big Tony Companion.bat: a 3D-look golden Big Tony that lives on your desktop, roams, blinks, lip-syncs, talks (offline voice), listens, and acts
- desktop.py: Windows automation + workspace awareness (active window, apps, clipboard, screen reading via LM Studio vision model or OCR)
- forge.py: Skill Forge (describe -> code -> safety check -> test -> auto-fix -> install) and Ultron Protocol (error analysis + safe recovery + incident log)
- Big Tony Chat: Desktop Pilot agent. Everything runs local-first on LM Studio / Ollama; MCP via the Big Tony MCP server.

## New in v14: Big Tony Image Studio (MOSS-Image, free + local)
images.py: MOSS-Image Base/SFT on NVIDIA, Apple Silicon or CPU with low-memory modes for 16 GB Macs; ComfyUI and stable-diffusion.cpp backends;
JSON layout control for exact text placement (poster helper); prompt enhancer; hard-test suite; speed benchmark; blind A/B comparison page;
official Gradio launcher. Image Studio agent in Big Tony Chat.

## New in v15: Big Tony Peerium mesh (no boss machine)
peerium.py: peer-to-peer mesh over your Wi-Fi with PIN-signed requests, unified global memory (hash ring + replica, RAM->disk tiers),
best-machine routing (GPU/model/FFmpeg/RAM/load), work stealing, Nested BSP supersteps, map across peers, peer swarm voting, shared answer cache.
Start Big Tony Mesh.bat on each computer. Peer Mesh agent in Big Tony Chat.

## New in v16: streaming + Google/GitHub sign-in, sealed sandbox, self-test, Instant-On
- Big Tony Chat: replies stream word by word (tool steps live); Continue with Google / GitHub (Admin > Sign-in providers)
- sandbox.py: sealed Docker code runner (no network, read-only, memory/CPU/process caps, non-root); Chat uses it automatically
- selftest.py: Big Tony Self-Test.bat checks every part on your PC and writes an HTML/JSON report with fixes
- instant.py (inspired by Tohoku/AISIN's no-RAM MRAM chip): memory-mapped persistent memory, snapshots + instant resume, keep-warm models,
  first-answer timing, boot profiler, offline Tiny YOLOv3 object detection (images/webcam). Instant Vision agent.
