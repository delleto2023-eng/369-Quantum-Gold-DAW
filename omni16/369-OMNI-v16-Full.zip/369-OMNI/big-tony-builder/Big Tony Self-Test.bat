@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" -m big_tony_builder.selftest
pause
