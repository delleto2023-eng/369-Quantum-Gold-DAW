# Big Tony Builder - one-click setup for Windows
# Installs Python 3.12, FFmpeg, LM Studio (+ lms CLI), creates a private Python environment,
# installs Big Tony's packages, starts the LM Studio server and makes a desktop shortcut.
param([switch]$NoModel, [string]$Model = "qwen2.5-coder-7b-instruct", [switch]$Full)
$ErrorActionPreference = "Continue"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Here
function Say($t) { Write-Host "`n== $t" -ForegroundColor Yellow }
function Refresh-Path { $env:Path = [Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [Environment]::GetEnvironmentVariable("Path","User") }
function Have($c) { return [bool](Get-Command $c -ErrorAction SilentlyContinue) }
$HasWinget = Have "winget"
$WG = @("--silent","--accept-package-agreements","--accept-source-agreements","-e")

# ---------- 1. Python ----------
Say "Checking Python"
function Find-Python {
  foreach ($c in @("py -3.12","py -3","python")) {
    try { $v = & cmd /c "$c --version 2>&1"; if ($v -match "Python 3\.(1[0-9])") { return $c } } catch {}
  }
  foreach ($p in @("$env:LOCALAPPDATA\Programs\Python\Python312\python.exe","$env:ProgramFiles\Python312\python.exe")) { if (Test-Path $p) { return "`"$p`"" } }
  return $null
}
$Py = Find-Python
if (-not $Py) {
  Say "Installing Python 3.12"
  if ($HasWinget) { winget install --id Python.Python.3.12 @WG }
  Refresh-Path; $Py = Find-Python
  if (-not $Py) {
    $exe = "$env:TEMP\python-3.12.10-amd64.exe"
    Invoke-WebRequest "https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe" -OutFile $exe
    Start-Process $exe -ArgumentList "/quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_pip=1" -Wait
    Refresh-Path; $Py = Find-Python
  }
}
if (-not $Py) { Write-Host "Python could not be installed. Get it from https://www.python.org/downloads/ and run this again." -ForegroundColor Red; pause; exit 1 }
Write-Host "Python: $(cmd /c "$Py --version")"

# ---------- 2. FFmpeg (video + audio tools) ----------
Say "Checking FFmpeg"
if (-not (Have "ffmpeg")) {
  if ($HasWinget) { winget install --id Gyan.FFmpeg @WG; Refresh-Path }
  if (-not (Have "ffmpeg")) { Write-Host "FFmpeg not installed system-wide; Big Tony will use the bundled imageio-ffmpeg copy instead." }
}

# ---------- 3. Private Python environment + packages ----------
Say "Setting up Big Tony's Python environment"
if (-not (Test-Path "$Here\.venv\Scripts\python.exe")) { cmd /c "$Py -m venv `"$Here\.venv`"" }
$VPy = "$Here\.venv\Scripts\python.exe"
& $VPy -m pip install --upgrade pip
& $VPy -m pip install -r "$Here\requirements.txt"
if ($Full) { & $VPy -m pip install -r "$Here\requirements-optional.txt"; & $VPy -m playwright install chromium }

# ---------- 4. LM Studio ----------
Say "Checking LM Studio"
$LmsPaths = @("$env:USERPROFILE\.lmstudio\bin\lms.exe", "$env:LOCALAPPDATA\Programs\LM Studio\resources\app\.webpack\lms.exe")
function Find-Lms { if (Have "lms") { return "lms" }; foreach ($p in $LmsPaths) { if (Test-Path $p) { return $p } }; return $null }
$AppExe = "$env:LOCALAPPDATA\Programs\LM Studio\LM Studio.exe"
if (-not (Test-Path $AppExe) -and -not (Find-Lms)) {
  Say "Installing LM Studio"
  if ($HasWinget) { winget install --id ElementLabs.LMStudio @WG }
  if (-not (Test-Path $AppExe)) {
    Write-Host "Installing LM Studio's headless engine (llmster) instead"
    try { Invoke-Expression (Invoke-RestMethod "https://lmstudio.ai/install.ps1") } catch { Write-Host "LM Studio download failed: $_" -ForegroundColor Red }
  }
}
if ((Test-Path $AppExe) -and -not (Test-Path "$env:USERPROFILE\.lmstudio")) {
  Write-Host "Opening LM Studio once so it can finish setting itself up..."
  Start-Process $AppExe; Start-Sleep -Seconds 20
}
$Lms = Find-Lms
if ($Lms) {
  & $Lms bootstrap 2>$null
  Refresh-Path
  Say "Starting LM Studio server on http://localhost:1234"
  & $Lms server start
  if (-not $NoModel) {
    $ans = Read-Host "Download starter model '$Model' (about 4-5 GB)? [Y/n]"
    if ($ans -ne "n" -and $ans -ne "N") { & $Lms get $Model -y; & $Lms load $Model -y --gpu max }
  }
} else { Write-Host "LM Studio installed but the lms command isn't ready yet. Open LM Studio once, then run this setup again." -ForegroundColor Yellow }

# ---------- 5. Shortcuts ----------
Say "Making shortcuts"
$Run = "$Here\Big Tony.bat"
Set-Content $Run "@echo off`r`ncd /d `"%~dp0`"`r`n`".venv\Scripts\python.exe`" -m big_tony_builder.harness %*`r`npause" -Encoding ASCII
$Doc = "$Here\Big Tony Doctor.bat"
Set-Content $Doc "@echo off`r`ncd /d `"%~dp0`"`r`n`".venv\Scripts\python.exe`" -m big_tony_builder.doctor`r`npause" -Encoding ASCII
try {
  $s = (New-Object -ComObject WScript.Shell).CreateShortcut("$([Environment]::GetFolderPath('Desktop'))\Big Tony.lnk")
  $s.TargetPath = $Run; $s.WorkingDirectory = $Here; $s.Save()
} catch {}

Say "Checking everything"
& $VPy -m big_tony_builder.doctor
Write-Host "`nDone. Double-click 'Big Tony' on your desktop to start." -ForegroundColor Green
pause
