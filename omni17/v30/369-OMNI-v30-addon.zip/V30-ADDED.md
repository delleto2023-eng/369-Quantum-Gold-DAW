# v30 Medium Topics
225 skills. Unzip over v29 369-OMNI-Desktop.
