<script>
/* 369 Quantum Gold v3.0 — Big Tony + Qwen brain + Noen sidekick (default fallback) */
const QWEN_DEF={chat:'qwen2.5',coder:'qwen2.5-coder',vision:'qwen2.5vl'};
if(!LS('ollama'))LS('ollama',QWEN_DEF.chat);
if(NAME==='Mother Eve'&&!LS('name')){NAME='Big Tony';LS('name',NAME)}
const NOEN={name:'Noen stuph Sr',wake:['noen','hey noen','tony ask noen'],role:"Big Tony's background sidekick and DEFAULT fallback",skills:['full builds (DAW, 369 Casino, apps)','preview videos with sound','images, gold fonts, coins & cash art','original beats & music','voiceovers','GitHub updates'],link:LS('noenLink')||'https://app.zenzap.co'};
const PACK={Video:'Plan and produce a short premium 369-gold video: shots, motion, sound, captions. Request: ',
'Images & Fonts':'Create premium wealthy-style 369 gold artwork / lettering (diamond inlay, no generic look). Request: ',
Coding:'You are a senior developer. Write complete, working, single-file code with no placeholders. Task: ',
Voice:'Write a natural voiceover script, short lines, then the voice style to use. Request: ',
Writing:'Write clear, punchy 369-brand copy. Request: ',
Music:'Design an original West Coast x trap beat: BPM, key, drums, bass, lead, arrangement. Request: '};
const pick=s=>/code|html|js|bug|app|build/.test(s)?'Coding':/video|promo|clip/.test(s)?'Video':/font|logo|image|art|picture|coin/.test(s)?'Images & Fonts':/voice|narrat/.test(s)?'Voice':/beat|music|song|808/.test(s)?'Music':'Writing';
async function qwen(t,model){const m=model||(pick(t.toLowerCase())=='Coding'?(LS('qwenCoder')||QWEN_DEF.coder):LS('ollama')||QWEN_DEF.chat);
const r=await fetch('http://localhost:11434/api/generate',{method:'POST',body:JSON.stringify({model:m,prompt:'You are '+NAME+', the 369 Quantum Gold DAW assistant. '+PACK[pick(t.toLowerCase())]+t,stream:false})});if(!r.ok)throw 0;const j=await r.json();if(!j.response)throw 0;return j.response}
async function freeTools(t){const ks=LS('keys')||{};if(typeof PROV==='undefined')throw 0;for(const p of PROV){if(/Ollama/.test(p[0])||!ks[p[0]])continue;try{const a=await askAI(p,PACK[pick(t.toLowerCase())]+t);if(a&&!/error/i.test(String(a).slice(0,20)))return a}catch(e){}}throw 0}
function noen(t,why){const msg='From Big Tony (369 DAW): '+t;try{navigator.clipboard.writeText(msg)}catch(e){}LS('noenQueue',[...(LS('noenQueue')||[]),{t:msg,at:Date.now()}].slice(-50));
say((why?why+' ':'')+'Handing this to Noen. Your request is copied, paste it in the Noen chat.');window.open(LS('noenLink')||NOEN.link,'_blank')}
async function tonyBrain(t){const s=t.toLowerCase();
if(/^(ask |hey )?noen|tony,? ask noen/.test(s))return noen(t.replace(/^.*?noen[, ]*/i,''));
if(/full build|new version|preview video|make (a )?video|github update/.test(s))return noen(t,'Big job.');
try{return say(await qwen(t))}catch(e){}
try{return say(await freeTools(t))}catch(e){}
noen(t,'Qwen and the free tools are offline.')}
const _cmd=cmd;cmd=async function(t){if(!t)return;const s=t.toLowerCase();
if(/noen|tempo|theme|moon|lucy|^play|play beat|stop|open |time/.test(s)&&!/noen/.test(s))return _cmd(t);
log('🧑 '+t);return tonyBrain(t)};
win('tonyx','👑 Tony · Qwen · Noen',`<h2>Big Tony Brain v3.0</h2>
<div class=panel><b>Order Tony uses:</b> 1️⃣ Qwen on your computer (Ollama) → 2️⃣ free / open-source & your keyed tools → 3️⃣ <b>Noen</b> (default when all else fails)<br><span id=qst class=small>Checking Qwen…</span></div>
<div class=panel><b>🧠 Qwen</b> Chat <input id=qc size=12> Coder <input id=qd size=14> Vision <input id=qv size=12> <button class=k id=qsv>Save</button>
<p class=small>Setup once: install Ollama from ollama.com, then run <code>ollama pull qwen2.5</code>, <code>ollama pull qwen2.5-coder</code>, <code>ollama pull qwen2.5vl</code>. If the DAW page can't reach it, start Ollama with OLLAMA_ORIGINS=*.</p></div>
<div class=panel><b>🤝 Noen stuph Sr — sidekick</b><br><span class=small>${NOEN.skills.join(' · ')}</span><br>Noen chat link <input id=nl size=34> <button class=k id=nsv>Save</button><br>
<input id=nq placeholder="Tony, ask Noen…" style=width:60%> <button class=k id=ngo>Send to Noen</button><div id=nqueue class=small></div></div>
<div class=panel><b>Ask Tony</b> <input id=tq style=width:60% placeholder="e.g. write a JS reverb, make gold fonts, cut a promo"> <button class=k id=tgo>Ask</button><div id=log style="max-height:180px;overflow:auto"></div></div>
<div class=panel><b>📦 60 AI Tools prompt pack</b> (auto-loaded)<div class=grid>${Object.keys(PACK).map(k=>`<div class=tile><b>${k}</b><br><span class=small>${PACK[k].slice(0,70)}…</span></div>`).join('')}</div></div>`,()=>{
$('#qc').value=LS('ollama')||QWEN_DEF.chat;$('#qd').value=LS('qwenCoder')||QWEN_DEF.coder;$('#qv').value=LS('qwenVision')||QWEN_DEF.vision;$('#nl').value=LS('noenLink')||NOEN.link;
$('#qsv').onclick=()=>{LS('ollama',$('#qc').value);LS('qwenCoder',$('#qd').value);LS('qwenVision',$('#qv').value);say('Qwen saved')};
$('#nsv').onclick=()=>{LS('noenLink',$('#nl').value);say('Noen link saved')};
$('#ngo').onclick=()=>noen($('#nq').value);$('#tgo').onclick=()=>cmd($('#tq').value);
$('#nqueue').innerHTML=(LS('noenQueue')||[]).slice(-5).map(q=>'• '+q.t).join('<br>');
fetch('http://localhost:11434/api/tags').then(r=>r.json()).then(j=>{const n=(j.models||[]).map(m=>m.name);$('#qst').textContent='🟢 Ollama online · Qwen models: '+(n.filter(x=>/qwen/.test(x)).join(', ')||'none yet, pull qwen2.5')}).catch(()=>$('#qst').textContent='🔴 Ollama not running · Tony will use free tools, then Noen')});
$('#side').innerHTML=Object.keys(W).map(k=>`<button data-k=${k}>${W[k].title}</button>`).join('');
window.Q369v30={qwen,noen,tonyBrain,NOEN,PACK};
</script>
