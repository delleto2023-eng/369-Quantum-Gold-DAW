import sys,re,urllib.request,json
def feed(x):
    u="https://medium.com/feed/"+(x if x.startswith(("@","tag/")) else "tag/"+x)
    r=urllib.request.urlopen(urllib.request.Request(u,headers={"User-Agent":"369"}),timeout=20).read().decode()
    return [{"title":t,"link":l} for t,l in re.findall(r"<item><title><!\[CDATA\[(.*?)\]\]></title><link>(.*?)</link>",r)]
if __name__=="__main__":
    for x in sys.argv[1:] or ["technology"]:
        print("#",x); [print("-",i["title"],i["link"]) for i in feed(x)]
