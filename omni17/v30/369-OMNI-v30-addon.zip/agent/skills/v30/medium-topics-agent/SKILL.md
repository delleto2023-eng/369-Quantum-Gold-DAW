---
name: medium-topics-agent
description: 369 Medium Topics orchestrator: routes any question to the right Medium topic skill, runs the topic feed reader, follows writers/publications.
group: Medium Topics (v30)
---
# 369 Medium Topics Agent
Follows: Jose Crespo, PhD, Data Science Collective, Josh Dubowsky, Level Up Coding, Thomas Oppong
Tools: tools/medium_reader.py (RSS reader for any tag, writer @user or publication), technology archive https://medium.com/tag/technology/archive
