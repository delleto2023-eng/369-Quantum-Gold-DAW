---
name: medium-story-07
description: 369 premium clone skill of Medium story: Coefficient of Variation: mouse vs elephant
group: Medium Topics (v30) / Featured Stories
---
# Coefficient of Variation: mouse vs elephant
Premium 369 clone: the agent recreates this story's core idea as a working skill: explain it, apply it to the 369 build, generate a checklist and an implementation plan, and research the original via Medium.
