---
name: medium-story-11
description: 369 premium clone skill of Medium story: Indian Tech Cutting Jobs and Can't Hire
group: Medium Topics (v30) / Featured Stories
---
# Indian Tech Cutting Jobs and Can't Hire
Premium 369 clone: the agent recreates this story's core idea as a working skill: explain it, apply it to the 369 build, generate a checklist and an implementation plan, and research the original via Medium.
