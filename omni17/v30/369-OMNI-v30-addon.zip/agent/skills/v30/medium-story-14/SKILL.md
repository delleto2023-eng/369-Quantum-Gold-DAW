---
name: medium-story-14
description: 369 premium clone skill of Medium story: Turn Reddit into Your LLM Citation Engine in 2026
group: Medium Topics (v30) / Featured Stories
---
# Turn Reddit into Your LLM Citation Engine in 2026
Premium 369 clone: the agent recreates this story's core idea as a working skill: explain it, apply it to the 369 build, generate a checklist and an implementation plan, and research the original via Medium.
