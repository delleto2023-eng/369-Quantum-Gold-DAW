---
name: medium-story-08
description: 369 premium clone skill of Medium story: Spec-Driven Development vs Spec-Driven Delivery
group: Medium Topics (v30) / Featured Stories
---
# Spec-Driven Development vs Spec-Driven Delivery
Premium 369 clone: the agent recreates this story's core idea as a working skill: explain it, apply it to the 369 build, generate a checklist and an implementation plan, and research the original via Medium.
