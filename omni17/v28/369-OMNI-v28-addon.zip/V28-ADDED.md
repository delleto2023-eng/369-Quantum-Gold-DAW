# 369 OMNI v28 add-on: Towards AI (https://towardsai.com/)
Lay this folder over 369-OMNI-Desktop (v27).
- agent/skills/v28: 38 skills + skills.json (group "Towards AI (v28)")
- app/tonebench.html: ToneBench writing benchmark (blind 4-judge Elo + cost per script)
- tools/receipt_pipeline.py: receipt PDFs -> job cost CSV + audit totals
- tools/tender_scout.py: tender scanning, ranking, win-rate, daily report
- towardsai-source.html: full saved homepage
- 369 Run ToneBench.bat
