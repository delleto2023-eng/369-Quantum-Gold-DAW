"""369 Receipt-to-Job-Cost pipeline. Usage: python receipt_pipeline.py receipts_folder out.csv
pip install pdfplumber requests. Set OPENROUTER_API_KEY, or OLLAMA=1 for local."""
import sys,os,json,glob,csv,requests
def llm(p):
    if os.getenv("OLLAMA"): u,h,m="http://localhost:11434/v1/chat/completions",{},"qwen2.5"
    else: u,h,m="https://openrouter.ai/api/v1/chat/completions",{"Authorization":"Bearer "+os.environ["OPENROUTER_API_KEY"]},"openai/gpt-4o-mini"
    return requests.post(u,headers=h,json={"model":m,"messages":[{"role":"user","content":p}]}).json()["choices"][0]["message"]["content"]
if __name__=="__main__":
    import pdfplumber
    rows=[]
    for f in glob.glob(os.path.join(sys.argv[1],"*.pdf")):
        t="\n".join((pg.extract_text() or "") for pg in pdfplumber.open(f).pages)
        j=llm('Return only JSON {"job":"","date":"","vendor":"","items":[{"material":"","qty":0,"cost":0}]} from this receipt:\n'+t)
        try: d=json.loads(j[j.find("{"):j.rfind("}")+1])
        except Exception: d={"job":"UNREAD","items":[]}
        for it in d.get("items",[]): rows.append([f,d.get("job"),d.get("date"),d.get("vendor"),it.get("material"),it.get("qty"),it.get("cost")])
    w=csv.writer(open(sys.argv[2],"w",newline="")); w.writerow(["file","job","date","vendor","material","qty","cost"]); w.writerows(rows)
    tot={}
    for r in rows: tot[r[1]]=tot.get(r[1],0)+float(r[6] or 0)
    print("Job totals:"); [print(k,round(v,2)) for k,v in tot.items()]
