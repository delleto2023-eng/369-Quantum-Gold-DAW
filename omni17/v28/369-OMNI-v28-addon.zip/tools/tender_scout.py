"""369 Tender Scout. Usage: python tender_scout.py sites.txt "company profile"  (one URL per line)"""
import sys,re,json,requests,datetime
from receipt_pipeline import llm
prof=sys.argv[2]; out=[]
for u in open(sys.argv[1]).read().split():
    try: h=requests.get(u,timeout=30).text
    except Exception as e: print("skip",u,e); continue
    txt=re.sub(r"\s+"," ",re.sub(r"<[^>]+>"," ",h))[:12000]
    r=llm(f'Company: {prof}\nList tenders on this page as JSON array [{{"title":"","deadline":"","relevance":0,"win_rate":"low|med|high","why":""}}] (relevance 0-10):\n{txt}')
    try: out+=[dict(x,source=u) for x in json.loads(r[r.find("["):r.rfind("]")+1])]
    except Exception: pass
out.sort(key=lambda x:-float(x.get("relevance",0) or 0))
open(f"tenders-{datetime.date.today()}.json","w").write(json.dumps(out,indent=1))
for x in out[:25]: print(x.get("relevance"),x.get("win_rate"),x.get("title"),x.get("deadline"),x["source"])
