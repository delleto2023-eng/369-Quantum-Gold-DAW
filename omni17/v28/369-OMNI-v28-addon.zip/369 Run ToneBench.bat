@echo off
start "" "%~dp0app\tonebench.html"
