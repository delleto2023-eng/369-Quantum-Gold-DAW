---
name: book-prompting
description: Production prompt design, versioning and testing.
---
# AI Eng for Production: Prompting

Production prompt design, versioning and testing.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
