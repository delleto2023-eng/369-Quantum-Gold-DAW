---
name: book-evaluation
description: Eval sets, LLM-as-judge, regression tests, observability.
---
# AI Eng for Production: Evaluation

Eval sets, LLM-as-judge, regression tests, observability.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
