---
name: receipt-cost-pipeline
description: PDF receipts to material cost per job, consolidation, audit-ready monthly report. Tool: tools/receipt_pipeline.py
---
# Receipt-to-Job-Cost Pipeline

PDF receipts to material cost per job, consolidation, audit-ready monthly report. Tool: tools/receipt_pipeline.py

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
