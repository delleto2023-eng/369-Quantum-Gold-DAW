---
name: case-studies
description: Problem / What we built / Outcome format.
---
# Case Study Writer

Problem / What we built / Outcome format.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
