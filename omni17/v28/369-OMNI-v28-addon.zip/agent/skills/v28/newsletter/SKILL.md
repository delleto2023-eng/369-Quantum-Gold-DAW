---
name: newsletter
description: Builds a weekly AI newsletter from saved links.
---
# Weekly AI Newsletter

Builds a weekly AI newsletter from saved links.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
