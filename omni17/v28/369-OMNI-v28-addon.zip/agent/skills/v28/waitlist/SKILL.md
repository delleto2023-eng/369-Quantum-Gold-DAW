---
name: waitlist
description: Collect signups, announce release dates first, invite to live launch.
---
# Launch Waitlist

Collect signups, announce release dates first, invite to live launch.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
