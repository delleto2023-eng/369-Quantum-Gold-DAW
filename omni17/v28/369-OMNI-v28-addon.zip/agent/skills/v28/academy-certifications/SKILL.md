---
name: academy-certifications
description: Generates exams and graded projects; issues a 369 certificate record when passed.
---
# Academy Certifications

Generates exams and graded projects; issues a 369 certificate record when passed.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
