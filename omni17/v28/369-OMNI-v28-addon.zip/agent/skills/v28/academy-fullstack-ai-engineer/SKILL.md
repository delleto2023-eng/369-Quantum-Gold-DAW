---
name: academy-fullstack-ai-engineer
description: Self-paced path developer to full-stack AI engineer: LLMs, prompting, RAG, fine-tuning, agents, evaluation, deployment, quizzes and certification.
---
# Academy: Full-Stack AI Engineer

Self-paced path developer to full-stack AI engineer: LLMs, prompting, RAG, fine-tuning, agents, evaluation, deployment, quizzes and certification.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
