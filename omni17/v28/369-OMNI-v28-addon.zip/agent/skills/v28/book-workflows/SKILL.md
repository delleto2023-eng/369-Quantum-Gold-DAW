---
name: book-workflows
description: Workflows vs agents; chaining, routing, parallelization.
---
# AI Eng for Production: Workflows

Workflows vs agents; chaining, routing, parallelization.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
