---
name: towards-ai-agent
description: Master agent: routes to Academy, Enterprise, Value Creation, ToneBench, Book and Community skills; trains you while it builds.
---
# Towards AI Agent

Master agent: routes to Academy, Enterprise, Value Creation, ToneBench, Book and Community skills; trains you while it builds.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
