---
name: deploy-scope
description: Identify and rank high-impact AI opportunities.
---
# Custom Deployment: Scope

Identify and rank high-impact AI opportunities.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
