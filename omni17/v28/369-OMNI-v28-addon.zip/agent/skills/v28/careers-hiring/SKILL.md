---
name: careers-hiring
description: Write roles, screen candidates.
---
# Careers / Hiring

Write roles, screen candidates.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
