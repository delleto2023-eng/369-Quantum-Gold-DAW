---
name: workforce-leadership
description: AI strategy and value-creation playbooks.
---
# Workforce: Leadership

AI strategy and value-creation playbooks.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
