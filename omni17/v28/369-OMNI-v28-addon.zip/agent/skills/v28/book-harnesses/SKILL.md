---
name: book-harnesses
description: The system around the model: test, observe, improve loops.
---
# AI Eng for Production: Harnesses

The system around the model: test, observe, improve loops.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
