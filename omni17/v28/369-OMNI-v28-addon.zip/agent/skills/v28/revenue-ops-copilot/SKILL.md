---
name: revenue-ops-copilot
description: Pipeline hygiene, follow-ups, forecasts.
---
# Revenue-Ops Co-Pilot

Pipeline hygiene, follow-ups, forecasts.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
