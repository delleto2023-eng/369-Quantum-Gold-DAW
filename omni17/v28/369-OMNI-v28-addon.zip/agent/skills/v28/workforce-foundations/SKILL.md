---
name: workforce-foundations
description: AI literacy, policy and governance training.
---
# Workforce: Foundations

AI literacy, policy and governance training.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
