---
name: deploy-build
description: Ship production-grade AI, not demos.
---
# Custom Deployment: Build

Ship production-grade AI, not demos.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
