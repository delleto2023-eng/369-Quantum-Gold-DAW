---
name: support-deflection
description: Answers common tickets from your docs, escalates the rest.
---
# Support Deflection Co-Pilot

Answers common tickets from your docs, escalates the rest.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
