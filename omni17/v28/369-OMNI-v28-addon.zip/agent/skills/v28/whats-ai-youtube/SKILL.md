---
name: whats-ai-youtube
description: Explainer video scripts on AI topics.
---
# What's AI YouTube Scripts

Explainer video scripts on AI topics.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
