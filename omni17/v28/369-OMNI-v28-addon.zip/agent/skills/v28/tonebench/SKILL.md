---
name: tonebench
description: Same brief to many models in a creator's voice, 4 blind judges, Elo leaderboard with cost per script. Tool: app/tonebench.html
---
# ToneBench Writing Benchmark

Same brief to many models in a creator's voice, 4 blind judges, Elo leaderboard with cost per script. Tool: app/tonebench.html

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
