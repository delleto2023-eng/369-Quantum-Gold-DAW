---
name: book-agents
description: Tool-using agents, planning, sub-agents, guardrails.
---
# AI Eng for Production: Agents

Tool-using agents, planning, sub-agents, guardrails.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
