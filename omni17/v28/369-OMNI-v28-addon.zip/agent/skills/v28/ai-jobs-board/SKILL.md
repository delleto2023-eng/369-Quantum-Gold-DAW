---
name: ai-jobs-board
description: Collect and match AI jobs to your skills.
---
# AI Jobs Board

Collect and match AI jobs to your skills.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
