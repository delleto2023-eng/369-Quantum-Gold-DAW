---
name: value-trading-asset-mgmt
description: AI playbooks for prop-trading firms and asset managers.
---
# Value Creation: Trading & Asset Management

AI playbooks for prop-trading firms and asset managers.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
