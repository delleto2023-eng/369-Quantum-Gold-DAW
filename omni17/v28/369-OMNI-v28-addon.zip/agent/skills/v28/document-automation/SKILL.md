---
name: document-automation
description: Extract, classify and file documents automatically.
---
# Document Automation

Extract, classify and file documents automatically.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
