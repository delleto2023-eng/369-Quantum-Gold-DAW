---
name: publication-writer
description: Draft, edit and publish AI articles.
---
# Publication Writer Network

Draft, edit and publish AI articles.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
