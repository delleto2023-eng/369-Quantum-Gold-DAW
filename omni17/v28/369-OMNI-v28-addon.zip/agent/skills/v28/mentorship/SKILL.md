---
name: mentorship
description: 1:1 mentor plans, goals and check-ins.
---
# Mentorship

1:1 mentor plans, goals and check-ins.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
