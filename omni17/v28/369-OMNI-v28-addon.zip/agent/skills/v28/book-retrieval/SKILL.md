---
name: book-retrieval
description: RAG: chunking, embeddings, hybrid search, reranking.
---
# AI Eng for Production: Retrieval

RAG: chunking, embeddings, hybrid search, reranking.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
