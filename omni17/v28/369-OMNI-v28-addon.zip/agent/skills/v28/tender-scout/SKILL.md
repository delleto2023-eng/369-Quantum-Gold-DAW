---
name: tender-scout
description: Scan tender sites, AI-rank relevance, win-rate category, daily report. Tool: tools/tender_scout.py
---
# Tender Scout Agent

Scan tender sites, AI-rank relevance, win-rate category, daily report. Tool: tools/tender_scout.py

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
