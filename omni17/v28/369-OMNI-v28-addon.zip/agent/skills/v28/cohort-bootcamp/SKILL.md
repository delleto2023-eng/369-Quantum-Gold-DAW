---
name: cohort-bootcamp
description: Multi-day intensive on LLM pipelines with hands-on labs, tailored to a domain.
---
# Cohort Bootcamp

Multi-day intensive on LLM pipelines with hands-on labs, tailored to a domain.

Runs on your OpenRouter key, 369 Gateway URL or local Ollama (http://localhost:11434/v1).
Source: https://towardsai.com/
