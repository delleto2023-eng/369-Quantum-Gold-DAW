---
name: copilot-sharepoint-and-onedrive-knowledge
description: Ground on files with user permissions
category: Knowledge
source: https://learn.microsoft.com/microsoft-copilot-studio/
---

# SharePoint and OneDrive Knowledge

Copilot Studio ability: SharePoint and OneDrive Knowledge.
1. Plan which topics, knowledge and tools to use.
2. Do it with OMNI's own tools (gateway models, connectors, Big Tony engines, Data Brain), free first.
3. Ask approval before external actions.
4. Test in the Self-Test tab, fix, re-test.
5. Report results and any key still needed.
Capability: Ground on files with user permissions.
