---
name: copilot-researcher-agent
description: Deep multi-step research with cited reports
category: Agents
source: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Researcher Agent

Copilot Studio ability: Researcher Agent.
1. Plan which topics, knowledge and tools to use.
2. Do it with OMNI's own tools (gateway models, connectors, Big Tony engines, Data Brain), free first.
3. Ask approval before external actions.
4. Test in the Self-Test tab, fix, re-test.
5. Report results and any key still needed.
Capability: Deep multi-step research with cited reports.
