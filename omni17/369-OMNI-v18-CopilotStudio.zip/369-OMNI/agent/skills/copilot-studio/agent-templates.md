---
name: copilot-agent-templates
description: IT helpdesk, HR, sales, customer service, website Q&A starters
category: Agents
source: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Agent Templates

Copilot Studio ability: Agent Templates.
1. Plan which topics, knowledge and tools to use.
2. Do it with OMNI's own tools (gateway models, connectors, Big Tony engines, Data Brain), free first.
3. Ask approval before external actions.
4. Test in the Self-Test tab, fix, re-test.
5. Report results and any key still needed.
Capability: IT helpdesk, HR, sales, customer service, website Q&A starters.
