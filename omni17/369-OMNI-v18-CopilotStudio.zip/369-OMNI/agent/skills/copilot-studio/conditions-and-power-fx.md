---
name: copilot-conditions-and-power-fx
description: Branching, variables and formulas
category: Topics
source: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Conditions and Power Fx

Copilot Studio ability: Conditions and Power Fx.
1. Plan which topics, knowledge and tools to use.
2. Do it with OMNI's own tools (gateway models, connectors, Big Tony engines, Data Brain), free first.
3. Ask approval before external actions.
4. Test in the Self-Test tab, fix, re-test.
5. Report results and any key still needed.
Capability: Branching, variables and formulas.
