---
name: copilot-declarative-m365-copilot-agents
description: Extend Microsoft 365 Copilot with instructions and actions
category: Agents
source: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Declarative M365 Copilot Agents

Copilot Studio ability: Declarative M365 Copilot Agents.
1. Plan which topics, knowledge and tools to use.
2. Do it with OMNI's own tools (gateway models, connectors, Big Tony engines, Data Brain), free first.
3. Ask approval before external actions.
4. Test in the Self-Test tab, fix, re-test.
5. Report results and any key still needed.
Capability: Extend Microsoft 365 Copilot with instructions and actions.
