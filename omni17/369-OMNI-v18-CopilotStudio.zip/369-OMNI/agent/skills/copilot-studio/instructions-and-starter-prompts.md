---
name: copilot-instructions-and-starter-prompts
description: Persona, rules, greeting and suggested prompts
category: Agents
source: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Instructions and Starter Prompts

Copilot Studio ability: Instructions and Starter Prompts.
1. Plan which topics, knowledge and tools to use.
2. Do it with OMNI's own tools (gateway models, connectors, Big Tony engines, Data Brain), free first.
3. Ask approval before external actions.
4. Test in the Self-Test tab, fix, re-test.
5. Report results and any key still needed.
Capability: Persona, rules, greeting and suggested prompts.
