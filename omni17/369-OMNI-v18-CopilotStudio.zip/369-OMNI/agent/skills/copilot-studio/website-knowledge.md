---
name: copilot-website-knowledge
description: Ground on public URLs
category: Knowledge
source: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Website Knowledge

Copilot Studio ability: Website Knowledge.
1. Plan which topics, knowledge and tools to use.
2. Do it with OMNI's own tools (gateway models, connectors, Big Tony engines, Data Brain), free first.
3. Ask approval before external actions.
4. Test in the Self-Test tab, fix, re-test.
5. Report results and any key still needed.
Capability: Ground on public URLs.
