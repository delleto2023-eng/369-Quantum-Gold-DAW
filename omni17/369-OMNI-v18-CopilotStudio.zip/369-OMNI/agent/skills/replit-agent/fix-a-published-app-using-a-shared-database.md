---
name: replit-fix-a-published-app-using-a-shared-database
description: Step-by-step instructions for updating a published app that still uses a database originally created for another app.
source: https://docs.replit.com/features/data-and-storage/shared-database-migration.md
---

# Fix a published app using a shared database

Replit-Agent ability: Fix a published app using a shared database.
1. Restate the user's goal for Fix a published app using a shared database in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Step-by-step instructions for updating a published app that still uses a database originally created for another app.
