---
name: replit-agent-builds-agents-automations
description: Build other agents, bots and scheduled automations (Slack/Telegram/email bots, timed jobs) from plain language.
source: https://replit.com/blog/introducing-agent-3-our-most-autonomous-agent-yet
---

# Agent builds Agents & Automations

Replit-Agent ability: Agent builds Agents & Automations.
1. Restate the user's goal for Agent builds Agents & Automations in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Build other agents, bots and scheduled automations (Slack/Telegram/email bots, timed jobs) from plain language.
