---
name: replit-replit-on-slack
description: Add Replit Agent to Slack to work on projects, use connected tools, and get answers in channels and direct messages. Learn setup, account linking, and permissions.
source: https://docs.replit.com/features/platforms/slack.md
---

# Replit on Slack

Replit-Agent ability: Replit on Slack.
1. Restate the user's goal for Replit on Slack in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Add Replit Agent to Slack to work on projects, use connected tools, and get answers in channels and direct messages. Learn setup, account linking, and permissions.
