---
name: replit-design-mode-design-systems
description: Generate design frames, explore suggestions, refine with Visual Editor, save DESIGN.md design systems, build the winning frame.
source: https://docs.replit.com/design/what-is-replit-design
---

# Design Mode & Design Systems

Replit-Agent ability: Design Mode & Design Systems.
1. Restate the user's goal for Design Mode & Design Systems in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Generate design frames, explore suggestions, refine with Visual Editor, save DESIGN.md design systems, build the winning frame.
