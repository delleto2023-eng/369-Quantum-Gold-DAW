---
name: replit-prospect-calling-outreach
description: Work a call/contact list toward a goal, book meetings, send personalized email, log outcomes.
source: https://docs.replit.com/use-cases/call-prospects
---

# Prospect calling & outreach

Replit-Agent ability: Prospect calling & outreach.
1. Restate the user's goal for Prospect calling & outreach in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Work a call/contact list toward a goal, book meetings, send personalized email, log outcomes.
