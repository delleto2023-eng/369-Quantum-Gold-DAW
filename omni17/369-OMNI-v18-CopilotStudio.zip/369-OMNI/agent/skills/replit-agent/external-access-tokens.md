---
name: replit-external-access-tokens
description: Let CI pipelines, webhooks, and other automated services reach your private Replit Project without signing in.
source: https://docs.replit.com/features/deployment-customization/external-access-tokens.md
---

# External Access Tokens

Replit-Agent ability: External Access Tokens.
1. Restate the user's goal for External Access Tokens in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Let CI pipelines, webhooks, and other automated services reach your private Replit Project without signing in.
