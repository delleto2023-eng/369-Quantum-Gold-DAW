---
name: replit-mobile-app-expo-testflight
description: Build native iOS/Android apps, preview with Expo Go QR, ship to TestFlight/App Store.
source: https://docs.replit.com/build/mobile-app
---

# Mobile app (Expo) + TestFlight

Replit-Agent ability: Mobile app (Expo) + TestFlight.
1. Restate the user's goal for Mobile app (Expo) + TestFlight in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Build native iOS/Android apps, preview with Expo Go QR, ship to TestFlight/App Store.
