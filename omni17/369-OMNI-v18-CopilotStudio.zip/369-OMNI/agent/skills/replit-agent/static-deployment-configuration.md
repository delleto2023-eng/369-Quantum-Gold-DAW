---
name: replit-static-deployment-configuration
description: Learn how to configure HTTP headers, routing rules, and URL rewrites for static deployments.
source: https://docs.replit.com/features/deployment-customization/static-deployments-advanced.md
---

# Static Deployment Configuration

Replit-Agent ability: Static Deployment Configuration.
1. Restate the user's goal for Static Deployment Configuration in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Learn how to configure HTTP headers, routing rules, and URL rewrites for static deployments.
