"""Dev tools from the DAW: Button Doctor and Run Build."""
import re, shutil, subprocess


def build_dev_tools(reg, guard):
    S = {"type": "string"}

    @reg.add("button_doctor", "Button Doctor: scan an HTML app for buttons that do nothing, missing handlers, swallowed errors and broken script syntax.",
             {"html": S}, ["html"])
    def button_doctor(html):
        p = guard.safe_path(html)
        t = p.read_text(encoding="utf-8", errors="replace")
        scripts = "\n".join(re.findall(r"(?is)<script[^>]*>(.*?)</script>", t))
        dead = []
        for m in re.finditer(r"(?is)<button([^>]*)>(.*?)</button>", t):
            attrs, label = m.group(1), re.sub(r"<[^>]+>", "", m.group(2)).strip()[:40]
            if "onclick" in attrs.lower() or "type=\"submit\"" in attrs.lower():
                continue
            ident = re.search(r'id="([^"]+)"', attrs)
            if ident and ident.group(1) in scripts:
                continue
            dead.append(label or "(no label)")
        swallowed = len(re.findall(r"catch\s*\(\s*\w*\s*\)\s*\{\s*\}", scripts))
        syntax = "not checked (install Node.js)"
        if shutil.which("node") and scripts:
            js = guard.safe_path("logs/_doctor_check.js"); js.parent.mkdir(parents=True, exist_ok=True)
            js.write_text(scripts)
            r = subprocess.run(["node", "--check", str(js)], capture_output=True, text=True)
            syntax = "OK" if r.returncode == 0 else "ERROR: " + r.stderr.strip().splitlines()[-1][:200]
        return (f"Buttons with no action found: {len(dead)}" + (": " + ", ".join(dead[:30]) if dead else "") +
                f"\nSwallowed errors (empty catch blocks): {swallowed}\nScript syntax: {syntax}")

    @reg.add("run_build", "Run Build: start a GitHub Actions workflow (e.g. installers or publish) with the GitHub CLI and show recent runs. Needs approval.",
             {"repo": S, "workflow": S}, ["repo"], risk="approve")
    def run_build(repo, workflow=""):
        if not shutil.which("gh"):
            return "GitHub CLI (gh) is not installed. Install it from cli.github.com and run `gh auth login` once."
        out = []
        if workflow:
            r = subprocess.run(["gh", "workflow", "run", workflow, "-R", repo], capture_output=True, text=True, timeout=120)
            out.append(("Started " + workflow) if r.returncode == 0 else ("Could not start: " + r.stderr.strip()[-300:]))
        r = subprocess.run(["gh", "run", "list", "-R", repo, "-L", "9"], capture_output=True, text=True, timeout=120)
        out.append(r.stdout.strip() or r.stderr.strip()[-300:])
        return "\n".join(out)

    return reg
