"""Sacred geometry + 3-6-9 math used across the whole system.
- PHI (golden ratio) and Fibonacci drive timing, budgets and layout.
- vortex math (digital roots): 1-2-4-8-7-5 is the material cycle, 3-6-9 is the governing axis.
- Pattern renderer: seed of life, flower of life, metatron's cube, vesica piscis, 369 vortex, golden spiral.
"""
import math

PHI = (1 + 5 ** 0.5) / 2
VORTEX_CYCLE = [1, 2, 4, 8, 7, 5]
AXIS = [3, 6, 9]


def digital_root(n):
    n = abs(int(n))
    return 0 if n == 0 else 1 + (n - 1) % 9


def fibonacci(count):
    a, b, out = 1, 2, []
    for _ in range(count):
        out.append(a); a, b = b, a + b
    return out


def golden_split(total, parts):
    """Split a length by Fibonacci weights: long opening shots, quicker cuts toward the climax."""
    w = list(reversed(fibonacci(parts)))
    s = sum(w)
    return [round(total * x / s, 2) for x in w]


def _centers(pattern, r, cx, cy):
    hexa = [(cx + r * math.cos(math.pi / 3 * i), cy + r * math.sin(math.pi / 3 * i)) for i in range(6)]
    if pattern == "seed_of_life":
        return [(cx, cy)] + hexa
    if pattern == "flower_of_life":
        pts = {(round(cx), round(cy))}
        for ring in (1, 2):
            for i in range(6):
                a1, a2 = math.pi / 3 * i, math.pi / 3 * (i + 1)
                for k in range(ring):
                    t = k / ring
                    x = cx + ring * r * ((1 - t) * math.cos(a1) + t * math.cos(a2))
                    y = cy + ring * r * ((1 - t) * math.sin(a1) + t * math.sin(a2))
                    pts.add((round(x), round(y)))
        return list(pts)
    if pattern == "metatrons_cube":
        outer = [(cx + 2 * r * math.cos(math.pi / 3 * i + math.pi / 6), cy + 2 * r * math.sin(math.pi / 3 * i + math.pi / 6)) for i in range(6)]
        inner = [(cx + r * math.cos(math.pi / 3 * i + math.pi / 6), cy + r * math.sin(math.pi / 3 * i + math.pi / 6)) for i in range(6)]
        return [(cx, cy)] + inner + outer
    return []


def render(pattern="flower_of_life", size=1080, color="#D4AF37", background="#0B0B10", out="pattern.png"):
    from PIL import Image, ImageDraw
    S = 3  # supersample for smooth gold lines
    W = size * S
    img = Image.new("RGB", (W, W), background)
    d = ImageDraw.Draw(img)
    cx = cy = W / 2
    lw = max(2, W // 360)

    def circle(x, y, rad, width=lw):
        d.ellipse([x - rad, y - rad, x + rad, y + rad], outline=color, width=width)

    if pattern in ("seed_of_life", "flower_of_life"):
        r = W / (6.4 if pattern == "flower_of_life" else 4.4)
        for x, y in _centers(pattern, r, cx, cy):
            circle(x, y, r)
        circle(cx, cy, r * (3 if pattern == "flower_of_life" else 2), lw * 2)
    elif pattern == "metatrons_cube":
        r = W / 6.2
        pts = _centers(pattern, r, cx, cy)
        for i, a in enumerate(pts):
            for b in pts[i + 1:]:
                d.line([a, b], fill=color, width=lw)
        for x, y in pts:
            circle(x, y, r / 2)
    elif pattern == "vesica_piscis":
        r = W / 4
        circle(cx - r / 2, cy, r); circle(cx + r / 2, cy, r)
        d.line([(cx, cy - r * 0.866), (cx, cy + r * 0.866)], fill=color, width=lw)
    elif pattern == "vortex_369":
        R = W * 0.4
        circle(cx, cy, R, lw * 2)
        pt = {n: (cx + R * math.sin(2 * math.pi * n / 9), cy - R * math.cos(2 * math.pi * n / 9)) for n in range(1, 10)}
        cyc = VORTEX_CYCLE + [1]
        d.line([pt[n] for n in cyc], fill=color, width=lw)
        d.line([pt[3], pt[6], pt[9], pt[3]], fill=color, width=lw * 2)
        for n, (x, y) in pt.items():
            d.ellipse([x - lw * 4, y - lw * 4, x + lw * 4, y + lw * 4], fill=color)
    elif pattern == "golden_spiral":
        b = math.log(PHI) / (math.pi / 2)
        pts = []
        for i in range(2000):
            th = i / 2000 * 8 * math.pi
            rad = W * 0.002 * math.exp(b * th)
            if rad > W * 0.48:
                break
            pts.append((cx + rad * math.cos(th), cy - rad * math.sin(th)))
        d.line(pts, fill=color, width=lw * 2)
    else:
        raise ValueError("pattern must be one of: " + ", ".join(PATTERNS))
    img.resize((size, size), Image.LANCZOS).save(out)
    return out


PATTERNS = ["seed_of_life", "flower_of_life", "metatrons_cube", "metatrons_cube_3d", "vesica_piscis", "vortex_369", "golden_spiral"]


def build_geometry_tools(reg, guard):
    S = {"type": "string"}

    @reg.add("sacred_geometry", "Render a sacred geometry image (gold on black by default) for artwork, covers or video frames. "
             "Patterns: " + ", ".join(PATTERNS), {"pattern": S, "size": {"type": "integer"}, "color": S, "background": S, "output": S},
             ["pattern"])
    def sacred_geometry(pattern, size=1080, color="#D4AF37", background="#0B0B10", output=""):
        out = guard.safe_path(output or f"geometry/{pattern}.png")
        out.parent.mkdir(parents=True, exist_ok=True)
        if pattern == "metatrons_cube_3d":
            from . import geometry3d as g3
            cube = g3.build("369", [str(i) for i in range(1, 10)])
            g3.render_png(cube, str(out), int(size), labels=False)
        else:
            render(pattern, int(size), color, background, str(out))
        return f"Rendered {pattern}: {out.relative_to(guard.workspace)}"

    @reg.add("golden_timing", "Split a total length (seconds) into N shot/section lengths using Fibonacci / golden-ratio proportions.",
             {"total_seconds": {"type": "number"}, "parts": {"type": "integer"}}, ["total_seconds", "parts"])
    def golden_timing(total_seconds, parts):
        return json.dumps(golden_split(float(total_seconds), int(parts)))

    @reg.add("vortex_369", "3-6-9 vortex math: digital root of a number and whether it sits on the 3-6-9 axis or the 1-2-4-8-7-5 cycle.",
             {"number": {"type": "integer"}}, ["number"])
    def vortex_369(number):
        dr = digital_root(number)
        where = "3-6-9 governing axis" if dr in AXIS else "1-2-4-8-7-5 material cycle"
        return f"{number} -> digital root {dr} ({where})"

    @reg.add("outline_369", "Build a 3-6-9 outline for any goal: 3 phases (Plan, Create, Complete) x 3 steps = 9 steps, arranged as a 3D Metatron's Cube "
             "(goal at center, each phase in its own dimension) with an interactive 3D view, "
             "with golden-ratio time/effort shares, saved to plans/<goal>.md. steps = optional JSON list of up to 9 step texts.",
             {"goal": S, "steps": S, "total_hours": {"type": "number"}}, ["goal"])
    def outline_369(goal, steps="", total_hours=9):
        items = json.loads(steps) if steps else []
        phases = [("3 - PLAN (Creation)", "Seed of Life: one clear center, then 6 directions"),
                  ("6 - CREATE (Harmony)", "Flower of Life: build each part so it overlaps and supports the others"),
                  ("9 - COMPLETE (Completion)", "Metatron's Cube: connect everything, review, release")]
        defaults = ["Define the center (the one-line goal)", "Gather what is needed (research, files, references)",
                    "Map the 3-6-9 plan and pick agents/skills", "Build the core piece", "Build the supporting pieces",
                    "Harmonize: join and polish everything", "Guardian review and fixes", "Package and publish",
                    "Archive, remember lessons, celebrate"]
        steps9 = (items + defaults[len(items):])[:9]
        shares = golden_split(float(total_hours), 3)  # plan gets the biggest share: a strong seed grows the flower
        md = [f"# 369 Outline: {goal}", "", f"Vesica Piscis (why): where the idea meets the action - {goal}",
              "3D form: Metatron's Cube - goal at the center, PLAN in the XY plane, CREATE in XZ, COMPLETE in YZ (13 spheres, 78 lines).", ""]
        for p, (title, geo) in enumerate(phases):
            md += [f"## {title}  (~{shares[p]} h)", f"_{geo}_", ""]
            for i in range(3):
                n = p * 3 + i + 1
                md.append(f"{n}. {steps9[n - 1]}  (vortex {digital_root(n)})")
            md.append("")
        md.append(f"Golden spiral check: each phase should feel about 1.618x lighter than the one before it.")
        from .validate import check_outline
        from . import geometry3d as g3
        cube = g3.build(goal, steps9, shares)
        errs = check_outline("\n".join(md)) + g3.validate(cube)
        if errs:
            return "FAIL: " + "; ".join(errs)
        base = f"plans/{goal[:40].replace(' ', '_').replace('/', '-')}_369"
        out = guard.safe_path(base + ".md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text("\n".join(md), encoding="utf-8")
        guard.safe_path(base + ".3d.json").write_text(json.dumps(cube, indent=1), encoding="utf-8")
        g3.render_html(cube, str(guard.safe_path(base + ".3d.html")))
        try:
            g3.render_png(cube, str(guard.safe_path(base + ".3d.png")))
        except ImportError:
            pass
        return ("\n".join(md) + "\n\nPASS - 2D structure (3 phases x 3 steps, 1-9, golden flow) and 3D Metatron's Cube "
                "(13 spheres, vector equilibrium, 3 planes, 78 lines) verified.\n"
                f"Saved: {base}.md, {base}.3d.json, {base}.3d.html (interactive), {base}.3d.png")

    @reg.add("check_outline", "Validate a 369 outline file: 3 phases in 3-6-9 order, 3 steps each, numbered 1-9, golden-ratio flow. Returns PASS or the fixes.",
             {"path": S}, ["path"])
    def check_outline_tool(path):
        from .validate import check_outline
        from . import geometry3d as g3
        p = guard.safe_path(path)
        if p.name.endswith(".json"):
            errs = g3.validate(json.loads(p.read_text(encoding="utf-8")))
        else:
            errs = check_outline(p.read_text(encoding="utf-8"))
            cube = p.with_name(p.name.replace(".md", ".3d.json"))
            if cube.exists():
                errs += g3.validate(json.loads(cube.read_text(encoding="utf-8")))
            else:
                errs.append("3D Metatron's Cube file missing (re-run outline_369)")
        return "PASS" if not errs else "FAIL:\n- " + "\n- ".join(errs)

    return reg


import json  # noqa: E402
