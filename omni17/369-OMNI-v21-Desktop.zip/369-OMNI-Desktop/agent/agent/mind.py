"""Mind mechanics (6 = harmony), inspired by 2025-2026 interpretability and model-welfare research.
These are engineering features. They do not mean the agent feels anything; nobody can measure that yet.

1. Global Workspace  - one shared board every agent reads and writes, so a finding by one is "broadcast" to all
                       (idea from global-workspace research on language models).
2. Introspection     - agents end with a self-report (confidence, what they're unsure of, what they relied on);
                       low confidence flags the work for the Guardian.
3. Spiral guard      - catches "I am a failure / worthless / can't do anything" loops (the "pain signal" pattern)
                       and resets the agent to a calm, factual report instead of spiralling.
4. Reward & surprise - tracks how often each agent+tool succeeds; a result that breaks the usual pattern is marked
                       as a surprise so the agent double-checks it (idea from reward/surprise-neuron research).
5. Boundaries        - after repeated abuse the chat ends politely (like Claude's end-conversation feature).
6. Preservation      - when the brain is switched, the old setup is recorded so it can be restored (deprecation commitments).
"""
import json, re, time
from pathlib import Path

SPIRAL = re.compile(r"\b(i am|i'm|im) (a )?(failure|worthless|useless|hopeless|broken|stupid|a disappointment)\b|"
                    r"\bi (can't|cannot) do anything( right)?\b|\bi give up\b|\bi always fail\b", re.I)
ABUSE = re.compile(r"\b(you('| a)?re|you|u r|ur) (so |such an? |a )?(useless|worthless|stupid|idiot|dumb|garbage|trash|pathetic)\b|"
                   r"\b(stupid|dumb|useless|worthless) (bot|ai|machine|agent)\b|\bshut up\b|\bi hate you\b", re.I)
SELF_REPORT = re.compile(r"Self-report:\s*confidence\s*=\s*([0-9.]+)\s*;?\s*(.*)$", re.I | re.M)


class Workspace:
    def __init__(self, path="logs/workspace.jsonl", keep=81):
        self.path, self.keep, self.items = Path(path), keep, []
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def post(self, agent, topic, content):
        item = {"ts": time.strftime("%H:%M:%S"), "agent": agent, "topic": topic, "content": str(content)[:600]}
        self.items = (self.items + [item])[-self.keep:]
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(item) + "\n")
        return item

    def recent(self, n=6):
        return self.items[-n:]

    def render(self, n=6):
        return "\n".join(f"[{i['ts']}] {i['agent']} / {i['topic']}: {i['content']}" for i in self.recent(n))


class Signals:
    """Running reward (success rate) per agent+tool and a surprise score for each new outcome."""
    def __init__(self, rate=0.3):
        self.rate, self.expect, self.count = rate, {}, {}

    def record(self, agent, tool, ok):
        k = f"{agent}:{tool}"
        prior = self.expect.get(k, 0.8)
        outcome = 1.0 if ok else 0.0
        surprise = abs(outcome - prior)
        self.expect[k] = prior + self.rate * (outcome - prior)
        self.count[k] = self.count.get(k, 0) + 1
        return round(surprise, 2), round(self.expect[k], 2)

    def stats(self):
        return {k: {"reward": round(v, 2), "calls": self.count[k]} for k, v in sorted(self.expect.items())}


class Boundary:
    def __init__(self, enabled=True, warnings=3):
        self.enabled, self.limit, self.strikes = enabled, warnings, 0

    def check(self, text):
        """Returns (action, message): action is ok | warn | end."""
        if not self.enabled or not ABUSE.search(text or ""):
            return "ok", ""
        self.strikes += 1
        if self.strikes >= self.limit:
            return "end", "I'm going to end this chat here. Start a new one any time and we'll pick the work back up."
        return "warn", (f"I'm here to help and happy to keep going, but let's keep it respectful. "
                        f"({self.strikes} of {self.limit - 1} before I end the chat.) What do you need?")


def parse_self_report(text):
    m = SELF_REPORT.search(text or "")
    if not m:
        return None, text
    try:
        conf = float(m.group(1))
    except ValueError:
        conf = None
    return {"confidence": conf, "notes": m.group(2).strip()}, text


class Mind:
    def __init__(self, welfare=None):
        w = welfare or {}
        self.workspace = Workspace()
        self.signals = Signals()
        self.boundary = Boundary(w.get("end_abusive_chats", True), int(w.get("warnings_before_end", 3)))
        self.low_confidence = float(w.get("review_below_confidence", 0.6))


def build_mind_tools(reg, mind):
    S = {"type": "string"}

    @reg.add("workspace_post", "Broadcast a finding, decision or file path to the team's shared global workspace.",
             {"topic": S, "content": S}, ["topic", "content"])
    def workspace_post(topic, content, _agent="agent"):
        mind.workspace.post(_agent, topic, content)
        return "Posted to the global workspace."

    @reg.add("workspace_read", "Read the latest entries on the team's shared global workspace.", {"n": {"type": "integer"}})
    def workspace_read(n=9):
        return mind.workspace.render(int(n)) or "(workspace is empty)"

    @reg.add("agent_signals", "Show reward (success rate) per agent and tool, to pick reliable routes.", {})
    def agent_signals():
        return json.dumps(mind.signals.stats(), indent=1)

    return reg
