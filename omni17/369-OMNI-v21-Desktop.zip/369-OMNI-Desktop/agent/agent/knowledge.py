"""Knowledge graph (Graphify + Obsidian style): map a project once, then answer from the graph
instead of rereading every file each session. Saves tokens (and money / usage limits).

graph_build      parse the project into graph-out/: graph.json, GRAPH_REPORT.md, graph.html, manifest.json
                 (incremental: only changed files are re-parsed; code parsing calls no AI model)
graph_query      return only the nodes + links that answer a question, trimmed to a token budget
graph_report     the short summary every agent reads at the start of a session
obsidian_export  turn the graph into an Obsidian vault: one note per node with [[links]]
graphify_cli     optional: run the real Graphify CLI if it is installed (needs approval)
"""
import ast, hashlib, json, re, shutil, subprocess
from collections import defaultdict, deque
from pathlib import Path

CODE = {".py", ".js", ".ts", ".tsx", ".jsx"}
TEXT = {".md", ".txt", ".json", ".html", ".css", ".csv", ".yaml", ".yml"}
SKIP = {"graph-out", "vault", ".git", "node_modules", "__pycache__", ".venv", "logs", "exports"}
STOP = set("the a an and or of to in on for with what how is are does do which where who why my me this that it from work".split())


def _id(*parts):
    return ":".join(parts)


def _parse_py(rel, text):
    nodes, edges = [], []
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return nodes, edges
    for n in ast.walk(tree):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            kind = "class" if isinstance(n, ast.ClassDef) else "function"
            nid = _id(rel, n.name)
            doc = (ast.get_docstring(n) or "").split("\n")[0][:160]
            nodes.append({"id": nid, "label": n.name, "kind": kind, "file": rel, "line": n.lineno, "doc": doc})
            edges.append([rel, nid, "defines"])
            for c in ast.walk(n):
                if isinstance(c, ast.Call):
                    f = c.func
                    name = f.id if isinstance(f, ast.Name) else f.attr if isinstance(f, ast.Attribute) else None
                    if name:
                        edges.append([nid, "?" + name, "calls"])
        elif isinstance(n, ast.Import):
            for a in n.names:
                edges.append([rel, "mod:" + a.name.split(".")[0], "imports"])
        elif isinstance(n, ast.ImportFrom) and n.module:
            edges.append([rel, "mod:" + n.module.split(".")[-1], "imports"])
    return nodes, edges


def _parse_js(rel, text):
    nodes, edges = [], []
    for m in re.finditer(r"(?:function\s+(\w+)|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\(|class\s+(\w+))", text):
        name = m.group(1) or m.group(2) or m.group(3)
        nid = _id(rel, name)
        nodes.append({"id": nid, "label": name, "kind": "class" if m.group(3) else "function", "file": rel,
                      "line": text[:m.start()].count("\n") + 1, "doc": ""})
        edges.append([rel, nid, "defines"])
    for m in re.finditer(r"(?:import .*? from|require\()\s*['\"]([^'\"]+)['\"]", text):
        edges.append([rel, "mod:" + Path(m.group(1)).stem, "imports"])
    return nodes, edges


def _parse_md(rel, text):
    nodes, edges = [], []
    for m in re.finditer(r"^(#{1,3})\s+(.+)$", text, re.M):
        nid = _id(rel, "#" + m.group(2).strip()[:60])
        nodes.append({"id": nid, "label": m.group(2).strip()[:60], "kind": "heading", "file": rel,
                      "line": text[:m.start()].count("\n") + 1, "doc": ""})
        edges.append([rel, nid, "section"])
    for m in re.finditer(r"\[\[([^\]|#]+)", text):
        edges.append([rel, "?" + m.group(1).strip(), "links"])
    for m in re.finditer(r"\]\(([^)#:]+\.\w+)\)", text):
        edges.append([rel, "file?" + m.group(1), "links"])
    return nodes, edges


def build(project, out):
    project, out = Path(project), Path(out)
    out.mkdir(parents=True, exist_ok=True)
    man_path, cache_path = out / "manifest.json", out / "cache.json"
    manifest = json.loads(man_path.read_text()) if man_path.exists() else {}
    cache = json.loads(cache_path.read_text()) if cache_path.exists() else {}
    new_manifest, changed, total_chars = {}, 0, 0
    for p in sorted(project.rglob("*")):
        if not p.is_file() or any(part in SKIP for part in p.relative_to(project).parts):
            continue
        if p.suffix.lower() not in CODE | TEXT:
            continue
        rel = str(p.relative_to(project)).replace("\\", "/")
        raw = p.read_bytes()
        h = hashlib.sha1(raw).hexdigest()
        new_manifest[rel] = h
        total_chars += len(raw)
        if manifest.get(rel) == h and rel in cache:
            continue
        changed += 1
        text = raw.decode("utf-8", errors="replace")
        parser = _parse_py if p.suffix == ".py" else _parse_js if p.suffix in CODE else _parse_md if p.suffix == ".md" else None
        n, e = parser(rel, text) if parser else ([], [])
        first = next((l.strip("# ").strip() for l in text.splitlines() if l.strip()), "")[:160]
        cache[rel] = {"nodes": [{"id": rel, "label": Path(rel).name, "kind": "file", "file": rel, "line": 1,
                                 "doc": first, "chars": len(raw)}] + n, "edges": e}
    cache = {k: v for k, v in cache.items() if k in new_manifest}
    nodes = {n["id"]: n for v in cache.values() for n in v["nodes"]}
    by_label = defaultdict(list)
    for n in nodes.values():
        by_label[n["label"]].append(n["id"])
        by_label[Path(n["file"]).stem].append(n["file"])
    edges = set()
    for v in cache.values():
        for a, b, t in v["edges"]:
            if b.startswith("?"):
                targets = [x for x in dict.fromkeys(by_label.get(b[1:], [])) if x != a][:3]
            elif b.startswith("file?"):
                targets = [x for x in nodes if x.endswith(b[5:].lstrip("./"))][:1]
            elif b.startswith("mod:"):
                targets = list(dict.fromkeys(by_label.get(b[4:], [])))[:1]
            else:
                targets = [b]
            for tgt in targets:
                if tgt in nodes and tgt != a:
                    edges.add((a, tgt, t))
    for n in nodes.values():
        n["community"] = n["file"].split("/")[0] if "/" in n["file"] else "(root)"
    graph = {"project": str(project.name), "nodes": list(nodes.values()), "edges": [list(e) for e in sorted(edges)],
             "source_chars": total_chars}
    (out / "graph.json").write_text(json.dumps(graph, indent=1), encoding="utf-8")
    man_path.write_text(json.dumps(new_manifest, indent=1))
    cache_path.write_text(json.dumps(cache))
    (out / "GRAPH_REPORT.md").write_text(report(graph), encoding="utf-8")
    (out / "graph.html").write_text(HTML.replace("__DATA__", json.dumps(graph)), encoding="utf-8")
    return {"files": len(new_manifest), "changed": changed, "nodes": len(nodes), "edges": len(edges)}


def _degree(graph):
    d = defaultdict(int)
    for a, b, _ in graph["edges"]:
        d[a] += 1
        d[b] += 1
    return d


def report(graph):
    deg = _degree(graph)
    nodes = {n["id"]: n for n in graph["nodes"]}
    comm = defaultdict(list)
    for n in graph["nodes"]:
        comm[n["community"]].append(n)
    hubs = sorted(nodes, key=lambda k: -deg[k])[:9]
    cross = [(a, b, t) for a, b, t in graph["edges"] if nodes[a]["community"] != nodes[b]["community"]][:9]
    L = [f"# Graph report: {graph['project']}", "",
         f"{len(nodes)} nodes, {len(graph['edges'])} links, {len(comm)} communities, "
         f"{graph['source_chars'] // 4:,} source tokens mapped (approx).", "",
         "Read this first. Use graph_query to pull only what a question needs instead of rereading files.", "",
         "## Key concepts (most connected)"]
    L += [f"- {nodes[h]['label']} ({nodes[h]['kind']}, {nodes[h]['file']}:{nodes[h]['line']}) - {deg[h]} links"
          + (f" - {nodes[h]['doc']}" if nodes[h].get("doc") else "") for h in hubs]
    L += ["", "## Communities"]
    L += [f"- {c}: {len(v)} nodes ({sum(1 for n in v if n['kind'] == 'file')} files)"
          for c, v in sorted(comm.items(), key=lambda x: -len(x[1]))]
    L += ["", "## Surprising connections (across communities)"]
    L += [f"- {nodes[a]['label']} ({nodes[a]['community']}) -{t}-> {nodes[b]['label']} ({nodes[b]['community']})"
          for a, b, t in cross] or ["- none"]
    L += ["", "## Suggested questions"]
    L += [f"- How does {nodes[h]['label']} work and what depends on it?" for h in hubs[:3]]
    L += [f"- What lives in {c} and how does it connect to the rest?" for c in list(comm)[:3]]
    L += ["- Where should a new feature go?", "- What breaks if I change the most connected file?",
          "- What is unused or isolated?"]
    return "\n".join(L) + "\n"


def query(graph, question, budget_tokens=1500):
    words = [w for w in re.findall(r"[a-z0-9_]+", question.lower()) if w not in STOP and len(w) > 2]
    nodes = {n["id"]: n for n in graph["nodes"]}
    adj = defaultdict(list)
    for a, b, t in graph["edges"]:
        adj[a].append((b, t))
        adj[b].append((a, "<-" + t))
    deg = _degree(graph)

    def score(n):
        hay = f"{n['label']} {n['file']} {n.get('doc', '')}".lower()
        return sum(3 if w == n["label"].lower() else 1 for w in words if w in hay) + min(deg[n["id"]], 9) * 0.01

    seeds = [n["id"] for n in sorted(nodes.values(), key=score, reverse=True) if score(n) >= 1][:6]
    if not seeds:
        return "No matching nodes. Try other words or read GRAPH_REPORT.md.", 0
    seen, out, q, used = set(), [], deque((s, 0) for s in seeds), 0
    limit = budget_tokens * 4
    while q:
        nid, depth = q.popleft()
        if nid in seen:
            continue
        seen.add(nid)
        n = nodes[nid]
        links = ", ".join(f"{t} {nodes[m]['label']}" for m, t in adj[nid][:9])
        line = (f"- {n['label']} [{n['kind']}] {n['file']}:{n['line']}" + (f" - {n['doc']}" if n.get("doc") else "")
                + (f" | {links}" if links else ""))
        if used + len(line) > limit:
            break
        out.append(line)
        used += len(line)
        if depth < 2:
            q.extend((m, depth + 1) for m, _ in adj[nid])
    saved = max(graph["source_chars"] // 4 - used // 4, 0)
    return ("\n".join(out) + f"\n\n(~{used // 4} tokens from the graph instead of ~{graph['source_chars'] // 4:,} "
            f"to reread the project; ~{saved:,} saved)"), saved


def _safe(name):
    return re.sub(r'[\\/:*?"<>|#^\[\]]', "-", name)[:80]


def obsidian(graph, vault):
    vault = Path(vault)
    if vault.exists():
        shutil.rmtree(vault)
    nodes = {n["id"]: n for n in graph["nodes"]}
    title = {k: _safe(f"{n['label']} ({Path(n['file']).stem})" if n["kind"] != "file" else n["file"].replace("/", " - "))
             for k, n in nodes.items()}
    adj = defaultdict(list)
    for a, b, t in graph["edges"]:
        adj[a].append((b, t))
        adj[b].append((a, "linked from (" + t + ")"))
    for k, n in nodes.items():
        folder = vault / _safe(n["community"])
        folder.mkdir(parents=True, exist_ok=True)
        body = ["---", f"kind: {n['kind']}", f"file: {n['file']}", f"line: {n['line']}",
                f"tags: [{n['kind']}, {_safe(n['community']).replace(' ', '-')}]", "---",
                f"# {n['label']}", "", n.get("doc", ""), "", "## Links"]
        body += [f"- {t}: [[{title[m]}]]" for m, t in adj[k]] or ["- (none)"]
        (folder / f"{title[k]}.md").write_text("\n".join(body) + "\n", encoding="utf-8")
    (vault / "369 Graph Index.md").write_text(
        report(graph).replace("# Graph report", "# 369 Graph Index") + "\n## All notes\n"
        + "\n".join(f"- [[{t}]]" for t in sorted(title.values())), encoding="utf-8")
    return len(nodes)


HTML = """<!doctype html><html><head><meta charset="utf-8"><title>369 Knowledge Graph</title><style>
body{margin:0;background:#0B0B10;color:#eee;font-family:Georgia,serif}canvas{display:block}#q{position:fixed;top:12px;left:12px;padding:8px;
background:#14141c;color:#D4AF37;border:1px solid #D4AF37;width:260px}#i{position:fixed;bottom:12px;left:12px;max-width:520px;font-size:13px}</style></head>
<body><input id="q" placeholder="search the graph..."><div id="i"></div><canvas id="c"></canvas><script>
const G=__DATA__,cv=document.getElementById('c'),x=cv.getContext('2d');cv.width=innerWidth;cv.height=innerHeight;
const col={file:'#D4AF37',function:'#9CFFB0',class:'#7FD3FF',heading:'#FFB0D9'};
const N=G.nodes.map((n,i)=>({...n,x:cv.width/2+Math.cos(i)*200*Math.random(),y:cv.height/2+Math.sin(i)*200*Math.random(),vx:0,vy:0}));
const ix={};N.forEach((n,i)=>ix[n.id]=i);const E=G.edges.map(([a,b])=>[ix[a],ix[b]]);let hit='',sel=null;
document.getElementById('q').oninput=e=>hit=e.target.value.toLowerCase();
cv.onclick=e=>{sel=N.find(n=>Math.hypot(n.x-e.clientX,n.y-e.clientY)<8);document.getElementById('i').textContent=sel?`${sel.label} [${sel.kind}] ${sel.file}:${sel.line} ${sel.doc||''}`:''};
function step(){for(const a of N){for(const b of N){if(a===b)continue;const dx=a.x-b.x,dy=a.y-b.y,d=dx*dx+dy*dy+.01;if(d<40000){a.vx+=dx/d*30;a.vy+=dy/d*30}}
a.vx+=(cv.width/2-a.x)*.0005;a.vy+=(cv.height/2-a.y)*.0005}for(const[a,b]of E){const A=N[a],B=N[b],dx=B.x-A.x,dy=B.y-A.y;A.vx+=dx*.002;A.vy+=dy*.002;B.vx-=dx*.002;B.vy-=dy*.002}
for(const n of N){n.vx*=.85;n.vy*=.85;n.x+=n.vx;n.y+=n.vy}}
function draw(){step();x.fillStyle='#0B0B10';x.fillRect(0,0,cv.width,cv.height);x.strokeStyle='rgba(212,175,55,.25)';
for(const[a,b]of E){x.beginPath();x.moveTo(N[a].x,N[a].y);x.lineTo(N[b].x,N[b].y);x.stroke()}
for(const n of N){const on=hit&&(n.label+n.file).toLowerCase().includes(hit);x.fillStyle=on?'#fff':col[n.kind]||'#aaa';x.beginPath();x.arc(n.x,n.y,n.kind=='file'?6:3.5,0,7);x.fill();
if(on||n===sel||n.kind=='file'){x.fillStyle='#ddd';x.font='11px Georgia';x.fillText(n.label,n.x+8,n.y+4)}}requestAnimationFrame(draw)}draw();</script></body></html>"""


def build_knowledge_tools(reg, guard):
    S = {"type": "string"}

    def load(out="graph-out"):
        p = guard.safe_path(out) / "graph.json"
        if not p.exists():
            raise FileNotFoundError("No graph yet. Run graph_build first.")
        return json.loads(p.read_text(encoding="utf-8"))

    @reg.add("graph_build", "Map a project folder into a knowledge graph (graph-out/: graph.json, GRAPH_REPORT.md, graph.html). "
             "Incremental: only changed files are re-parsed. Run once per project, then after big changes.",
             {"path": S, "out": S})
    def graph_build(path=".", out="graph-out"):
        r = build(guard.safe_path(path), guard.safe_path(out))
        return (f"Graph built: {r['files']} files ({r['changed']} re-parsed), {r['nodes']} nodes, {r['edges']} links. "
                f"Open {out}/graph.html; agents now read {out}/GRAPH_REPORT.md first.")

    @reg.add("graph_query", "Answer a question from the knowledge graph: returns only the relevant nodes and links, "
             "trimmed to a token budget. Use this BEFORE reading files.",
             {"question": S, "budget_tokens": {"type": "integer"}}, ["question"])
    def graph_query(question, budget_tokens=1500):
        return query(load(), question, int(budget_tokens))[0]

    @reg.add("graph_report", "Read the knowledge graph summary (key concepts, communities, surprising links, suggested questions).", {})
    def graph_report():
        p = guard.safe_path("graph-out/GRAPH_REPORT.md")
        return p.read_text(encoding="utf-8") if p.exists() else "No graph yet. Run graph_build first."

    @reg.add("obsidian_export", "Export the knowledge graph as an Obsidian vault (one note per node, [[links]], tags, index note).",
             {"vault": S})
    def obsidian_export(vault="vault"):
        n = obsidian(load(), guard.safe_path(vault))
        return f"Obsidian vault ready: {vault}/ ({n} notes). In Obsidian: Open folder as vault, then open the Graph view."

    @reg.add("graphify_cli", "Run the real Graphify CLI if installed (e.g. args='extract . --code-only'). Needs approval.",
             {"args": S}, ["args"], risk="approve")
    def graphify_cli(args):
        if not shutil.which("graphify"):
            return "Graphify CLI is not installed. The built-in graph_build does the same job locally."
        guard.check_shell("graphify " + args)
        r = subprocess.run(["graphify"] + args.split(), cwd=guard.workspace, capture_output=True, text=True, timeout=900)
        return f"exit={r.returncode}\n{r.stdout[-3000:]}\n{r.stderr[-1500:]}"

    return reg
