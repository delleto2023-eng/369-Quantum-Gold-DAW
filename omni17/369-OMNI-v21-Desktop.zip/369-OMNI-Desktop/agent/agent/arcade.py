"""Arcade & Creator triad (from the 369 Kombat Kings and AURA App Creator / Universal File Studio chats).
sprite_sheet   Sprite Artist: draw a fighter sprite sheet (idle, walk, punch, kick, special, KO) from a simple spec
app_scaffold   App Creator: make a runnable single-file HTML app (tool, game, player) in a test window folder
convert_file   Universal File Studio: convert between formats (audio/video via ffmpeg, images via Pillow, text/markdown/html/json/csv)
"""
import csv, html, io, json, re, shutil, subprocess
from pathlib import Path

POSES = ["idle", "walk", "punch", "kick", "special", "ko"]


def build_arcade_tools(reg, guard, ffmpeg):
    S = {"type": "string"}

    @reg.add("sprite_sheet", "Sprite Artist: draw a fighter sprite sheet (6 poses x 4 frames) from name + colors. Placeholder-quality pixel art to iterate on.",
             {"name": S, "body_color": S, "accent_color": S, "size": {"type": "integer"}}, ["name"])
    def sprite_sheet(name, body_color="#D4AF37", accent_color="#E0115F", size=96):
        from PIL import Image, ImageDraw
        s = int(size); W, H = s * 4, s * len(POSES)
        img = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
        for r, pose in enumerate(POSES):
            for f in range(4):
                ox, oy = f * s, r * s
                bob = (f % 2) * 2
                cx = ox + s // 2
                lean = {"punch": 6, "kick": -4, "special": 8, "ko": 0}.get(pose, 0)
                if pose == "ko":
                    d.rectangle([ox + 10, oy + s - 22, ox + s - 10, oy + s - 10], fill=body_color); continue
                d.ellipse([cx - 9 + lean, oy + 8 + bob, cx + 9 + lean, oy + 26 + bob], fill=accent_color)
                d.rectangle([cx - 10 + lean // 2, oy + 27 + bob, cx + 10 + lean // 2, oy + 58], fill=body_color)
                step = [-6, 0, 6, 0][f] if pose == "walk" else 0
                d.line([cx - 5, oy + 58, cx - 8 + step, oy + s - 6], fill=body_color, width=6)
                kick = (s // 3) * (f in (1, 2)) if pose == "kick" else 0
                d.line([cx + 5, oy + 58, cx + 8 - step + kick, oy + s - 6 - kick], fill=body_color, width=6)
                reach = (s // 3) * (f in (1, 2)) if pose in ("punch", "special") else 0
                d.line([cx + lean, oy + 34 + bob, cx + 16 + reach + lean, oy + 40], fill=accent_color, width=5)
                if pose == "special" and f in (1, 2):
                    d.ellipse([cx + 18 + reach, oy + 30, cx + 34 + reach, oy + 46], outline="#B9F2FF", width=3)
        out = guard.safe_path(f"arcade/sprites/{name.replace(' ', '_')}_sheet.png"); out.parent.mkdir(parents=True, exist_ok=True)
        img.save(out)
        (out.with_suffix(".json")).write_text(json.dumps({"name": name, "frame": [s, s], "rows": POSES, "frames_per_row": 4}, indent=1))
        return f"Sprite sheet for {name}: {out.relative_to(guard.workspace)} ({len(POSES)} poses x 4 frames, {s}px) + frame map JSON"

    @reg.add("app_scaffold", "App Creator: create a runnable single-file HTML app (kind: tool, game, player) with the gold theme, ready to open and test.",
             {"name": S, "kind": S, "description": S}, ["name"])
    def app_scaffold(name, kind="tool", description=""):
        body = {"game": "<canvas id='c' width='640' height='360'></canvas><script>const c=document.getElementById('c').getContext('2d');let x=300,v=0;"
                         "addEventListener('keydown',e=>{if(e.key=='ArrowLeft')v=-4;if(e.key=='ArrowRight')v=4});addEventListener('keyup',()=>v=0);"
                         "(function loop(){x=Math.max(0,Math.min(600,x+v));c.fillStyle='#0B0B10';c.fillRect(0,0,640,360);c.fillStyle='#D4AF37';c.fillRect(x,300,40,40);requestAnimationFrame(loop)})()</script>",
                "player": "<input type='file' id='f' accept='audio/*,video/*'><video id='v' controls style='width:100%'></video><script>f.onchange=e=>v.src=URL.createObjectURL(e.target.files[0])</script>",
                "tool": "<textarea id='i' rows='8' style='width:100%'></textarea><button onclick=\"o.textContent=i.value.toUpperCase()\">Run</button><pre id='o'></pre>"}.get(kind, "")
        page = (f"<!doctype html><html><head><meta charset='utf-8'><title>{html.escape(name)}</title><style>body{{background:#0B0B10;color:#eee;"
                f"font-family:system-ui;padding:24px}}h1{{color:#D4AF37;font-family:Cinzel,serif}}button{{background:linear-gradient(#FFD76A,#B8862A);border:0;padding:8px 18px;border-radius:9px}}</style></head>"
                f"<body><h1>{html.escape(name)}</h1><p>{html.escape(description)}</p>{body}</body></html>")
        out = guard.safe_path(f"apps/{name.replace(' ', '_')}/index.html"); out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(page)
        return f"App created: {out.relative_to(guard.workspace)} - open it in a browser to test (button_doctor can check it)."

    @reg.add("convert_file", "Universal File Studio: convert a file to another format (wav/mp3/flac/ogg/mp4/webm/gif, png/jpg/webp, md/html/txt, json/csv).",
             {"path": S, "to": S}, ["path", "to"])
    def convert_file(path, to):
        src = guard.safe_path(path); to = to.lower().strip("."); out = src.with_suffix("." + to)
        a, b = src.suffix.lower().strip("."), to
        media = {"wav", "mp3", "flac", "ogg", "m4a", "aac", "mp4", "webm", "mov", "gif", "mkv"}
        if a in media or b in media:
            r = subprocess.run([ffmpeg(), "-y", "-i", str(src), str(out)], capture_output=True, text=True, timeout=900)
            if r.returncode: raise RuntimeError(r.stderr[-300:])
        elif b in {"png", "jpg", "jpeg", "webp", "bmp"}:
            from PIL import Image
            im = Image.open(src); (im.convert("RGB") if b in ("jpg", "jpeg") else im).save(out)
        elif a == "md" and b == "html":
            t = src.read_text(); t = re.sub(r"^### (.*)$", r"<h3>\1</h3>", t, flags=re.M); t = re.sub(r"^## (.*)$", r"<h2>\1</h2>", t, flags=re.M)
            t = re.sub(r"^# (.*)$", r"<h1>\1</h1>", t, flags=re.M); t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
            out.write_text("<html><body>" + "\n".join(l if l.startswith("<h") else f"<p>{l}</p>" for l in t.splitlines() if l.strip()) + "</body></html>")
        elif a in ("html", "htm") and b in ("txt", "md"):
            out.write_text(html.unescape(re.sub(r"(?s)<[^>]+>", " ", src.read_text())))
        elif a == "json" and b == "csv":
            data = json.loads(src.read_text()); rows = data if isinstance(data, list) else [data]
            keys = sorted({k for r in rows for k in r}); buf = io.StringIO(); w = csv.DictWriter(buf, keys); w.writeheader(); w.writerows(rows); out.write_text(buf.getvalue())
        elif a == "csv" and b == "json":
            out.write_text(json.dumps(list(csv.DictReader(io.StringIO(src.read_text()))), indent=1))
        else:
            shutil.copy(src, out) if a in ("txt", "md") and b in ("txt", "md") else (_ for _ in ()).throw(ValueError(f"{a} to {b} is not supported yet"))
        return f"Converted: {out.relative_to(guard.workspace)}"

    return reg
