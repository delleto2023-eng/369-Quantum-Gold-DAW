"""JARVIS mode (from BT2 in 369 Super DAW Studio): speak, listen, alerts.
speak   offline text-to-speech (pyttsx3, macOS say, Linux espeak, or Windows speech)
listen  speech-to-text from the microphone (needs SpeechRecognition + a mic)
alert   a live alert: posted to the team workspace, printed with a bell, optionally spoken
Wake word "Hey BT2" / "Hey Tony" is handled by `/jarvis` in the chat.
"""
import platform, shutil, subprocess


def tts_engine():
    try:
        import pyttsx3  # noqa
        return "pyttsx3"
    except Exception:
        pass
    if platform.system() == "Darwin" and shutil.which("say"):
        return "say"
    if shutil.which("espeak") or shutil.which("espeak-ng"):
        return "espeak"
    if platform.system() == "Windows":
        return "powershell"
    return None


def say(text):
    eng = tts_engine()
    text = text[:2000]
    if eng == "pyttsx3":
        import pyttsx3
        e = pyttsx3.init(); e.say(text); e.runAndWait()
    elif eng == "say":
        subprocess.run(["say", text], timeout=300)
    elif eng == "espeak":
        subprocess.run([shutil.which("espeak") or shutil.which("espeak-ng"), text], timeout=300)
    elif eng == "powershell":
        safe = text.replace("'", "''")
        subprocess.run(["powershell", "-Command", f"Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{safe}')"], timeout=300)
    else:
        raise RuntimeError("no text-to-speech engine")
    return eng


def hear(seconds=6):
    import speech_recognition as sr
    r = sr.Recognizer()
    with sr.Microphone() as src:
        r.adjust_for_ambient_noise(src, duration=0.5)
        audio = r.listen(src, phrase_time_limit=seconds)
    return r.recognize_google(audio)


def build_voice_tools(reg, guard):
    S = {"type": "string"}

    @reg.add("speak", "JARVIS voice: say text out loud (offline text-to-speech).", {"text": S}, ["text"])
    def speak(text):
        return f"Spoke with {say(text)}."

    @reg.add("listen", "JARVIS ears: listen to the microphone and return what was said.", {"seconds": {"type": "integer"}})
    def listen(seconds=6):
        return "Heard: " + hear(int(seconds))

    @reg.add("alert", "JARVIS live alert: tell the user something important now (workspace + bell, spoken if voice=true).",
             {"message": S, "voice": {"type": "boolean"}}, ["message"])
    def alert(message, voice=False):
        print(f"\a\n[ALERT] {message}\n")
        mind = getattr(guard, "mind", None)
        if mind:
            mind.workspace.post("JARVIS", "alert", message)
        if voice and tts_engine():
            say(message)
        return "Alert sent."

    return reg
