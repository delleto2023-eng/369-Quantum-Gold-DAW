"""Layer 3 - The Connector (Model Context Protocol).
Connects to MCP servers listed in mcp_servers.json and registers their tools,
so any MCP server (files, browser, GitHub, calendar, your own API) becomes plug-and-play.
Each server runs in one long-lived background task; calls are passed through a queue.
"""
import asyncio, json, os, threading
from .tools import Tool


class MCPBridge:
    def __init__(self):
        self.loop = asyncio.new_event_loop()
        threading.Thread(target=self.loop.run_forever, daemon=True).start()
        self.queues = {}

    def _run(self, coro, timeout=180):
        return asyncio.run_coroutine_threadsafe(coro, self.loop).result(timeout=timeout)

    async def _server(self, name, params, ready):
        from mcp import ClientSession
        from mcp.client.stdio import stdio_client
        try:
            async with stdio_client(params) as (r, w):
                async with ClientSession(r, w) as s:
                    await s.initialize()
                    tools = (await s.list_tools()).tools
                    q = asyncio.Queue()
                    self.queues[name] = q
                    ready.set_result(tools)
                    while True:
                        tool_name, args, fut = await q.get()
                        try:
                            fut.set_result(await s.call_tool(tool_name, args))
                        except Exception as e:
                            fut.set_exception(e)
        except Exception as e:
            if not ready.done():
                ready.set_exception(e)

    async def _start(self, name, params):
        ready = self.loop.create_future()
        self.loop.create_task(self._server(name, params, ready))
        return await ready

    async def _call(self, name, tool_name, args):
        fut = self.loop.create_future()
        await self.queues[name].put((tool_name, args, fut))
        return await fut

    def connect(self, name, command, args, registry, risk="approve", env=None):
        from mcp import StdioServerParameters
        params = StdioServerParameters(command=command, args=args, env={**os.environ, **(env or {})})
        tools = self._run(self._start(name, params))
        for t in tools:
            def make(tn):
                def fn(**kw):
                    res = self._run(self._call(name, tn, kw))
                    return "\n".join(getattr(c, "text", str(c)) for c in res.content)
                return fn
            registry.register(Tool(f"{name}__{t.name}", t.description or t.name,
                                   t.inputSchema or {"type": "object", "properties": {}}, make(t.name), risk))
        return [t.name for t in tools]


def load_mcp_servers(registry, path="mcp_servers.json"):
    if not os.path.exists(path):
        return
    servers = json.loads(__import__("pathlib").Path(path).read_text()).get("servers", {})
    enabled = {k: v for k, v in servers.items() if v.get("enabled", True)}
    if not enabled:
        return
    bridge = MCPBridge()
    for name, cfg in enabled.items():
        try:
            names = bridge.connect(name, cfg["command"], cfg.get("args", []), registry,
                                   cfg.get("risk", "approve"), cfg.get("env"))
            print(f"MCP: connected {name} ({len(names)} tools)")
        except Exception as e:
            print(f"MCP: could not connect {name}: {e}")
