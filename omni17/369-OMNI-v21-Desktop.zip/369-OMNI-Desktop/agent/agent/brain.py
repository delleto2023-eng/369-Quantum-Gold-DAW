"""Layer 1 - The Brain.
One thin adapter so you can swap model providers without touching the rest of the agent.
Messages use a neutral format:
  {"role": "user", "content": str}
  {"role": "assistant", "content": str, "tool_calls": [{"id", "name", "input"}]}
  {"role": "tool", "tool_call_id": str, "name": str, "content": str}
"""
import json, os, uuid
from dataclasses import dataclass, field


@dataclass
class Reply:
    text: str = ""
    tool_calls: list = field(default_factory=list)


class Brain:
    def __init__(self, provider=None, model=None, max_tokens=4096, base_url=None):
        self.max_tokens = max_tokens
        self.switch(provider or os.getenv("AGENT_PROVIDER", "anthropic"), model or os.getenv("AGENT_MODEL"), base_url)

    usage = None

    def switch(self, provider, model=None, base_url=None):
        """anthropic (Claude) | ollama | openai (any OpenAI-compatible server: llama.cpp llama-server, LM Studio, vLLM)"""
        self.provider = provider.lower()
        self.model = model or {"anthropic": "claude-sonnet-4-5", "ollama": "llama3.1"}.get(self.provider, "local")
        self.base_url = base_url or os.getenv("OPENAI_BASE_URL", "http://localhost:8080/v1")
        if self.provider == "anthropic":
            import anthropic
            self.client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY

    def chat(self, system, messages, tools, temperature=None):
        self._temp = temperature
        if self.usage is None:
            self.usage = {"input": 0, "output": 0, "calls": 0}
        self.usage["calls"] += 1
        if self.provider == "anthropic":
            return self._anthropic(system, messages, tools)
        if self.provider == "ollama":
            return self._ollama(system, messages, tools)
        if self.provider == "openai":
            return self._openai(system, messages, tools)
        raise ValueError(f"Unknown provider: {self.provider}")

    # ---- Anthropic (Claude) ----
    def _anthropic(self, system, messages, tools):
        out = []
        for m in messages:
            if m["role"] == "user":
                out.append({"role": "user", "content": m["content"]})
            elif m["role"] == "assistant":
                blocks = []
                if m.get("content"):
                    blocks.append({"type": "text", "text": m["content"]})
                for c in m.get("tool_calls") or []:
                    blocks.append({"type": "tool_use", "id": c["id"], "name": c["name"], "input": c["input"]})
                out.append({"role": "assistant", "content": blocks or [{"type": "text", "text": "..."}]})
            elif m["role"] == "tool":
                block = {"type": "tool_result", "tool_use_id": m["tool_call_id"], "content": m["content"]}
                if out and out[-1]["role"] == "user" and isinstance(out[-1]["content"], list):
                    out[-1]["content"].append(block)  # merge consecutive tool results
                else:
                    out.append({"role": "user", "content": [block]})
        kwargs = dict(model=self.model, max_tokens=self.max_tokens, system=system, messages=out)
        if getattr(self, "_temp", None) is not None:
            kwargs["temperature"] = self._temp
        if tools:
            kwargs["tools"] = tools
        resp = self.client.messages.create(**kwargs)
        u = getattr(resp, "usage", None)
        if u:
            self.usage["input"] += getattr(u, "input_tokens", 0) or 0
            self.usage["output"] += getattr(u, "output_tokens", 0) or 0
        reply = Reply()
        for b in resp.content:
            if b.type == "text":
                reply.text += b.text
            elif b.type == "tool_use":
                reply.tool_calls.append({"id": b.id, "name": b.name, "input": b.input or {}})
        return reply

    # ---- Ollama (local, private, free) ----
    def _ollama(self, system, messages, tools):
        import requests
        out = [{"role": "system", "content": system}]
        for m in messages:
            if m["role"] == "assistant":
                msg = {"role": "assistant", "content": m.get("content") or ""}
                if m.get("tool_calls"):
                    msg["tool_calls"] = [{"function": {"name": c["name"], "arguments": c["input"]}}
                                         for c in m["tool_calls"]]
                out.append(msg)
            elif m["role"] == "tool":
                out.append({"role": "tool", "content": m["content"]})
            else:
                out.append({"role": "user", "content": m["content"]})
        body = {"model": self.model, "messages": out, "stream": False,
                "options": {"temperature": self._temp} if getattr(self, "_temp", None) is not None else {},
                "tools": [{"type": "function", "function": {
                    "name": t["name"], "description": t["description"],
                    "parameters": t["input_schema"]}} for t in tools]}
        url = os.getenv("OLLAMA_URL", "http://localhost:11434") + "/api/chat"
        full = requests.post(url, json=body, timeout=300).json()
        self.usage["input"] += full.get("prompt_eval_count", 0) or 0
        self.usage["output"] += full.get("eval_count", 0) or 0
        data = full["message"]
        reply = Reply(text=data.get("content") or "")
        for c in data.get("tool_calls") or []:
            args = c["function"].get("arguments") or {}
            if isinstance(args, str):
                args = json.loads(args or "{}")
            reply.tool_calls.append({"id": "call_" + uuid.uuid4().hex[:8],
                                     "name": c["function"]["name"], "input": args})
        return reply

    # ---- OpenAI-compatible (llama.cpp llama-server --jinja, LM Studio, vLLM, Cline-compatible servers) ----
    def _openai(self, system, messages, tools):
        import requests
        out = [{"role": "system", "content": system}]
        for m in messages:
            if m["role"] == "assistant":
                msg = {"role": "assistant", "content": m.get("content") or ""}
                if m.get("tool_calls"):
                    msg["tool_calls"] = [{"id": c["id"], "type": "function",
                                          "function": {"name": c["name"], "arguments": json.dumps(c["input"])}}
                                         for c in m["tool_calls"]]
                out.append(msg)
            elif m["role"] == "tool":
                out.append({"role": "tool", "tool_call_id": m["tool_call_id"], "content": m["content"]})
            else:
                out.append({"role": "user", "content": m["content"]})
        body = {"model": self.model, "messages": out, "max_tokens": self.max_tokens}
        if getattr(self, "_temp", None) is not None:
            body["temperature"] = self._temp
        if tools:
            body["tools"] = [{"type": "function", "function": {"name": t["name"], "description": t["description"],
                                                               "parameters": t["input_schema"]}} for t in tools]
        headers = {"Authorization": "Bearer " + (getattr(self, "api_key", None) or os.getenv("OPENAI_API_KEY", "none"))}
        full = requests.post(self.base_url.rstrip("/") + "/chat/completions", json=body, headers=headers,
                             timeout=900).json()
        us = full.get("usage") or {}
        self.usage["input"] += us.get("prompt_tokens", 0) or 0
        self.usage["output"] += us.get("completion_tokens", 0) or 0
        data = full["choices"][0]["message"]
        reply = Reply(text=data.get("content") or "")
        for c in data.get("tool_calls") or []:
            args = c["function"].get("arguments") or "{}"
            reply.tool_calls.append({"id": c.get("id") or "call_" + uuid.uuid4().hex[:8], "name": c["function"]["name"],
                                     "input": json.loads(args) if isinstance(args, str) else args})
        return reply
