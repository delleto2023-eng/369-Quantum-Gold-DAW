"""The team: Big Tony routes every request to the right specialist + skill automatically.
Everything comes from agents.json (who) + catalog.STACKS (what tools) + skills/ (how).
"""
import json
from .loop import Agent
from .tools import ToolRegistry
from .catalog import tools_for, describe


def load_config(path="agents.json"):
    return json.loads(__import__("pathlib").Path(path).read_text(encoding="utf-8"))


def agent_tools(a, registry):
    """Behavior: an agent whose max_risk is 'safe' never even sees risky tools."""
    reg = tools_for(a["stacks"], registry)
    if a.get("attributes", {}).get("max_risk") == "safe":
        reg = reg.subset([n for n, t in reg.tools.items() if t.risk == "safe"])
    return reg


def all_agents(cfg):
    """Core 12 (Metatron's Cube) + the Studio Circle from 369 Super DAW Studio."""
    out = dict(cfg["agents"])
    for ring in cfg.get("rings", []):
        out.update(ring["agents"])
    return out


def build_specialists(cfg, brain, registry, guard, memory):
    return {key: Agent(a.get("display", key.replace("_", " ").title()), a["role"], brain, agent_tools(a, registry), guard, memory,
                       a.get("attributes"), a.get("behaviors"))
            for key, a in all_agents(cfg).items()}


def build_team(brain, registry, guard, memory, library, cfg=None):
    cfg = cfg or load_config()
    team = build_specialists(cfg, brain, registry, guard, memory)
    sup_cfg = cfg["supervisor"]
    sup_tools = tools_for(sup_cfg.get("stacks", []), registry)

    @sup_tools.add("delegate", "Hand a focused step to a specialist and get their result back. "
                   "Optionally attach a skill playbook and context (earlier results, file paths).",
                   {"specialist": {"type": "string", "enum": list(team)},
                    "task": {"type": "string", "description": "Clear, self-contained instructions."},
                    "skill": {"type": "string", "description": "Optional skill name to follow."},
                    "context": {"type": "string", "description": "Optional results/paths from earlier steps."}},
                   ["specialist", "task"])
    def delegate(specialist, task, skill="", context=""):
        prompt = task
        if skill:
            s = library.get(skill)
            owner = s.get("agent")
            if owner in team and owner != specialist:
                print(f"   (skill {skill} belongs to {owner}; routing there)")
                specialist = owner
            prompt = library.brief(skill) + f"\n\nTask: {task}"
        if context:
            prompt += f"\n\nContext from the team:\n{context}"
        print(f"\n== {sup_cfg['name']} -> {specialist}{' [' + skill + ']' if skill else ''} ==")
        result, _ = team[specialist].run(prompt)
        mind = getattr(guard, "mind", None)
        if mind:
            mind.workspace.post(specialist, skill or "result", result[:300])
        return result

    roster = ""
    for triad, members in cfg.get("triads", {"Team": list(cfg["agents"])}).items():
        roster += f"\n{triad}:\n" + "\n".join(
            f"  {cfg['agents'][k].get('number', '')}. {k} [{cfg['agents'][k].get('attributes', {}).get('geometry', '')}]: "
            f"{cfg['agents'][k]['role'].split('.')[0]}; strengths: "
            f"{', '.join(cfg['agents'][k].get('attributes', {}).get('strengths', []))}; hands off to: "
            f"{', '.join(cfg['agents'][k].get('behaviors', {}).get('handoff_to', []))}" for k in members)
    for st in cfg.get("rings", []):
        roster += f"\n\n{st['name']} ({st['note']}):"
        for ph, members in st["phases"].items():
            roster += f"\n{ph}:\n" + "\n".join(
                f"  {st['agents'][k]['number']}. {k}: {st['agents'][k]['role'].split('.')[0]}" for k in members)
    if cfg.get("principle"):
        roster = cfg["principle"] + "\n" + roster
    role = (sup_cfg["role"] + f"\n\nYour specialists:\n{roster}\n\nSkill playbooks:\n{library.catalog()}"
            f"\n\nTool stacks:\n{describe()}")
    def hint(task):
        m = library.match(task)
        return ("Skills that match this request (use them unless clearly wrong): " + ", ".join(
            f"{n} -> {library.get(n).get('agent')}" for n in m)) if m else ""

    sup = Agent(sup_cfg["name"], role, brain, sup_tools, guard, memory,
                sup_cfg.get("attributes"), sup_cfg.get("behaviors"), hint_fn=hint)
    sup.team = team
    return sup
