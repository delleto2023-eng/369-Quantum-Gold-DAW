"""Tony AI Collective tools (from the Jewel Studio / AURA FL Gold DAW chat).
chord_progression  Melody & Harmony Wizard: chords for a key + mood (incl. minor 9th velvet, phrygian dark) -> MIDI
synth_patch        Sonic Alchemist: JewelSynth patch (wave, cutoff, resonance, ADSR, FX) saved as JSON + audition WAV
song_structure     Song Arranger: intro/verse/hook/bridge/drop map with bars and timestamps (golden-ratio aware)
design_guidelines  Design Agent: 24K gold / jewel UI tokens (colors, fonts, spacing, components) as JSON + CSS
"""
import json, math
from pathlib import Path

MOODS = {"dark": ("minor", [0, 5, 3, 4], [0, 3, 7, 10]), "velvet": ("minor", [1, 4, 0, 5], [0, 3, 7, 10, 14]),
         "phrygian": ("minor", [0, 1, 0, 6], [0, 3, 7]), "happy": ("major", [0, 4, 5, 3], [0, 4, 7]),
         "soulful": ("major", [3, 2, 1, 0], [0, 4, 7, 11]), "epic": ("minor", [0, 5, 2, 6], [0, 3, 7]),
         "dreamy": ("major", [0, 3, 0, 3], [0, 4, 7, 11, 14])}
SC = {"major": [0, 2, 4, 5, 7, 9, 11], "minor": [0, 2, 3, 5, 7, 8, 10]}
NN = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
FORMS = {"trap": [("Intro", 4), ("Hook", 8), ("Verse 1", 16), ("Hook", 8), ("Verse 2", 16), ("Hook", 8), ("Outro", 4)],
         "pop": [("Intro", 4), ("Verse 1", 8), ("Pre-Chorus", 4), ("Chorus", 8), ("Verse 2", 8), ("Pre-Chorus", 4), ("Chorus", 8), ("Bridge", 8), ("Chorus", 8), ("Outro", 4)],
         "edm": [("Intro", 16), ("Build", 8), ("Drop", 16), ("Break", 8), ("Build", 8), ("Drop", 16), ("Outro", 8)],
         "rnb": [("Intro", 4), ("Verse 1", 16), ("Hook", 8), ("Verse 2", 16), ("Hook", 8), ("Bridge", 8), ("Hook", 8), ("Outro", 4)],
         "healing": [("Arrival", 8), ("Settle", 16), ("Deepen", 24), ("Still Point", 16), ("Return", 8)]}


def build_tony_tools(reg, guard):
    S, N = {"type": "string"}, {"type": "number"}

    @reg.add("chord_progression", "Write a chord progression for a key and mood (" + ", ".join(MOODS) + ") and save it as MIDI.",
             {"key": S, "mood": S, "bars": {"type": "integer"}, "bpm": N}, ["key"])
    def chord_progression(key="C", mood="dark", bars=8, bpm=140):
        from .studio import _write_midi, _key_root
        root, _ = _key_root(key)
        scale, degs, shape = MOODS.get(mood, MOODS["dark"])
        names, notes, beat = [], [], 60 / float(bpm)
        for b in range(int(bars)):
            d = degs[b % len(degs)]
            r = 48 + root + SC[scale][d % 7]
            names.append(NN[r % 12] + ("m" if scale == "minor" and d in (0, 3, 4) else "") + ("9" if len(shape) > 4 else "7" if len(shape) == 4 else ""))
            for iv in shape:
                notes.append({"midi": r + iv, "start": b * 4 * beat, "dur": 4 * beat * 0.95})
        out = guard.safe_path(f"studio/midi/{NN[root]}_{mood}_chords.mid"); out.parent.mkdir(parents=True, exist_ok=True)
        _write_midi(out, sorted(notes, key=lambda n: n["start"]), float(bpm))
        return f"{' - '.join(names)} ({mood}, {NN[root]} {scale}). MIDI: {out.relative_to(guard.workspace)}"

    @reg.add("synth_patch", "Design a JewelSynth patch and render a 2-second audition note. wave: saw, square, sine, triangle.",
             {"name": S, "wave": S, "cutoff": N, "resonance": N, "attack": N, "decay": N, "sustain": N, "release": N, "note": S}, ["name"])
    def synth_patch(name, wave="saw", cutoff=2400, resonance=0.3, attack=0.01, decay=0.3, sustain=0.6, release=0.4, note="C4"):
        import numpy as np
        from .studio import _write_wav, SR
        m = NN.index(note[:-1].upper()) + 12 * (int(note[-1]) + 1) if note[:-1].upper() in NN else 60
        hz = 440 * 2 ** ((m - 69) / 12)
        t = np.arange(int(SR * 2.0)) / SR
        ph = (t * hz) % 1
        osc = {"saw": 2 * ph - 1, "square": np.sign(np.sin(2 * np.pi * hz * t)), "sine": np.sin(2 * np.pi * hz * t),
               "triangle": 2 * np.abs(2 * ph - 1) - 1}.get(wave, 2 * ph - 1)
        a = max(float(attack), 1e-3); d = max(float(decay), 1e-3); rl = max(float(release), 1e-3); s = float(sustain)
        env = np.piecewise(t, [t < a, (t >= a) & (t < a + d), (t >= a + d) & (t < 2 - rl), t >= 2 - rl],
                           [lambda x: x / a, lambda x: 1 - (1 - s) * (x - a) / d, s, lambda x: s * (2 - x) / rl])
        alpha = 1 - math.exp(-2 * math.pi * float(cutoff) / SR)
        y = np.zeros_like(osc); prev = 0.0
        for i, v in enumerate(osc):
            prev += alpha * (v - prev); y[i] = prev
        y = y * env * 0.6
        base = guard.safe_path(f"studio/patches/{name.replace(' ', '_')}"); base.parent.mkdir(parents=True, exist_ok=True)
        patch = dict(name=name, wave=wave, cutoff=cutoff, resonance=resonance, adsr=[attack, decay, sustain, release])
        base.with_suffix(".jewelpreset.json").write_text(json.dumps(patch, indent=1))
        _write_wav(base.with_suffix(".wav"), y)
        return f"Patch '{name}' saved: {base.with_suffix('.jewelpreset.json').relative_to(guard.workspace)} (audition {base.with_suffix('.wav').name})"

    @reg.add("song_structure", "Song Arranger: map a song's sections with bars and start times. form: " + ", ".join(FORMS), {"form": S, "bpm": N}, ["form"])
    def song_structure(form="trap", bpm=140):
        secs, t, out = FORMS.get(form, FORMS["trap"]), 0.0, []
        bar = 240 / float(bpm)
        for n, b in secs:
            out.append(f"{int(t // 60)}:{int(t % 60):02d}  {n} ({b} bars)"); t += b * bar
        return "\n".join(out) + f"\nTotal {int(t // 60)}:{int(t % 60):02d} at {bpm} BPM"

    @reg.add("design_guidelines", "Design Agent: write 24K gold + jewel UI design tokens (colors, fonts, spacing, components) as JSON and CSS.",
             {"theme": S}, [])
    def design_guidelines(theme="24k gold"):
        tokens = {"theme": theme, "colors": {"bg": "#0B0B10", "panel": "#14141c", "gold": "#D4AF37", "gold_light": "#FFD76A",
                  "silver": "#C0C0C8", "ruby": "#E0115F", "emerald": "#50C878", "sapphire": "#0F52BA", "amethyst": "#9966CC", "diamond": "#B9F2FF"},
                  "fonts": {"display": "Cinzel, serif", "body": "Inter, system-ui, sans-serif", "mono": "JetBrains Mono, monospace"},
                  "spacing": [3, 6, 9, 18, 27, 36], "radius": 9,
                  "components": {"button": "gold gradient, dark text, glow on hover", "fader": "long-throw brushed silver", "led": "jewel color per track"}}
        out = guard.safe_path("design/design_guidelines.json"); out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(tokens, indent=1))
        css = ":root{" + "".join(f"--{k}:{v};" for k, v in tokens["colors"].items()) + "--radius:9px;}"
        out.with_suffix(".css").write_text(css)
        return f"Design tokens saved: design/design_guidelines.json and .css (spacing on 3-6-9)"

    return reg
