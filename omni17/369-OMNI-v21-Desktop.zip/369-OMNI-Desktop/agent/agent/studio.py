"""Studio stack - the 369 Super DAW Studio agents' tools, rebuilt for the Python agent.
forge_song        369 Song Forge: offline beat/song from 15 genre templates (drums, 808/bass, chords) -> WAV
hum_to_midi       Hum to MIDI: find notes, key and tempo in a hummed WAV -> .mid + note list
remix_song        Remix Generator: 12 styles (slowed+reverb, sped up, 8D, bass boosted, lo-fi, chopped & screwed...)
master_track      AI Mastering: Spotify, Apple, SoundCloud, YouTube, Club, Podcast, Film, Healing targets
loudness_meter    Pro Meters: integrated LUFS, true peak, loudness range
sort_sound_pack   Sound Packs: Shield-scan, then sort into 808s, Kicks, Snares, Claps, Hi Hats... folders
sample_doctor     Sample Doctor: root note, peak normalize, clipping check -> fixed copy
studio_command    BT2 action tags: [[bpm:140]] [[key:A Minor]] [[song:summer trap]] [[play:file]] [[stop]] [[status]]
shield_scan       369 Shield: block and quarantine dangerous files (programs, scripts, zip bombs)
"""
import json, math, os, re, shutil, subprocess, wave, zipfile
from pathlib import Path

SR = 44100
NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
TEMPLATES = {  # bpm, scale, chord degrees, kick, snare, hat (16 steps)
    "trap": (140, "minor", [0, 5, 3, 4], "x.....x...x.....", "....x.......x...", "x.x.x.x.xxx.x.xx"),
    "drill": (142, "minor", [0, 3, 5, 4], "x......x..x.....", "....x.......x...", "x..x..x.x..x..x."),
    "rnb": (90, "minor", [0, 5, 2, 6], "x.......x.x.....", "....x.......x...", "x.x.x.x.x.x.x.x."),
    "afrobeat": (105, "major", [0, 4, 5, 3], "x...x...x...x...", "...x..x....x..x.", "x.xxx.xxx.xxx.xx"),
    "amapiano": (113, "minor", [0, 3, 6, 4], "x...x...x...x...", "......x.......x.", "..x...x...x...x."),
    "lofi": (80, "major", [1, 4, 0, 5], "x......x..x.....", "....x.......x...", "x.x.x.x.x.x.x.x."),
    "gospel": (75, "major", [0, 3, 4, 0], "x.......x.......", "....x.......x...", "x.x.x.x.x.x.x.x."),
    "pop": (120, "major", [0, 4, 5, 3], "x...x...x...x...", "....x.......x...", "x.x.x.x.x.x.x.x."),
    "house": (124, "minor", [0, 5, 6, 4], "x...x...x...x...", "....x.......x...", "..x...x...x...x."),
    "healing": (60, "major", [0, 3, 4, 0], "................", "................", "................"),
    "cinematic": (90, "minor", [0, 5, 2, 6], "x.......x.......", "........x.......", "................"),
    "country": (100, "major", [0, 3, 4, 0], "x.......x.......", "....x.......x...", "x.x.x.x.x.x.x.x."),
    "reggae": (75, "major", [0, 3, 4, 3], "........x.......", "........x.......", "..x...x...x...x."),
    "reggaeton": (95, "minor", [0, 5, 3, 4], "x...x...x...x...", "...x..x....x..x.", "x.x.x.x.x.x.x.x."),
    "rock": (120, "major", [0, 4, 5, 3], "x.x.....x.x.....", "....x.......x...", "x.x.x.x.x.x.x.x."),
}
SCALES = {"major": [0, 2, 4, 5, 7, 9, 11], "minor": [0, 2, 3, 5, 7, 8, 10]}
REMIX = {
    "slowed_reverb": "aresample=44100,asetrate=44100*0.85,aresample=44100,aecho=0.8:0.88:60:0.4",
    "sped_up": "aresample=44100,asetrate=44100*1.25,aresample=44100",
    "nightcore": "aresample=44100,asetrate=44100*1.3,aresample=44100,bass=g=3",
    "chopped_screwed": "aresample=44100,asetrate=44100*0.75,aresample=44100,aecho=0.8:0.8:120:0.3",
    "8d": "apulsator=hz=0.125",
    "bass_boosted": "bass=g=10,alimiter=limit=0.95",
    "lofi": "lowpass=f=3200,highpass=f=120,aecho=0.6:0.6:30:0.2,volume=0.9",
    "reverse_ambient": "areverse,aecho=0.8:0.9:1000:0.5",
    "instrumental": "pan=stereo|c0=c0-c1|c1=c1-c0",
    "telephone": "highpass=f=300,lowpass=f=3400",
    "underwater": "lowpass=f=600,aecho=0.8:0.7:40:0.5",
    "half_time": "aresample=44100,atempo=0.5",
}
TARGETS = {"spotify": (-14, -1), "apple": (-16, -1), "soundcloud": (-14, -1), "youtube": (-14, -1),
           "club": (-9, -0.5), "podcast": (-16, -1.5), "film": (-24, -2), "healing": (-18, -1.5)}
PACK_RULES = [("808s", r"808"), ("Open Hats", r"open|\boh\b"), ("Hi Hats", r"hat|\bhh\b|hihat"), ("Kicks", r"kick|\bbd\b"),
              ("Snares", r"snare|\bsd\b"), ("Claps", r"clap"), ("Rims", r"rim"), ("Snaps", r"snap"), ("Cymbals", r"cym|crash|ride"),
              ("Percs", r"perc|conga|bongo|shaker|tamb"), ("Vox", r"vox|vocal|chant"), ("FX", r"fx|riser|impact|sweep|noise"),
              ("Loops", r"loop"), ("Melodic", r"melod|keys|piano|synth|guitar|pad|bell|pluck|lead")]
AUDIO = {".wav", ".mp3", ".flac", ".aif", ".aiff", ".ogg", ".m4a", ".mid", ".midi"}
DANGER_EXT = {".exe", ".bat", ".cmd", ".com", ".scr", ".ps1", ".vbs", ".vbe", ".js", ".jse", ".jar", ".msi", ".dll", ".sh",
              ".app", ".lnk", ".hta", ".reg", ".pif", ".cpl", ".wsf", ".scf", ".docm", ".xlsm"}


def _np():
    import numpy as np
    return np


def _write_wav(path, data, sr=SR):
    np = _np()
    data = np.clip(data, -1, 1)
    if data.ndim == 1:
        data = np.stack([data, data], 1)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((data * 32767).astype("<i2").tobytes())


def _read_wav(path):
    np = _np()
    with wave.open(str(path), "rb") as w:
        sr, ch, sw, n = w.getframerate(), w.getnchannels(), w.getsampwidth(), w.getnframes()
        raw = w.readframes(n)
    dt = {1: np.uint8, 2: "<i2", 4: "<i4"}[sw]
    x = np.frombuffer(raw, dtype=dt).astype(float)
    x = (x - 128) / 128 if sw == 1 else x / float(2 ** (8 * sw - 1))
    x = x.reshape(-1, ch).mean(1)
    return x, sr


def _note_hz(midi):
    return 440.0 * 2 ** ((midi - 69) / 12)


def _hz_note(hz):
    m = int(round(69 + 12 * math.log2(hz / 440.0)))
    return m, f"{NOTE_NAMES[m % 12]}{m // 12 - 1}"


def _key_root(key):
    m = re.match(r"\s*([A-Ga-g])([#b]?)\s*(major|minor|maj|min|m)?", key or "C minor")
    if not m:
        return 0, "minor"
    root = NOTE_NAMES.index(m.group(1).upper()) + (1 if m.group(2) == "#" else -1 if m.group(2) == "b" else 0)
    q = (m.group(3) or "minor").lower()
    return root % 12, "major" if q.startswith("maj") else "minor"


def forge(genre="trap", bpm=None, key="C minor", bars=8, out="song.wav"):
    np = _np()
    g = TEMPLATES.get(genre.lower(), TEMPLATES["trap"])
    bpm = float(bpm or g[0])
    root, scale = _key_root(key) if key else (0, g[1])
    steps = SCALES[scale]
    step_len = 60 / bpm / 4
    total = int(SR * step_len * 16 * bars)
    mix = np.zeros(total + SR)
    t = lambda d: np.arange(int(SR * d)) / SR
    rng = np.random.default_rng(369)
    kick = np.sin(2 * np.pi * (50 + 120 * np.exp(-t(0.25) * 30)) * t(0.25)) * np.exp(-t(0.25) * 9)
    snare = rng.uniform(-1, 1, len(t(0.18))) * np.exp(-t(0.18) * 22) * 0.6 + np.sin(2 * np.pi * 190 * t(0.18)) * np.exp(-t(0.18) * 30) * 0.4
    hn = rng.uniform(-1, 1, len(t(0.05)))
    hat = np.diff(hn, prepend=0) * np.exp(-t(0.05) * 80) * 0.25

    def place(sample, pos, gain=1.0):
        i = int(pos * SR)
        j = min(i + len(sample), len(mix))
        mix[i:j] += sample[: j - i] * gain
    for b in range(bars):
        deg = g[2][b % len(g[2])]
        chord_root = 48 + root + steps[deg % 7]
        bar_start = b * 16 * step_len
        dur = 16 * step_len
        tt = t(dur)
        pad = sum(np.sin(2 * np.pi * _note_hz(chord_root + 12 + steps[(deg + k) % 7] - steps[deg % 7] + (12 if (deg + k) >= 7 else 0)) * tt) for k in (0, 2, 4))
        pad *= 0.07 * np.minimum(1, tt * 4) * np.minimum(1, (dur - tt) * 4)
        place(pad, bar_start)
        bass = np.sin(2 * np.pi * _note_hz(chord_root - 12) * tt) * np.exp(-tt * (0.6 if genre != "healing" else 0.05)) * 0.35
        place(bass, bar_start)
        for s in range(16):
            pos = bar_start + s * step_len
            if g[3][s] == "x": place(kick, pos, 0.9)
            if g[4][s] == "x": place(snare, pos, 0.7)
            if g[5][s] == "x": place(hat, pos, 0.6 + 0.2 * (s % 2 == 0))
    mix = mix[:total]
    mix = mix / (np.max(np.abs(mix)) + 1e-9) * 0.89
    _write_wav(out, mix)
    return {"genre": genre, "bpm": bpm, "key": f"{NOTE_NAMES[root]} {scale}", "bars": bars, "seconds": round(total / SR, 1)}


def _pitch_track(x, sr, frame=2048, hop=512):
    np = _np()
    out = []
    thresh = max(0.02, float(np.sqrt(np.mean(x ** 2))) * 0.5)
    lo, hi = int(sr / 1000), int(sr / 70)
    for i in range(0, len(x) - frame, hop):
        f = x[i:i + frame] * np.hanning(frame)
        if np.sqrt(np.mean(f ** 2)) < thresh * 0.5:
            out.append(None); continue
        ac = np.correlate(f, f, "full")[frame - 1:]
        ac[:lo] = 0
        lag = int(np.argmax(ac[lo:hi])) + lo
        out.append(sr / lag if ac[lag] > 0.3 * ac[0] else None)
    return out, hop / sr


def _write_midi(path, notes, bpm):
    def vlq(n):
        b = [n & 0x7F]
        while n > 127:
            n >>= 7; b.insert(0, (n & 0x7F) | 0x80)
        return bytes(b)
    tpq = 480
    ev, last = bytearray(), 0
    tempo = int(60_000_000 / bpm)
    ev += vlq(0) + bytes([0xFF, 0x51, 0x03]) + tempo.to_bytes(3, "big")
    for n in notes:
        on = int(n["start"] * bpm / 60 * tpq); off = int((n["start"] + n["dur"]) * bpm / 60 * tpq)
        ev += vlq(max(on - last, 0)) + bytes([0x90, n["midi"], 96]); last = on
        ev += vlq(max(off - last, 0)) + bytes([0x80, n["midi"], 0]); last = off
    ev += vlq(0) + bytes([0xFF, 0x2F, 0x00])
    data = b"MThd" + (6).to_bytes(4, "big") + (0).to_bytes(2, "big") + (1).to_bytes(2, "big") + tpq.to_bytes(2, "big")
    data += b"MTrk" + len(ev).to_bytes(4, "big") + bytes(ev)
    Path(path).write_bytes(data)


def hum(path, out_mid):
    np = _np()
    x, sr = _read_wav(path)
    track, dt = _pitch_track(x, sr)
    notes, cur = [], None
    for i, hz in enumerate(track):
        m = _hz_note(hz)[0] if hz else None
        if cur and m == cur["midi"]:
            cur["dur"] += dt
        else:
            if cur and cur["dur"] >= 0.08:
                notes.append(cur)
            cur = {"midi": m, "start": i * dt, "dur": dt} if m else None
    if cur and cur["dur"] >= 0.08:
        notes.append(cur)
    if not notes:
        return {"notes": [], "key": None, "bpm": None}
    major = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88]
    minor = [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]
    hist = np.zeros(12)
    for n in notes:
        hist[n["midi"] % 12] += n["dur"]
    best = max(((np.corrcoef(hist, np.roll(p, r))[0, 1] if hist.std() else 0, r, q) for r in range(12)
                for q, p in (("major", major), ("minor", minor))), key=lambda z: z[0])
    starts = [n["start"] for n in notes]
    ioi = np.diff(starts) if len(starts) > 1 else np.array([0.5])
    beat = float(np.median(ioi)) or 0.5
    bpm = 60 / beat
    while bpm < 70: bpm *= 2
    while bpm > 180: bpm /= 2
    _write_midi(out_mid, notes, bpm)
    return {"notes": [f"{NOTE_NAMES[n['midi'] % 12]}{n['midi'] // 12 - 1} ({n['dur']:.2f}s)" for n in notes][:64],
            "key": f"{NOTE_NAMES[best[1]]} {best[2]}", "bpm": round(bpm)}


def shield(paths, quarantine):
    """Return (safe, blocked) lists; blocked files are moved to quarantine."""
    safe, blocked = [], []
    Path(quarantine).mkdir(parents=True, exist_ok=True)
    for p in paths:
        p = Path(p)
        reason = None
        ext = p.suffix.lower()
        try:
            head = p.read_bytes()[:4]
        except Exception:
            head = b""
        if ext in DANGER_EXT:
            reason = f"dangerous file type {ext}"
        elif head[:2] == b"MZ":
            reason = "Windows program disguised as another file"
        elif head == b"\x7fELF":
            reason = "Linux program disguised as another file"
        elif head[:2] == b"#!":
            reason = "script disguised as another file"
        elif ext == ".zip":
            try:
                with zipfile.ZipFile(p) as z:
                    size = sum(i.file_size for i in z.infolist()); packed = max(sum(i.compress_size for i in z.infolist()), 1)
                    if size / packed > 100 or size > 4 * 2**30:
                        reason = "possible zip bomb"
                    elif any(Path(i.filename).suffix.lower() in DANGER_EXT for i in z.infolist()):
                        reason = "zip contains programs or scripts"
            except zipfile.BadZipFile:
                reason = "broken or fake zip"
        if reason:
            dest = Path(quarantine) / p.name
            shutil.move(str(p), dest)
            blocked.append({"file": p.name, "reason": reason})
        else:
            safe.append(str(p))
    return safe, blocked


def build_studio_tools(reg, guard, ffmpeg):
    S, N = {"type": "string"}, {"type": "number"}
    state_path = lambda: guard.safe_path("studio/project.json")

    def state():
        p = state_path()
        return json.loads(p.read_text()) if p.exists() else {"title": "369 Session", "bpm": 140, "key": "C minor", "songs": []}

    def save(st):
        p = state_path(); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(st, indent=1))

    @reg.add("forge_song", "369 Song Forge: make an original beat/song offline from a genre template (" + ", ".join(TEMPLATES)
             + ") with drums, 808/bass and chords. Saves a WAV.", {"genre": S, "bpm": N, "key": S, "bars": {"type": "integer"}, "output": S}, ["genre"])
    def forge_song(genre, bpm=None, key="", bars=8, output=""):
        st = state()
        out = guard.safe_path(output or f"studio/songs/{genre}_{int(bpm or TEMPLATES.get(genre, TEMPLATES['trap'])[0])}bpm.wav")
        out.parent.mkdir(parents=True, exist_ok=True)
        info = forge(genre, bpm, key or st.get("key"), int(bars), out)
        st["songs"].append({"file": str(out.relative_to(guard.workspace)), **info}); save(st)
        return f"Forged {info['genre']} at {info['bpm']} BPM in {info['key']} ({info['seconds']}s): {out.relative_to(guard.workspace)}"

    @reg.add("hum_to_midi", "Hum to MIDI: find the notes, key and tempo in a hummed/sung WAV and save a .mid file for any DAW.", {"audio": S}, ["audio"])
    def hum_to_midi(audio):
        src = guard.safe_path(audio)
        out = src.with_suffix(".mid")
        r = hum(src, out)
        if not r["notes"]:
            return "No clear notes found. Hum louder and closer to the mic, one note at a time."
        return f"Found {len(r['notes'])} notes, key {r['key']}, about {r['bpm']} BPM. MIDI: {out.relative_to(guard.workspace)}\nNotes: {', '.join(r['notes'][:24])}"

    @reg.add("remix_song", "Remix Generator: make remixes of a song. styles = comma list of: " + ", ".join(REMIX), {"audio": S, "styles": S}, ["audio", "styles"])
    def remix_song(audio, styles):
        src = guard.safe_path(audio)
        done = []
        for s in [x.strip().lower().replace(" ", "_").replace("+", "") for x in styles.split(",") if x.strip()][:6]:
            s = {"slowed_reverb": "slowed_reverb", "slowed__reverb": "slowed_reverb", "slowed": "slowed_reverb"}.get(s, s)
            if s not in REMIX:
                done.append(f"{s}: unknown style"); continue
            out = guard.safe_path(f"studio/remixes/{src.stem}_{s}.wav"); out.parent.mkdir(parents=True, exist_ok=True)
            r = subprocess.run([ffmpeg(), "-y", "-i", str(src), "-af", REMIX[s], "-ar", "44100", str(out)], capture_output=True, text=True, timeout=600)
            done.append(f"{s}: {out.relative_to(guard.workspace)}" if r.returncode == 0 else f"{s}: failed ({r.stderr[-200:]})")
        return "\n".join(done)

    def meter(path):
        r = subprocess.run([ffmpeg(), "-nostats", "-i", str(path), "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True, timeout=600)
        txt = r.stderr[r.stderr.rfind("Summary"):]
        g = lambda k: (re.search(k + r":\s*(-?[\d.]+|-inf)", txt) or [None, "?"])[1]
        return {"lufs": g("I"), "lra": g("LRA"), "true_peak": g("Peak")}

    @reg.add("loudness_meter", "Pro Meters: integrated loudness (LUFS), loudness range and true peak of a track.", {"audio": S}, ["audio"])
    def loudness_meter(audio):
        m = meter(guard.safe_path(audio))
        return f"Integrated {m['lufs']} LUFS, range {m['lra']} LU, true peak {m['true_peak']} dBFS"

    @reg.add("master_track", "AI Mastering to a target: " + ", ".join(f"{k} ({v[0]} LUFS)" for k, v in TARGETS.items())
             + ". style: warm, balanced or loud.", {"audio": S, "target": S, "style": S}, ["audio"])
    def master_track(audio, target="spotify", style="balanced"):
        src = guard.safe_path(audio)
        lufs, tp = TARGETS.get(target.lower(), TARGETS["spotify"])
        tone = {"warm": "bass=g=2,treble=g=-1,", "loud": "acompressor=threshold=-18dB:ratio=3:attack=10:release=120,", "balanced": "acompressor=threshold=-20dB:ratio=2,"}.get(style, "")
        out = guard.safe_path(f"studio/masters/{src.stem}_{target}_{style}.wav"); out.parent.mkdir(parents=True, exist_ok=True)
        r = subprocess.run([ffmpeg(), "-y", "-i", str(src), "-af", f"{tone}loudnorm=I={lufs}:TP={tp}:LRA=9", "-ar", "44100", str(out)], capture_output=True, text=True, timeout=600)
        if r.returncode:
            raise RuntimeError(r.stderr[-400:])
        m = meter(out)
        return f"Mastered for {target} ({style}): {out.relative_to(guard.workspace)} - now {m['lufs']} LUFS, peak {m['true_peak']} dBFS (target {lufs} LUFS)"

    @reg.add("shield_scan", "369 Shield: scan a file or folder; programs, scripts, disguised files and zip bombs are moved to quarantine/.", {"path": S}, ["path"])
    def shield_scan(path):
        p = guard.safe_path(path)
        files = [p] if p.is_file() else [f for f in p.rglob("*") if f.is_file()]
        safe, blocked = shield(files, guard.safe_path("quarantine"))
        lines = [f"Scanned {len(files)} files: {len(safe)} safe, {len(blocked)} blocked."]
        lines += [f"- BLOCKED {b['file']}: {b['reason']} (moved to quarantine/)" for b in blocked]
        return "\n".join(lines)

    @reg.add("sort_sound_pack", "Sound Packs: import a drum kit (zip or folder). Shield-scans it, then sorts every sound into 808s, Kicks, Snares, "
             "Claps, Hi Hats, Open Hats, Percs, Rims, Snaps, Cymbals, Vox, FX, Loops, Melodic.", {"path": S, "name": S}, ["path"])
    def sort_sound_pack(path, name=""):
        src = guard.safe_path(path)
        name = name or src.stem
        tmp = guard.safe_path(f"studio/_import_{name}")
        if tmp.exists(): shutil.rmtree(tmp)
        if src.suffix.lower() == ".zip":
            safe, blocked = shield([src], guard.safe_path("quarantine"))
            if blocked:
                return f"BLOCKED by 369 Shield: {blocked[0]['reason']}. Nothing imported."
            with zipfile.ZipFile(src) as z:
                z.extractall(tmp)
            base = tmp
        else:
            base = src
        files = [f for f in base.rglob("*") if f.is_file()]
        safe, blocked = shield(files, guard.safe_path("quarantine"))
        dest = guard.safe_path(f"sounds/packs/{name}")
        counts = {}
        for f in map(Path, safe):
            if f.suffix.lower() not in AUDIO:
                continue
            low = f.stem.lower() + " " + f.parent.name.lower()
            cat = next((c for c, rx in PACK_RULES if re.search(rx, low)), "Other")
            (dest / cat).mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, dest / cat / f.name)
            counts[cat] = counts.get(cat, 0) + 1
        if tmp.exists(): shutil.rmtree(tmp)
        txt = ", ".join(f"{k} {v}" for k, v in sorted(counts.items())) or "no audio found"
        return f"Pack '{name}' sorted into sounds/packs/{name}: {txt}." + (f" Shield blocked {len(blocked)} file(s)." if blocked else "")

    @reg.add("sample_doctor", "Sample Doctor: find a sample's root note, check clipping, and save a peak-normalized copy named with its note.", {"audio": S}, ["audio"])
    def sample_doctor(audio):
        np = _np()
        src = guard.safe_path(audio)
        x, sr = _read_wav(src)
        clipped = int(np.sum(np.abs(x) > 0.999))
        hz = [h for h in _pitch_track(x, sr)[0] if h]
        note = _hz_note(float(np.median(hz)))[1] if hz else "no clear pitch (drum/noise)"
        y = x / (np.max(np.abs(x)) + 1e-9) * 0.891
        out = src.with_name(f"{src.stem} [{note.split(' ')[0] if hz else 'perc'}] fixed.wav")
        _write_wav(out, y, sr)
        return f"Root note: {note}. Clipped samples: {clipped}. Normalized to -1 dBFS: {out.relative_to(guard.workspace)}"

    @reg.add("studio_command", "BT2 studio control with action tags: [[bpm:140]] [[key:A Minor]] [[title:Gold Nights]] [[song:summer trap]] "
             "[[play:file.wav]] [[stop]] [[status]]. Several tags can be sent at once.", {"tags": S}, ["tags"])
    def studio_command(tags):
        st, out = state(), []
        for tag in re.findall(r"\[\[([^\]]+)\]\]", tags) or [tags]:
            k, _, v = tag.partition(":"); k, v = k.strip().lower(), v.strip()
            if k == "bpm":
                st["bpm"] = max(40, min(300, int(float(v)))); out.append(f"Tempo set to {st['bpm']} BPM.")
            elif k == "key":
                st["key"] = v; out.append(f"Key set to {v}.")
            elif k == "title":
                st["title"] = v; out.append(f"Project titled {v}.")
            elif k == "song":
                genre = next((g for g in TEMPLATES if g in v.lower()), "trap")
                save(st); out.append(forge_song(genre, st["bpm"] if genre == "trap" or "bpm" in v else None, st["key"])); st = state()
            elif k == "play":
                p = guard.safe_path(v) if v else None
                if p and p.exists() and shutil.which("ffplay"):
                    subprocess.Popen(["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", str(p)]); out.append(f"Playing {v}.")
                else:
                    out.append("Nothing to play (give a file, and install ffplay).")
            elif k == "stop":
                subprocess.run(["pkill", "-f", "ffplay"], capture_output=True); out.append("Stopped.")
            elif k == "status":
                out.append(f"{st['title']}: {st['bpm']} BPM, {st['key']}, {len(st['songs'])} songs.")
            else:
                out.append(f"Unknown tag {k}.")
        save(st)
        return "\n".join(out)

    return reg
