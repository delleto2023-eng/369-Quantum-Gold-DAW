"""Sound Alchemist stack: healing tones and audio finishing (ffmpeg)."""
import json, subprocess
from .film import _ffmpeg, _run

SOLFEGGIO = {"174": "grounding", "285": "restoration", "396": "release fear", "417": "change", "432": "natural tuning",
             "528": "love / repair", "639": "connection", "741": "expression", "852": "intuition", "963": "unity"}


def build_audio_tools(reg, guard):
    S = {"type": "string"}

    @reg.add("tone_generate", "Generate a healing tone WAV. modes: pure, binaural (stereo, headphones), isochronic (pulsed). "
             "Common frequencies: " + ", ".join(f"{k} Hz {v}" for k, v in SOLFEGGIO.items()),
             {"frequency": {"type": "number"}, "seconds": {"type": "number"}, "mode": S,
              "beat_hz": {"type": "number", "description": "pulse/binaural offset, default 9"}, "output": S}, ["frequency"])
    def tone_generate(frequency, seconds=63, mode="pure", beat_hz=9, output=""):
        f, s, b = float(frequency), float(seconds), float(beat_hz)
        out = guard.safe_path(output or f"audio/{int(f)}hz_{mode}.wav")
        out.parent.mkdir(parents=True, exist_ok=True)
        fade = f"afade=t=in:d=3,afade=t=out:st={max(s - 3, 0)}:d=3"
        if mode == "binaural":
            cmd = [_ffmpeg(), "-y", "-f", "lavfi", "-i", f"sine=frequency={f}:duration={s}", "-f", "lavfi",
                   "-i", f"sine=frequency={f + b}:duration={s}", "-filter_complex", f"[0][1]amerge=inputs=2,{fade}[a]", "-map", "[a]"]
        elif mode == "isochronic":
            cmd = [_ffmpeg(), "-y", "-f", "lavfi", "-i", f"sine=frequency={f}:duration={s}",
                   "-af", f"volume='0.5*(1+sgn(sin(2*PI*{b}*t)))':eval=frame,{fade}"]
        else:
            cmd = [_ffmpeg(), "-y", "-f", "lavfi", "-i", f"sine=frequency={f}:duration={s}", "-af", fade]
        _run(cmd + ["-ar", "44100", "-c:a", "pcm_s16le", str(out)])
        return f"Made {f} Hz {mode} tone ({s}s): {out.relative_to(guard.workspace)}"

    @reg.add("audio_normalize", "Loudness-normalize audio for streaming (-14 LUFS).", {"path": S, "output": S}, ["path"])
    def audio_normalize(path, output=""):
        src = guard.safe_path(path)
        out = guard.safe_path(output or f"audio/{src.stem}_mastered.wav")
        out.parent.mkdir(parents=True, exist_ok=True)
        _run([_ffmpeg(), "-y", "-i", str(src), "-af", "loudnorm=I=-14:TP=-1:LRA=9", "-ar", "44100", str(out)])
        return f"Normalized: {out.relative_to(guard.workspace)}"

    @reg.add("audio_mix", "Layer audio tracks together (e.g. a beat under a healing tone). tracks = JSON list of paths, volumes = JSON list.",
             {"tracks": S, "volumes": S, "output": S}, ["tracks"])
    def audio_mix(tracks, volumes="", output="audio/mix.wav"):
        paths = [guard.safe_path(t) for t in json.loads(tracks)]
        vols = json.loads(volumes) if volumes else [1.0] * len(paths)
        out = guard.safe_path(output); out.parent.mkdir(parents=True, exist_ok=True)
        cmd = [_ffmpeg(), "-y"]
        for p in paths:
            cmd += ["-i", str(p)]
        fc = "".join(f"[{i}]volume={vols[i]}[a{i}];" for i in range(len(paths)))
        fc += "".join(f"[a{i}]" for i in range(len(paths))) + f"amix=inputs={len(paths)}:duration=longest[m]"
        _run(cmd + ["-filter_complex", fc, "-map", "[m]", str(out)])
        return f"Mixed {len(paths)} tracks: {out.relative_to(guard.workspace)}"

    @reg.add("audio_convert", "Convert audio to wav, mp3, flac or ogg.", {"path": S, "format": S}, ["path", "format"])
    def audio_convert(path, format):
        src = guard.safe_path(path)
        out = src.with_suffix("." + format.strip(".").lower())
        _run([_ffmpeg(), "-y", "-i", str(src), str(out)])
        return f"Converted: {out.relative_to(guard.workspace)}"

    return reg
