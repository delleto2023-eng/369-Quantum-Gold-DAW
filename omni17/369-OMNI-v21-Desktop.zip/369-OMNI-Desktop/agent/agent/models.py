"""Model Smith stack: run open-weight models locally on your own GPU (llama.cpp / any OpenAI-compatible server).
Mechanics from the Codacus "best AI model your GPU can run" guide:
- Mixture-of-experts (MoE) models only use a few "active" experts per token, so the big expert weights can live in
  system RAM while attention + active work stays on the GPU. That is how 35B-763B models run on 4-16 GB cards.
- KV cache quantization (-ctk/-ctv q8_0) roughly halves context memory.
- The expert cache (--moe-cache-mib) helps generation (small batches <=32 tokens), not prompt prefill.
- Fewer CPU threads can be faster (video: -t 6 held 24.1 t/s vs -t 12 at 13.6) - always benchmark.
Fit numbers here are arithmetic estimates from file sizes, like the video's. Measure on your machine.
"""
import json, os, platform, re, shutil, subprocess, time

QUANT_BITS = {"Q2_K": 2.63, "IQ3_XXS": 3.06, "IQ3_S": 3.44, "Q3_K_M": 3.91, "IQ4_XS": 4.25, "Q4_K_M": 4.85,
              "UD-Q4_K_XL": 4.9, "NVFP4": 4.5, "Q5_K_M": 5.69, "Q6_K": 6.56, "Q8_0": 8.5, "F16": 16.0}

CATALOG_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models_catalog.json")


def load_catalog():
    with open(CATALOG_FILE, encoding="utf-8") as f:
        return json.load(f)["models"]


def save_catalog(models):
    with open(CATALOG_FILE, "w", encoding="utf-8") as f:
        json.dump({"_note": "Model facts come from the listed sources (often video claims). Verify on the model card before downloading.",
                   "models": models}, f, indent=1)


def _gb(x):
    return round(x, 1)


def scan():
    info = {"os": platform.system(), "cpu_threads": os.cpu_count(), "gpus": [], "ram_gb": None}
    try:
        import psutil
        info["ram_gb"] = _gb(psutil.virtual_memory().total / 2**30)
    except Exception:
        if os.path.exists("/proc/meminfo"):
            kb = int(re.search(r"MemTotal:\s+(\d+)", open("/proc/meminfo").read()).group(1))
            info["ram_gb"] = _gb(kb / 2**20)
        elif info["os"] == "Darwin":
            info["ram_gb"] = _gb(int(subprocess.check_output(["sysctl", "-n", "hw.memsize"])) / 2**30)
    if shutil.which("nvidia-smi"):
        out = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total,memory.free", "--format=csv,noheader,nounits"],
                             capture_output=True, text=True).stdout
        for line in out.strip().splitlines():
            name, tot, free = [s.strip() for s in line.split(",")]
            info["gpus"].append({"name": name, "vram_gb": _gb(int(tot) / 1024), "free_gb": _gb(int(free) / 1024)})
    elif info["os"] == "Darwin" and platform.machine() == "arm64":
        info["gpus"].append({"name": "Apple Silicon (unified memory)", "vram_gb": _gb((info["ram_gb"] or 0) * 0.7)})
    return info


def fit(total_b, active_b=None, quant="Q4_K_M", vram_gb=8, ram_gb=32, ctx=32768, kv_mb_per_1k=64, moe=None, peak_gb=None):
    """kv_mb_per_1k: KV cache MB per 1k tokens at q8_0 (check your model's config; 30-130 is typical)."""
    bits = QUANT_BITS.get(quant, quant if isinstance(quant, (int, float)) else 4.85)
    weights = total_b * bits / 8
    active = (active_b or total_b) * bits / 8
    kv = ctx / 1024 * kv_mb_per_1k / 1024
    overhead = 0.8
    moe = (active_b is not None and active_b < total_b) if moe is None else moe
    need_gpu_full = weights + kv + overhead
    r = {"quant": quant, "bits": bits, "weights_gb": _gb(weights), "kv_cache_gb": _gb(kv), "ctx": ctx}
    if peak_gb:  # publisher-reported peak memory (e.g. latent-MoE models that stream tiny experts)
        r["reported_peak_gb"] = peak_gb
        if peak_gb <= vram_gb * 0.95:
            r.update(plan="FULL GPU (reported)", detail="The model's reported peak memory fits your VRAM. Verify with model_benchmark.", flags=["-ngl 99"])
            return r
        if peak_gb <= vram_gb + ram_gb * 0.85:
            r.update(plan="MOE OFFLOAD (reported)", detail="Reported peak memory fits VRAM + RAM; keep attention on GPU, experts in RAM.",
                     flags=["-ngl 99", "--n-cpu-moe <layers>  (or -ot exps=CPU)", "-ctk q8_0 -ctv q8_0"])
            return r
    if need_gpu_full <= vram_gb * 0.95:
        r.update(plan="FULL GPU", detail="Everything fits in VRAM: fastest.", flags=["-ngl 99"])
    elif moe and active * 1.6 + kv + overhead <= vram_gb and weights <= ram_gb * 0.85 + vram_gb:
        r.update(plan="MOE OFFLOAD", detail="Attention + shared layers on GPU, expert weights in system RAM. "
                 "Generation stays usable because only the active experts are read per token.",
                 flags=["-ngl 99", "--n-cpu-moe <layers>  (or -ot exps=CPU)", "-ctk q8_0 -ctv q8_0"])
    elif weights <= ram_gb * 0.85 + vram_gb:
        r.update(plan="PARTIAL OFFLOAD", detail="Some layers on GPU, rest on CPU: works but slower.",
                 flags=["-ngl <as many as fit>", "-ctk q8_0 -ctv q8_0"])
    elif weights <= ram_gb * 2 + vram_gb:
        r.update(plan="MMAP STREAM", detail="Too big for RAM+VRAM; streams from disk with mmap. Expect it to be slow.",
                 flags=["--load-mode mmap  (fork flag; mainline mmaps by default)"])
    else:
        r.update(plan="TOO BIG", detail="Pick a smaller model or a lower quant (try about 3-4 bits before going smaller).", flags=[])
    return r


def server_command(hf_repo, hf_file, ctx=32768, port=8080, spare_vram_gb=2, ram_short=False, moe=True, binary="./build/bin/llama-server"):
    cmd = [binary, "-hf", hf_repo, "-hff", hf_file, "-c", str(ctx), "-ctk", "q8_0", "-ctv", "q8_0",
           "--no-mmproj", "--port", str(port), "--jinja", "--fit-target", "512"]
    if spare_vram_gb >= 2:
        cmd += ["-ub", "1024"] + (["--moe-cache-mib", "2048"] if moe else [])
    if ram_short:
        cmd += ["--load-mode", "mmap"]
    return cmd


def build_model_tools(reg, guard, brain_holder):
    S = {"type": "string"}
    N = {"type": "number"}
    state = {"proc": None}

    @reg.add("hardware_scan", "Detect GPU VRAM, system RAM, CPU threads and OS to choose local models.", {})
    def hardware_scan():
        return json.dumps(scan(), indent=1)

    @reg.add("model_catalog", "List the local open-weight models the team knows (models_catalog.json) plus quant sizes.", {})
    def model_catalog():
        return json.dumps({"models": load_catalog(), "quant_bits_per_weight": QUANT_BITS}, indent=1)

    @reg.add("model_catalog_add", "Add or update a model in the team's catalog (e.g. from a video or model card). "
             "Mark unverified claims in note. Fields: name, hf, file, total_b, active_b, moe, quant, peak_memory_gb, note, source.",
             {"name": S, "hf": S, "file": S, "total_b": N, "active_b": N, "moe": {"type": "boolean"}, "quant": S,
              "peak_memory_gb": N, "note": S, "source": S}, ["name", "total_b", "source"])
    def model_catalog_add(name, total_b, source, **kw):
        models = load_catalog()
        models[name] = {**models.get(name, {}), "total_b": total_b, "source": source, **kw}
        save_catalog(models)
        return f"Saved {name} to the catalog ({len(models)} models)."

    @reg.add("model_fit", "Estimate whether a model fits your GPU/RAM and how to run it (full GPU, MoE expert offload, partial, mmap). "
             "Give a catalog model name, or total and active params in billions.",
             {"model": S, "total_b": N, "active_b": N, "quant": S, "vram_gb": N, "ram_gb": N, "ctx": {"type": "integer"},
              "kv_mb_per_1k": N}, ["vram_gb", "ram_gb"])
    def model_fit(vram_gb, ram_gb, total_b=None, active_b=None, quant=None, ctx=32768, kv_mb_per_1k=64, model=""):
        peak = None
        if model:
            c = load_catalog()[model]
            total_b, active_b = total_b or c["total_b"], active_b or c.get("active_b")
            quant, peak = quant or c.get("quant"), c.get("peak_memory_gb")
        r = fit(float(total_b), active_b and float(active_b), quant or "Q4_K_M", float(vram_gb), float(ram_gb),
                int(ctx), float(kv_mb_per_1k), peak_gb=peak)
        if model:
            r["model"] = model
        return json.dumps(r, indent=1)

    @reg.add("llama_server_command", "Build a llama.cpp llama-server command (the video's flags, adjusted to your spare VRAM/RAM). "
             "These flags were never all run together in the video: treat it as a starting point.",
             {"hf_repo": S, "hf_file": S, "ctx": {"type": "integer"}, "port": {"type": "integer"}, "spare_vram_gb": N,
              "ram_short": {"type": "boolean"}, "moe": {"type": "boolean"}, "binary": S}, ["hf_repo", "hf_file"])
    def llama_server_command(hf_repo, hf_file, ctx=32768, port=8080, spare_vram_gb=2, ram_short=False, moe=True,
                             binary="./build/bin/llama-server"):
        cmd = server_command(hf_repo, hf_file, ctx, port, spare_vram_gb, ram_short, moe, binary)
        return " ".join(cmd) + ("\nNote: --fit-target, --moe-cache-mib and --load-mode may need a recent llama.cpp "
                                "or the video's fork; if one is rejected, check `llama-server --help` and drop it.")

    @reg.add("llama_server_start", "Start a local model server in the background (needs approval). command = full llama-server command line.",
             {"command": S}, ["command"], risk="approve")
    def llama_server_start(command):
        guard.check_shell(command)
        log = guard.safe_path("logs/llama-server.log")
        log.parent.mkdir(parents=True, exist_ok=True)
        state["proc"] = subprocess.Popen(command, shell=True, stdout=open(log, "w"), stderr=subprocess.STDOUT)
        return f"Started (pid {state['proc'].pid}). Loading can take minutes; check llama_server_status. Log: logs/llama-server.log"

    @reg.add("llama_server_status", "Check whether a local OpenAI-compatible server (llama.cpp, LM Studio, Ollama /v1) is up and which model it serves.",
             {"base_url": S})
    def llama_server_status(base_url="http://localhost:8080/v1"):
        import requests
        try:
            return requests.get(base_url.rstrip("/") + "/models", timeout=5).text[:1500]
        except Exception as e:
            tail = ""
            log = guard.workspace / "logs/llama-server.log"
            if log.exists():
                tail = "\nLog tail:\n" + log.read_text(errors="replace")[-1200:]
            return f"Not reachable: {e}{tail}"

    @reg.add("llama_server_stop", "Stop the local model server started by llama_server_start.", {})
    def llama_server_stop():
        if state["proc"] and state["proc"].poll() is None:
            state["proc"].terminate()
            return "Stopped."
        return "No server running from this session."

    @reg.add("model_benchmark", "Measure tokens/second of a local OpenAI-compatible server with a test prompt.",
             {"base_url": S, "model": S, "max_tokens": {"type": "integer"}})
    def model_benchmark(base_url="http://localhost:8080/v1", model="local", max_tokens=256):
        import requests
        t = time.time()
        r = requests.post(base_url.rstrip("/") + "/chat/completions", timeout=600, json={
            "model": model, "max_tokens": int(max_tokens),
            "messages": [{"role": "user", "content": "Write 200 words about the number 369 and sacred geometry."}]}).json()
        dt = time.time() - t
        toks = (r.get("usage") or {}).get("completion_tokens") or 0
        tim = r.get("timings") or {}
        gen = tim.get("predicted_per_second") or (toks / dt if dt else 0)
        return json.dumps({"completion_tokens": toks, "seconds": round(dt, 2), "gen_tokens_per_s": round(gen, 1),
                           "prefill_tokens_per_s": round(tim.get("prompt_per_second", 0), 1)})

    @reg.add("use_local_brain", "Switch the WHOLE team to a local OpenAI-compatible model server (or back to Claude with provider=anthropic). Needs approval.",
             {"provider": S, "base_url": S, "model": S}, ["provider"], risk="approve")
    def use_local_brain(provider, base_url="http://localhost:8080/v1", model="local"):
        b = brain_holder["brain"]
        guard.log(event="brain_preserved", previous={"provider": b.provider, "model": b.model,
                                                     "base_url": getattr(b, "base_url", "")})
        prev = f"{b.provider}:{b.model}"
        b.switch(provider, model, base_url)
        return (f"Team brain is now {b.provider}:{b.model} ({b.base_url if b.provider == 'openai' else 'cloud'}). "
                f"Previous brain {prev} is preserved in logs/audit.jsonl and can be restored with use_local_brain.")

    return reg
