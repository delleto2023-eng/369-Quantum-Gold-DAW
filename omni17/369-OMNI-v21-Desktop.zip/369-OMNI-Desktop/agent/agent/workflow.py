"""Workflow Circle tools (mirrors the user's Town workspace routines and helpers, run locally).
inbox_scan       Auto-inbox: read-only list of recent/unread mail over IMAP (app password in .env)
calendar_read    Briefings: read events from an .ics file or calendar URL for a date range
briefing_build   Morning/Weekly Briefing: schedule + inbox + team workspace -> a short briefing note
voice_samples    Write in User Voice: save samples of how the user writes
voice_profile    Write in User Voice: style notes (length, casing, punctuation, greetings) from the samples
browse_page      Browser Driver: open a page in a real browser (Playwright) and return its text + a screenshot
Nothing is sent, deleted or bought by these tools.
"""
import datetime as dt, email, imaplib, json, os, re
from email.header import decode_header
from pathlib import Path


def _dh(v):
    out = ""
    for part, enc in decode_header(v or ""):
        out += part.decode(enc or "utf-8", "replace") if isinstance(part, bytes) else part
    return out


def parse_ics(text, start, end):
    evs = []
    for block in text.split("BEGIN:VEVENT")[1:]:
        g = lambda k: (re.search(rf"^{k}[^:]*:(.*)$", block, re.M) or [None, ""])[1].strip()
        raw = g("DTSTART")
        try:
            d = dt.datetime.strptime(raw[:15], "%Y%m%dT%H%M%S") if "T" in raw else dt.datetime.strptime(raw[:8], "%Y%m%d")
        except ValueError:
            continue
        if start <= d.date() <= end:
            evs.append((d, g("SUMMARY"), g("LOCATION")))
    return sorted(evs)


def build_workflow_tools(reg, guard):
    S = {"type": "string"}

    def inbox(n=15, unread=True):
        host, user, pw = os.getenv("IMAP_HOST"), os.getenv("IMAP_USER"), os.getenv("IMAP_PASSWORD")
        if not (host and user and pw):
            return None
        M = imaplib.IMAP4_SSL(host); M.login(user, pw); M.select("INBOX", readonly=True)
        _, ids = M.search(None, "UNSEEN" if unread else "ALL")
        rows = []
        for i in ids[0].split()[-int(n):][::-1]:
            _, data = M.fetch(i, "(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])")
            msg = email.message_from_bytes(data[0][1])
            rows.append(f"- {_dh(msg['From'])[:40]} | {_dh(msg['Subject'])[:80]} | {msg['Date'][:16] if msg['Date'] else ''}")
        M.logout()
        return rows

    @reg.add("inbox_scan", "Auto-inbox (read-only): list recent unread email (sender, subject, date). Needs IMAP_HOST, IMAP_USER, IMAP_PASSWORD (app password) in .env.",
             {"count": {"type": "integer"}, "unread_only": {"type": "boolean"}})
    def inbox_scan(count=15, unread_only=True):
        rows = inbox(count, unread_only)
        if rows is None:
            return "Email not set up. Add IMAP_HOST (e.g. imap.gmail.com), IMAP_USER and IMAP_PASSWORD (an app password) to .env."
        return guard.untrusted("inbox", "\n".join(rows) or "No unread mail.")

    def cal(days=1, start=None):
        src = os.getenv("CALENDAR_ICS", "")
        if not src:
            p = guard.workspace / "calendar.ics"
            src = str(p) if p.exists() else ""
        if not src:
            return None
        if src.startswith("http"):
            import requests
            text = requests.get(src, timeout=30).text
        else:
            text = Path(src).read_text(encoding="utf-8", errors="replace")
        s = start or dt.date.today()
        return parse_ics(text, s, s + dt.timedelta(days=int(days) - 1))

    @reg.add("calendar_read", "Read calendar events for the next N days from CALENDAR_ICS (file path or secret iCal URL) or workspace/calendar.ics.",
             {"days": {"type": "integer"}, "start": S})
    def calendar_read(days=1, start=""):
        evs = cal(days, dt.date.fromisoformat(start) if start else None)
        if evs is None:
            return "Calendar not set up. Put your calendar's secret iCal link in CALENDAR_ICS in .env, or save calendar.ics in the workspace."
        return "\n".join(f"- {d:%a %b %d %I:%M %p} {s}" + (f" @ {l}" if l else "") for d, s, l in evs) or "Nothing on the calendar."

    @reg.add("briefing_build", "Morning or Weekly Briefing: combine the calendar, unread email and the team workspace into a short note saved in briefings/.",
             {"kind": S}, [])
    def briefing_build(kind="morning"):
        days = 7 if kind == "weekly" else 1
        evs = cal(days)
        mail = inbox(9)
        mind = getattr(guard, "mind", None)
        L = [f"# {kind.title()} briefing - {dt.date.today():%A %B %d}", "", "## Schedule"]
        L += [f"- {d:%a %I:%M %p} {s}" for d, s, _ in evs] if evs else ["- calendar not set up" if evs is None else "- nothing scheduled"]
        L += ["", "## Unread email"] + (mail[:9] if mail else ["- email not set up" if mail is None else "- inbox clear"])
        if mind and mind.workspace.items:
            L += ["", "## Team updates"] + [f"- {i['agent']}: {i['content'][:120]}" for i in mind.workspace.recent(6)]
        out = guard.safe_path(f"briefings/{kind}_{dt.date.today()}.md"); out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text("\n".join(L))
        return guard.untrusted("briefing sources", "\n".join(L)) + f"\nSaved: {out.relative_to(guard.workspace)}"

    @reg.add("voice_samples", "Save a sample of the user's own writing (email, text, post) so drafts can match their voice.",
             {"text": S, "surface": S}, ["text"])
    def voice_samples(text, surface="message"):
        p = guard.safe_path("memory/voice_samples.json"); p.parent.mkdir(parents=True, exist_ok=True)
        data = json.loads(p.read_text()) if p.exists() else []
        data.append({"surface": surface, "text": text[:4000]}); p.write_text(json.dumps(data, indent=1))
        return f"Saved sample {len(data)} ({surface})."

    @reg.add("voice_profile", "Describe how the user writes (from saved samples) so a draft can be rewritten in their voice.", {})
    def voice_profile():
        p = guard.safe_path("memory/voice_samples.json")
        if not p.exists():
            return "No samples yet. Save a few with voice_samples. Default for this user: short, casual, texting style, little punctuation, no sign-off."
        texts = [d["text"] for d in json.loads(p.read_text())]
        words = sum(len(t.split()) for t in texts) / len(texts)
        lower = sum(t[:1].islower() for t in texts) / len(texts)
        punct = sum(t.count(".") + t.count(",") for t in texts) / max(sum(len(t.split()) for t in texts), 1)
        openers = sorted({t.split()[0].strip(",").lower() for t in texts if t.split()})[:9]
        return (f"Average length {words:.0f} words; starts lowercase {lower:.0%} of the time; punctuation per word {punct:.2f}; "
                f"common openers: {', '.join(openers)}. Match this: keep it about as long, same casing and punctuation habits, no formal sign-off.")

    @reg.add("browse_page", "Browser Driver: open a page in a real browser and return its visible text plus a screenshot (needs Playwright). Read-only.",
             {"url": S}, ["url"])
    def browse_page(url):
        from playwright.sync_api import sync_playwright
        shot = guard.safe_path(f"browser/{re.sub(r'[^a-z0-9]+', '_', url.lower())[:60]}.png"); shot.parent.mkdir(parents=True, exist_ok=True)
        with sync_playwright() as p:
            b = p.chromium.launch(); pg = b.new_page(); pg.goto(url, timeout=45000)
            text = pg.inner_text("body")[:15000]; pg.screenshot(path=str(shot), full_page=False); b.close()
        return guard.untrusted(url, text) + f"\nScreenshot: {shot.relative_to(guard.workspace)}"

    return reg
