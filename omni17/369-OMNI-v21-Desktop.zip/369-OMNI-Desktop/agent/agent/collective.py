"""Big Tony Collective + Big Tony's Brain (from 369 Super DAW Studio).
collective_ask      ask every switched-on AI member at once (Claude, DeepSeek V4.1 Flash, Ox Alpha / GLM-5.3 Flash,
                    Gemini, Llama, GPT, local Ollama...) and merge their answers; wins/fails are tracked per member
collective_members  list members, whether each is ready (key set), wins and fails
collective_toggle   switch a member on or off
kb_add_link / kb_add_text / kb_refresh / kb_search / kb_correct / kb_export  - the learning knowledge base:
                    learn from links and text, re-learn links that changed, corrections override facts, export md/json
Keys come from environment variables (.env), never from chat.
"""
import concurrent.futures, hashlib, html, json, os, re, time
from pathlib import Path

DEFAULT_MEMBERS = [
    {"name": "Claude", "provider": "anthropic", "model": "claude-sonnet-4-5", "key_env": "ANTHROPIC_API_KEY", "on": True},
    {"name": "DeepSeek V4.1 Flash", "provider": "openai", "base_url": "https://openrouter.ai/api/v1", "model": "deepseek/deepseek-v4.1-flash", "key_env": "OPENROUTER_API_KEY", "on": True},
    {"name": "Ox Alpha (GLM-5.3 Flash)", "provider": "openai", "base_url": "https://openrouter.ai/api/v1", "model": "z-ai/glm-5.3-flash", "key_env": "OPENROUTER_API_KEY", "on": True},
    {"name": "Gemini 2.5 Flash", "provider": "openai", "base_url": "https://generativelanguage.googleapis.com/v1beta/openai", "model": "gemini-2.5-flash", "key_env": "GEMINI_API_KEY", "on": True},
    {"name": "Llama 3.3 70B (free)", "provider": "openai", "base_url": "https://openrouter.ai/api/v1", "model": "meta-llama/llama-3.3-70b-instruct:free", "key_env": "OPENROUTER_API_KEY", "on": False},
    {"name": "GPT-4.1 mini", "provider": "openai", "base_url": "https://api.openai.com/v1", "model": "gpt-4.1-mini", "key_env": "OPENAI_API_KEY", "on": False},
    {"name": "Local Llama (Ollama)", "provider": "ollama", "model": "llama3.1", "key_env": "", "on": False},
]


class Collective:
    def __init__(self, path):
        self.path = Path(path)
        if not self.path.exists():
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.save([dict(m, wins=0, fails=0) for m in DEFAULT_MEMBERS])

    def load(self):
        return json.loads(self.path.read_text())

    def save(self, members):
        self.path.write_text(json.dumps(members, indent=1))

    @staticmethod
    def ready(m):
        return m.get("on") and (not m.get("key_env") or bool(os.getenv(m["key_env"])))

    def ask(self, question, merger=None, timeout=120):
        from .brain import Brain
        members = self.load()
        live = [m for m in members if self.ready(m)]
        if not live:
            return "No collective members are ready. Add a key in .env (ANTHROPIC_API_KEY, OPENROUTER_API_KEY, GEMINI_API_KEY...) or switch on Local Llama.", {}

        def one(m):
            b = Brain(m["provider"], m["model"], base_url=m.get("base_url"))
            if m.get("key_env"):
                b.api_key = os.getenv(m["key_env"])
            return b.chat("You are one member of Big Tony's AI collective in 369 Super DAW Studio. Answer briefly and practically.",
                          [{"role": "user", "content": question}], []).text
        answers = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(live)) as ex:
            futs = {ex.submit(one, m): m["name"] for m in live}
            for f in concurrent.futures.as_completed(futs, timeout=timeout):
                try:
                    answers[futs[f]] = f.result()
                except Exception as e:
                    answers[futs[f]] = None
        for m in members:
            if m["name"] in answers:
                m["wins" if answers[m["name"]] else "fails"] = m.get("wins" if answers[m["name"]] else "fails", 0) + 1
        self.save(members)
        good = {k: v for k, v in answers.items() if v}
        if not good:
            return "Every member failed to answer (check keys and internet).", answers
        if merger and len(good) > 1:
            joined = "\n\n".join(f"[{k}]\n{v}" for k, v in good.items())
            merged = merger("Merge these answers from different AI models into one best answer. Keep what they agree on, "
                            "flag real disagreements, drop mistakes. Be short.\n\n" + joined)
            return merged + f"\n\n(Collective: {', '.join(good)})", answers
        k, v = max(good.items(), key=lambda kv: len(kv[1]))
        return v + f"\n\n(Collective: {', '.join(good)})", answers


class KnowledgeBase:
    def __init__(self, path):
        self.path = Path(path)
        self.data = json.loads(self.path.read_text()) if self.path.exists() else {"items": [], "corrections": [], "last_refresh": 0}

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self.data, indent=1))

    @staticmethod
    def learn(text, n=12):
        sents = re.split(r"(?<=[.!?])\s+", re.sub(r"\s+", " ", text))
        good = [s.strip() for s in sents if 40 <= len(s.strip()) <= 300]
        return good[:n]

    def add(self, kind, title, text, url=""):
        h = hashlib.sha1(text.encode()).hexdigest()
        self.data["items"] = [i for i in self.data["items"] if not (i["title"] == title and i["kind"] == kind)]
        self.data["items"].append({"kind": kind, "title": title, "url": url, "text": text[:60000], "hash": h,
                                   "facts": self.learn(text), "added": time.strftime("%Y-%m-%d")})
        self.save()
        return self.data["items"][-1]

    def search(self, query, k=6):
        words = [w[:6] for w in re.findall(r"[a-z0-9]+", query.lower()) if len(w) > 3 or w.isdigit() and len(w) >= 3]
        corr = [c for c in self.data["corrections"] if any(w in c.lower() for w in words)]
        hits = []
        for it in self.data["items"]:
            for f in it["facts"]:
                s = sum(w in f.lower() for w in words)
                if s:
                    hits.append((s, f"{f} ({it['title']})"))
        hits.sort(reverse=True)
        return corr, [h for _, h in hits[:k]]


def _fetch(url):
    import requests
    try:
        r = requests.get(url, timeout=30, headers={"User-Agent": "369-ultimate-agent"})
        t = r.text
        if "html" in r.headers.get("content-type", ""):
            t = re.sub(r"(?is)<(script|style).*?</\1>", " ", t)
            t = html.unescape(re.sub(r"(?s)<[^>]+>", " ", t))
        if len(t.strip()) > 50:
            return t
    except Exception:
        pass
    return requests.get("https://r.jina.ai/" + url, timeout=45).text  # reader fallback, like the DAW


def build_collective_tools(reg, guard, holder):
    S = {"type": "string"}
    col = lambda: Collective(guard.safe_path("studio/collective.json"))
    kb = lambda: KnowledgeBase(guard.safe_path("studio/knowledge.json"))

    @reg.add("collective_ask", "Ask Big Tony's whole AI collective (every switched-on model) at once and get one merged answer.", {"question": S}, ["question"])
    def collective_ask(question):
        brain = holder.get("brain")
        merger = (lambda p: brain.chat("You merge answers.", [{"role": "user", "content": p}], []).text) if brain and brain.provider != "fake" else None
        return col().ask(question, merger)[0]

    @reg.add("collective_members", "List Big Tony's collective: each AI, whether it is on and ready (key set), wins and fails.", {})
    def collective_members():
        c = col()
        return "\n".join(f"- {m['name']} [{m['model']}] {'ON' if m.get('on') else 'off'}, {'ready' if c.ready(m) else 'needs ' + (m.get('key_env') or 'Ollama running')}, "
                         f"wins {m.get('wins', 0)}, fails {m.get('fails', 0)}" for m in c.load())

    @reg.add("collective_toggle", "Switch a collective member on or off by name.", {"name": S, "on": {"type": "boolean"}}, ["name", "on"])
    def collective_toggle(name, on):
        c = col(); ms = c.load()
        hit = [m for m in ms if name.lower() in m["name"].lower()]
        if not hit:
            return "No member called " + name
        for m in hit:
            m["on"] = bool(on)
        c.save(ms)
        return f"{', '.join(m['name'] for m in hit)} switched {'on' if on else 'off'}."

    @reg.add("kb_add_link", "Big Tony's Brain: read a web page and learn its key facts (re-learned automatically when it changes).", {"url": S}, ["url"])
    def kb_add_link(url):
        if not url.startswith("http"):
            url = "https://" + url
        it = kb().add("link", url.split("//", 1)[1][:80], _fetch(url), url)
        return guard.untrusted(url, f"Learned {len(it['facts'])} facts from {url}:\n- " + "\n- ".join(it["facts"][:9]))

    @reg.add("kb_add_text", "Big Tony's Brain: learn from text you give it (notes, a video summary, a manual).", {"title": S, "text": S}, ["title", "text"])
    def kb_add_text(title, text):
        it = kb().add("text", title, text)
        return f"Learned {len(it['facts'])} facts as '{title}'."

    @reg.add("kb_refresh", "Re-read every learned link and re-learn the ones that changed.", {})
    def kb_refresh():
        k = kb(); n = 0
        for it in [i for i in k.data["items"] if i["kind"] == "link"]:
            try:
                t = _fetch(it["url"])
                if hashlib.sha1(t.encode()).hexdigest() != it["hash"]:
                    k.add("link", it["title"], t, it["url"]); n += 1
            except Exception as e:
                it["last_error"] = str(e)
        k.data["last_refresh"] = time.time(); k.save()
        return f"Checked {len([i for i in k.data['items'] if i['kind'] == 'link'])} links, {n} changed and re-learned."

    @reg.add("kb_search", "Search Big Tony's Brain. Corrections come first and override older facts.", {"query": S}, ["query"])
    def kb_search(query):
        corr, hits = kb().search(query)
        out = (["Corrections (these win):"] + ["- " + c for c in corr] if corr else []) + (["Facts:"] + ["- " + h for h in hits] if hits else [])
        return "\n".join(out) or "Nothing learned about that yet."

    @reg.add("kb_correct", "Teach Big Tony a correction; it overrides anything older he learned.", {"text": S}, ["text"])
    def kb_correct(text):
        k = kb(); k.data["corrections"].append(text); k.save()
        return "Correction saved. It now overrides older facts."

    @reg.add("kb_export", "Export Big Tony's Brain as Markdown or JSON (format: md or json).", {"format": S})
    def kb_export(format="md"):
        k = kb()
        out = guard.safe_path(f"exports/369 Knowledge {time.strftime('%Y-%m-%d')}.{format}")
        out.parent.mkdir(parents=True, exist_ok=True)
        if format == "json":
            out.write_text(json.dumps(k.data, indent=1))
        else:
            md = ["# 369 - Big Tony Knowledge", ""] + [f"## {i['title']}\nType: {i['kind']} | Added {i['added']}\n" + "\n".join("- " + f for f in i["facts"]) for i in k.data["items"]]
            md += ["", "## Corrections"] + ["- " + c for c in k.data["corrections"]]
            out.write_text("\n".join(md))
        return f"Exported: {out.relative_to(guard.workspace)}"

    return reg
