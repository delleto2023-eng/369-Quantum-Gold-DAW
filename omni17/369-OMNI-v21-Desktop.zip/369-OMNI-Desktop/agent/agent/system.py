"""Builds the whole system in one call so main.py, launchers and tests all share it."""
import os, shutil
from .brain import Brain
from .guardrails import Guardrails
from .memory import Memory
from .tools import build_builtin_tools
from .film import build_film_tools
from .audio import build_audio_tools
from .geometry import build_geometry_tools
from .publish import build_publish_tools
from .models import build_model_tools
from .skills import SkillLibrary, add_skill_tools
from .mcp_bridge import load_mcp_servers
from .team import build_team
from .mind import Mind, build_mind_tools
import json as _json


def build_system(provider=None, model=None, auto_approve=False, max_steps=27, brain=None):
    guard = Guardrails(max_steps=max_steps, auto_approve=auto_approve)
    memory = Memory()
    library = SkillLibrary()
    welfare = _json.loads(__import__("pathlib").Path("agents.json").read_text(encoding="utf-8")).get("welfare", {})
    mind = guard.mind = Mind(welfare)
    tools = build_builtin_tools(guard, memory)
    build_mind_tools(tools, mind)
    from .plans import build_plan_tools, apply_plan
    plan_holder = {}
    build_plan_tools(tools, plan_holder)
    from .knowledge import build_knowledge_tools
    build_knowledge_tools(tools, guard)
    build_film_tools(tools, guard)
    from .studio import build_studio_tools
    from .film import _ffmpeg
    build_studio_tools(tools, guard, _ffmpeg)
    from .collective import build_collective_tools
    build_collective_tools(tools, guard, holder := {})
    from .voice import build_voice_tools
    build_voice_tools(tools, guard)
    from .tony import build_tony_tools
    build_tony_tools(tools, guard)
    from .workflow import build_workflow_tools
    build_workflow_tools(tools, guard)
    from .arcade import build_arcade_tools
    build_arcade_tools(tools, guard, _ffmpeg)
    from .devtools import build_dev_tools
    build_dev_tools(tools, guard)
    build_audio_tools(tools, guard)
    build_geometry_tools(tools, guard)
    build_publish_tools(tools, guard)
    add_skill_tools(tools, library)
    build_model_tools(tools, guard, holder)
    load_mcp_servers(tools)
    from .catalog import apply_tool_attributes
    apply_tool_attributes(tools)
    brain = brain or Brain(provider, model)
    holder["brain"] = brain
    boss = build_team(brain, tools, guard, memory, library)
    sysm = dict(mind=mind, brain=brain, guard=guard, memory=memory, library=library, tools=tools, boss=boss)
    plan_holder["sysm"] = sysm
    apply_plan(sysm, os.getenv("AGENT_PLAN", "max"))
    return sysm


def doctor():
    lines = []
    prov = os.getenv("AGENT_PROVIDER", "anthropic")
    lines.append(f"Provider: {prov}")
    if prov == "anthropic":
        lines.append("Claude key: " + ("OK" if os.getenv("ANTHROPIC_API_KEY", "").startswith("sk-") else "MISSING - add ANTHROPIC_API_KEY to .env"))
    else:
        try:
            import requests
            requests.get(os.getenv("OLLAMA_URL", "http://localhost:11434"), timeout=3)
            lines.append("Ollama: running")
        except Exception:
            lines.append("Ollama: NOT reachable - install from ollama.com and run `ollama pull llama3.1`")
    if prov == "openai":
        try:
            import requests
            requests.get(os.getenv("OPENAI_BASE_URL", "http://localhost:8080/v1") + "/models", timeout=3)
            lines.append("Local model server: running")
        except Exception:
            lines.append("Local model server: NOT reachable - start llama-server (ask Big Tony: 'set up a local model')")
    try:
        from .models import scan
        hw = scan()
        lines.append(f"Hardware: {hw['cpu_threads']} CPU threads, {hw['ram_gb']} GB RAM, GPU: " +
                     (", ".join(f"{g['name']} {g['vram_gb']} GB" for g in hw["gpus"]) or "none detected"))
    except Exception:
        pass
    ff = shutil.which("ffmpeg")
    if not ff:
        try:
            import imageio_ffmpeg; ff = imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            pass
    lines.append("ffmpeg (film tools): " + ("OK" if ff else "missing - film rendering off"))
    lines.append("Higgsfield: " + ("keys set" if os.getenv("HF_API_KEY_ID") and os.getenv("HF_API_KEY_SECRET") else "no keys (optional, local film tools still work)"))
    try:
        import mcp  # noqa
        lines.append("MCP SDK: installed")
    except Exception:
        lines.append("MCP SDK: not installed (optional)")
    try:
        from .catalog import STACKS, TOOL_ATTRS, requirement_ok
        off = [r for r in ("ffmpeg", "pillow", "hf_keys", "mcp", "internet") if not requirement_ok(r)]
        lines.append("Tools switched off until set up: " + (", ".join(off) if off else "none"))
    except Exception:
        pass
    return "\n".join(lines)
