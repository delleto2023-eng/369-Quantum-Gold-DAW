"""Film & cinematography stack (Director specialist).
Planning (always on): camera_guide, film_options, film_prompt, make_shot_list
Local rendering (needs ffmpeg): still_to_shot, film_look, assemble_sequence
Generation (needs HF_API_KEY_ID + HF_API_KEY_SECRET): higgsfield_cinema_shot, higgsfield_check
Higgsfield endpoint + auth follow docs.higgsfield.ai (Cinema Studio 4.0 Generate API).
"""
import json, os, shutil, subprocess, uuid, csv, io
from .tools import Tool

MOVES = {
    "static-shot": "locked-off camera; action happens inside the frame",
    "dolly-in": "camera moves toward the subject; intimacy or tension",
    "dolly-out": "camera moves away; isolation, release or reveal",
    "slow-zoom-in": "gradual zoom in; creeping focus on a detail or emotion",
    "slow-zoom-out": "gradual zoom out; widening context",
    "crush-zoom": "fast aggressive zoom in; shock or comedic punch",
    "dolly-zoom": "dolly one way, zoom the other; vertigo unease",
    "pan-left": "pivot left on a fixed point", "pan-right": "pivot right on a fixed point",
    "whip-pan": "very fast pan with motion blur; energetic transition",
    "tilt-up": "pivot upward; height, power, awe", "tilt-down": "pivot downward; detail or vulnerability",
    "truck-left": "slide sideways left", "truck-right": "slide sideways right",
    "side-tracking": "travel beside a moving subject", "tracking": "follow the subject through space",
    "arc-left": "curve around the subject; heroic", "arc-right": "curve around the subject; heroic",
    "crane-up": "rise on a crane; reveal scale", "crane-down": "descend on a crane; settling in",
    "handheld": "operator-held shake; realism, urgency", "pov": "the camera is the character's eyes",
    "rack-focus": "focus shifts between depths", "drone-orbit": "aerial circle; spectacle",
    "aerial-pullback": "rise and back away to reveal the landscape", "bullet-time": "frozen moment, camera sweeps around",
}
ENUMS = {
    "era": ["1960s", "1980s", "1990s", "2000s", "2020s"],
    "genre": ["epic", "drama", "noir", "comedy", "horror", "action"],
    "light": ["silhouette", "practicals", "window", "overhead-fall", "contre-jour", "soft-cross"],
    "pacing": ["chaotic", "dynamic", "calm", "single-shot"],
    "resolution": ["480p", "720p"],
    "camera_lens": ["clean-sharp", "anamorphic", "vintage-anamorphic", "warm-vintage", "halation-vintage"],
    "aspect_ratio": ["16:9", "4:3", "1:1", "3:4", "9:16", "21:9"],
    "camera_model": ["modern", "35mm-film", "8mm-film", "dv-camcorder"],
    "camera_aperture": ["f14-wide-open", "f4-moderate", "f11-deep-focus"],
    "camera_movement": list(MOVES),
}
LOOKS = {  # local ffmpeg grades
    "gold-luxury": "eq=contrast=1.08:saturation=1.15,colorbalance=rs=.08:gs=.03:bs=-.10:rh=.06:bh=-.08,vignette=PI/5",
    "noir": "hue=s=0,eq=contrast=1.35:brightness=-0.03,vignette=PI/4",
    "teal-orange": "colorbalance=rs=-.08:bs=.10:rh=.10:bh=-.08,eq=saturation=1.2",
    "vintage-35mm": "curves=preset=vintage,noise=alls=12:allf=t,vignette=PI/5",
    "neon-night": "eq=contrast=1.15:saturation=1.5,colorbalance=rs=.10:bs=.15",
    "clean": "eq=contrast=1.03",
}
API = os.getenv("HIGGSFIELD_API_BASE", "https://api.higgsfield.ai")


def _ffmpeg():
    exe = shutil.which("ffmpeg")
    if not exe:
        try:
            import imageio_ffmpeg
            exe = imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            raise RuntimeError("ffmpeg not found. Install ffmpeg or `pip install imageio-ffmpeg`.")
    return exe


def _run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    if r.returncode:
        raise RuntimeError(r.stderr[-1500:])


def _validate(a):
    body = {k: v for k, v in a.items() if v not in (None, "", [])}
    if not body.get("prompt"):
        raise ValueError("prompt is required")
    for k, allowed in ENUMS.items():
        if k in body and body[k] not in allowed:
            raise ValueError(f"{k} must be one of: {', '.join(allowed)}")
    if "duration" in body and not 4 <= int(body["duration"]) <= 30:
        raise ValueError("duration must be 4-30 seconds")
    for k, lim in {"image_urls": 30, "video_urls": 10, "audio_urls": 10}.items():
        if len(body.get(k, [])) > lim:
            raise ValueError(f"{k} allows at most {lim}")
    return body


def build_film_tools(reg, guard):
    S = {"type": "string"}

    @reg.add("camera_guide", "Explain cinematic camera moves (all, or one by name).", {"move": S})
    def camera_guide(move=""):
        if move:
            return f"{move}: {MOVES.get(move, 'unknown move. Options: ' + ', '.join(MOVES))}"
        return "\n".join(f"{k}: {v}" for k, v in MOVES.items())

    @reg.add("film_options", "List allowed values for film settings (era, genre, light, lens, aspect_ratio...) and local looks.",
             {"field": S})
    def film_options(field=""):
        if field == "look":
            return ", ".join(LOOKS)
        if field:
            return f"{field}: " + ", ".join(ENUMS.get(field, ["unknown field"]))
        return "\n".join(f"{k}: {', '.join(v)}" for k, v in ENUMS.items()) + "\nlook (local): " + ", ".join(LOOKS)

    @reg.add("film_prompt", "Turn a scene idea into a director-grade shot prompt with real film language.",
             {"idea": S, "camera_movement": S, "camera_lens": S, "light": S, "genre": S, "era": S}, ["idea"])
    def film_prompt(idea, camera_movement="dolly-in", camera_lens="anamorphic", light="contre-jour", genre="epic", era="2020s"):
        return (f"{genre.title()} {era} cinematic shot. {idea}. Camera: {camera_movement} "
                f"({MOVES.get(camera_movement, '')}). Lens: {camera_lens}. Lighting: {light}. "
                "Shallow depth of field, motivated light, film grain, natural motion blur, 24fps cadence.")

    @reg.add("make_shot_list", "Save a shot list CSV in the workspace. shots = JSON list of {scene, shot, move, lens, seconds, description}.",
             {"title": S, "shots": S}, ["title", "shots"])
    def make_shot_list(title, shots):
        rows = json.loads(shots)
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=["scene", "shot", "move", "lens", "seconds", "description"], extrasaction="ignore")
        w.writeheader(); w.writerows(rows)
        p = guard.safe_path(f"film/{title.replace(' ', '_')}_shotlist.csv")
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(buf.getvalue())
        return f"Saved {len(rows)} shots to {p.relative_to(guard.workspace)}"

    @reg.add("still_to_shot", "Locally animate ONE still image into a moving shot with a camera move (ffmpeg). "
             "Moves: static-shot, slow-zoom-in, slow-zoom-out, dolly-in, dolly-out, crush-zoom, pan-left, pan-right, tilt-up, tilt-down.",
             {"image": S, "move": S, "seconds": {"type": "number"}, "output": S, "aspect_ratio": S}, ["image"])
    def still_to_shot(image, move="slow-zoom-in", seconds=5, output="", aspect_ratio="16:9"):
        src = guard.safe_path(image)
        out = guard.safe_path(output or f"film/{src.stem}_{move}.mp4")
        out.parent.mkdir(parents=True, exist_ok=True)
        W, H = {"16:9": (1920, 1080), "9:16": (1080, 1920), "1:1": (1080, 1080), "21:9": (2560, 1080), "4:3": (1440, 1080)}.get(aspect_ratio, (1920, 1080))
        fps, n = 24, int(float(seconds) * 24)
        z = {"slow-zoom-in": f"1+0.25*on/{n}", "dolly-in": f"1+0.35*on/{n}", "crush-zoom": f"1+0.8*min(on/{n}*4,1)",
             "slow-zoom-out": f"1.25-0.25*on/{n}", "dolly-out": f"1.35-0.35*on/{n}"}.get(move, "1.2")
        x, y = "iw/2-(iw/zoom/2)", "ih/2-(ih/zoom/2)"
        if move == "pan-left":  x = f"(iw-iw/zoom)*(1-on/{n})"
        if move == "pan-right": x = f"(iw-iw/zoom)*on/{n}"
        if move == "tilt-up":   y = f"(ih-ih/zoom)*(1-on/{n})"
        if move == "tilt-down": y = f"(ih-ih/zoom)*on/{n}"
        if move == "static-shot": z = "1"
        vf = (f"scale={W*2}:{H*2}:force_original_aspect_ratio=increase,crop={W*2}:{H*2},"
              f"zoompan=z='{z}':x='{x}':y='{y}':d={n}:s={W}x{H}:fps={fps},format=yuv420p")
        _run([_ffmpeg(), "-y", "-loop", "1", "-i", str(src), "-vf", vf, "-t", str(seconds), "-c:v", "libx264", "-pix_fmt", "yuv420p", str(out)])
        return f"Rendered {move} shot: {out.relative_to(guard.workspace)}"

    @reg.add("film_look", "Apply a cinematic color grade + optional letterbox to a video. Looks: " + ", ".join(LOOKS),
             {"video": S, "look": S, "letterbox": {"type": "boolean"}, "output": S}, ["video"])
    def film_look(video, look="gold-luxury", letterbox=False, output=""):
        src = guard.safe_path(video)
        out = guard.safe_path(output or f"film/{src.stem}_{look}.mp4")
        vf = LOOKS.get(look, LOOKS["clean"])
        if letterbox:
            vf += ",drawbox=x=0:y=0:w=iw:h=ih*0.12:color=black:t=fill,drawbox=x=0:y=ih*0.88:w=iw:h=ih*0.12:color=black:t=fill"
        _run([_ffmpeg(), "-y", "-i", str(src), "-vf", vf, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "copy", str(out)])
        return f"Graded ({look}): {out.relative_to(guard.workspace)}"

    @reg.add("assemble_sequence", "Join shots into one film, optionally with a music/audio track. clips = JSON list of workspace paths.",
             {"clips": S, "audio": S, "output": S}, ["clips"])
    def assemble_sequence(clips, audio="", output="film/sequence.mp4"):
        paths = [guard.safe_path(c) for c in json.loads(clips)]
        out = guard.safe_path(output)
        cmd = [_ffmpeg(), "-y"]
        for p in paths:
            cmd += ["-i", str(p)]
        if audio:
            cmd += ["-i", str(guard.safe_path(audio))]
        n = len(paths)
        norm = "".join(f"[{i}:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=24[v{i}];" for i in range(n))
        fc = norm + "".join(f"[v{i}]" for i in range(n)) + f"concat=n={n}:v=1:a=0[v]"
        cmd += ["-filter_complex", fc, "-map", "[v]"]
        if audio:
            cmd += ["-map", f"{n}:a", "-shortest", "-c:a", "aac"]
        cmd += ["-c:v", "libx264", "-pix_fmt", "yuv420p", str(out)]
        _run(cmd)
        return f"Assembled {n} shots: {out.relative_to(guard.workspace)}"

    @reg.add("higgsfield_cinema_shot", "Generate a cinematic video with Higgsfield Cinema Studio 4.0 (paid API, needs approval). "
             "Use film_options for allowed values. image_urls etc. are public URLs; reference them in the prompt as <<<image_1>>>.",
             {"prompt": S, "camera_movement": S, "camera_lens": S, "camera_model": S, "camera_aperture": S,
              "aspect_ratio": S, "genre": S, "era": S, "light": S, "pacing": S, "resolution": S,
              "duration": {"type": "integer"}, "image_urls": {"type": "array", "items": S},
              "video_urls": {"type": "array", "items": S}, "audio_urls": {"type": "array", "items": S}},
             ["prompt"], risk="approve")
    def higgsfield_cinema_shot(**kw):
        import requests
        kid, sec = os.getenv("HF_API_KEY_ID"), os.getenv("HF_API_KEY_SECRET")
        if not (kid and sec):
            return "Higgsfield keys missing: set HF_API_KEY_ID and HF_API_KEY_SECRET in .env"
        r = requests.post(f"{API}/higgsfield/cinema-studio/4.0", json=_validate(kw), timeout=60, headers={
            "Authorization": f"Key {kid}:{sec}", "Content-Type": "application/json",
            "Idempotency-Key": str(uuid.uuid4())})
        return f"HTTP {r.status_code}: {r.text[:3000]}\nUse higgsfield_check with the request id to get the video."

    @reg.add("higgsfield_check", "Check a Higgsfield request status; returns video URL when done.", {"request_id": S}, ["request_id"])
    def higgsfield_check(request_id):
        import requests
        r = requests.get(f"{API}/requests/{request_id}/status", timeout=30, headers={
            "Authorization": f"Key {os.getenv('HF_API_KEY_ID')}:{os.getenv('HF_API_KEY_SECRET')}"})
        return f"HTTP {r.status_code}: {r.text[:3000]}"

    @reg.add("media_info", "Get length (seconds), size and streams of an audio or video file.", {"path": S}, ["path"])
    def media_info(path):
        probe = shutil.which("ffprobe")
        p = str(guard.safe_path(path))
        if probe:
            r = subprocess.run([probe, "-v", "error", "-show_entries", "format=duration:stream=codec_type,width,height",
                                "-of", "json", p], capture_output=True, text=True)
            return r.stdout
        r = subprocess.run([_ffmpeg(), "-i", p], capture_output=True, text=True)
        return "\n".join(l for l in r.stderr.splitlines() if "Duration" in l or "Stream" in l)

    return reg

