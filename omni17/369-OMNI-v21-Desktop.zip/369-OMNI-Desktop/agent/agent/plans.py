"""Plan modes: run the whole team lean (Pro) or full power (Max).
Pro  = usage-saving mode: smaller limits, graph-first strict, short answers, no extra review passes, lighter model.
Max  = power mode: full 3-6-9 limits (27 steps / 81 tool calls), self-checks on, deep recall, strongest model.
Note: this agent bills through your API key or a local model. The modes copy how you'd work on each Claude plan;
they do not log in to a Claude subscription.
"""
import os

PLANS = {
    "pro": {"label": "Pro (lean)", "model_env": "PRO_MODEL", "model": "claude-sonnet-4-5",
            "max_steps": 9, "max_tool_calls": 27, "result_chars": 3999, "recall_k": 3,
            "history_max_msgs": 18, "keep_turns": 3, "self_check": False, "max_tokens": 2048,
            "note": "Usage-saving mode: use graph_query before opening ANY file, read only what the graph points to, "
                    "keep answers short, skip optional extra passes, and batch work into as few steps as possible."},
    "max": {"label": "Max (power)", "model_env": "MAX_MODEL", "model": "claude-opus-4-1",
            "max_steps": 27, "max_tool_calls": 81, "result_chars": 9999, "recall_k": 9,
            "history_max_msgs": 36, "keep_turns": 6, "self_check": None, "max_tokens": 8192,
            "note": "Power mode: go deep, verify thoroughly, run review passes, and use the full 3-6-9 cycle."},
}


def apply_plan(sysm, name):
    name = name.lower()
    if name not in PLANS:
        raise ValueError(f"plan must be one of: {', '.join(PLANS)}")
    p = PLANS[name]
    g, brain = sysm["guard"], sysm["brain"]
    g.max_steps, g.max_tool_calls, g.max_result_chars = p["max_steps"], p["max_tool_calls"], p["result_chars"]
    g.plan, g.plan_note = name, p["note"]
    sysm["memory"].k = p["recall_k"]
    sysm["compact"] = {"max_msgs": p["history_max_msgs"], "keep_turns": p["keep_turns"]}
    if getattr(brain, "provider", "") == "anthropic" and not os.getenv("AGENT_MODEL"):
        brain.model = os.getenv(p["model_env"], p["model"])
    if hasattr(brain, "max_tokens"):
        brain.max_tokens = p["max_tokens"]
    for ag in list(sysm["boss"].team.values()) + [sysm["boss"]]:
        if "_self_check_default" not in ag.__dict__:
            ag._self_check_default = ag.behaviors.get("self_check", False)
        ag.behaviors["self_check"] = ag._self_check_default if p["self_check"] is None else p["self_check"]
    return f"{p['label']} mode on: {p['max_steps']} steps, {p['max_tool_calls']} tool calls, model {getattr(brain, 'model', '?')}."


def build_plan_tools(reg, holder):
    S = {"type": "string"}

    @reg.add("set_plan", "Switch the whole team between pro (lean, saves usage) and max (full power) modes.",
             {"plan": {"type": "string", "enum": list(PLANS)}}, ["plan"], risk="approve")
    def set_plan(plan):
        return apply_plan(holder["sysm"], plan)

    @reg.add("usage_report", "Show tokens used this session (input/output/calls), the current plan mode, and a tip.", {})
    def usage_report():
        b = holder["sysm"]["brain"]
        u = getattr(b, "usage", {"input": 0, "output": 0, "calls": 0})
        plan = getattr(holder["sysm"]["guard"], "plan", "max")
        tip = ("Heavy use: switch to pro mode and build a knowledge graph so agents stop rereading files."
               if u["input"] > 300000 else "Usage looks fine.")
        return (f"Plan mode: {PLANS[plan]['label']}\nModel calls: {u['calls']}\nInput tokens: {u['input']:,}\n"
                f"Output tokens: {u['output']:,}\nTip: {tip}")

    return reg
