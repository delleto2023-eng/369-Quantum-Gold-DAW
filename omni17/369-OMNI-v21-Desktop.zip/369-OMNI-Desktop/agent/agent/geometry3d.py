"""3D Metatron's Cube outline.
Metatron's Cube = 13 spheres. In 3D they sit at the center + the 12 corners of a cuboctahedron
(the "vector equilibrium": every corner is the same distance from the center and from its neighbours).
369 mapping, 1 + 3 + 9 = 13:
  center         = the goal (the source)
  3 phase heads  = PLAN, CREATE, COMPLETE
  9 steps        = 3 per phase
Each phase lives in its own dimension: PLAN = XY plane, CREATE = XZ plane, COMPLETE = YZ plane.
A phase head + its 3 steps form one square of the cuboctahedron. All 13 nodes are joined by 78 lines,
like the flat Metatron's Cube.
"""
import json, math
from itertools import combinations

PLANES = {  # square corners in walking order: head, step a, step b, step c
    "PLAN": [(1, 1, 0), (-1, 1, 0), (-1, -1, 0), (1, -1, 0)],
    "CREATE": [(1, 0, 1), (-1, 0, 1), (-1, 0, -1), (1, 0, -1)],
    "COMPLETE": [(0, 1, 1), (0, -1, 1), (0, -1, -1), (0, 1, -1)],
}
NUM = {"PLAN": 3, "CREATE": 6, "COMPLETE": 9}
COLORS = {"GOAL": "#D4AF37", "PLAN": "#7FD3FF", "CREATE": "#9CFFB0", "COMPLETE": "#FFB0D9"}


def build(goal, steps9, shares=None):
    nodes = [{"id": 0, "label": goal, "kind": "goal", "phase": "GOAL", "xyz": [0, 0, 0]}]
    for p, (phase, corners) in enumerate(PLANES.items()):
        head = {"id": len(nodes), "label": f"{NUM[phase]} - {phase}", "kind": "phase", "phase": phase,
                "xyz": list(corners[0])}
        if shares:
            head["hours"] = shares[p]
        nodes.append(head)
        for i in range(3):
            n = p * 3 + i + 1
            nodes.append({"id": len(nodes), "label": steps9[n - 1], "kind": "step", "step": n, "phase": phase,
                          "xyz": list(corners[i + 1])})
    edges = []
    for a, b in combinations(range(len(nodes)), 2):
        A, B = nodes[a], nodes[b]
        if A["kind"] == "goal" or B["kind"] == "goal":
            t = "spoke"
        elif A["phase"] == B["phase"] and _dist(A["xyz"], B["xyz"]) < 2.01:
            t = "phase"
        else:
            t = "lattice"
        edges.append([a, b, t])
    return {"goal": goal, "form": "metatrons_cube_3d", "nodes": nodes, "edges": edges}


def _dist(a, b):
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


def validate(d):
    errs = []
    nodes = d.get("nodes", [])
    if len(nodes) != 13:
        errs.append(f"need 13 spheres (1 goal + 3 phases + 9 steps), have {len(nodes)}")
        return errs
    goals = [n for n in nodes if n["kind"] == "goal"]
    if len(goals) != 1 or goals[0]["xyz"] != [0, 0, 0]:
        errs.append("exactly one goal must sit at the center (0,0,0)")
    outer = [n for n in nodes if n["kind"] != "goal"]
    if any(abs(_dist(n["xyz"], [0, 0, 0]) - math.sqrt(2)) > 1e-6 for n in outer):
        errs.append("all 12 outer spheres must be equidistant from the center (vector equilibrium)")
    if len({tuple(n["xyz"]) for n in nodes}) != 13:
        errs.append("spheres overlap")
    axes = []
    for phase in PLANES:
        group = [n for n in outer if n["phase"] == phase]
        heads = [n for n in group if n["kind"] == "phase"]
        if len(group) != 4 or len(heads) != 1:
            errs.append(f"{phase} needs 1 head + 3 steps")
            continue
        zero = [i for i in range(3) if all(n["xyz"][i] == 0 for n in group)]
        if len(zero) != 1:
            errs.append(f"{phase} is not flat in its own plane")
        else:
            axes.append(zero[0])
    if sorted(axes) != [0, 1, 2]:
        errs.append("the 3 phases must fill the 3 dimensions (XY, XZ, YZ planes)")
    steps = sorted(n["step"] for n in outer if n["kind"] == "step")
    if steps != list(range(1, 10)):
        errs.append(f"steps must be 1-9, found {steps}")
    for phase, num in NUM.items():
        ph = [n["step"] for n in outer if n["phase"] == phase and n["kind"] == "step"]
        if sorted(ph) != list(range(num - 2, num + 1)):
            errs.append(f"{phase} must hold steps {num - 2}-{num}")
    if len(d.get("edges", [])) != 78:
        errs.append(f"Metatron's Cube joins all 13 spheres with 78 lines, found {len(d.get('edges', []))}")
    if any(not str(n["label"]).strip() for n in nodes):
        errs.append("every sphere needs a label")
    return errs


def _project(xyz, ry, rx, size, scale=0.27):
    x, y, z = xyz
    x, z = x * math.cos(ry) + z * math.sin(ry), -x * math.sin(ry) + z * math.cos(ry)
    y, z = y * math.cos(rx) - z * math.sin(rx), y * math.sin(rx) + z * math.cos(rx)
    f = 4.5 / (4.5 + z)
    return size / 2 + x * f * size * scale, size / 2 - y * f * size * scale, z, f


def render_png(d, out, size=1200, ry=0.62, rx=0.42, labels=True):
    from PIL import Image, ImageDraw, ImageFont
    S = 2
    W = size * S
    img = Image.new("RGB", (W, W), "#0B0B10")
    dr = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("DejaVuSans-Bold.ttf", 15 * S)
    except Exception:
        font = ImageFont.load_default()
    P = [_project(n["xyz"], ry, rx, W) for n in d["nodes"]]
    for a, b, t in sorted(d["edges"], key=lambda e: -(P[e[0]][2] + P[e[1]][2])):
        depth = 1 - min(max((P[a][2] + P[b][2]) / 4 + .5, 0), 1) * .6
        g = int(212 * depth)
        col = (g, int(175 * depth), int(55 * depth))
        dr.line([P[a][:2], P[b][:2]], fill=col, width=(3 if t != "lattice" else 1) * S)
    for i in sorted(range(len(P)), key=lambda i: -P[i][2]):
        n, (x, y, z, f) = d["nodes"][i], P[i]
        r = (46 if n["kind"] == "goal" else 34 if n["kind"] == "phase" else 26) * f * S
        c = COLORS[n["phase"]]
        dr.ellipse([x - r, y - r, x + r, y + r], fill="#14141c", outline=c, width=4 * S)
        tag = "369" if n["kind"] == "goal" else str(NUM[n["phase"]]) if n["kind"] == "phase" else str(n["step"])
        dr.text((x, y), tag, fill=c, font=font, anchor="mm")
        if labels:
            dr.text((x, y + r + 12 * S), str(n["label"])[:34], fill="white", font=font, anchor="ma")
    img.resize((size, size), Image.LANCZOS).save(out)
    return out


HTML = """<!doctype html><html><head><meta charset="utf-8"><title>369 Outline - __GOAL__</title>
<style>body{margin:0;background:#0B0B10;color:#eee;font-family:Georgia,serif;display:flex;height:100vh}
#c{flex:1}#side{width:340px;padding:22px;overflow:auto;background:#111118;border-left:2px solid #D4AF37}
h1{color:#D4AF37;font-size:20px}h2{font-size:15px;margin:18px 0 6px}li{margin:4px 0;cursor:pointer}
.PLAN{color:#7FD3FF}.CREATE{color:#9CFFB0}.COMPLETE{color:#FFB0D9}.hint{opacity:.6;font-size:12px}</style></head>
<body><canvas id="c"></canvas><div id="side"><h1>369 Outline<br>__GOAL__</h1>
<div class="hint">Metatron's Cube in 3D: drag to rotate, scroll to zoom, click a step to focus. PASS-verified.</div>
<div id="list"></div></div><script>
const D=__DATA__;const C={GOAL:"#D4AF37",PLAN:"#7FD3FF",CREATE:"#9CFFB0",COMPLETE:"#FFB0D9"};const N={PLAN:3,CREATE:6,COMPLETE:9};
const cv=document.getElementById('c'),x=cv.getContext('2d');let ry=.6,rx=.4,zoom=1,drag=null,spin=true,focus=-1;
function size(){cv.width=cv.clientWidth*devicePixelRatio;cv.height=cv.clientHeight*devicePixelRatio}addEventListener('resize',size);size();
cv.onmousedown=e=>{drag=[e.clientX,e.clientY];spin=false};onmouseup=()=>drag=null;
onmousemove=e=>{if(!drag)return;ry+=(e.clientX-drag[0])*.01;rx+=(e.clientY-drag[1])*.01;drag=[e.clientX,e.clientY]};
cv.onwheel=e=>{zoom*=e.deltaY<0?1.1:.9;e.preventDefault()};
function P(p){let[X,Y,Z]=p;[X,Z]=[X*Math.cos(ry)+Z*Math.sin(ry),-X*Math.sin(ry)+Z*Math.cos(ry)];
[Y,Z]=[Y*Math.cos(rx)-Z*Math.sin(rx),Y*Math.sin(rx)+Z*Math.cos(rx)];const f=4.5/(4.5+Z),s=Math.min(cv.width,cv.height)*.27*zoom;
return[cv.width/2+X*f*s,cv.height/2-Y*f*s,Z,f]}
function draw(){if(spin)ry+=.003;x.fillStyle='#0B0B10';x.fillRect(0,0,cv.width,cv.height);const p=D.nodes.map(n=>P(n.xyz));
D.edges.slice().sort((a,b)=>(p[b[0]][2]+p[b[1]][2])-(p[a[0]][2]+p[a[1]][2])).forEach(([a,b,t])=>{const d=1-Math.min(Math.max((p[a][2]+p[b][2])/4+.5,0),1)*.6;
const hl=focus>=0&&(a==focus||b==focus);x.strokeStyle=hl?'#fff':`rgba(212,175,55,${d*(t=='lattice'?.35:.9)})`;x.lineWidth=(t=='lattice'?1:2.5)*devicePixelRatio;
x.beginPath();x.moveTo(p[a][0],p[a][1]);x.lineTo(p[b][0],p[b][1]);x.stroke()});
[...D.nodes.keys()].sort((a,b)=>p[b][2]-p[a][2]).forEach(i=>{const n=D.nodes[i],[X,Y,Z,f]=p[i],r=(n.kind=='goal'?40:n.kind=='phase'?30:22)*f*devicePixelRatio*zoom;
x.fillStyle='#14141c';x.strokeStyle=C[n.phase];x.lineWidth=(i==focus?6:3)*devicePixelRatio;x.beginPath();x.arc(X,Y,r,0,7);x.fill();x.stroke();
x.fillStyle=C[n.phase];x.font=`bold ${14*devicePixelRatio}px Georgia`;x.textAlign='center';x.textBaseline='middle';
x.fillText(n.kind=='goal'?'369':n.kind=='phase'?N[n.phase]:n.step,X,Y);x.fillStyle='#fff';x.font=`${12*devicePixelRatio}px Georgia`;
x.fillText(String(n.label).slice(0,36),X,Y+r+12*devicePixelRatio)});requestAnimationFrame(draw)}draw();
let h='';['PLAN','CREATE','COMPLETE'].forEach(ph=>{const head=D.nodes.find(n=>n.kind=='phase'&&n.phase==ph);
h+=`<h2 class="${ph}">${head.label}${head.hours?' (~'+head.hours+' h)':''}</h2><ol start="${N[ph]-2}">`;
D.nodes.filter(n=>n.phase==ph&&n.kind=='step').forEach(n=>h+=`<li class="${ph}" onclick="focus=${n.id};spin=false">${n.label}</li>`);h+='</ol>'});
document.getElementById('list').innerHTML=h;</script></body></html>"""


def render_html(d, out):
    page = HTML.replace("__DATA__", json.dumps(d)).replace("__GOAL__", str(d["goal"]).replace("<", "&lt;"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(page)
    return out
