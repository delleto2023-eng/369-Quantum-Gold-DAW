"""Layer 4 - The Memory.
Long-term: SQLite full-text search (zero setup) for notes + a key/value table for durable facts.
Swap `recall` for a vector store (Chroma, sqlite-vec, Pinecone) later without changing the agent.
Short-term: conversation history + running summary (see loop.compact_history).
"""
import re, sqlite3, time


class Memory:
    def __init__(self, path="memory.db"):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.fts = True
        try:
            self.db.execute("CREATE VIRTUAL TABLE IF NOT EXISTS notes USING fts5(content, kind, created)")
        except sqlite3.OperationalError:
            self.fts = False
            self.db.execute("CREATE TABLE IF NOT EXISTS notes (content TEXT, kind TEXT, created TEXT)")
        self.db.execute("CREATE TABLE IF NOT EXISTS facts (key TEXT PRIMARY KEY, value TEXT)")
        self.db.commit()

    def remember(self, content, kind="note"):
        self.db.execute("INSERT INTO notes VALUES (?, ?, ?)", (content, kind, time.strftime("%Y-%m-%d %H:%M")))
        self.db.commit()
        return "Saved to memory."

    k = 9

    def recall(self, query, k=None):
        k = k or self.k
        words = [w for w in re.findall(r"[A-Za-z0-9]+", query) if len(w) > 2]
        if not words:
            return []
        if self.fts:
            q = " OR ".join(f'"{w}"' for w in words)
            rows = self.db.execute("SELECT content, created FROM notes WHERE notes MATCH ? ORDER BY rank LIMIT ?",
                                   (q, k)).fetchall()
        else:
            like = " OR ".join("content LIKE ?" for _ in words)
            rows = self.db.execute(f"SELECT content, created FROM notes WHERE {like} LIMIT ?",
                                   [f"%{w}%" for w in words] + [k]).fetchall()
        return [f"[{c}] {t}" for t, c in rows]

    def set_fact(self, key, value):
        self.db.execute("INSERT OR REPLACE INTO facts VALUES (?, ?)", (key, value))
        self.db.commit()
        return f"Fact saved: {key}"

    def facts(self):
        return dict(self.db.execute("SELECT key, value FROM facts").fetchall())
