"""Skills = reusable playbooks (markdown files in skills/).
Header attributes:
  name, agent, description
  phase       3 (Plan) | 6 (Create) | 9 (Complete)
  triggers    words that make Big Tony pick this skill automatically
  tools       tools the playbook needs (must belong to the agent)
  inputs      what it needs     outputs   what it produces
  success     pass criteria the agent self-checks and the Guardian verifies
  est_minutes rough time
Drop a new .md file in skills/ and every agent can use it instantly.
"""
import re
from pathlib import Path

LIST_KEYS = {"triggers", "tools", "inputs", "outputs", "success"}


class SkillLibrary:
    def __init__(self, folder="skills"):
        self.folder = Path(folder)
        self.skills = {}
        self.reload()

    def reload(self):
        self.skills = {}
        for f in sorted(self.folder.glob("*.md")):
            text = f.read_text(encoding="utf-8")
            meta, body = {"name": f.stem}, text
            if text.startswith("---"):
                _, head, body = text.split("---", 2)
                for line in head.strip().splitlines():
                    if ":" in line:
                        k, v = line.split(":", 1)
                        k, v = k.strip(), v.strip()
                        meta[k] = [x.strip() for x in re.split(r"[;,]", v) if x.strip()] if k in LIST_KEYS else v
            meta["body"] = body.strip()
            self.skills[meta["name"]] = meta

    def catalog(self):
        return "\n".join(f"- {n} [phase {s.get('phase', '?')}, agent: {s.get('agent', 'any')}]: {s.get('description', '')} "
                         f"(triggers: {', '.join(s.get('triggers', []))})" for n, s in self.skills.items()) or "(no skills yet)"

    def get(self, name):
        if name not in self.skills:
            raise KeyError(f"No skill '{name}'. Available: {', '.join(self.skills)}")
        return self.skills[name]

    def match(self, task, top=3):
        """Behavior: auto-pick skills whose trigger words appear in the request."""
        words = set(re.findall(r"[a-z0-9]+", task.lower()))
        text = task.lower()
        scored = []
        for n, s in self.skills.items():
            score = sum(2 if " " in t and t.lower() in text else 1 for t in s.get("triggers", [])
                        if (t.lower() in text if " " in t else t.lower() in words))
            if score:
                scored.append((score, n))
        return [n for _, n in sorted(scored, reverse=True)[:top]]

    def brief(self, name):
        s = self.get(name)
        out = f"Follow this playbook ({name}):\n{s['body']}"
        if s.get("success"):
            out += "\n\nSuccess criteria (check before you answer):\n" + "\n".join("- " + x for x in s["success"])
        if s.get("outputs"):
            out += "\nExpected outputs: " + ", ".join(s["outputs"])
        return out


def add_skill_tools(reg, library):
    @reg.add("list_skills", "List the skill playbooks available to the team.", {})
    def list_skills():
        library.reload()
        return library.catalog()

    @reg.add("load_skill", "Load the full step-by-step playbook for a skill, with its success criteria.",
             {"name": {"type": "string"}}, ["name"])
    def load_skill(name):
        return library.brief(name)
