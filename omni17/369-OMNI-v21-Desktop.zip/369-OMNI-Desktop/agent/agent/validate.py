"""369 validation: the outline and the whole system must PASS before work is called done."""
import re

PHASES = ["3 - PLAN", "6 - CREATE", "9 - COMPLETE"]


def check_outline(md):
    """Rules: title, 3 phases in 3-6-9 order, exactly 3 steps per phase, steps numbered 1-9 in order,
    no empty steps, phase shares follow the golden ratio (each about 1.618x the next)."""
    errors = []
    if not re.search(r"^# 369 Outline: .+", md, re.M):
        errors.append("missing '# 369 Outline: <goal>' title")
    heads = re.findall(r"^## (\d) - (\w+)[^\n]*?\(~([\d.]+) h\)", md, re.M)
    if [f"{n} - {w}" for n, w, _ in heads] != PHASES:
        errors.append(f"phases must be exactly {PHASES} in order, found {[f'{n} - {w}' for n, w, _ in heads]}")
    sections = re.split(r"^## ", md, flags=re.M)[1:]
    nums = []
    for i, sec in enumerate(sections):
        steps = re.findall(r"^(\d+)\. (.*)$", sec, re.M)
        if len(steps) != 3:
            errors.append(f"phase {i + 1} must have 3 steps, has {len(steps)}")
        for n, text in steps:
            nums.append(int(n))
            if len(re.sub(r"\(vortex \d\)", "", text).strip()) < 3:
                errors.append(f"step {n} is empty")
    if nums != list(range(1, 10)):
        errors.append(f"steps must be numbered 1-9 in order, found {nums}")
    shares = [float(h) for _, _, h in heads]
    if len(shares) == 3 and shares[2] > 0:
        for a, b in zip(shares, shares[1:]):
            if b and not 1.3 <= a / b <= 2.2:
                errors.append(f"phase shares {shares} break the golden-ratio flow")
                break
    return errors


def check_system(sysm, cfg):
    from .catalog import STACKS, ALWAYS
    errors, tools, lib = [], sysm["tools"].tools, sysm["library"].skills
    agents, triads = cfg["agents"], cfg.get("triads", {})
    # Metatron's Cube: 1 center + 12 agents = 13 spheres; 3 phases x 4 agents (one square per dimension)
    if len(triads) != 3 or any(len(m) != 4 for m in triads.values()):
        errors.append("need 3 phases of 4 agents (12 around Big Tony = Metatron's 13)")
    flat = [a for m in triads.values() for a in m]
    if sorted(flat) != sorted(agents) or len(agents) != 12:
        errors.append("phases must list each of the 12 agents exactly once")
    if sorted(a.get("number") for a in agents.values()) != list(range(1, 13)):
        errors.append("agents must be numbered 1-12")
    from .geometry import digital_root as _d
    nums = []
    sa = {}
    for ring in cfg.get("rings", []):
        ra, rp = ring["agents"], ring["phases"]
        sizes = {len(m) for m in rp.values()}
        if len(rp) != 3 or len(sizes) != 1 or _d(len(ra)) not in (3, 6, 9):
            errors.append(f"ring {ring['name']}: needs 3 equal phases and an agent count on the 3-6-9 axis")
        if sorted(a for m in rp.values() for a in m) != sorted(ra):
            errors.append(f"ring {ring['name']}: phases must list each agent once")
        if set(ra) & (set(agents) | set(sa)):
            errors.append(f"ring {ring['name']}: agent names must be unique")
        nums += [a.get("number") for a in ra.values()]
        sa.update(ra)
    if sorted(nums) != list(range(13, 13 + len(nums))):
        errors.append("ring agents must be numbered from 13 with no gaps")
    agents = {**agents, **sa}
    from .geometry import digital_root as _dr
    if _dr(len(STACKS)) not in (3, 6, 9):
        errors.append(f"stack count must sit on the 3-6-9 axis, have {len(STACKS)}")
    for s, (_, names) in STACKS.items():
        for n in names:
            if n != "@mcp" and n not in tools:
                errors.append(f"stack {s}: tool {n} is not registered")
    for n in ALWAYS:
        if n not in tools:
            errors.append(f"tool {n} missing")
    for k, a in agents.items():
        for s in a["stacks"]:
            if s not in STACKS:
                errors.append(f"agent {k}: unknown stack {s}")
    from .geometry import digital_root
    if digital_root(len(lib)) not in (3, 6, 9):
        errors.append(f"skill count must sit on the 3-6-9 axis (digital root 3, 6 or 9), have {len(lib)}")
    for n, s in lib.items():
        if s.get("agent") not in agents:
            errors.append(f"skill {n}: agent {s.get('agent')} does not exist")
        if not s.get("description") or not re.search(r"^1\. ", s["body"], re.M):
            errors.append(f"skill {n}: needs a description and numbered steps")
    for t in tools.values():
        if t.schema.get("type") != "object" or not t.description:
            errors.append(f"tool {t.name}: bad schema or description")
    errors += check_attributes(sysm, cfg)
    return errors


AGENT_ATTRS = ["triad", "geometry", "element", "color", "personality", "strengths", "temperature", "max_steps", "max_risk"]
AGENT_BEHAVIORS = ["introspect", "self_check", "retry_on_error", "handoff_to", "escalate_when", "always", "never"]
SKILL_ATTRS = ["phase", "triggers", "tools", "inputs", "outputs", "success", "est_minutes"]


def check_attributes(sysm, cfg):
    from .catalog import SIDE_EFFECTS, REQUIREMENTS
    from .geometry import digital_root
    errors, lib, tools = [], sysm["library"].skills, sysm["tools"].tools
    agents = dict(cfg["agents"])
    for ring in cfg.get("rings", []):
        agents.update(ring["agents"])
    team = sysm["boss"].team
    if not cfg.get("welfare"):
        errors.append("missing welfare settings (boundaries, review threshold)")
    for k, a in list(agents.items()) + [("supervisor", cfg["supervisor"])]:
        at, bh = a.get("attributes", {}), a.get("behaviors", {})
        for f in (AGENT_ATTRS if k != "supervisor" else AGENT_ATTRS[1:]):
            if f not in at:
                errors.append(f"agent {k}: missing attribute {f}")
        for f in AGENT_BEHAVIORS:
            if f not in bh:
                errors.append(f"agent {k}: missing behavior {f}")
        if not 0 <= float(at.get("temperature", 0)) <= 1:
            errors.append(f"agent {k}: temperature must be 0-1")
        ms = int(at.get("max_steps", 9))
        if ms > 27 or digital_root(ms) not in (3, 6, 9):
            errors.append(f"agent {k}: max_steps {ms} must be 27 or less and on the 3-6-9 axis")
        if at.get("max_risk") not in ("safe", "approve"):
            errors.append(f"agent {k}: max_risk must be safe or approve")
        for h in bh.get("handoff_to", []):
            if h not in agents:
                errors.append(f"agent {k}: hands off to unknown agent {h}")
    for name, ag in team.items():
        if agents[name]["attributes"].get("max_risk") == "safe" and any(t.risk != "safe" for t in ag.tools.tools.values()):
            errors.append(f"agent {name}: safe agent can see risky tools")
    triad_num = {k: int(agents[k]["attributes"]["triad"][0]) for k in agents if "attributes" in agents[k]}
    for n, s in lib.items():
        for f in SKILL_ATTRS:
            if not s.get(f):
                errors.append(f"skill {n}: missing attribute {f}")
        owner = s.get("agent")
        if owner in team:
            if str(s.get("phase")) not in ("3", "6", "9"):
                errors.append(f"skill {n}: phase must be 3, 6 or 9")
            for tn in s.get("tools", []):
                if tn not in team[owner].tools.tools:
                    errors.append(f"skill {n}: needs tool {tn} that agent {owner} does not have")
    for t in tools.values():
        if t.cost not in ("free", "paid"):
            errors.append(f"tool {t.name}: cost must be free or paid")
        if t.cost == "paid" and t.risk != "approve":
            errors.append(f"tool {t.name}: paid tools must need approval")
        if t.side_effects not in SIDE_EFFECTS:
            errors.append(f"tool {t.name}: unknown side effect {t.side_effects}")
        if set(t.requires) - REQUIREMENTS:
            errors.append(f"tool {t.name}: unknown requirement {set(t.requires) - REQUIREMENTS}")
        if t.side_effects in ("spends_money", "changes_brain") and t.risk != "approve":
            errors.append(f"tool {t.name}: {t.side_effects} must need approval")
    return errors
