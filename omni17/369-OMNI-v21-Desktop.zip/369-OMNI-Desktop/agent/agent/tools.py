"""Layer 5 - The Hands.
Every tool has a strict JSON schema, a clear description, and a risk level.
risk="safe"    -> runs immediately
risk="approve" -> a human must say yes first (Layer 6)
"""
import html, os, re, subprocess, sys
from dataclasses import dataclass
from typing import Callable


@dataclass
class Tool:
    """Tool attributes (set in agent/catalog.py TOOL_ATTRS):
    risk: safe | approve        cost: free | paid           offline: works without internet
    requires: ffmpeg, internet, pillow, hf_keys, anthropic_key, local_server, mcp
    timeout: seconds            retries: auto-retries on network/timeout errors
    side_effects: none | writes_files | writes_memory | runs_code | network | spends_money | changes_brain"""
    name: str
    description: str
    schema: dict
    fn: Callable
    risk: str = "safe"
    cost: str = "free"
    offline: bool = True
    requires: tuple = ()
    timeout: int = 120
    retries: int = 0
    side_effects: str = "none"

    def card(self):
        return (f"{self.name}: risk={self.risk}, cost={self.cost}, offline={'yes' if self.offline else 'no'}, "
                f"requires={','.join(self.requires) or '-'}, timeout={self.timeout}s, retries={self.retries}, "
                f"effects={self.side_effects}")


class ToolRegistry:
    def __init__(self):
        self.tools = {}

    def register(self, tool):
        self.tools[tool.name] = tool

    def add(self, name, description, properties, required=None, risk="safe"):
        def deco(fn):
            schema = {"type": "object", "properties": properties, "required": required or []}
            self.register(Tool(name, description, schema, fn, risk))
            return fn
        return deco

    def subset(self, names):
        r = ToolRegistry()
        for n in names:
            if n in self.tools:
                r.register(self.tools[n])
        return r

    def specs(self):
        return [{"name": t.name, "description": t.description, "input_schema": t.schema}
                for t in self.tools.values()]


def build_builtin_tools(guard, memory):
    reg = ToolRegistry()
    S = {"type": "string"}

    @reg.add("list_files", "List files in the workspace folder (or a subfolder).", {"path": S})
    def list_files(path="."):
        base = guard.safe_path(path)
        return "\n".join(sorted(str(p.relative_to(guard.workspace)) for p in base.rglob("*"))[:500]) or "(empty)"

    @reg.add("read_file", "Read a text file from the workspace.", {"path": S}, ["path"])
    def read_file(path):
        return guard.untrusted(path, guard.safe_path(path).read_text(encoding="utf-8", errors="replace"))

    @reg.add("write_file", "Create or overwrite a text file in the workspace.",
             {"path": S, "content": S}, ["path", "content"])
    def write_file(path, content):
        p = guard.safe_path(path)
        if p.exists() and not guard.approve("overwrite " + path, {"path": path}):
            return "DENIED: user did not approve overwriting this file."
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"Wrote {len(content)} chars to {path}"

    @reg.add("delete_file", "Delete a file in the workspace.", {"path": S}, ["path"], risk="approve")
    def delete_file(path):
        guard.safe_path(path).unlink()
        return f"Deleted {path}"

    @reg.add("run_shell", "Run a shell command inside the workspace folder. Returns stdout/stderr.",
             {"command": S}, ["command"], risk="approve")
    def run_shell(command):
        guard.check_shell(command)
        r = subprocess.run(command, shell=True, cwd=guard.workspace, capture_output=True, text=True, timeout=120)
        return f"exit={r.returncode}\n{r.stdout}\n{r.stderr}"

    @reg.add("run_python", "Run a Python snippet inside the workspace folder. Use print() for output.",
             {"code": S}, ["code"], risk="approve")
    def run_python(code):
        r = subprocess.run([sys.executable, "-c", code], cwd=guard.workspace,
                           capture_output=True, text=True, timeout=120)
        return f"exit={r.returncode}\n{r.stdout}\n{r.stderr}"

    @reg.add("fetch_url", "Download a web page and return its readable text.", {"url": S}, ["url"])
    def fetch_url(url):
        import requests
        if not url.startswith(("http://", "https://")):
            return "Only http(s) URLs are allowed."
        t = requests.get(url, timeout=30, headers={"User-Agent": "369-ultimate-agent"}).text
        t = re.sub(r"(?is)<(script|style).*?</\1>", " ", t)
        t = html.unescape(re.sub(r"(?s)<[^>]+>", " ", t))
        return guard.untrusted(url, re.sub(r"\s+", " ", t)[:15000])

    @reg.add("remember", "Save a note to long-term memory for future sessions.",
             {"content": S}, ["content"])
    def remember(content):
        return memory.remember(content)

    @reg.add("recall", "Search long-term memory for notes related to a query.", {"query": S}, ["query"])
    def recall(query):
        return "\n".join(memory.recall(query)) or "Nothing found."

    @reg.add("set_fact", "Save a durable fact or preference (key/value), e.g. user_name=Delleto.",
             {"key": S, "value": S}, ["key", "value"])
    def set_fact(key, value):
        return memory.set_fact(key, value)

    return reg
