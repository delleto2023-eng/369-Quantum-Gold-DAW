"""Publisher stack: package finished work for release."""
import zipfile, time


def build_publish_tools(reg, guard):
    S = {"type": "string"}

    @reg.add("package_zip", "Zip a workspace folder (or file) into exports/<name>.zip for sharing or release.",
             {"path": S, "name": S}, ["path", "name"])
    def package_zip(path, name):
        src = guard.safe_path(path)
        out = guard.safe_path(f"exports/{name.replace(' ', '_')}.zip")
        out.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
            files = [src] if src.is_file() else [p for p in src.rglob("*") if p.is_file()]
            for p in files:
                z.write(p, p.relative_to(src.parent))
        return f"Packaged {len(files)} files: {out.relative_to(guard.workspace)}"

    @reg.add("release_notes", "Write release notes / a delivery report to exports/<title>.md.",
             {"title": S, "content": S}, ["title", "content"])
    def release_notes(title, content):
        out = guard.safe_path(f"exports/{title.replace(' ', '_')}.md")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(f"# {title}\n_{time.strftime('%Y-%m-%d')}_\n\n{content}\n", encoding="utf-8")
        return f"Saved: {out.relative_to(guard.workspace)}"

    return reg
