---
name: copilot-test-pane-and-activity-map
description: See what fired live
category: Analytics
source: https://learn.microsoft.com/microsoft-copilot-studio/
---

# Test Pane and Activity Map

Copilot Studio ability: Test Pane and Activity Map.
1. Plan which topics, knowledge and tools to use.
2. Do it with OMNI's own tools (gateway models, connectors, Big Tony engines, Data Brain), free first.
3. Ask approval before external actions.
4. Test in the Self-Test tab, fix, re-test.
5. Report results and any key still needed.
Capability: See what fired live.
