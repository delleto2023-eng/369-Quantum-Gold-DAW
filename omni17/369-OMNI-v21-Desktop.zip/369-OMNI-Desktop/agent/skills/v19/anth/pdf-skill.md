---
name: pdf-skill
description: Fill, merge, extract PDFs
---
# PDF Skill

Anthropic Skills Lab Formats (v19) ability: PDF Skill.
1. Load relevant memory (semantic, episodic, procedural).
2. Plan, then act with OMNI tools/gateway models, free first.
3. Loop max 2 times; answer by 3.5 minutes.
4. Ask approval before external actions.
5. Save what was learned to memory.
Capability: Fill, merge, extract PDFs.
