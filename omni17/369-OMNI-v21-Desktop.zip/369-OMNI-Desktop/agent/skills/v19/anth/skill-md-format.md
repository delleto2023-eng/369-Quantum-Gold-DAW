---
name: skill-md-format
description: Name/description frontmatter, instructions, resources, scripts
---
# SKILL.md Format

Anthropic Skills Lab Formats (v19) ability: SKILL.md Format.
1. Load relevant memory (semantic, episodic, procedural).
2. Plan, then act with OMNI tools/gateway models, free first.
3. Loop max 2 times; answer by 3.5 minutes.
4. Ask approval before external actions.
5. Save what was learned to memory.
Capability: Name/description frontmatter, instructions, resources, scripts.
