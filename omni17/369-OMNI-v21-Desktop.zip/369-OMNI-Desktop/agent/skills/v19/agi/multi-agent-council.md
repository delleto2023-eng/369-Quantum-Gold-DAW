---
name: multi-agent-council
description: Several agents debate and a judge decides
---
# Multi-Agent Council

Premium AGI Mode (v19) ability: Multi-Agent Council.
1. Load relevant memory (semantic, episodic, procedural).
2. Plan, then act with OMNI tools/gateway models, free first.
3. Loop max 2 times; answer by 3.5 minutes.
4. Ask approval before external actions.
5. Save what was learned to memory.
Capability: Several agents debate and a judge decides.
