---
name: premium-reasoning-stack
description: Best available model + plan, self-critique, tool use for every agent
---
# Premium Reasoning Stack

Premium AGI Mode (v19) ability: Premium Reasoning Stack.
1. Load relevant memory (semantic, episodic, procedural).
2. Plan, then act with OMNI tools/gateway models, free first.
3. Loop max 2 times; answer by 3.5 minutes.
4. Ask approval before external actions.
5. Save what was learned to memory.
Capability: Best available model + plan, self-critique, tool use for every agent.
