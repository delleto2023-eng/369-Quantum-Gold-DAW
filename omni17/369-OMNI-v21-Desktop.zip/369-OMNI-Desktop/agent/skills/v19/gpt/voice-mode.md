---
name: voice-mode
description: Talk in real time
---
# Voice Mode

ChatGPT Skills & Tools — all versions (v19) ability: Voice Mode.
1. Load relevant memory (semantic, episodic, procedural).
2. Plan, then act with OMNI tools/gateway models, free first.
3. Loop max 2 times; answer by 3.5 minutes.
4. Ask approval before external actions.
5. Save what was learned to memory.
Capability: Talk in real time.
