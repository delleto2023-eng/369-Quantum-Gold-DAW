---
name: gpt-3-5-chat
description: Fast chat
---
# GPT-3.5 Chat

ChatGPT Skills & Tools — all versions (v19) ability: GPT-3.5 Chat.
1. Load relevant memory (semantic, episodic, procedural).
2. Plan, then act with OMNI tools/gateway models, free first.
3. Loop max 2 times; answer by 3.5 minutes.
4. Ask approval before external actions.
5. Save what was learned to memory.
Capability: Fast chat.
