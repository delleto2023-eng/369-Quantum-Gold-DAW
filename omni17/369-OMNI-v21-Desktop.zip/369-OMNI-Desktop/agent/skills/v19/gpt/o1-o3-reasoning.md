---
name: o1-o3-reasoning
description: Step-by-step thinking models
---
# o1/o3 Reasoning

ChatGPT Skills & Tools — all versions (v19) ability: o1/o3 Reasoning.
1. Load relevant memory (semantic, episodic, procedural).
2. Plan, then act with OMNI tools/gateway models, free first.
3. Loop max 2 times; answer by 3.5 minutes.
4. Ask approval before external actions.
5. Save what was learned to memory.
Capability: Step-by-step thinking models.
