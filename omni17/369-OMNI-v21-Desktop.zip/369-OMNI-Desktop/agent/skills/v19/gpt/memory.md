---
name: memory
description: Remember user across chats
---
# Memory

ChatGPT Skills & Tools — all versions (v19) ability: Memory.
1. Load relevant memory (semantic, episodic, procedural).
2. Plan, then act with OMNI tools/gateway models, free first.
3. Loop max 2 times; answer by 3.5 minutes.
4. Ask approval before external actions.
5. Save what was learned to memory.
Capability: Remember user across chats.
