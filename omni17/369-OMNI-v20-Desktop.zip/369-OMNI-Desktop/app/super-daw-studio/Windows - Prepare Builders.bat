@echo off
rem 369 Super DAW Studio - Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
cd /d "%~dp0"
echo Preparing the installer builder and the FL plugin builder...
xcopy /E /I /Y "app" "Build Real Installers (optional)\app" >nul
xcopy /E /I /Y "app" "369 FL Studio Plugin (VST3 AU)\app" >nul
echo Done. Both builder folders now have the app.
pause
