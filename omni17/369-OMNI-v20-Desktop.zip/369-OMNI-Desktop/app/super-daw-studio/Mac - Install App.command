#!/bin/bash
# 369 Super DAW Studio - Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
# Builds "369 Super DAW Studio.app" in your Applications folder with its own icon.
SRC="$(cd "$(dirname "$0")" && pwd)"
A="$HOME/Applications/369 Super DAW Studio.app"
mkdir -p "$A/Contents/MacOS" "$A/Contents/Resources"
rm -rf "$A/Contents/Resources/app"; cp -R "$SRC/app" "$A/Contents/Resources/app"
cp "$SRC/app/icons/369.icns" "$A/Contents/Resources/369.icns"
cat > "$A/Contents/Info.plist" <<'P'
<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict><key>CFBundleName</key><string>369 Super DAW Studio</string><key>CFBundleDisplayName</key><string>369 Super DAW Studio</string><key>CFBundleIdentifier</key><string>com.delletowhitehead.369solidgoldstudio</string><key>CFBundleVersion</key><string>9.0</string><key>CFBundleExecutable</key><string>run</string><key>CFBundleIconFile</key><string>369</string><key>CFBundlePackageType</key><string>APPL</string><key>NSHumanReadableCopyright</key><string>Copyright 2026 Delleto Whitehead. All rights reserved.</string></dict></plist>
P
cat > "$A/Contents/MacOS/run" <<'R'
#!/bin/bash
APP="$(cd "$(dirname "$0")/../Resources/app" && pwd)/index.html"
for B in "Google Chrome" "Microsoft Edge" "Brave Browser"; do
  if [ -d "/Applications/$B.app" ]; then open -na "$B" --args --app="file://$APP" --user-data-dir="$HOME/Library/Application Support/369SolidGoldStudio"; exit 0; fi
done
open "$APP"
R
chmod +x "$A/Contents/MacOS/run"; touch "$A"
echo "Installed: $A"; open "$HOME/Applications"
