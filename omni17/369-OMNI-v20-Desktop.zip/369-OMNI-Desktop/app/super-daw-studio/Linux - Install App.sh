#!/bin/bash
# 369 Super DAW Studio - Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
DEST="$HOME/.local/share/369-super-daw-studio"; mkdir -p "$DEST" "$HOME/.local/share/applications"
cp -R "$(cd "$(dirname "$0")" && pwd)/app" "$DEST/"; cp "$(cd "$(dirname "$0")" && pwd)/Linux - Open 369 Studio.sh" "$DEST/run.sh"; chmod +x "$DEST/run.sh"
cat > "$HOME/.local/share/applications/369-super-daw-studio.desktop" <<E
[Desktop Entry]
Name=369 Super DAW Studio
Comment=Royal digital audio workstation by Delleto Whitehead
Exec="$DEST/run.sh"
Icon=$DEST/app/icons/369-256.png
Terminal=false
Type=Application
Categories=AudioVideo;Audio;Music;
E
cp "$HOME/.local/share/applications/369-super-daw-studio.desktop" "$HOME/Desktop/" 2>/dev/null; chmod +x "$HOME/Desktop/369-super-daw-studio.desktop" 2>/dev/null
echo "Installed. Find 369 Super DAW Studio in your apps menu."
