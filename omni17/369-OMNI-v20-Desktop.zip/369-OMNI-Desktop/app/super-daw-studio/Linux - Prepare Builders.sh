#!/bin/bash
# 369 Super DAW Studio - Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
cd "$(dirname "$0")"
echo "Preparing the installer builder and the FL plugin builder..."
mkdir -p "Build Real Installers (optional)/app" "369 FL Studio Plugin (VST3 AU)/app"
cp -R app/. "Build Real Installers (optional)/app/"
cp -R app/. "369 FL Studio Plugin (VST3 AU)/app/"
echo "Done. Both builder folders now have the app."
