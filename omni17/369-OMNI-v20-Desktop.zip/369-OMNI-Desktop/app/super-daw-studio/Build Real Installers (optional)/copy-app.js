// 369 Super DAW Studio - Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
// Copies the shared app folder into this builder (only if it is not here yet).
const fs=require('fs'),path=require('path');const here=path.join(__dirname,'app'),src=path.join(__dirname,'..','app');
if(fs.existsSync(path.join(here,'index.html'))){console.log('app folder ready');process.exit(0);}
if(fs.existsSync(src)==false){console.error('Put the app folder from the main 369 Super DAW Studio folder into this folder, then try again.');process.exit(1);}
fs.cpSync(src,here,{recursive:true});console.log('app folder copied in');
