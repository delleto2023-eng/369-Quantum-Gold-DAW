// 369 Super DAW Studio - Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
const {app,BrowserWindow,shell,session}=require('electron');const path=require('path');
function win(){const w=new BrowserWindow({width:1440,height:900,minWidth:900,minHeight:600,backgroundColor:'#0b0906',title:'369 Super DAW Studio',icon:path.join(__dirname,'app/icons/icon-512.png'),autoHideMenuBar:true,webPreferences:{contextIsolation:true,sandbox:true}});
 w.loadFile(path.join(__dirname,'app/index.html'));w.webContents.setWindowOpenHandler(({url})=>{shell.openExternal(url);return{action:'deny'};});}
app.whenReady().then(()=>{session.defaultSession.setPermissionRequestHandler((wc,perm,cb)=>cb(['media','clipboard-read','clipboard-sanitized-write','fileSystem'].includes(perm)));win();app.on('activate',()=>{if(!BrowserWindow.getAllWindows().length)win();});});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
