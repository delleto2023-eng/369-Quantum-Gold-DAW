369 SUPER DAW STUDIO v9

ON A COMPUTER (Windows, Mac, Linux)
Keep this folder anywhere (for example your desktop) and double-click index.html.
It opens in Chrome, Edge, Safari or Firefox and works offline.

ON A PHONE OR TABLET, AND TO SHARE A LINK
1. Go to app.netlify.com/drop and drag this whole folder onto the page (a free account keeps the site up).
2. Open the link Netlify gives you on any phone or computer.
3. iPhone/iPad: Safari > Share > Add to Home Screen. Android/computer: tap Install.
4. Paste the link into the Share window in the app so friends and group chats can open it.
GitHub Pages and other free static hosts work the same way.

Your projects, libraries and plugins are saved in each browser on each device.
Use Save Project to move work between devices.

Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.


ONLINE AND OFFLINE (v5)
- The whole studio now works with no internet: beats, piano roll, mixer, recording, effects, saving projects and exporting audio.
- Fonts are built into the app, so it looks the same offline.
- Installed app (hosted on a website): open it once while online. After that it opens and runs offline. When you're back online it picks up updates automatically.
- Single-file version (369 Super DAW Studio v5.html): save it to your device and open it any time, online or offline.
- Needs internet: the AI assistant (unless using local Ollama) and downloading new sounds from the web. Sounds you've already loaded stay saved.
- A small badge in the bottom corner shows when you're Online or Offline.


HEALING FREQUENCIES + EXPORT LIBRARY (v6)
- New Healing Hz tab: 432, 528, 741, 852 and 963 Hz in five modes - Pure Tone, Binaural Beats, Isochronic Tones, Tuned Drums and Mixed Ambient.
- Session timer (10, 30, 60 min or infinite) with a 30 second fade out and a singing bowl chime at the end. Live cymatics visual.
- Frequency Sound Library: 315 frequency-locked samples in 7 categories (105 drums) across Ambient, Downtempo, Lo-Fi, Chillhop, Meditation and Trance. Play, add to your Vault, or download as WAV.
- Export Library: "Export Everything to a Folder" (Chrome or Edge on a computer) writes the full set:
    369 Healing Frequencies/healing-frequencies/<Hz>/<mode>/..._10min/30min/60min.wav
    369 Healing Frequencies/sound-library/<category>/<Hz>/...wav
  The full export is around 18 GB, so check your free space. Untick anything you don't need.
- "Download Sound Library (ZIP)" works in every browser. Phones, Safari and Firefox can also download single tracks one at a time.
- All of it is generated in the app, so it works offline.


FULL LIBRARY DOWNLOAD (v7)
- "Download Full Library (WAV)" in the Sound Vault and the Healing Hz tab builds one ZIP with every sound: the 369 Core Vault (369 sounds), any libraries you've forged, your own vault, and the 315 healing samples. All 16-bit 44.1 kHz WAV. Works offline.


BIG TONY COLLECTIVE + LEARNING BRAIN (v8)
- Open Big Tony and tap "Collective". Every AI you connect (Claude, GPT, Gemini, OpenRouter, Ollama) becomes one mind: each question goes to all of them at once, then the strongest one fuses the answers into a single reply.
- Auto-update: when the app updates, once a day, and whenever you come back online, Big Tony scans for new AI models (newest free OpenRouter models, models installed in Ollama, and the newest models your Gemini/GPT/Claude keys can use) and adds them to the collective automatically. Turn "New AI joins automatically" off to approve them yourself.
- Learns as you go: remembers what you tell him ("I make trap at 140 BPM"), your favourite BPMs, your most-used sounds and what you talk about, and uses it in every answer. Rate replies Good / Not good and the collective gives more power to the minds that serve you best.
- Offline: the collective rests, and Big Tony answers from his built-in brain plus his memory of you. A local Ollama model keeps full AI working with no internet.
- Export brain / Import brain moves what he has learned to another device (API keys are never included).
- Ask "what do you know about me" to see his memory. Forget or reset anything in the Collective panel.

OFFLINE FIX (v8)
- The offline engine (sw.js) was empty in v7, so a hosted copy could not open offline. v8 restores it: open the hosted app once online and it works offline after that, and picks up updates automatically.


KNOWLEDGE, MODEL PICKER, CORRECTIONS + AI DIRECTORY (v9)
- Model picker: chips above Big Tony's message box let you choose which AIs answer each question (all are on by default).
- Knowledge tab (Big Tony > Collective > Knowledge): drop files (TXT, MD, ODT, DOCX, HTML, CSV, JSON, simple PDFs), paste text, or add links. Big Tony pulls out the key points and uses them in every answer. Each new addition also re-learns anything that was learned offline.
- Link sources re-learn automatically every day and whenever you come back online, or tap "Refresh link sources now". No plan or credits needed - it runs in the app.
- Corrections: tap Not good and say what was wrong. Every AI in the collective sees your corrections from then on.
- AI Directory: free and paid AIs with "Get key" and "Add" buttons. It grows with every auto-scan.
- Export knowledge as JSON or Markdown, and import it on another device.
