// Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>
#include <cstring>

SG369Processor::SG369Processor()
    : AudioProcessor (BusesProperties().withOutput ("Output", juce::AudioChannelSet::stereo(), true)) {}

juce::AudioProcessorEditor* SG369Processor::createEditor() { return new SG369Editor (*this); }

void SG369Processor::startNote (int note, float velocity)
{
    const bool pad = note >= firstPadNote && note < firstPadNote + numSlots;
    const int slot = pad ? note - firstPadNote : juce::jlimit (0, numSlots - 1, keysSlot.load());
    auto& s = slots[slot];
    if (s.buf.getNumSamples() < 2) return;
    double inc = s.sr / rate;
    if (\! pad) inc *= std::pow (2.0, (note - 60) / 12.0);
    auto& v = voices[nextVoice];
    nextVoice = (nextVoice + 1) % numVoices;
    v.slot = slot; v.note = note; v.pos = 0.0; v.inc = inc;
    v.gain = 0.2f + 0.8f * velocity; v.env = 1.0f;
    v.active = true; v.releasing = false; v.oneShot = pad;
}

void SG369Processor::stopNote (int note)
{
    for (auto& v : voices)
        if (v.active && \! v.oneShot && v.note == note) v.releasing = true;
}

void SG369Processor::render (juce::AudioBuffer<float>& out, int start, int num)
{
    for (auto& v : voices)
    {
        if (\! v.active) continue;
        auto& s = slots[v.slot];
        const int len = s.buf.getNumSamples(), nch = s.buf.getNumChannels();
        if (len < 2 || nch < 1) { v.active = false; continue; }
        for (int i = 0; i < num; ++i)
        {
            const int idx = (int) v.pos;
            if (idx >= len - 1) { v.active = false; break; }
            if (v.releasing) { v.env *= 0.9993f; if (v.env < 0.0005f) { v.active = false; break; } }
            const float fr = (float) (v.pos - idx);
            for (int c = 0; c < out.getNumChannels(); ++c)
            {
                const float* d = s.buf.getReadPointer (juce::jmin (c, nch - 1));
                out.addSample (c, start + i, (d[idx] + (d[idx + 1] - d[idx]) * fr) * v.gain * v.env);
            }
            v.pos += v.inc;
        }
    }
}

void SG369Processor::processBlock (juce::AudioBuffer<float>& out, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    out.clear();
    if (auto* ph = getPlayHead())
        if (auto pos = ph->getPosition())
            if (auto bpm = pos->getBpm()) hostBpm.store (*bpm);

    const juce::SpinLock::ScopedTryLockType tl (lock);
    if (\! tl.isLocked()) return;

    const int pv = previewSlot.exchange (-1);
    if (pv >= 0 && pv < numSlots) startNote (firstPadNote + pv, 0.9f);

    int pos = 0;
    for (const auto meta : midi)
    {
        const auto m = meta.getMessage();
        const int t = juce::jlimit (0, out.getNumSamples(), meta.samplePosition);
        if (t > pos) { render (out, pos, t - pos); pos = t; }
        if (m.isNoteOn()) startNote (m.getNoteNumber(), m.getFloatVelocity());
        else if (m.isNoteOff()) stopNote (m.getNoteNumber());
        else if (m.isAllNotesOff() || m.isAllSoundOff()) for (auto& v : voices) v.active = false;
    }
    if (pos < out.getNumSamples()) render (out, pos, out.getNumSamples() - pos);
    out.applyGain (masterGain.load());
}

void SG369Processor::setSlot (int index, juce::AudioBuffer<float>&& b, double sr, const juce::String& name)
{
    if (index < 0 || index >= numSlots) return;
    const juce::SpinLock::ScopedLockType sl (lock);
    for (auto& v : voices) if (v.slot == index) v.active = false;
    slots[index].buf = std::move (b);
    slots[index].sr = sr > 0 ? sr : 44100.0;
    slots[index].name = name;
}

void SG369Processor::clearSlot (int index)
{
    juce::AudioBuffer<float> empty;
    setSlot (index, std::move (empty), 44100.0, {});
}

juce::StringArray SG369Processor::getSlotNames()
{
    juce::StringArray names;
    const juce::SpinLock::ScopedLockType sl (lock);
    for (auto& s : slots) names.add (s.name);
    return names;
}

void SG369Processor::getStateInformation (juce::MemoryBlock& dest)
{
    juce::ValueTree tree ("SG369");
    tree.setProperty ("keys", keysSlot.load(), nullptr);
    tree.setProperty ("gain", masterGain.load(), nullptr);
    const juce::SpinLock::ScopedLockType sl (lock);
    for (int i = 0; i < numSlots; ++i)
    {
        auto& s = slots[i];
        if (s.buf.getNumSamples() == 0) continue;
        juce::ValueTree c ("Slot");
        c.setProperty ("index", i, nullptr);
        c.setProperty ("name", s.name, nullptr);
        c.setProperty ("sr", s.sr, nullptr);
        c.setProperty ("ch", s.buf.getNumChannels(), nullptr);
        for (int ch = 0; ch < s.buf.getNumChannels(); ++ch)
            c.setProperty ("d" + juce::String (ch),
                           juce::var (juce::MemoryBlock (s.buf.getReadPointer (ch), (size_t) s.buf.getNumSamples() * sizeof (float))), nullptr);
        tree.appendChild (c, nullptr);
    }
    juce::MemoryOutputStream mo (dest, false);
    tree.writeToStream (mo);
}

void SG369Processor::setStateInformation (const void* data, int size)
{
    auto tree = juce::ValueTree::readFromData (data, (size_t) size);
    if (\! tree.isValid()) return;
    keysSlot = (int) tree.getProperty ("keys", 0);
    masterGain = (float) (double) tree.getProperty ("gain", 0.8);
    for (auto c : tree)
    {
        const int idx = c.getProperty ("index", -1), nch = c.getProperty ("ch", 0);
        if (idx < 0 || nch < 1) continue;
        auto* first = c.getProperty ("d0").getBinaryData();
        if (first == nullptr) continue;
        const int len = (int) (first->getSize() / sizeof (float));
        juce::AudioBuffer<float> b (nch, len);
        for (int ch = 0; ch < nch; ++ch)
            if (auto* mb = c.getProperty ("d" + juce::String (ch)).getBinaryData())
                std::memcpy (b.getWritePointer (ch), mb->getData(), juce::jmin (mb->getSize(), (size_t) len * sizeof (float)));
        setSlot (idx, std::move (b), (double) c.getProperty ("sr", 44100.0), c.getProperty ("name").toString());
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new SG369Processor(); }
