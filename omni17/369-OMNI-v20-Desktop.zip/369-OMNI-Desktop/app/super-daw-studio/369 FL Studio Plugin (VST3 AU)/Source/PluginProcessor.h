// Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_audio_utils/juce_audio_utils.h>
#include <atomic>

// 369 Super DAW Studio as an instrument plugin.
// The full 369 app runs inside the plugin window. Sounds you send from the app
// load into 16 pads. FL Studio's piano roll / keyboard plays them:
//   MIDI notes 36-51 (FL: C3 to D#4)  -> pads 1-16 (one-shot)
//   every other note                    -> the "Keys" pad, pitched across the keyboard
class SG369Processor : public juce::AudioProcessor
{
public:
    static constexpr int numSlots = 16, numVoices = 32, firstPadNote = 36;
    struct Slot { juce::AudioBuffer<float> buf; double sr = 44100.0; juce::String name; };

    SG369Processor();
    void prepareToPlay (double sampleRate, int) override { rate = sampleRate; }
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& l) const override
    {
        auto o = l.getMainOutputChannelSet();
        return o == juce::AudioChannelSet::stereo() || o == juce::AudioChannelSet::mono();
    }
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    using AudioProcessor::processBlock;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "369 Super DAW Studio"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 2.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return "Default"; }
    void changeProgramName (int, const juce::String&) override {}
    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    void setSlot (int index, juce::AudioBuffer<float>&& b, double sr, const juce::String& name);
    void clearSlot (int index);
    juce::StringArray getSlotNames();

    std::atomic<double> hostBpm { 0.0 };
    std::atomic<int> keysSlot { 0 }, previewSlot { -1 };
    std::atomic<float> masterGain { 0.8f };

private:
    struct Voice { int slot = -1, note = -1; double pos = 0.0, inc = 1.0; float gain = 0.0f, env = 1.0f; bool active = false, releasing = false, oneShot = true; };
    void startNote (int note, float velocity);
    void stopNote (int note);
    void render (juce::AudioBuffer<float>&, int start, int num);

    Slot slots[numSlots];
    Voice voices[numVoices];
    int nextVoice = 0;
    double rate = 44100.0;
    juce::SpinLock lock;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SG369Processor)
};
