// Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
#include "PluginEditor.h"
#include "BinaryData.h"

SG369Editor::SG369Editor (SG369Processor& p)
    : AudioProcessorEditor (p), proc (p),
      web (juce::WebBrowserComponent::Options{}
               .withBackend (juce::WebBrowserComponent::Options::Backend::webview2)
               .withWinWebView2Options (juce::WebBrowserComponent::Options::WinWebView2{}
                   .withUserDataFolder (juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                                            .getChildFile ("369 Super DAW Studio Plugin")))
               .withNativeIntegrationEnabled()
               .withKeepPageLoadedWhenBrowserIsHidden()
               .withResourceProvider ([] (const juce::String& url) { return getResource (url); })
               .withEventListener ("sg369_slot", [this] (juce::var v) { onSlot (v); })
               .withEventListener ("sg369_cmd", [this] (juce::var v) { onCmd (v); }))
{
    addAndMakeVisible (web);
    web.goToURL (juce::WebBrowserComponent::getResourceProviderRoot());
    setResizable (true, true);
    setResizeLimits (900, 600, 3840, 2160);
    setSize (1400, 860);
    startTimerHz (2);
}

std::optional<juce::WebBrowserComponent::Resource> SG369Editor::getResource (const juce::String& url)
{
    const auto path = url.upToFirstOccurrenceOf ("?", false, false);
    if (path.isEmpty() || path == "/" || path == "/index.html")
    {
        const auto* d = reinterpret_cast<const std::byte*> (BinaryData::index_html);
        return juce::WebBrowserComponent::Resource { std::vector<std::byte> (d, d + BinaryData::index_htmlSize), "text/html" };
    }
    return std::nullopt;
}

void SG369Editor::onSlot (const juce::var& v)
{
    const int index = v["slot"];
    const auto* chans = v["ch"].getArray();
    if (chans == nullptr || chans->isEmpty()) return;
    std::vector<juce::MemoryBlock> data;
    for (auto& c : *chans)
    {
        juce::MemoryOutputStream mo;
        juce::Base64::convertFromBase64 (mo, c.toString());
        data.push_back (mo.getMemoryBlock());
    }
    const int nch = juce::jmin (2, (int) data.size());
    const int len = (int) (data[0].getSize() / sizeof (float));
    if (len < 2) return;
    juce::AudioBuffer<float> b (nch, len);
    for (int ch = 0; ch < nch; ++ch)
    {
        b.clear (ch, 0, len);
        std::memcpy (b.getWritePointer (ch), data[(size_t) ch].getData(), juce::jmin (data[(size_t) ch].getSize(), (size_t) len * sizeof (float)));
    }
    proc.setSlot (index, std::move (b), (double) v["sr"], v["name"].toString());
}

void SG369Editor::onCmd (const juce::var& v)
{
    const auto cmd = v["cmd"].toString();
    const int slot = v["slot"];
    if (cmd == "preview") proc.previewSlot = slot;
    else if (cmd == "clear") proc.clearSlot (slot);
    else if (cmd == "keys") proc.keysSlot = juce::jlimit (0, SG369Processor::numSlots - 1, slot);
    else if (cmd == "gain") proc.masterGain = (float) (double) v["value"];
}

void SG369Editor::timerCallback()
{
    auto* o = new juce::DynamicObject();
    o->setProperty ("bpm", proc.hostBpm.load());
    o->setProperty ("keys", proc.keysSlot.load());
    o->setProperty ("gain", proc.masterGain.load());
    juce::Array<juce::var> names;
    for (auto& n : proc.getSlotNames()) names.add (n);
    o->setProperty ("slots", names);
    o->setProperty ("host", juce::PluginHostType().getHostDescription());
    juce::var info (o);
    const auto json = juce::JSON::toString (info, true);
    if (json == lastSent) return;
    lastSent = json;
    web.emitEventIfBrowserIsVisible ("sg369_host", info);
}
