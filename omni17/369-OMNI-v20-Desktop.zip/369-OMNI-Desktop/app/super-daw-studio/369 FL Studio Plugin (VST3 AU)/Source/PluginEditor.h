// Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
#pragma once
#include "PluginProcessor.h"
#include <juce_gui_extra/juce_gui_extra.h>
#include <optional>

class SG369Editor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit SG369Editor (SG369Processor&);
    void resized() override { web.setBounds (getLocalBounds()); }

private:
    void timerCallback() override;
    void onSlot (const juce::var&);
    void onCmd (const juce::var&);
    static std::optional<juce::WebBrowserComponent::Resource> getResource (const juce::String& url);

    SG369Processor& proc;
    juce::WebBrowserComponent web;
    juce::String lastSent;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SG369Editor)
};
