# Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
cmake_minimum_required(VERSION 3.22)
project(SolidGold369 VERSION 33.0.0)
include(FetchContent)
FetchContent_Declare(JUCE GIT_REPOSITORY https://github.com/juce-framework/JUCE.git GIT_TAG 8.0.4 GIT_SHALLOW TRUE)
FetchContent_MakeAvailable(JUCE)

juce_add_plugin(SolidGold369
    COMPANY_NAME "Delleto Whitehead"
    PRODUCT_NAME "369 Super DAW Studio"
    BUNDLE_ID com.delletowhitehead.solidgold369
    PLUGIN_MANUFACTURER_CODE Dw36
    PLUGIN_CODE S369
    IS_SYNTH TRUE
    NEEDS_MIDI_INPUT TRUE
    NEEDS_MIDI_OUTPUT FALSE
    IS_MIDI_EFFECT FALSE
    EDITOR_WANTS_KEYBOARD_FOCUS TRUE
    NEEDS_WEBVIEW2 TRUE
    VST3_CATEGORIES Instrument Sampler
    AU_MAIN_TYPE kAudioUnitType_MusicDevice
    ICON_BIG "app/369-256.png"
    FORMATS VST3 AU Standalone)

juce_add_binary_data(SG369Data SOURCES app/index.html)

target_sources(SolidGold369 PRIVATE Source/PluginProcessor.cpp Source/PluginEditor.cpp)
target_compile_features(SolidGold369 PRIVATE cxx_std_17)
target_compile_definitions(SolidGold369 PUBLIC
    JUCE_WEB_BROWSER=1
    JUCE_USE_CURL=0
    JUCE_VST3_CAN_REPLACE_VST2=0
    JUCE_USE_WIN_WEBVIEW2_WITH_STATIC_LINKING=1)
target_link_libraries(SolidGold369
    PRIVATE SG369Data juce::juce_audio_utils juce::juce_gui_extra
    PUBLIC juce::juce_recommended_config_flags juce::juce_recommended_warning_flags)
