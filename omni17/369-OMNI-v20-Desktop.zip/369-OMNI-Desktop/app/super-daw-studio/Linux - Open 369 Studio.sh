#!/bin/bash
# 369 Super DAW Studio - Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
DIR="$(cd "$(dirname "$0")" && pwd)"; APP="$DIR/app/index.html"
for B in google-chrome chromium chromium-browser microsoft-edge brave-browser; do
  if command -v $B >/dev/null; then exec $B --app="file://$APP" --user-data-dir="$HOME/.config/369SolidGoldStudio"; fi
done
xdg-open "$APP"
