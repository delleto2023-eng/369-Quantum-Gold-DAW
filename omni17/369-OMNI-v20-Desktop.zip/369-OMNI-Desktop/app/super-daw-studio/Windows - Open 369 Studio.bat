@echo off
rem 369 Super DAW Studio - Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
set "APP=%~dp0app\index.html"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if exist "%CHROME%" ( start "" "%CHROME%" --app="file:///%APP:\=/%" --user-data-dir="%LocalAppData%\369SolidGoldStudio" --window-size=1440,900 & exit /b )
if exist "%EDGE%" ( start "" "%EDGE%" --app="file:///%APP:\=/%" --user-data-dir="%LocalAppData%\369SolidGoldStudio" --window-size=1440,900 & exit /b )
start "" "%APP%"
