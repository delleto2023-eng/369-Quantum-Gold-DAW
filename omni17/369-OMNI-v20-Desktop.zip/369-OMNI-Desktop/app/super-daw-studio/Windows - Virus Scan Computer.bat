@echo off
rem 369 Shield - Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
rem Updates Microsoft Defender, scans this computer and removes any threats it finds.
net session >nul 2>&1 || (powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs" & exit /b)
set "MP=%ProgramFiles%\Windows Defender\MpCmdRun.exe"
if not exist "%MP%" ( echo Microsoft Defender was not found. If you use another antivirus, run its scan instead. & pause & exit /b )
echo 369 SHIELD - WHOLE COMPUTER VIRUS SCAN
echo.
echo  1 = Quick scan (about 5-15 minutes)
echo  2 = Full scan  (can take an hour or more)
echo.
choice /c 12 /n /m "Choose 1 or 2: "
set T=%errorlevel%
echo.
echo Updating virus definitions...
"%MP%" -SignatureUpdate
echo.
echo Scanning. Threats are removed or quarantined automatically...
"%MP%" -Scan -ScanType %T%
echo.
echo Removing anything Defender found...
powershell -NoProfile -Command "Remove-MpThreat -ErrorAction SilentlyContinue; Get-MpThreatDetection | Select-Object -Last 20 InitialDetectionTime,ThreatID,Resources | Format-List"
echo.
echo Done. Opening Windows Security protection history.
start "" windowsdefender://threat/
pause
