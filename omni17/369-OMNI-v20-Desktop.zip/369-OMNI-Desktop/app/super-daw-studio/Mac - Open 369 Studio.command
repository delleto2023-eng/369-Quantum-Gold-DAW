#!/bin/bash
# 369 Super DAW Studio - Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
DIR="$(cd "$(dirname "$0")" && pwd)"; APP="$DIR/app/index.html"
for B in "Google Chrome" "Microsoft Edge" "Brave Browser"; do
  if [ -d "/Applications/$B.app" ]; then open -na "$B" --args --app="file://$APP" --user-data-dir="$HOME/Library/Application Support/369SolidGoldStudio"; exit 0; fi
done
open "$APP"
