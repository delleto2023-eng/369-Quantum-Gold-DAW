@echo off
rem 369 Super DAW Studio - Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
rem Copies the studio to your user folder and puts "369 Super DAW Studio" on your Desktop and Start menu.
set "DEST=%LocalAppData%\369 Super DAW Studio"
echo Installing 369 Super DAW Studio to "%DEST%" ...
xcopy "%~dp0app" "%DEST%\app\" /E /I /Y /Q >nul
copy /Y "%~dp0Windows - Open 369 Studio.bat" "%DEST%\Open 369 Studio.bat" >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$s=New-Object -ComObject WScript.Shell;" ^
 "foreach($p in @([Environment]::GetFolderPath('Desktop'),(Join-Path $env:AppData 'Microsoft\Windows\Start Menu\Programs'))){" ^
 "$l=$s.CreateShortcut((Join-Path $p '369 Super DAW Studio.lnk'));" ^
 "$l.TargetPath=Join-Path $env:LocalAppData '369 Super DAW Studio\Open 369 Studio.bat';" ^
 "$l.WorkingDirectory=Join-Path $env:LocalAppData '369 Super DAW Studio';" ^
 "$l.IconLocation=(Join-Path $env:LocalAppData '369 Super DAW Studio\app\icons\369.ico')+',0';" ^
 "$l.WindowStyle=7;$l.Description='369 Super DAW Studio';$l.Save()}"
echo.
echo Done. Double-click "369 Super DAW Studio" on your Desktop or in the Start menu.
pause
