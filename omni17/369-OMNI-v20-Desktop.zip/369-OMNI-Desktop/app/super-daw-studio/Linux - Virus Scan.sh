#!/bin/bash
# 369 Shield - Created by Delleto Whitehead. Copyright 2026 Delleto Whitehead. All rights reserved.
# Scans your home folder with the free ClamAV scanner and deletes infected files.
echo "369 SHIELD - VIRUS SCAN"
if ! command -v clamscan >/dev/null; then
  echo "ClamAV (free antivirus scanner) is not installed."
  if command -v brew >/dev/null; then read -p "Install it now with Homebrew? (y/n) " a; [ "$a" = y ] && brew install clamav && { CONF="$(brew --prefix)/etc/clamav"; [ -f "$CONF/freshclam.conf" ] || sed 's/^Example/#Example/' "$CONF/freshclam.conf.sample" > "$CONF/freshclam.conf"; };
  elif command -v apt-get >/dev/null; then read -p "Install it now? (y/n) " a; [ "$a" = y ] && sudo apt-get update && sudo apt-get install -y clamav;
  elif command -v dnf >/dev/null; then read -p "Install it now? (y/n) " a; [ "$a" = y ] && sudo dnf install -y clamav clamav-update;
  else echo "Install ClamAV from https://www.clamav.net/downloads then run this again."; fi
fi
command -v clamscan >/dev/null || { read -p "Press Enter to close"; exit 1; }
echo "Updating virus definitions..."; (freshclam || sudo freshclam) 2>/dev/null
echo; echo "1 = Quick (Downloads, Desktop, Documents, Music)   2 = Full home folder"; read -p "Choose 1 or 2: " t
if [ "$t" = 2 ]; then T=("$HOME"); else T=("$HOME/Downloads" "$HOME/Desktop" "$HOME/Documents" "$HOME/Music"); fi
LOG="$HOME/369 Shield scan $(date +%Y-%m-%d_%H%M).txt"
echo "Scanning... infected files are deleted. Report: $LOG"
clamscan -r -i --remove=yes --exclude-dir="Library/Caches" "${T[@]}" | tee "$LOG"
echo; echo "Done."; read -p "Press Enter to close"
