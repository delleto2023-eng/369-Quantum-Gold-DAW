/* Big Tony Cloud tab for 369 OMNI  -  drop-in, no dependencies.
   Shows both 300 GB stacks, upload / download / share / delete, with bling, sun rays and crystal-diamond clicks.
   Talks to Big Tony Cloud (python -m big_tony_builder.cloud serve) at http://localhost:3691 by default. */
(function () {
  "use strict";
  if (window.BigTonyCloudTab) return;
  var CFG = Object.assign({ server: localStorage.getItem("btc-server") || "http://localhost:3691", tabLabel: "BIG TONY CLOUD", mount: null }, window.BIG_TONY_CLOUD_CONFIG || {});
  var token = sessionStorage.getItem("btc-token") || "";
  var state = { stacks: [], stack: null, path: "", items: [], busy: false };

  /* ---------- effects level: honours OMNI's 3D effects switch (Full / Lite / Off) ---------- */
  function fx() {
    var v = (document.body.getAttribute("data-effects") || localStorage.getItem("omni-effects") || localStorage.getItem("effects") || "full").toLowerCase();
    if (window.OMNI && window.OMNI.effects) v = String(window.OMNI.effects).toLowerCase();
    return v.indexOf("off") === 0 ? "off" : v.indexOf("lite") === 0 ? "lite" : "full";
  }

  /* ---------- styles ---------- */
  var css = `
  .btc-tab{position:relative;font-family:Georgia,"Times New Roman",serif;letter-spacing:.22em;text-transform:uppercase;font-size:12px;color:#f5e6c0;background:linear-gradient(135deg,#1a1222,#2a1c05);border:1px solid #b8860b;border-radius:999px;padding:9px 18px;cursor:pointer;overflow:visible}
  .btc-tab.active{box-shadow:0 0 18px #d4af3788,inset 0 0 12px #f5d78e33;color:#fff3c4}
  #btc-panel{display:none;font-family:Georgia,serif;color:#f5e6c0;padding:22px 3vw;min-height:60vh;background:radial-gradient(circle at 18% 0,#2a1c05 0,#0b0710 60%)}
  #btc-panel.show{display:block}
  #btc-panel h2{font-weight:400;letter-spacing:.18em;margin:0 0 16px;background:linear-gradient(90deg,#f5d78e,#b8860b,#fff3c4);-webkit-background-clip:text;background-clip:text;color:transparent}
  .btc-stacks{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:18px;margin-bottom:22px}
  .btc-card{position:relative;border:1px solid #b8860b99;border-radius:18px;padding:18px;background:linear-gradient(160deg,#1d1426,#120b18);cursor:pointer;transition:transform .25s}
  .btc-card.sel{border-color:#f5d78e;box-shadow:0 0 24px #d4af3755}
  .btc-card:hover{transform:translateY(-2px)}
  .btc-card h3{margin:0 0 10px;font-weight:400;letter-spacing:.14em;color:#fff3c4}
  .btc-bar{height:12px;border-radius:9px;background:#2a1f33;overflow:hidden}
  .btc-bar i{display:block;height:100%;background:linear-gradient(90deg,#b8860b,#f5d78e,#fff3c4);box-shadow:0 0 10px #f5d78e}
  .btc-meta{font-size:13px;opacity:.85;margin-top:8px}
  .btc-row{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:10px 0}
  .btc-btn{position:relative;font-family:Georgia,serif;letter-spacing:.14em;text-transform:uppercase;font-size:11px;font-weight:700;color:#1a0f00;background:linear-gradient(135deg,#fff3c4,#f5d78e 35%,#b8860b);border:0;border-radius:999px;padding:9px 18px;cursor:pointer;overflow:visible}
  .btc-btn.small{padding:5px 11px;font-size:10px}
  .btc-btn.ghost{background:transparent;color:#f5d78e;border:1px solid #b8860b}
  .btc-table{width:100%;border-collapse:collapse;font-size:14px}
  .btc-table td{padding:9px 6px;border-bottom:1px solid #b8860b33}
  .btc-table tr:hover td{background:#d4af3711}
  .btc-crumb a{color:#f5d78e;cursor:pointer;text-decoration:none}
  .btc-drop{border:1px dashed #b8860b;border-radius:14px;padding:16px;text-align:center;opacity:.85;margin:10px 0}
  .btc-drop.over{background:#d4af3722;opacity:1}
  .btc-msg{min-height:20px;font-size:13px;color:#fff3c4}
  .btc-login input,.btc-row input{padding:9px 12px;background:#0b0710;color:#f5e6c0;border:1px solid #b8860b;border-radius:10px;font-family:Georgia,serif}
  .btc-prog{height:6px;border-radius:5px;background:#2a1f33;overflow:hidden;margin-top:6px}.btc-prog i{display:block;height:100%;width:0;background:linear-gradient(90deg,#b8860b,#fff3c4)}
  /* bling + sun rays */
  .btc-bling{position:absolute;pointer-events:none;width:6px;height:6px;border-radius:50%;background:radial-gradient(circle,#fff 0,#f5d78e 40%,transparent 70%);animation:btcTw 1.8s ease-in-out infinite;z-index:3}
  @keyframes btcTw{0%,100%{opacity:0;transform:scale(.3) translateY(0)}50%{opacity:1;transform:scale(1.1) translateY(-6px)}}
  .btc-rays{position:absolute;inset:-26px;pointer-events:none;opacity:0;transition:opacity .3s;z-index:0;
    background:repeating-conic-gradient(from 0deg,rgba(255,236,170,.55) 0 3deg,transparent 3deg 15deg);
    -webkit-mask:radial-gradient(circle,transparent 38%,#000 46%,transparent 72%);mask:radial-gradient(circle,transparent 38%,#000 46%,transparent 72%);animation:btcSpin 9s linear infinite;border-radius:50%}
  .btc-fx:hover>.btc-rays,.btc-tab.active>.btc-rays{opacity:1}.btc-tab.active>.btc-rays{opacity:.45}
  @keyframes btcSpin{to{transform:rotate(360deg)}}
  /* crystal diamond morph */
  .btc-crystal{animation:btcCrystal .5s cubic-bezier(.3,1.4,.5,1) forwards;background:conic-gradient(from 30deg,#fff,#c9f1ff,#f5d78e,#ffd1f5,#c9ffe0,#fff) !important;color:transparent !important;
    clip-path:polygon(50% 0,100% 38%,50% 100%,0 38%);border-radius:0 !important}
  @keyframes btcCrystal{0%{transform:perspective(400px) rotateY(0) scale(1)}60%{transform:perspective(400px) rotateY(300deg) scale(1.25)}100%{transform:perspective(400px) rotateY(360deg) scale(1)}}
  .btc-burst{position:fixed;pointer-events:none;z-index:99999;width:4px;height:4px;border-radius:50%}
  .btc-ring{position:fixed;pointer-events:none;z-index:99998;border:2px solid #fff3c4;border-radius:50%;animation:btcRing .55s ease-out forwards}
  @keyframes btcRing{from{opacity:1;transform:translate(-50%,-50%) scale(.2)}to{opacity:0;transform:translate(-50%,-50%) scale(2.6)}}
  .btc-shard{position:fixed;pointer-events:none;z-index:99999;width:8px;height:12px;clip-path:polygon(50% 0,100% 50%,50% 100%,0 50%);background:linear-gradient(135deg,#fff,#c9f1ff,#f5d78e)}
  @media (prefers-reduced-motion:reduce){.btc-rays,.btc-bling{animation:none}}
  `;
  var st = document.createElement("style"); st.id = "btc-style"; st.textContent = css; document.head.appendChild(st);

  /* ---------- bling helpers ---------- */
  function addBling(el, n) {
    if (fx() === "off" || el.__btcBling) return; el.__btcBling = true;
    el.classList.add("btc-fx");
    if (getComputedStyle(el).position === "static") el.style.position = "relative";
    var r = document.createElement("span"); r.className = "btc-rays"; el.insertBefore(r, el.firstChild);
    var count = fx() === "lite" ? Math.min(2, n || 3) : (n || 3);
    for (var i = 0; i < count; i++) {
      var s = document.createElement("span"); s.className = "btc-bling";
      s.style.left = (Math.random() * 100) + "%"; s.style.top = (Math.random() * 100) + "%"; s.style.animationDelay = (Math.random() * 1.8) + "s";
      el.appendChild(s);
    }
  }
  function burst(el, big) {
    var r = el.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    var ring = document.createElement("div"); ring.className = "btc-ring"; ring.style.left = cx + "px"; ring.style.top = cy + "px";
    ring.style.width = ring.style.height = Math.max(r.width, r.height) + "px"; document.body.appendChild(ring); setTimeout(function () { ring.remove(); }, 600);
    var n = big ? 22 : 8;
    for (var i = 0; i < n; i++) {
      var p = document.createElement("div"); p.className = i % 3 === 0 && big ? "btc-shard" : "btc-burst";
      if (p.className === "btc-burst") p.style.background = i % 2 ? "#fff3c4" : "#f5d78e";
      p.style.left = cx + "px"; p.style.top = cy + "px"; document.body.appendChild(p);
      var a = Math.PI * 2 * i / n, d = (big ? 70 : 34) + Math.random() * 40;
      p.animate([{ transform: "translate(0,0) rotate(0)", opacity: 1 }, { transform: "translate(" + Math.cos(a) * d + "px," + Math.sin(a) * d + "px) rotate(" + (200 + Math.random() * 300) + "deg)", opacity: 0 }], { duration: 600, easing: "cubic-bezier(.2,.8,.3,1)" });
      (function (q) { setTimeout(function () { q.remove(); }, 650); })(p);
    }
  }
  /* crystal click: button spins into a diamond, bursts, then the task runs (~0.5s). Small buttons: burst + instant. */
  function crystal(el, action, small) {
    if (window.OMNI && typeof window.OMNI.crystalClick === "function") return window.OMNI.crystalClick(el, action, small);
    var level = fx();
    if (level === "off") return action();
    if (small || level === "lite") { if (level !== "off") burst(el, false); return action(); }
    if (el.__btcBusy) return; el.__btcBusy = true;
    el.classList.add("btc-crystal"); burst(el, true);
    setTimeout(function () { el.classList.remove("btc-crystal"); el.__btcBusy = false; action(); }, 500);
  }
  function btn(label, action, opts) {
    opts = opts || {};
    var b = document.createElement("button"); b.className = "btc-btn" + (opts.small ? " small" : "") + (opts.ghost ? " ghost" : ""); b.type = "button";
    var t = document.createElement("span"); t.textContent = label; t.style.position = "relative"; t.style.zIndex = 1; b.appendChild(t);
    b.addEventListener("click", function (e) { e.preventDefault(); crystal(b, action, opts.small); });
    setTimeout(function () { addBling(b, opts.small ? 1 : 3); }, 0);
    return b;
  }

  /* ---------- API ---------- */
  function api(path, opt) {
    opt = opt || {}; opt.headers = Object.assign({}, opt.headers || {}, token ? { Authorization: "Bearer " + token } : {});
    return fetch(CFG.server + path, opt).then(function (r) {
      if (r.status === 401) { token = ""; sessionStorage.removeItem("btc-token"); render(); throw new Error("Please unlock with your PIN"); }
      return r.headers.get("content-type") && r.headers.get("content-type").indexOf("json") >= 0 ? r.json().then(function (j) { if (!r.ok) throw new Error(j.error || r.status); return j; }) : r;
    });
  }
  function q(o) { return Object.keys(o).map(function (k) { return k + "=" + encodeURIComponent(o[k]); }).join("&"); }
  function fmt(b) { return b > 1e9 ? (b / 1e9).toFixed(2) + " GB" : b > 1e6 ? (b / 1e6).toFixed(1) + " MB" : b > 1e3 ? (b / 1e3).toFixed(0) + " KB" : b + " B"; }
  function msg(t) { var m = panel.querySelector(".btc-msg"); if (m) m.textContent = t || ""; }

  function login(pin) {
    return fetch(CFG.server + "/api/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pin: pin }) })
      .then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || "Wrong PIN"); token = j.token; sessionStorage.setItem("btc-token", token); return loadStacks(); }); });
  }
  function loadStacks() { return api("/api/stacks").then(function (s) { state.stacks = s.stacks; if (!state.stack && s.stacks[0]) state.stack = s.stacks[0].stack; return loadItems(); }); }
  function loadItems() { return api("/api/ls?" + q({ stack: state.stack, path: state.path })).then(function (r) { state.items = r.items; render(); }); }
  function upload(files) {
    var list = Array.prototype.slice.call(files), i = 0, bar = panel.querySelector(".btc-prog i");
    function next() {
      if (i >= list.length) { msg("Uploaded " + list.length + " file" + (list.length > 1 ? "s" : "") + " to " + state.stack); return loadStacks(); }
      var f = list[i++]; return new Promise(function (res, rej) {
        var x = new XMLHttpRequest(); x.open("POST", CFG.server + "/api/upload?" + q({ stack: state.stack, path: state.path }));
        x.setRequestHeader("Authorization", "Bearer " + token); x.setRequestHeader("X-Filename", encodeURIComponent(f.name));
        x.upload.onprogress = function (e) { if (bar && e.lengthComputable) bar.style.width = (100 * e.loaded / e.total) + "%"; msg("Uploading " + f.name + "  " + Math.round(100 * e.loaded / (e.total || 1)) + "%"); };
        x.onload = function () { if (x.status >= 200 && x.status < 300) res(); else { try { rej(new Error(JSON.parse(x.responseText).error)); } catch (e) { rej(new Error("Upload failed")); } } };
        x.onerror = function () { rej(new Error("Cannot reach Big Tony Cloud at " + CFG.server)); }; x.send(f);
      }).then(next);
    }
    return next().catch(function (e) { msg(e.message); });
  }
  function download(name) {
    var url = CFG.server + "/api/download?" + q({ stack: state.stack, path: join(state.path, name), token: token });
    if (window.OMNI && typeof window.OMNI.openExternal === "function") return window.OMNI.openExternal(url);
    var a = document.createElement("a"); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  }
  function shareFile(name) {
    return api("/api/share", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ stack: state.stack, path: join(state.path, name), hours: 72 }) })
      .then(function (r) { (navigator.clipboard ? navigator.clipboard.writeText(r.url) : Promise.resolve()).catch(function () {}); msg("Share link copied (72 hours): " + r.url); });
  }
  function del(name) { if (!confirm("Delete " + name + "?")) return; return api("/api/item?" + q({ stack: state.stack, path: join(state.path, name) }), { method: "DELETE" }).then(loadStacks).catch(function (e) { msg(e.message); }); }
  function newFolder() { var n = prompt("Folder name"); if (!n) return; return api("/api/mkdir", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ stack: state.stack, path: join(state.path, n) }) }).then(loadItems); }
  function join(a, b) { return a ? a.replace(/\/$/, "") + "/" + b : b; }

  /* ---------- UI ---------- */
  var panel = document.createElement("section"); panel.id = "btc-panel";
  function render() {
    panel.innerHTML = ""; var h = document.createElement("h2"); h.textContent = "BIG TONY CLOUD"; panel.appendChild(h);
    if (!token) {
      var box = document.createElement("div"); box.className = "btc-login btc-row";
      var srv = document.createElement("input"); srv.value = CFG.server; srv.title = "Cloud address"; srv.style.width = "230px";
      var pin = document.createElement("input"); pin.type = "password"; pin.placeholder = "PIN";
      var go = function () { CFG.server = srv.value.replace(/\/$/, ""); localStorage.setItem("btc-server", CFG.server); login(pin.value).catch(function (e) { msg(e.message === "Failed to fetch" ? "Cannot reach Big Tony Cloud - start it with Start Big Tony Cloud" : e.message); }); };
      pin.addEventListener("keydown", function (e) { if (e.key === "Enter") go(); });
      box.appendChild(srv); box.appendChild(pin); box.appendChild(btn("Unlock", go)); panel.appendChild(box);
      var m = document.createElement("div"); m.className = "btc-msg"; panel.appendChild(m); return;
    }
    var grid = document.createElement("div"); grid.className = "btc-stacks";
    state.stacks.forEach(function (s) {
      var c = document.createElement("div"); c.className = "btc-card" + (s.stack === state.stack ? " sel" : "");
      c.innerHTML = "<h3></h3><div class=btc-bar><i></i></div><div class=btc-meta></div>";
      c.querySelector("h3").textContent = s.stack; c.querySelector("i").style.width = Math.max(1, Math.min(100, s.percent)) + "%";
      c.querySelector(".btc-meta").textContent = s.used_gb.toFixed(2) + " GB used of " + s.quota_gb + " GB  -  " + s.free_gb.toFixed(1) + " GB free";
      c.addEventListener("click", function () { crystal(c, function () { state.stack = s.stack; state.path = ""; loadItems(); }, true); });
      addBling(c, 4); grid.appendChild(c);
    });
    panel.appendChild(grid);
    var tools = document.createElement("div"); tools.className = "btc-row";
    var fi = document.createElement("input"); fi.type = "file"; fi.multiple = true; fi.style.display = "none"; fi.addEventListener("change", function () { upload(fi.files); fi.value = ""; });
    tools.appendChild(btn("Upload", function () { fi.click(); })); tools.appendChild(btn("New Folder", newFolder, { ghost: true }));
    tools.appendChild(btn("Refresh", loadStacks, { ghost: true })); tools.appendChild(btn("Lock", function () { token = ""; sessionStorage.removeItem("btc-token"); render(); }, { ghost: true, small: true }));
    tools.appendChild(fi); panel.appendChild(tools);
    var drop = document.createElement("div"); drop.className = "btc-drop"; drop.textContent = "Drop files here to upload to " + state.stack;
    drop.addEventListener("dragover", function (e) { e.preventDefault(); drop.classList.add("over"); });
    drop.addEventListener("dragleave", function () { drop.classList.remove("over"); });
    drop.addEventListener("drop", function (e) { e.preventDefault(); drop.classList.remove("over"); burst(drop, true); upload(e.dataTransfer.files); });
    panel.appendChild(drop);
    var pr = document.createElement("div"); pr.className = "btc-prog"; pr.innerHTML = "<i></i>"; panel.appendChild(pr);
    var m2 = document.createElement("div"); m2.className = "btc-msg"; panel.appendChild(m2);
    var crumb = document.createElement("div"); crumb.className = "btc-crumb";
    var parts = state.path ? state.path.split("/") : [], acc = "";
    var root = document.createElement("a"); root.textContent = state.stack; root.onclick = function () { state.path = ""; loadItems(); }; crumb.appendChild(root);
    parts.forEach(function (p) { acc = join(acc, p); var a = document.createElement("a"); var target = acc; a.textContent = " / " + p; a.onclick = function () { state.path = target; loadItems(); }; crumb.appendChild(a); });
    panel.appendChild(crumb);
    var tb = document.createElement("table"); tb.className = "btc-table";
    if (!state.items.length) { var e = document.createElement("tr"); e.innerHTML = "<td>This folder is empty - upload something golden.</td>"; tb.appendChild(e); }
    state.items.forEach(function (it) {
      var tr = document.createElement("tr"), n = document.createElement("td"), sz = document.createElement("td"), ac = document.createElement("td");
      n.textContent = (it.dir ? "[folder] " : "") + it.name; sz.textContent = it.dir ? "" : fmt(it.size);
      if (it.dir) { n.style.cursor = "pointer"; n.onclick = function () { state.path = join(state.path, it.name); loadItems(); }; }
      else { ac.appendChild(btn("Download", function () { download(it.name); }, { small: true })); ac.appendChild(document.createTextNode(" ")); ac.appendChild(btn("Share", function () { shareFile(it.name); }, { small: true })); ac.appendChild(document.createTextNode(" ")); }
      ac.appendChild(btn("Delete", function () { del(it.name); }, { small: true, ghost: true }));
      tr.appendChild(n); tr.appendChild(sz); tr.appendChild(ac); tb.appendChild(tr);
    });
    panel.appendChild(tb);
  }

  /* ---------- mount into OMNI ---------- */
  function mount() {
    var tab = document.createElement("button"); tab.className = "btc-tab"; tab.type = "button"; tab.setAttribute("role", "tab");
    var lbl = document.createElement("span"); lbl.textContent = CFG.tabLabel; lbl.style.position = "relative"; lbl.style.zIndex = 1; tab.appendChild(lbl);
    if (window.OMNI && typeof window.OMNI.registerTab === "function") {
      window.OMNI.registerTab({ id: "big-tony-cloud", label: CFG.tabLabel, element: panel, onShow: function () { token ? loadStacks().catch(function (e) { msg(e.message); }) : render(); } });
    } else {
      var bar = (CFG.mount && document.querySelector(CFG.mount)) || document.querySelector("[role=tablist]") || document.querySelector(".tabs,.tab-bar,.tabbar,nav") ;
      var host = (bar && bar.parentNode) || document.body;
      if (bar) bar.appendChild(tab); else { var fb = document.createElement("div"); fb.style.cssText = "padding:10px 3vw"; fb.appendChild(tab); document.body.insertBefore(fb, document.body.firstChild); }
      var view = document.querySelector("main,[role=main],.content,.tab-content,.panels") || host;
      view.appendChild(panel);
      function show(on) {
        panel.classList.toggle("show", on); tab.classList.toggle("active", on);
        Array.prototype.forEach.call(view.children, function (c) { if (c !== panel) c.style.display = on ? "none" : (c.__btcDisp || ""); });
        if (on) { (token ? loadStacks().catch(function (e) { msg(e.message); }) : render()); }
      }
      Array.prototype.forEach.call(view.children, function (c) { c.__btcDisp = c.style.display; });
      tab.addEventListener("click", function () { crystal(tab, function () { show(!panel.classList.contains("show")); }); });
      if (bar) bar.addEventListener("click", function (e) { if (e.target.closest && !e.target.closest(".btc-tab") && e.target.closest("button,[role=tab],a") && panel.classList.contains("show")) show(false); }, true);
      addBling(tab, 4);
    }
    render();
  }
  window.BigTonyCloudTab = { config: CFG, refresh: function () { return loadStacks(); }, crystal: crystal, addBling: addBling };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount); else mount();
})();
