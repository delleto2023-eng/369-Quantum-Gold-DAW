// 369 OMNI v16 One App: every DAW + the one OMNI agent in a single screen
(function(){
var DAWS=[["Super DAW v51","super-daw-studio/app/index.html"],["Offline Studio (Resona)","super-daw-studio/app/offline-studio.html"],["Gold DAW v3.3","daws/gold-daw-v3.3.html"],["Big Tony AI","bigtony-ai/index.html"],["JARVIS","jarvis/index.html"]];
function go(){
var css=document.createElement('style');css.textContent='#one{position:fixed;inset:0;z-index:9000;display:flex;background:#07060a;color:#f5d27a;font-family:system-ui}#one .side{width:190px;border-right:1px solid #5a4510;padding:8px;overflow:auto}#one .side button{display:block;width:100%;margin:4px 0;padding:8px;background:#151018;color:#f5d27a;border:1px solid #5a4510;border-radius:8px;text-align:left;cursor:pointer}#one .side button.on{background:#f5d27a;color:#000}#one .stage{flex:1;position:relative}#one iframe{position:absolute;inset:0;width:100%;height:100%;border:0;display:none;background:#000}#one iframe.on{display:block}#one .ag{width:340px;border-left:1px solid #5a4510;display:flex;flex-direction:column}#one .ag.hide{display:none}#one .lg{flex:1;overflow:auto;padding:8px;font-size:13px;white-space:pre-wrap}#one .lg div{margin:6px 0;padding:6px;border-radius:6px;background:#151018}#one .lg .u{background:#2a2010}#one textarea{height:70px;background:#000;color:#fff;border:1px solid #5a4510;margin:6px}#onebtn{position:fixed;right:12px;bottom:12px;z-index:9001;padding:10px 14px;border-radius:20px;background:#f5d27a;color:#000;border:0;font-weight:700;cursor:pointer}';document.head.appendChild(css);
var w=document.createElement('div');w.id='one';
var h='<div class="side"><b>369 OMNI ONE</b><div style="font-size:11px;opacity:.7">DAWs + agents, one app</div><button data-k="omni">OMNI Agent Hub (all tabs)</button>';
DAWS.forEach(function(d,i){h+='<button data-k="'+i+'">'+d[0]+'</button>'});
h+='<button data-k="ag">Show/hide OMNI agent</button></div><div class="stage">';
DAWS.forEach(function(d,i){h+='<iframe data-i="'+i+'" data-src="'+d[1]+'"></iframe>'});
h+='</div><div class="ag"><div style="padding:8px"><b>OMNI agent</b> <span style="font-size:11px;opacity:.7">one brain for every DAW</span></div><div class="lg"></div><textarea placeholder="Ask OMNI about the DAW on screen..."></textarea><button id="onego" style="margin:0 6px 6px">Send</button></div>';
w.innerHTML=h;document.body.appendChild(w);
var fb=document.createElement('button');fb.id='onebtn';fb.textContent='369 ONE';fb.style.display='none';document.body.appendChild(fb);
var cur=null,lg=w.querySelector('.lg'),ta=w.querySelector('textarea'),hist=[];
function show(k){if(k=='ag'){w.querySelector('.ag').classList.toggle('hide');return}
if(k=='omni'){w.style.display='none';fb.style.display='block';return}
w.querySelectorAll('.side button').forEach(function(b){b.classList.toggle('on',b.dataset.k==k)});
w.querySelectorAll('iframe').forEach(function(f){var on=f.dataset.i==k;if(on&&!f.src)f.src=f.dataset.src;f.classList.toggle('on',on)});cur=DAWS[+k][0]}
fb.onclick=function(){w.style.display='flex';fb.style.display='none'};
w.querySelector('.side').onclick=function(e){if(e.target.dataset.k)show(e.target.dataset.k)};
function add(c,t){var d=document.createElement('div');d.className=c;d.textContent=t;lg.appendChild(d);lg.scrollTop=1e9;return d}
async function ask(t,src){add('u',t);hist.push({role:'user',content:t});var d=add('b','OMNI is thinking...');
var act=typeof pick=='function'?pick(t,3):[];var sys=(typeof CORE!='undefined'?CORE:'You are 369 OMNI.')+'\nThe user is working inside '+(src||cur||'the 369 app')+'. Help them with that DAW or app directly.'+(act.length?'\nActive skills: '+act.map(function(a){return a.name+' ('+a.sk+')'}).join('; '):'');
var ans=typeof llm=='function'?await llm((act[0]&&act[0].model)||(typeof D!='undefined'?D:'openrouter/auto'),[{role:'system',content:sys}].concat(hist.slice(-12))):'OMNI core not loaded.';
d.textContent=ans;hist.push({role:'assistant',content:ans});return ans}
w.querySelector('#onego').onclick=function(){var t=ta.value.trim();if(t){ta.value='';ask(t)}};
ta.onkeydown=function(e){if(e.key=='Enter'&&!e.shiftKey){e.preventDefault();w.querySelector('#onego').click()}};
// bridge: any DAW/app frame can call OMNI with parent.postMessage({type:'omni-ask',text:'...'},'*')
window.addEventListener('message',async function(e){var m=e.data||{};if(m.type!=='omni-ask'||!m.text)return;var a=await ask(m.text,m.app);try{e.source.postMessage({type:'omni-answer',id:m.id,text:a},'*')}catch(x){}});
window.OMNI_ONE={ask:ask,show:show,daws:DAWS};show('0');add('b','369 OMNI ONE: every DAW and every agent in one app. Pick a DAW on the left; I stay here as the one agent for all of them.');}
document.readyState==='loading'?document.addEventListener('DOMContentLoaded',go):go();})();
