// Big Tony AI — preload (Electron 31, contextIsolation: true).
// Exposes a small, explicit bridge as window.bigTonyDesktop. The page uses
// it ONLY when present and keeps working standalone in a browser without it.
//
// Note: `app` and `safeStorage` are main-process-only APIs, so userDataPath
// and vaultAvailable are fetched here through synchronous IPC channels
// ('bt:user-data-path' / 'bt:vault-available') answered in main.js. The
// exposed shape is unchanged: plain values, not promises.
const { contextBridge, ipcRenderer } = require('electron');

const userDataPath = ipcRenderer.sendSync('bt:user-data-path');
const vaultAvailable = ipcRenderer.sendSync('bt:vault-available');

contextBridge.exposeInMainWorld('bigTonyDesktop', {
  isDesktop: true,
  platform: process.platform,
  userDataPath,
  vaultAvailable,
  vaultEncrypt: (plain) => ipcRenderer.invoke('bt:vault-encrypt', plain),
  vaultDecrypt: (cipher) => ipcRenderer.invoke('bt:vault-decrypt', cipher),
  showOpenDialog: (options) => ipcRenderer.invoke('bt:show-open', options),
  showSaveDialog: (options) => ipcRenderer.invoke('bt:show-save', options),
  readFileText: (path) => ipcRenderer.invoke('bt:read-file', path),
  writeFileText: (path, text) => ipcRenderer.invoke('bt:write-file', path, text),
  ollamaList: () => ipcRenderer.invoke('bt:ollama-list'),
  onMenuAction: (cb) => ipcRenderer.on('bt:menu', (_e, action) => cb(action)),
  openExternal: (url) => ipcRenderer.invoke('bt:open-external', url)
});
