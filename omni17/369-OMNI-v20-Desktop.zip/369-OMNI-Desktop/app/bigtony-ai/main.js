// Big Tony AI — desktop shell (Electron 31).
// Town/Lofibadger, Zenzap, Base44, Claude, Bolt, and Muse combined in one
// app, local-first with a build preview. Loads the self-contained
// index.html in this folder; no server needed.
// API keys are pasted in the app (in-session only, never stored). Without a
// key the app runs its built-in local engine, honestly labelled LOCAL.
//
// The page is one self-contained HTML file that uses inline scripts, inline
// onclick handlers and inline styles everywhere, and its Build Preview is a
// sandboxed srcdoc iframe that INHERITS the parent document's CSP. The CSP
// below therefore allows 'unsafe-inline' and https: script/style sources so
// generated previews that load outside-CDN scripts still run, while still
// blocking objects, framing and form posts. The page looks for
// window.bigTonyDesktop (see preload.js) and works standalone in a browser
// without it.
const { app, BrowserWindow, Menu, Tray, dialog, globalShortcut, ipcMain, screen, session, shell, safeStorage } = require('electron');
const fs = require('fs');
const path = require('path');
const http = require('http');
const { fileURLToPath } = require('url');

app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

// ---------------------------------------------------------------------------
// Content Security Policy (applied to the main window's document).
// See the header comment: 'unsafe-inline' + https: are REQUIRED — the page
// itself is inline-scripted and srcdoc previews inherit this CSP, so
// blocking https: scripts would break previews that load outside CDNs.
// ---------------------------------------------------------------------------
const CSP = [
  "default-src 'self' file: data: blob:",
  "script-src 'self' 'unsafe-inline' https:",
  "style-src 'self' 'unsafe-inline' https:",
  "img-src 'self' data: blob: https:",
  "font-src 'self' data: https:",
  'connect-src \'self\' http://localhost:11434 https: wss:',
  "media-src 'self' blob: data:",
  "object-src 'none'",
  "base-uri 'self'",
  "frame-ancestors 'none'",
  "form-action 'none'"
].join('; ');

// ---------------------------------------------------------------------------
// Single instance: a second launch restores + focuses the existing window.
// ---------------------------------------------------------------------------
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();

let w = null;        // main BrowserWindow
let tray = null;
let zoomFactor = 1;  // main-process zoom fallback (also sent to the page)

// ---------------------------------------------------------------------------
// Remembered window bounds (window-state.json in the app userData folder).
// Restored bounds are validated against the current displays; anything
// off-screen falls back to 1440x900 centered.
// ---------------------------------------------------------------------------
const statePath = path.join(app.getPath('userData'), 'window-state.json');

function loadWindowState() {
  const fallback = { width: 1440, height: 900 };
  try {
    const raw = JSON.parse(fs.readFileSync(statePath, 'utf8'));
    if (!raw || typeof raw !== 'object') return fallback;
    const width = Math.max(800, Math.min(4000, Number(raw.width) || 0));
    const height = Math.max(600, Math.min(4000, Number(raw.height) || 0));
    if (!width || !height) return fallback;
    const state = { width, height };
    if (typeof raw.x === 'number' && typeof raw.y === 'number') {
      const onScreen = screen.getAllDisplays().some((d) => {
        const a = d.workArea;
        return raw.x + 80 > a.x && raw.x + 80 < a.x + a.width &&
               raw.y + 80 > a.y && raw.y + 80 < a.y + a.height;
      });
      if (onScreen) { state.x = Math.round(raw.x); state.y = Math.round(raw.y); }
    }
    return state;
  } catch (_) {
    return fallback; // missing or corrupt state: fresh default
  }
}

function saveWindowState() {
  if (!w || w.isDestroyed()) return;
  try {
    const b = w.getBounds();
    fs.mkdirSync(path.dirname(statePath), { recursive: true });
    fs.writeFileSync(statePath, JSON.stringify({ x: b.x, y: b.y, width: b.width, height: b.height }), 'utf8');
  } catch (_) { /* state is best-effort; a failed write must not break quit */ }
}
let saveTimer = null;
function saveWindowStateSoon() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveWindowState, 250);
}

// ---------------------------------------------------------------------------
// Menu. Page actions are sent to the renderer as 'bt:menu' with an action
// string; the preload exposes them via window.bigTonyDesktop.onMenuAction.
// Zoom also applies from the main process as a fallback in case the page
// has not registered the listener yet.
// ---------------------------------------------------------------------------
function sendMenuAction(action) {
  if (w && !w.isDestroyed()) w.webContents.send('bt:menu', action);
}
function applyZoom(factor) {
  zoomFactor = Math.max(0.25, Math.min(3, factor));
  if (w && !w.isDestroyed()) w.webContents.setZoomFactor(zoomFactor);
}

const menuTemplate = [
  {
    label: 'File',
    submenu: [
      { label: 'Backup', click: () => sendMenuAction('backup') },
      { label: 'Restore', click: () => sendMenuAction('restore') },
      { label: 'Export Chat as Markdown', click: () => sendMenuAction('export-chat-md') },
      { type: 'separator' },
      { label: 'Quit', role: 'quit' }
    ]
  },
  {
    label: 'View',
    submenu: [
      { label: 'Zoom In', accelerator: 'CmdOrCtrl+=', click: () => { applyZoom(zoomFactor * 1.1); sendMenuAction('zoom-in'); } },
      { label: 'Zoom Out', accelerator: 'CmdOrCtrl+-', click: () => { applyZoom(zoomFactor / 1.1); sendMenuAction('zoom-out'); } },
      { label: 'Reset Zoom', accelerator: 'CmdOrCtrl+0', click: () => { applyZoom(1); sendMenuAction('zoom-reset'); } },
      { type: 'separator' },
      { label: 'Reload', accelerator: 'CmdOrCtrl+R', role: 'reload' },
      { label: 'Toggle Developer Tools', accelerator: 'CmdOrCtrl+Shift+I', role: 'toggleDevTools' }
    ]
  },
  {
    label: 'Premium',
    submenu: [
      { label: 'Open Premium Settings', click: () => sendMenuAction('open-premium') }
    ]
  }
];

// ---------------------------------------------------------------------------
// System tray: Show + Quit. Close still quits (minimize-to-tray is NOT used).
// ---------------------------------------------------------------------------
function createTray() {
  const iconPath = path.join(__dirname, 'tray-icon.png');
  try {
    tray = new Tray(iconPath);
  } catch (_) {
    return; // tray is a nicety; the app must work without it
  }
  tray.setToolTip('Big Tony AI');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Show', click: () => { if (w) { if (w.isMinimized()) w.restore(); w.show(); w.focus(); } } },
    { label: 'Quit', click: () => app.quit() }
  ]));
  tray.on('click', () => {
    if (w) { if (w.isMinimized()) w.restore(); w.show(); w.focus(); }
  });
}

// ---------------------------------------------------------------------------
// Hardened navigation / permissions.
// - window.open / target=_blank: external http(s) goes to the OS browser,
//   never a new Electron window.
// - will-navigate: only file:// URLs under the app folder are allowed
//   in-window; anything else goes to the OS browser or is blocked.
// - Permissions: camera + microphone allowed (gesture panel needs them);
//   everything else denied.
// ---------------------------------------------------------------------------
function isAppFileUrl(url) {
  try {
    const u = new URL(url);
    if (u.protocol !== 'file:') return false;
    const appDir = path.resolve(__dirname) + path.sep;
    return decodeURIComponent(u.pathname).startsWith(appDir) ||
           path.resolve(decodeURIComponent(u.pathname)).startsWith(appDir);
  } catch (_) {
    return false;
  }
}
function isHttpUrl(url) { return /^https?:\/\//i.test(url || ''); }

function hardenWindow(win) {
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (isHttpUrl(url)) { shell.openExternal(url).catch(() => {}); }
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (event, url) => {
    if (isAppFileUrl(url)) return; // in-app navigation stays in-window
    event.preventDefault();
    if (isHttpUrl(url)) shell.openExternal(url).catch(() => {});
  });
}

// ---------------------------------------------------------------------------
// Main-process IPC (the preload bridges these to window.bigTonyDesktop).
// Vault: safeStorage, base64 in/out, null when unavailable — never throws
// into the renderer. File read/write: only paths the user picked in a
// dialog (tracked below) plus files under userData.
// ---------------------------------------------------------------------------
const dialogPickedPaths = new Set(); // absolute file paths the user chose
function isAllowedFilePath(p) {
  try {
    const resolved = path.resolve(p);
    if (dialogPickedPaths.has(resolved)) return true;
    const userData = path.resolve(app.getPath('userData')) + path.sep;
    return resolved.startsWith(userData);
  } catch (_) {
    return false;
  }
}
function ollamaList() {
  return new Promise((resolve) => {
    const req = http.get(
      { host: '127.0.0.1', port: 11434, path: '/api/tags', timeout: 1500 },
      (res) => {
        let body = '';
        res.on('data', (c) => { body += c; });
        res.on('end', () => {
          try {
            const json = JSON.parse(body);
            const models = Array.isArray(json.models)
              ? json.models.map((m) => m.name).filter(Boolean)
              : [];
            resolve({ models });
          } catch (_) { resolve(null); }
        });
      }
    );
    req.on('timeout', () => { req.destroy(); resolve(null); });
    req.on('error', () => resolve(null));
  });
}

function registerIpc() {
  ipcMain.on('bt:user-data-path', (e) => { e.returnValue = app.getPath('userData'); });
  ipcMain.on('bt:vault-available', (e) => {
    try { e.returnValue = safeStorage.isEncryptionAvailable(); }
    catch (_) { e.returnValue = false; }
  });
  ipcMain.handle('bt:vault-encrypt', (_e, plain) => {
    try {
      if (!safeStorage.isEncryptionAvailable() || typeof plain !== 'string') return null;
      return safeStorage.encryptString(plain).toString('base64');
    } catch (_) { return null; }
  });
  ipcMain.handle('bt:vault-decrypt', (_e, cipher) => {
    try {
      if (!safeStorage.isEncryptionAvailable() || typeof cipher !== 'string') return null;
      return safeStorage.decryptString(Buffer.from(cipher, 'base64'));
    } catch (_) { return null; }
  });
  ipcMain.handle('bt:show-open', async (_e, options) => {
    const result = await dialog.showOpenDialog(w, options || {});
    if (result.canceled || !result.filePaths.length) return null;
    result.filePaths.forEach((p) => dialogPickedPaths.add(path.resolve(p)));
    return result.filePaths;
  });
  ipcMain.handle('bt:show-save', async (_e, options) => {
    const result = await dialog.showSaveDialog(w, options || {});
    if (result.canceled || !result.filePath) return null;
    dialogPickedPaths.add(path.resolve(result.filePath));
    return result.filePath;
  });
  ipcMain.handle('bt:read-file', async (_e, filePath) => {
    try {
      if (typeof filePath !== 'string' || !isAllowedFilePath(filePath)) return null;
      return await fs.promises.readFile(filePath, 'utf8');
    } catch (_) { return null; }
  });
  ipcMain.handle('bt:write-file', async (_e, filePath, text) => {
    try {
      if (typeof filePath !== 'string' || typeof text !== 'string' || !isAllowedFilePath(filePath)) return false;
      await fs.promises.writeFile(filePath, text, 'utf8');
      return true;
    } catch (_) { return false; }
  });
  ipcMain.handle('bt:ollama-list', () => ollamaList());
  ipcMain.handle('bt:open-external', async (_e, url) => {
    if (typeof url !== 'string' || !isHttpUrl(url)) return false;
    try { await shell.openExternal(url); return true; }
    catch (_) { return false; }
  });
}

// ---------------------------------------------------------------------------
// Window creation.
// ---------------------------------------------------------------------------
function createWindow() {
  const state = loadWindowState();
  w = new BrowserWindow({
    width: state.width,
    height: state.height,
    x: state.x,
    y: state.y,
    backgroundColor: '#060707',
    title: 'Big Tony AI',
    icon: path.join(__dirname, 'tray-icon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });
  hardenWindow(w);
  w.__btPageErrors = [];
  w.webContents.on('console-message', (_e, level, message) => {
    if (level === 'error') w.__btPageErrors.push(String(message).slice(0, 300));
  });
  w.loadFile('index.html');
  w.on('resize', saveWindowStateSoon);
  w.on('move', saveWindowStateSoon);
  w.on('close', saveWindowState);
  w.on('closed', () => { w = null; });
  if (process.argv.includes('--bt-self-test')) runSelfTest();
}

app.whenReady().then(() => {
  // CSP on the main window's document. Verified at runtime (2026-11-14):
  // onHeadersReceived does NOT fire for file:// URLs in Electron 31 — the
  // self-test proved it (a data: script ran, no CSP violation fired). So
  // the CSP is attached by intercepting the file protocol instead, exactly
  // as the Electron protocol docs demonstrate (callback { path, headers }
  // with a Content-Security-Policy header). The page still loads via
  // loadFile from the same file:// origin, so localStorage and file://
  // behavior are unchanged. onHeadersReceived is kept as well so any
  // non-file document response gets the same header.
  session.defaultSession.protocol.interceptFileProtocol('file', (request, callback) => {
    try {
      const filePath = path.resolve(fileURLToPath(request.url));
      const appDir = path.resolve(__dirname);
      if (filePath !== appDir && !filePath.startsWith(appDir + path.sep)) {
        callback({ error: -6 }); // serve only files inside the app folder
        return;
      }
      callback({ path: filePath, headers: { 'Content-Security-Policy': CSP } });
    } catch (_) {
      callback({ error: -6 });
    }
  }, (error) => {
    if (error) console.error('Big Tony AI: file-protocol CSP intercept failed:', error);
  });
  session.defaultSession.webRequest.onHeadersReceived(
    { urls: ['file://*', 'http://*/*', 'https://*/*'] },
    (details, callback) => {
      if (details.resourceType === 'main_frame' || details.resourceType === 'sub_frame') {
        details.responseHeaders['Content-Security-Policy'] = [CSP];
      }
      callback({ responseHeaders: details.responseHeaders });
    }
  );
  session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback) => {
    // Gesture panel needs camera + microphone; deny everything else
    // (geolocation, notifications, midi, etc.).
    callback(permission === 'camera' || permission === 'microphone' || permission === 'media');
  });
  Menu.setApplicationMenu(Menu.buildFromTemplate(menuTemplate));
  registerIpc();
  createTray();
  createWindow();
  // Ctrl+Shift+J brings Big Tony AI to the front from anywhere.
  globalShortcut.register('CommandOrControl+Shift+J', () => {
    if (w) {
      if (w.isMinimized()) w.restore();
      w.focus();
    } else {
      createWindow();
    }
  });
});

app.on('second-instance', () => {
  if (w) {
    if (w.isMinimized()) w.restore();
    w.show();
    w.focus();
  }
});
app.on('activate', () => { if (!w) createWindow(); });
app.on('window-all-closed', () => app.quit());
app.on('will-quit', () => globalShortcut.unregisterAll());

// ---------------------------------------------------------------------------
// Dev-only self-test (--bt-self-test). NOT run in normal use. Loads the real
// page headlessly, checks the bridge, the registry render, localStorage, and
// the CSP (https: CDN script in a Build Preview must run; an http: script
// must be blocked), then writes results to the userData folder and quits.
// ---------------------------------------------------------------------------
async function runSelfTest() {
  const results = {};
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const mark = (step) => console.log('BT-TEST step: ' + step);
  try {
    mark('waiting-for-load');
    await new Promise((resolve) => {
      if (w.webContents.isLoading()) w.webContents.once('did-finish-load', resolve);
      else resolve();
    });
    mark('loaded, settling');
    await sleep(3000); // let the page's inline scripts settle
    const evalJs = (expr) => w.webContents.executeJavaScript(expr, true).catch((e) => 'EVAL-ERROR: ' + e.message);

    mark('bridge/registry/localStorage');
    results.bridgePresent = await evalJs(`!!(window.bigTonyDesktop && window.bigTonyDesktop.isDesktop)`);
    results.platform = await evalJs(`window.bigTonyDesktop ? window.bigTonyDesktop.platform : null`);
    results.vaultAvailable = await evalJs(`window.bigTonyDesktop ? window.bigTonyDesktop.vaultAvailable : null`);
    results.userDataPath = await evalJs(`window.bigTonyDesktop ? window.bigTonyDesktop.userDataPath : null`);
    results.registryRenders = await evalJs(`(function(){var el=document.getElementById('registryOut');return !!(el && el.textContent && el.textContent.trim().length>20);})()`);
    results.localStorageWorks = await evalJs(`(function(){try{localStorage.setItem('__bt_test','1');return localStorage.getItem('__bt_test')==='1';}catch(e){return false;}})()`);
    results.pageErrors = (w.__btPageErrors || []).slice(0, 5);

    mark('csp (local servers: http must block, https must load, data: must block)');
    // Decisive CSP proof that does not depend on outside network:
    // a securitypolicyviolation listener + a data: script (blocked by
    // script-src, never by mixed-content rules). Local http/https servers
    // on 127.0.0.1:18080 / 18443 stand in for an outside CDN.
    await evalJs(`window.__btCspViolations=[];document.addEventListener('securitypolicyviolation',function(ev){window.__btCspViolations.push(ev.violatedDirective||ev.type);});`);
    results.dataScriptBlocked = await evalJs(`(function(){return new Promise(function(res){var s=document.createElement('script');var done=false;var fin=function(v){if(!done){done=true;res(v);}};s.onload=function(){fin(window.__dataScriptRan===true?false:true)};s.onerror=function(){fin(true)};s.src='data:text/javascript,window.__dataScriptRan=true';document.head.appendChild(s);setTimeout(function(){fin(window.__dataScriptRan===true?false:true)},6000);});})()`);
    results.cspViolations = await evalJs(`window.__btCspViolations.slice()`);
    results.localHttpBlocked = await evalJs(`(function(){return new Promise(function(res){var s=document.createElement('script');var done=false;var fin=function(v){if(!done){done=true;res(v);}};s.onload=function(){fin(false)};s.onerror=function(){fin(true)};s.src='http://127.0.0.1:18080/cdn.js';document.head.appendChild(s);setTimeout(function(){fin('timeout')},6000);});})()`);
    results.localHttpsLoads = await evalJs(`(function(){return new Promise(function(res){var s=document.createElement('script');var done=false;var fin=function(v){if(!done){done=true;res(v);}};s.onload=function(){fin(window.__localHttpsLoaded===true)};s.onerror=function(){fin(false)};s.src='https://127.0.0.1:18443/cdn.js';document.head.appendChild(s);setTimeout(function(){fin('timeout')},6000);});})()`);
    results.previewLocalHttpsRuns = await evalJs(`(function(){return new Promise(function(res){var f=document.getElementById('previewFrame');if(!f){res('no-preview-frame');return;}window.__btPreviewLocal=null;var onMsg=function(ev){if(ev.data&&ev.data.btPreviewLocal!==undefined){window.__btPreviewLocal=ev.data.btPreviewLocal;}};window.addEventListener('message',onMsg);f.srcdoc='<script src="https://127.0.0.1:18443/cdn.js"><\/script><script>parent.postMessage({btPreviewLocal:(window.__localHttpsLoaded===true)},"*");<\/script>';var n=0;var iv=setInterval(function(){if(window.__btPreviewLocal===true){clearInterval(iv);window.removeEventListener('message',onMsg);res(true);}else if(++n>40){clearInterval(iv);window.removeEventListener('message',onMsg);res(false);}},250);});})()`);
    mark('http-script (must be blocked by CSP)');
    // CSP negative control: an http: script must be BLOCKED by the CSP.
    results.httpScriptBlocked = await evalJs(`(function(){return new Promise(function(res){var s=document.createElement('script');s.onload=function(){res(false)};s.onerror=function(){res(true)};s.src='http://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js';document.head.appendChild(s);setTimeout(function(){res('timeout')},8000);});})()`);
    mark('https-script (must load)');
    // CSP positive control: an https: script must LOAD in the main page.
    results.httpsScriptLoads = await evalJs(`(function(){return new Promise(function(res){var s=document.createElement('script');s.onload=function(){res(typeof window.confetti==='function')};s.onerror=function(){res(false)};s.src='https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js';document.head.appendChild(s);setTimeout(function(){res('timeout')},8000);});})()`);
    mark('preview-cdn');
    // Build Preview test: srcdoc iframe fed the way runPreview() does it,
    // with an outside-CDN script that must execute under the inherited CSP.
    // The iframe is sandboxed without allow-same-origin (opaque origin),
    // so the result comes back via postMessage, not contentWindow access.
    results.previewCdnRuns = await evalJs(`(function(){return new Promise(function(res){var f=document.getElementById('previewFrame');if(!f){res('no-preview-frame');return;}window.__btPreviewOk=null;var onMsg=function(ev){if(ev.data&&ev.data.btPreviewOk!==undefined){window.__btPreviewOk=ev.data.btPreviewOk;}};window.addEventListener('message',onMsg);f.srcdoc='<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js"><\/script><script>parent.postMessage({btPreviewOk:(typeof confetti === "function")},"*");<\/script>';var n=0;var iv=setInterval(function(){if(window.__btPreviewOk===true){clearInterval(iv);window.removeEventListener('message',onMsg);res(true);}else if(++n>40){clearInterval(iv);window.removeEventListener('message',onMsg);res(false);}},250);});})()`);
    mark('window.open + ollama + menu');
    // Window bounds (proves the restored window-state was applied).
    results.windowBounds = (w && !w.isDestroyed()) ? w.getBounds() : null;
    results.trayCreated = !!tray;
    // Main-process zoom fallback (setZoomFactor, independent of the page).
    applyZoom(1.5);
    results.zoomFactorAfterApply = w.webContents.getZoomFactor();
    applyZoom(1);
    // Vault on this Linux VM has no keyring: encrypt must return null,
    // never throw into the renderer.
    results.vaultEncryptNullWhenUnavailable = await evalJs(`window.bigTonyDesktop ? window.bigTonyDesktop.vaultEncrypt('test-secret') : 'no-bridge'`);
    // File bridge: round-trip through userData (allowed) + a path outside
    // userData and outside any dialog pick (must be refused).
    results.fileRoundTrip = await evalJs(`(async function(){var p=window.bigTonyDesktop.userDataPath+'/bt-test.txt';var ok=await window.bigTonyDesktop.writeFileText(p,'hello-tony');var back=await window.bigTonyDesktop.readFileText(p);return ok===true&&back==='hello-tony';})()`);
    results.fileOutsideRefused = await evalJs(`(async function(){var r=await window.bigTonyDesktop.readFileText('/etc/passwd');var w2=await window.bigTonyDesktop.writeFileText('/tmp/bt-evil.txt','x');return r===null&&w2===false;})()`);
    // openExternal: non-http(s) must be refused.
    results.openExternalRefusesNonHttp = await evalJs(`window.bigTonyDesktop ? window.bigTonyDesktop.openExternal('javascript:void(0)') : 'no-bridge'`);
    // External link: window.open must NOT create a new Electron window.
    const winsBefore = BrowserWindow.getAllWindows().length;
    await evalJs(`window.open('https://example.com','_blank')`);
    await sleep(1500);
    results.windowOpenNoNewWindow = BrowserWindow.getAllWindows().length === winsBefore;
    // Ollama fallback through the main process (null when Ollama is down).
    results.ollamaList = await evalJs(`window.bigTonyDesktop ? window.bigTonyDesktop.ollamaList() : null`);
    // Menu IPC reaches the renderer (listener registered by the preload).
    await evalJs(`window.__btMenuTestSeen=null;window.bigTonyDesktop.onMenuAction(function(a){window.__btMenuTestSeen=a;})`);
    if (w && !w.isDestroyed()) w.webContents.send('bt:menu', '__bt_test__');
    await sleep(800);
    results.menuIpcDelivered = await evalJs(`window.__btMenuTestSeen==='__bt_test__'`);
  } catch (e) {
    results.selfTestError = String(e && e.stack || e);
  }
  try {
    const out = path.join(app.getPath('userData'), 'bt-self-test.json');
    fs.mkdirSync(path.dirname(out), { recursive: true });
    fs.writeFileSync(out, JSON.stringify(results, null, 2), 'utf8');
  } catch (_) {}
  console.log('BT-SELF-TEST ' + JSON.stringify(results));
  app.quit();
  // Test-only: app.quit() can hang on VMs without a GPU/DBus session, so
  // force-exit shortly after; this line never runs in normal use.
  setTimeout(() => process.exit(0), 3000);
}
