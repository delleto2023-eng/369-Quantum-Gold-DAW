const { app, BrowserWindow, globalShortcut } = require('electron');

// JARVIS — Real-Time AI Assistant with Jev routing (Windows desktop shell).
// Loads the self-contained index.html in this folder; no server needed.
// Jev calls go to https://api.typesafe.ai/v1/systemone with the key the
// user pastes in the app (in-session only, never stored). Without a key the
// app runs its built-in local routing engine, honestly labelled LOCAL ENGINE.
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

let w = null;

function createWindow() {
  w = new BrowserWindow({
    width: 1440,
    height: 900,
    backgroundColor: '#0a0e14',
    title: 'JARVIS — Real-Time AI Assistant',
    autoHideMenuBar: true,
    webPreferences: { nodeIntegration: false, contextIsolation: true }
  });
  w.loadFile('index.html');
  w.on('closed', () => { w = null; });
}

app.whenReady().then(() => {
  createWindow();
  // Ctrl+Shift+J brings JARVIS to the front from anywhere.
  globalShortcut.register('CommandOrControl+Shift+J', () => {
    if (w) {
      if (w.isMinimized()) w.restore();
      w.focus();
    } else {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => app.quit());
app.on('will-quit', () => globalShortcut.unregisterAll());
