/* 369 OMNI v19 runtime: memory stack (short/long term, semantic/episodic/procedural) + bounded loop (2 passes, 210s deadline) */
(function(){
var K='omni369_mem_v19';
function load(){try{return JSON.parse(localStorage.getItem(K))||{semantic:{},episodic:[],procedural:{}}}catch(e){return {semantic:{},episodic:[],procedural:{}}}}
function save(m){try{localStorage.setItem(K,JSON.stringify(m))}catch(e){}}
var short={};
var Mem={
 remember:function(agent,key,val){var m=load();(m.semantic[agent]=m.semantic[agent]||{})[key]=val;save(m)},
 episode:function(agent,text){var m=load();m.episodic.push({agent:agent,t:Date.now(),text:String(text).slice(0,2000)});if(m.episodic.length>2000)m.episodic=m.episodic.slice(-2000);save(m)},
 learn:function(agent,name,steps){var m=load();(m.procedural[agent]=m.procedural[agent]||{})[name]=steps;save(m)},
 push:function(agent,role,text){var s=short[agent]=short[agent]||[];s.push({role:role,content:text});if(s.length>20)s.shift()},
 shortTerm:function(agent){return short[agent]||[]},
 context:function(agent,query){var m=load(),q=String(query||'').toLowerCase().split(/\W+/).filter(Boolean);
  var sem=Object.assign({},m.semantic['*']||{},m.semantic[agent]||{});
  var eps=m.episodic.filter(function(e){return e.agent===agent||e.agent==='*'}).map(function(e){var sc=q.reduce(function(a,w){return a+(e.text.toLowerCase().indexOf(w)>=0)},0);return [sc,e]}).filter(function(x){return x[0]>0}).sort(function(a,b){return b[0]-a[0]}).slice(0,5).map(function(x){return x[1].text});
  var pro=Object.assign({},m.procedural['*']||{},m.procedural[agent]||{});
  return 'USER FACTS: '+JSON.stringify(sem)+'\nRELEVANT PAST: '+eps.join(' | ')+'\nKNOWN PROCEDURES: '+Object.keys(pro).join(', ')},
 export:function(){return load()},clear:function(){localStorage.removeItem(K);short={}}
};
/* Bounded loop: exactly up to 2 passes, then answer; hard deadline 3.5 min */
var Loop={MAX:2,DEADLINE_MS:210000,
 run:async function(agent,task,callModel){var t0=Date.now(),best='';
  var ctx=Mem.context(agent,task);Mem.push(agent,'user',task);
  for(var i=0;i<Loop.MAX;i++){
   var left=Loop.DEADLINE_MS-(Date.now()-t0);if(left<=0)break;
   var prompt=(i===0?'':'Improve and fix this draft:\n'+best+'\n\n')+ctx+'\n\nTASK: '+task;
   try{best=await Promise.race([callModel(prompt,Mem.shortTerm(agent)),new Promise(function(r){setTimeout(function(){r(best||'(time limit reached)')},left)})])}catch(e){if(!best)best='Error: '+e.message}
  }
  Mem.push(agent,'assistant',best);Mem.episode(agent,'Q: '+task+' A: '+best);return best}};
window.OMNI_MEMORY=Mem;window.OMNI_LOOP=Loop;
})();
