window.OMNI_ECC={
 "source": "https://github.com/affaan-m/everything-claude-code",
 "agents": [
  {
   "id": "ecc-a11y-architect",
   "name": "A11Y Architect",
   "group": "Everything Claude Code Dev Team",
   "role": "A11Y Architect sub-agent: handles a11y architect work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/a11y-architect.md"
  },
  {
   "id": "ecc-agent-evaluator",
   "name": "Agent Evaluator",
   "group": "Everything Claude Code Dev Team",
   "role": "Agent Evaluator sub-agent: handles agent evaluator work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/agent-evaluator.md"
  },
  {
   "id": "ecc-architect",
   "name": "Architect",
   "group": "Everything Claude Code Dev Team",
   "role": "Architect sub-agent: handles architect work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/architect.md"
  },
  {
   "id": "ecc-bengali-reviewer",
   "name": "Bengali Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Bengali Reviewer sub-agent: handles bengali reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/bengali-reviewer.md"
  },
  {
   "id": "ecc-build-error-resolver",
   "name": "Build Error Resolver",
   "group": "Everything Claude Code Dev Team",
   "role": "Build Error Resolver sub-agent: handles build error resolver work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/build-error-resolver.md"
  },
  {
   "id": "ecc-chief-of-staff",
   "name": "Chief Of Staff",
   "group": "Everything Claude Code Dev Team",
   "role": "Chief Of Staff sub-agent: handles chief of staff work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/chief-of-staff.md"
  },
  {
   "id": "ecc-code-architect",
   "name": "Code Architect",
   "group": "Everything Claude Code Dev Team",
   "role": "Code Architect sub-agent: handles code architect work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/code-architect.md"
  },
  {
   "id": "ecc-code-explorer",
   "name": "Code Explorer",
   "group": "Everything Claude Code Dev Team",
   "role": "Code Explorer sub-agent: handles code explorer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/code-explorer.md"
  },
  {
   "id": "ecc-code-reviewer",
   "name": "Code Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Code Reviewer sub-agent: handles code reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/code-reviewer.md"
  },
  {
   "id": "ecc-code-simplifier",
   "name": "Code Simplifier",
   "group": "Everything Claude Code Dev Team",
   "role": "Code Simplifier sub-agent: handles code simplifier work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/code-simplifier.md"
  },
  {
   "id": "ecc-comment-analyzer",
   "name": "Comment Analyzer",
   "group": "Everything Claude Code Dev Team",
   "role": "Comment Analyzer sub-agent: handles comment analyzer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/comment-analyzer.md"
  },
  {
   "id": "ecc-commit-reviewer",
   "name": "Commit Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Commit Reviewer sub-agent: handles commit reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/commit-reviewer.md"
  },
  {
   "id": "ecc-conversation-analyzer",
   "name": "Conversation Analyzer",
   "group": "Everything Claude Code Dev Team",
   "role": "Conversation Analyzer sub-agent: handles conversation analyzer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/conversation-analyzer.md"
  },
  {
   "id": "ecc-cpp-build-resolver",
   "name": "Cpp Build Resolver",
   "group": "Everything Claude Code Dev Team",
   "role": "Cpp Build Resolver sub-agent: handles cpp build resolver work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/cpp-build-resolver.md"
  },
  {
   "id": "ecc-cpp-reviewer",
   "name": "Cpp Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Cpp Reviewer sub-agent: handles cpp reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/cpp-reviewer.md"
  },
  {
   "id": "ecc-csharp-reviewer",
   "name": "Csharp Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Csharp Reviewer sub-agent: handles csharp reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/csharp-reviewer.md"
  },
  {
   "id": "ecc-dart-build-resolver",
   "name": "Dart Build Resolver",
   "group": "Everything Claude Code Dev Team",
   "role": "Dart Build Resolver sub-agent: handles dart build resolver work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/dart-build-resolver.md"
  },
  {
   "id": "ecc-database-reviewer",
   "name": "Database Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Database Reviewer sub-agent: handles database reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/database-reviewer.md"
  },
  {
   "id": "ecc-django-build-resolver",
   "name": "Django Build Resolver",
   "group": "Everything Claude Code Dev Team",
   "role": "Django Build Resolver sub-agent: handles django build resolver work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/django-build-resolver.md"
  },
  {
   "id": "ecc-django-reviewer",
   "name": "Django Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Django Reviewer sub-agent: handles django reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/django-reviewer.md"
  },
  {
   "id": "ecc-doc-updater",
   "name": "Doc Updater",
   "group": "Everything Claude Code Dev Team",
   "role": "Doc Updater sub-agent: handles doc updater work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/doc-updater.md"
  },
  {
   "id": "ecc-docs-lookup",
   "name": "Docs Lookup",
   "group": "Everything Claude Code Dev Team",
   "role": "Docs Lookup sub-agent: handles docs lookup work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/docs-lookup.md"
  },
  {
   "id": "ecc-e2e-runner",
   "name": "E2E Runner",
   "group": "Everything Claude Code Dev Team",
   "role": "E2E Runner sub-agent: handles e2e runner work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/e2e-runner.md"
  },
  {
   "id": "ecc-fastapi-reviewer",
   "name": "Fastapi Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Fastapi Reviewer sub-agent: handles fastapi reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/fastapi-reviewer.md"
  },
  {
   "id": "ecc-flutter-reviewer",
   "name": "Flutter Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Flutter Reviewer sub-agent: handles flutter reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/flutter-reviewer.md"
  },
  {
   "id": "ecc-fsharp-reviewer",
   "name": "Fsharp Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Fsharp Reviewer sub-agent: handles fsharp reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/fsharp-reviewer.md"
  },
  {
   "id": "ecc-gan-evaluator",
   "name": "Gan Evaluator",
   "group": "Everything Claude Code Dev Team",
   "role": "Gan Evaluator sub-agent: handles gan evaluator work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/gan-evaluator.md"
  },
  {
   "id": "ecc-gan-generator",
   "name": "Gan Generator",
   "group": "Everything Claude Code Dev Team",
   "role": "Gan Generator sub-agent: handles gan generator work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/gan-generator.md"
  },
  {
   "id": "ecc-gan-planner",
   "name": "Gan Planner",
   "group": "Everything Claude Code Dev Team",
   "role": "Gan Planner sub-agent: handles gan planner work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/gan-planner.md"
  },
  {
   "id": "ecc-go-build-resolver",
   "name": "Go Build Resolver",
   "group": "Everything Claude Code Dev Team",
   "role": "Go Build Resolver sub-agent: handles go build resolver work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/go-build-resolver.md"
  },
  {
   "id": "ecc-go-reviewer",
   "name": "Go Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Go Reviewer sub-agent: handles go reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/go-reviewer.md"
  },
  {
   "id": "ecc-harmonyos-app-resolver",
   "name": "Harmonyos App Resolver",
   "group": "Everything Claude Code Dev Team",
   "role": "Harmonyos App Resolver sub-agent: handles harmonyos app resolver work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/harmonyos-app-resolver.md"
  },
  {
   "id": "ecc-harness-optimizer",
   "name": "Harness Optimizer",
   "group": "Everything Claude Code Dev Team",
   "role": "Harness Optimizer sub-agent: handles harness optimizer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/harness-optimizer.md"
  },
  {
   "id": "ecc-healthcare-reviewer",
   "name": "Healthcare Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Healthcare Reviewer sub-agent: handles healthcare reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/healthcare-reviewer.md"
  },
  {
   "id": "ecc-homelab-architect",
   "name": "Homelab Architect",
   "group": "Everything Claude Code Dev Team",
   "role": "Homelab Architect sub-agent: handles homelab architect work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/homelab-architect.md"
  },
  {
   "id": "ecc-java-build-resolver",
   "name": "Java Build Resolver",
   "group": "Everything Claude Code Dev Team",
   "role": "Java Build Resolver sub-agent: handles java build resolver work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/java-build-resolver.md"
  },
  {
   "id": "ecc-java-reviewer",
   "name": "Java Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Java Reviewer sub-agent: handles java reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/java-reviewer.md"
  },
  {
   "id": "ecc-kotlin-build-resolver",
   "name": "Kotlin Build Resolver",
   "group": "Everything Claude Code Dev Team",
   "role": "Kotlin Build Resolver sub-agent: handles kotlin build resolver work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/kotlin-build-resolver.md"
  },
  {
   "id": "ecc-kotlin-reviewer",
   "name": "Kotlin Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Kotlin Reviewer sub-agent: handles kotlin reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/kotlin-reviewer.md"
  },
  {
   "id": "ecc-loop-operator",
   "name": "Loop Operator",
   "group": "Everything Claude Code Dev Team",
   "role": "Loop Operator sub-agent: handles loop operator work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/loop-operator.md"
  },
  {
   "id": "ecc-marketing-agent",
   "name": "Marketing Agent",
   "group": "Everything Claude Code Dev Team",
   "role": "Marketing Agent sub-agent: handles marketing agent work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/marketing-agent.md"
  },
  {
   "id": "ecc-mle-reviewer",
   "name": "Mle Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Mle Reviewer sub-agent: handles mle reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/mle-reviewer.md"
  },
  {
   "id": "ecc-network-architect",
   "name": "Network Architect",
   "group": "Everything Claude Code Dev Team",
   "role": "Network Architect sub-agent: handles network architect work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/network-architect.md"
  },
  {
   "id": "ecc-network-config-reviewer",
   "name": "Network Config Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Network Config Reviewer sub-agent: handles network config reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/network-config-reviewer.md"
  },
  {
   "id": "ecc-network-troubleshooter",
   "name": "Network Troubleshooter",
   "group": "Everything Claude Code Dev Team",
   "role": "Network Troubleshooter sub-agent: handles network troubleshooter work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/network-troubleshooter.md"
  },
  {
   "id": "ecc-opensource-forker",
   "name": "Opensource Forker",
   "group": "Everything Claude Code Dev Team",
   "role": "Opensource Forker sub-agent: handles opensource forker work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/opensource-forker.md"
  },
  {
   "id": "ecc-opensource-packager",
   "name": "Opensource Packager",
   "group": "Everything Claude Code Dev Team",
   "role": "Opensource Packager sub-agent: handles opensource packager work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/opensource-packager.md"
  },
  {
   "id": "ecc-opensource-sanitizer",
   "name": "Opensource Sanitizer",
   "group": "Everything Claude Code Dev Team",
   "role": "Opensource Sanitizer sub-agent: handles opensource sanitizer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/opensource-sanitizer.md"
  },
  {
   "id": "ecc-performance-optimizer",
   "name": "Performance Optimizer",
   "group": "Everything Claude Code Dev Team",
   "role": "Performance Optimizer sub-agent: handles performance optimizer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/performance-optimizer.md"
  },
  {
   "id": "ecc-php-reviewer",
   "name": "Php Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Php Reviewer sub-agent: handles php reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/php-reviewer.md"
  },
  {
   "id": "ecc-planner",
   "name": "Planner",
   "group": "Everything Claude Code Dev Team",
   "role": "Planner sub-agent: handles planner work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/planner.md"
  },
  {
   "id": "ecc-pr-test-analyzer",
   "name": "Pr Test Analyzer",
   "group": "Everything Claude Code Dev Team",
   "role": "Pr Test Analyzer sub-agent: handles pr test analyzer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/pr-test-analyzer.md"
  },
  {
   "id": "ecc-python-reviewer",
   "name": "Python Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Python Reviewer sub-agent: handles python reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/python-reviewer.md"
  },
  {
   "id": "ecc-pytorch-build-resolver",
   "name": "Pytorch Build Resolver",
   "group": "Everything Claude Code Dev Team",
   "role": "Pytorch Build Resolver sub-agent: handles pytorch build resolver work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/pytorch-build-resolver.md"
  },
  {
   "id": "ecc-rag-pipeline-reviewer",
   "name": "Rag Pipeline Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Rag Pipeline Reviewer sub-agent: handles rag pipeline reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/rag-pipeline-reviewer.md"
  },
  {
   "id": "ecc-react-build-resolver",
   "name": "React Build Resolver",
   "group": "Everything Claude Code Dev Team",
   "role": "React Build Resolver sub-agent: handles react build resolver work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/react-build-resolver.md"
  },
  {
   "id": "ecc-react-reviewer",
   "name": "React Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "React Reviewer sub-agent: handles react reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/react-reviewer.md"
  },
  {
   "id": "ecc-refactor-cleaner",
   "name": "Refactor Cleaner",
   "group": "Everything Claude Code Dev Team",
   "role": "Refactor Cleaner sub-agent: handles refactor cleaner work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/refactor-cleaner.md"
  },
  {
   "id": "ecc-ruby-reviewer",
   "name": "Ruby Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Ruby Reviewer sub-agent: handles ruby reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/ruby-reviewer.md"
  },
  {
   "id": "ecc-rust-build-resolver",
   "name": "Rust Build Resolver",
   "group": "Everything Claude Code Dev Team",
   "role": "Rust Build Resolver sub-agent: handles rust build resolver work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/rust-build-resolver.md"
  },
  {
   "id": "ecc-rust-reviewer",
   "name": "Rust Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Rust Reviewer sub-agent: handles rust reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/rust-reviewer.md"
  },
  {
   "id": "ecc-security-reviewer",
   "name": "Security Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Security Reviewer sub-agent: handles security reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/security-reviewer.md"
  },
  {
   "id": "ecc-seo-specialist",
   "name": "Seo Specialist",
   "group": "Everything Claude Code Dev Team",
   "role": "Seo Specialist sub-agent: handles seo specialist work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/seo-specialist.md"
  },
  {
   "id": "ecc-silent-failure-hunter",
   "name": "Silent Failure Hunter",
   "group": "Everything Claude Code Dev Team",
   "role": "Silent Failure Hunter sub-agent: handles silent failure hunter work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/silent-failure-hunter.md"
  },
  {
   "id": "ecc-spec-miner",
   "name": "Spec Miner",
   "group": "Everything Claude Code Dev Team",
   "role": "Spec Miner sub-agent: handles spec miner work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/spec-miner.md"
  },
  {
   "id": "ecc-swift-build-resolver",
   "name": "Swift Build Resolver",
   "group": "Everything Claude Code Dev Team",
   "role": "Swift Build Resolver sub-agent: handles swift build resolver work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/swift-build-resolver.md"
  },
  {
   "id": "ecc-swift-reviewer",
   "name": "Swift Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Swift Reviewer sub-agent: handles swift reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/swift-reviewer.md"
  },
  {
   "id": "ecc-tdd-guide",
   "name": "Tdd Guide",
   "group": "Everything Claude Code Dev Team",
   "role": "Tdd Guide sub-agent: handles tdd guide work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/tdd-guide.md"
  },
  {
   "id": "ecc-type-design-analyzer",
   "name": "Type Design Analyzer",
   "group": "Everything Claude Code Dev Team",
   "role": "Type Design Analyzer sub-agent: handles type design analyzer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/type-design-analyzer.md"
  },
  {
   "id": "ecc-typescript-reviewer",
   "name": "Typescript Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Typescript Reviewer sub-agent: handles typescript reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/typescript-reviewer.md"
  },
  {
   "id": "ecc-vue-reviewer",
   "name": "Vue Reviewer",
   "group": "Everything Claude Code Dev Team",
   "role": "Vue Reviewer sub-agent: handles vue reviewer work, hands off to Big Tony for final merge.",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/agents/vue-reviewer.md"
  }
 ],
 "skills": [
  {
   "id": "ecc-accessibility",
   "name": "Accessibility",
   "trigger": "accessibility",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/accessibility/SKILL.md"
  },
  {
   "id": "ecc-agent-architecture-audit",
   "name": "Agent Architecture Audit",
   "trigger": "agent architecture audit",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/agent-architecture-audit/SKILL.md"
  },
  {
   "id": "ecc-agent-eval",
   "name": "Agent Eval",
   "trigger": "agent eval",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/agent-eval/SKILL.md"
  },
  {
   "id": "ecc-agent-harness-construction",
   "name": "Agent Harness Construction",
   "trigger": "agent harness construction",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/agent-harness-construction/SKILL.md"
  },
  {
   "id": "ecc-agent-introspection-debugging",
   "name": "Agent Introspection Debugging",
   "trigger": "agent introspection debugging",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/agent-introspection-debugging/SKILL.md"
  },
  {
   "id": "ecc-agent-payment-x402",
   "name": "Agent Payment X402",
   "trigger": "agent payment x402",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/agent-payment-x402/SKILL.md"
  },
  {
   "id": "ecc-agent-runtime-gateway-smoke-test",
   "name": "Agent Runtime Gateway Smoke Test",
   "trigger": "agent runtime gateway smoke test",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/agent-runtime-gateway-smoke-test/SKILL.md"
  },
  {
   "id": "ecc-agent-security-hardening",
   "name": "Agent Security Hardening",
   "trigger": "agent security hardening",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/agent-security-hardening/SKILL.md"
  },
  {
   "id": "ecc-agent-self-evaluation",
   "name": "Agent Self Evaluation",
   "trigger": "agent self evaluation",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/agent-self-evaluation/SKILL.md"
  },
  {
   "id": "ecc-agent-sort",
   "name": "Agent Sort",
   "trigger": "agent sort",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/agent-sort/SKILL.md"
  },
  {
   "id": "ecc-agentic-engineering",
   "name": "Agentic Engineering",
   "trigger": "agentic engineering",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/agentic-engineering/SKILL.md"
  },
  {
   "id": "ecc-agentic-os",
   "name": "Agentic Os",
   "trigger": "agentic os",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/agentic-os/SKILL.md"
  },
  {
   "id": "ecc-ai-first-engineering",
   "name": "Ai First Engineering",
   "trigger": "ai first engineering",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/ai-first-engineering/SKILL.md"
  },
  {
   "id": "ecc-ai-regression-testing",
   "name": "Ai Regression Testing",
   "trigger": "ai regression testing",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/ai-regression-testing/SKILL.md"
  },
  {
   "id": "ecc-android-clean-architecture",
   "name": "Android Clean Architecture",
   "trigger": "android clean architecture",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/android-clean-architecture/SKILL.md"
  },
  {
   "id": "ecc-angular-developer",
   "name": "Angular Developer",
   "trigger": "angular developer",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/angular-developer/SKILL.md"
  },
  {
   "id": "ecc-api-connector-builder",
   "name": "Api Connector Builder",
   "trigger": "api connector builder",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/api-connector-builder/SKILL.md"
  },
  {
   "id": "ecc-api-design",
   "name": "Api Design",
   "trigger": "api design",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/api-design/SKILL.md"
  },
  {
   "id": "ecc-architecture-decision-records",
   "name": "Architecture Decision Records",
   "trigger": "architecture decision records",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/architecture-decision-records/SKILL.md"
  },
  {
   "id": "ecc-article-writing",
   "name": "Article Writing",
   "trigger": "article writing",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/article-writing/SKILL.md"
  },
  {
   "id": "ecc-automation-audit-ops",
   "name": "Automation Audit Ops",
   "trigger": "automation audit ops",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/automation-audit-ops/SKILL.md"
  },
  {
   "id": "ecc-autonomous-agent-harness",
   "name": "Autonomous Agent Harness",
   "trigger": "autonomous agent harness",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/autonomous-agent-harness/SKILL.md"
  },
  {
   "id": "ecc-autonomous-loops",
   "name": "Autonomous Loops",
   "trigger": "autonomous loops",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/autonomous-loops/SKILL.md"
  },
  {
   "id": "ecc-backend-patterns",
   "name": "Backend Patterns",
   "trigger": "backend patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/backend-patterns/SKILL.md"
  },
  {
   "id": "ecc-benchmark",
   "name": "Benchmark",
   "trigger": "benchmark",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/benchmark/SKILL.md"
  },
  {
   "id": "ecc-benchmark-methodology",
   "name": "Benchmark Methodology",
   "trigger": "benchmark methodology",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/benchmark-methodology/SKILL.md"
  },
  {
   "id": "ecc-benchmark-optimization-loop",
   "name": "Benchmark Optimization Loop",
   "trigger": "benchmark optimization loop",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/benchmark-optimization-loop/SKILL.md"
  },
  {
   "id": "ecc-bengali-nlp",
   "name": "Bengali Nlp",
   "trigger": "bengali nlp",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/bengali-nlp/SKILL.md"
  },
  {
   "id": "ecc-blender-motion-state-inspection",
   "name": "Blender Motion State Inspection",
   "trigger": "blender motion state inspection",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/blender-motion-state-inspection/SKILL.md"
  },
  {
   "id": "ecc-blueprint",
   "name": "Blueprint",
   "trigger": "blueprint",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/blueprint/SKILL.md"
  },
  {
   "id": "ecc-brand-discovery",
   "name": "Brand Discovery",
   "trigger": "brand discovery",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/brand-discovery/SKILL.md"
  },
  {
   "id": "ecc-brand-voice",
   "name": "Brand Voice",
   "trigger": "brand voice",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/brand-voice/SKILL.md"
  },
  {
   "id": "ecc-brownfield-retrospective",
   "name": "Brownfield Retrospective",
   "trigger": "brownfield retrospective",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/brownfield-retrospective/SKILL.md"
  },
  {
   "id": "ecc-browser-qa",
   "name": "Browser Qa",
   "trigger": "browser qa",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/browser-qa/SKILL.md"
  },
  {
   "id": "ecc-bun-runtime",
   "name": "Bun Runtime",
   "trigger": "bun runtime",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/bun-runtime/SKILL.md"
  },
  {
   "id": "ecc-canary-watch",
   "name": "Canary Watch",
   "trigger": "canary watch",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/canary-watch/SKILL.md"
  },
  {
   "id": "ecc-carrier-relationship-management",
   "name": "Carrier Relationship Management",
   "trigger": "carrier relationship management",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/carrier-relationship-management/SKILL.md"
  },
  {
   "id": "ecc-change-impact",
   "name": "Change Impact",
   "trigger": "change impact",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/change-impact/SKILL.md"
  },
  {
   "id": "ecc-cisco-ios-patterns",
   "name": "Cisco Ios Patterns",
   "trigger": "cisco ios patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/cisco-ios-patterns/SKILL.md"
  },
  {
   "id": "ecc-ck",
   "name": "Ck",
   "trigger": "ck",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/ck/SKILL.md"
  },
  {
   "id": "ecc-claude-devfleet",
   "name": "Claude Devfleet",
   "trigger": "claude devfleet",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/claude-devfleet/SKILL.md"
  },
  {
   "id": "ecc-click-path-audit",
   "name": "Click Path Audit",
   "trigger": "click path audit",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/click-path-audit/SKILL.md"
  },
  {
   "id": "ecc-clickhouse-io",
   "name": "Clickhouse Io",
   "trigger": "clickhouse io",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/clickhouse-io/SKILL.md"
  },
  {
   "id": "ecc-code-tour",
   "name": "Code Tour",
   "trigger": "code tour",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/code-tour/SKILL.md"
  },
  {
   "id": "ecc-codebase-onboarding",
   "name": "Codebase Onboarding",
   "trigger": "codebase onboarding",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/codebase-onboarding/SKILL.md"
  },
  {
   "id": "ecc-codehealth-mcp",
   "name": "Codehealth Mcp",
   "trigger": "codehealth mcp",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/codehealth-mcp/SKILL.md"
  },
  {
   "id": "ecc-coding-standards",
   "name": "Coding Standards",
   "trigger": "coding standards",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/coding-standards/SKILL.md"
  },
  {
   "id": "ecc-competitive-platform-analysis",
   "name": "Competitive Platform Analysis",
   "trigger": "competitive platform analysis",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/competitive-platform-analysis/SKILL.md"
  },
  {
   "id": "ecc-competitive-report-structure",
   "name": "Competitive Report Structure",
   "trigger": "competitive report structure",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/competitive-report-structure/SKILL.md"
  },
  {
   "id": "ecc-compose-multiplatform-patterns",
   "name": "Compose Multiplatform Patterns",
   "trigger": "compose multiplatform patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/compose-multiplatform-patterns/SKILL.md"
  },
  {
   "id": "ecc-config-gc",
   "name": "Config Gc",
   "trigger": "config gc",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/config-gc/SKILL.md"
  },
  {
   "id": "ecc-configure-ecc",
   "name": "Configure Ecc",
   "trigger": "configure ecc",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/configure-ecc/SKILL.md"
  },
  {
   "id": "ecc-connections-optimizer",
   "name": "Connections Optimizer",
   "trigger": "connections optimizer",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/connections-optimizer/SKILL.md"
  },
  {
   "id": "ecc-content-engine",
   "name": "Content Engine",
   "trigger": "content engine",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/content-engine/SKILL.md"
  },
  {
   "id": "ecc-content-hash-cache-pattern",
   "name": "Content Hash Cache Pattern",
   "trigger": "content hash cache pattern",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/content-hash-cache-pattern/SKILL.md"
  },
  {
   "id": "ecc-context-and-decisions",
   "name": "Context And Decisions",
   "trigger": "context and decisions",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/context-and-decisions/SKILL.md"
  },
  {
   "id": "ecc-context-budget",
   "name": "Context Budget",
   "trigger": "context budget",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/context-budget/SKILL.md"
  },
  {
   "id": "ecc-continuous-agent-loop",
   "name": "Continuous Agent Loop",
   "trigger": "continuous agent loop",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/continuous-agent-loop/SKILL.md"
  },
  {
   "id": "ecc-continuous-learning",
   "name": "Continuous Learning",
   "trigger": "continuous learning",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/continuous-learning/SKILL.md"
  },
  {
   "id": "ecc-continuous-learning-v2",
   "name": "Continuous Learning V2",
   "trigger": "continuous learning v2",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/continuous-learning-v2/SKILL.md"
  },
  {
   "id": "ecc-contract-first",
   "name": "Contract First",
   "trigger": "contract first",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/contract-first/SKILL.md"
  },
  {
   "id": "ecc-conventional-commit-review",
   "name": "Conventional Commit Review",
   "trigger": "conventional commit review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/conventional-commit-review/SKILL.md"
  },
  {
   "id": "ecc-cost-aware-llm-pipeline",
   "name": "Cost Aware Llm Pipeline",
   "trigger": "cost aware llm pipeline",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/cost-aware-llm-pipeline/SKILL.md"
  },
  {
   "id": "ecc-cost-tracking",
   "name": "Cost Tracking",
   "trigger": "cost tracking",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/cost-tracking/SKILL.md"
  },
  {
   "id": "ecc-council",
   "name": "Council",
   "trigger": "council",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/council/SKILL.md"
  },
  {
   "id": "ecc-council-multi-model",
   "name": "Council Multi Model",
   "trigger": "council multi model",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/council-multi-model/SKILL.md"
  },
  {
   "id": "ecc-counterparty-channel-discipline",
   "name": "Counterparty Channel Discipline",
   "trigger": "counterparty channel discipline",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/counterparty-channel-discipline/SKILL.md"
  },
  {
   "id": "ecc-cpp-coding-standards",
   "name": "Cpp Coding Standards",
   "trigger": "cpp coding standards",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/cpp-coding-standards/SKILL.md"
  },
  {
   "id": "ecc-cpp-testing",
   "name": "Cpp Testing",
   "trigger": "cpp testing",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/cpp-testing/SKILL.md"
  },
  {
   "id": "ecc-crosspost",
   "name": "Crosspost",
   "trigger": "crosspost",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/crosspost/SKILL.md"
  },
  {
   "id": "ecc-csharp-testing",
   "name": "Csharp Testing",
   "trigger": "csharp testing",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/csharp-testing/SKILL.md"
  },
  {
   "id": "ecc-customer-billing-ops",
   "name": "Customer Billing Ops",
   "trigger": "customer billing ops",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/customer-billing-ops/SKILL.md"
  },
  {
   "id": "ecc-customs-trade-compliance",
   "name": "Customs Trade Compliance",
   "trigger": "customs trade compliance",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/customs-trade-compliance/SKILL.md"
  },
  {
   "id": "ecc-dart-flutter-patterns",
   "name": "Dart Flutter Patterns",
   "trigger": "dart flutter patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/dart-flutter-patterns/SKILL.md"
  },
  {
   "id": "ecc-dashboard-builder",
   "name": "Dashboard Builder",
   "trigger": "dashboard builder",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/dashboard-builder/SKILL.md"
  },
  {
   "id": "ecc-data-scraper-agent",
   "name": "Data Scraper Agent",
   "trigger": "data scraper agent",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/data-scraper-agent/SKILL.md"
  },
  {
   "id": "ecc-data-throughput-accelerator",
   "name": "Data Throughput Accelerator",
   "trigger": "data throughput accelerator",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/data-throughput-accelerator/SKILL.md"
  },
  {
   "id": "ecc-database-migrations",
   "name": "Database Migrations",
   "trigger": "database migrations",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/database-migrations/SKILL.md"
  },
  {
   "id": "ecc-deep-research",
   "name": "Deep Research",
   "trigger": "deep research",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/deep-research/SKILL.md"
  },
  {
   "id": "ecc-deepseek-harness-setup",
   "name": "Deepseek Harness Setup",
   "trigger": "deepseek harness setup",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/deepseek-harness-setup/SKILL.md"
  },
  {
   "id": "ecc-defi-amm-security",
   "name": "Defi Amm Security",
   "trigger": "defi amm security",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/defi-amm-security/SKILL.md"
  },
  {
   "id": "ecc-delivery-gate",
   "name": "Delivery Gate",
   "trigger": "delivery gate",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/delivery-gate/SKILL.md"
  },
  {
   "id": "ecc-deployment-patterns",
   "name": "Deployment Patterns",
   "trigger": "deployment patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/deployment-patterns/SKILL.md"
  },
  {
   "id": "ecc-design-system",
   "name": "Design System",
   "trigger": "design system",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/design-system/SKILL.md"
  },
  {
   "id": "ecc-dev-team",
   "name": "Dev Team",
   "trigger": "dev team",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/dev-team/SKILL.md"
  },
  {
   "id": "ecc-django-celery",
   "name": "Django Celery",
   "trigger": "django celery",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/django-celery/SKILL.md"
  },
  {
   "id": "ecc-django-patterns",
   "name": "Django Patterns",
   "trigger": "django patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/django-patterns/SKILL.md"
  },
  {
   "id": "ecc-django-security",
   "name": "Django Security",
   "trigger": "django security",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/django-security/SKILL.md"
  },
  {
   "id": "ecc-django-tdd",
   "name": "Django Tdd",
   "trigger": "django tdd",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/django-tdd/SKILL.md"
  },
  {
   "id": "ecc-django-verification",
   "name": "Django Verification",
   "trigger": "django verification",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/django-verification/SKILL.md"
  },
  {
   "id": "ecc-dmux-workflows",
   "name": "Dmux Workflows",
   "trigger": "dmux workflows",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/dmux-workflows/SKILL.md"
  },
  {
   "id": "ecc-docker-patterns",
   "name": "Docker Patterns",
   "trigger": "docker patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/docker-patterns/SKILL.md"
  },
  {
   "id": "ecc-docs-governance",
   "name": "Docs Governance",
   "trigger": "docs governance",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/docs-governance/SKILL.md"
  },
  {
   "id": "ecc-documentation-lookup",
   "name": "Documentation Lookup",
   "trigger": "documentation lookup",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/documentation-lookup/SKILL.md"
  },
  {
   "id": "ecc-dotnet-patterns",
   "name": "Dotnet Patterns",
   "trigger": "dotnet patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/dotnet-patterns/SKILL.md"
  },
  {
   "id": "ecc-dynamic-workflow-mode",
   "name": "Dynamic Workflow Mode",
   "trigger": "dynamic workflow mode",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/dynamic-workflow-mode/SKILL.md"
  },
  {
   "id": "ecc-e2e-testing",
   "name": "E2E Testing",
   "trigger": "e2e testing",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/e2e-testing/SKILL.md"
  },
  {
   "id": "ecc-ecc-guide",
   "name": "Ecc Guide",
   "trigger": "ecc guide",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/ecc-guide/SKILL.md"
  },
  {
   "id": "ecc-ecc-recipes",
   "name": "Ecc Recipes",
   "trigger": "ecc recipes",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/ecc-recipes/SKILL.md"
  },
  {
   "id": "ecc-ecc-tools-cost-audit",
   "name": "Ecc Tools Cost Audit",
   "trigger": "ecc tools cost audit",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/ecc-tools-cost-audit/SKILL.md"
  },
  {
   "id": "ecc-email-ops",
   "name": "Email Ops",
   "trigger": "email ops",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/email-ops/SKILL.md"
  },
  {
   "id": "ecc-energy-procurement",
   "name": "Energy Procurement",
   "trigger": "energy procurement",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/energy-procurement/SKILL.md"
  },
  {
   "id": "ecc-enterprise-agent-ops",
   "name": "Enterprise Agent Ops",
   "trigger": "enterprise agent ops",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/enterprise-agent-ops/SKILL.md"
  },
  {
   "id": "ecc-error-handling",
   "name": "Error Handling",
   "trigger": "error handling",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/error-handling/SKILL.md"
  },
  {
   "id": "ecc-esign-field-placement",
   "name": "Esign Field Placement",
   "trigger": "esign field placement",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/esign-field-placement/SKILL.md"
  },
  {
   "id": "ecc-eval-harness",
   "name": "Eval Harness",
   "trigger": "eval harness",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/eval-harness/SKILL.md"
  },
  {
   "id": "ecc-evm-token-decimals",
   "name": "Evm Token Decimals",
   "trigger": "evm token decimals",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/evm-token-decimals/SKILL.md"
  },
  {
   "id": "ecc-exa-search",
   "name": "Exa Search",
   "trigger": "exa search",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/exa-search/SKILL.md"
  },
  {
   "id": "ecc-fal-ai-media",
   "name": "Fal Ai Media",
   "trigger": "fal ai media",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/fal-ai-media/SKILL.md"
  },
  {
   "id": "ecc-fastapi-patterns",
   "name": "Fastapi Patterns",
   "trigger": "fastapi patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/fastapi-patterns/SKILL.md"
  },
  {
   "id": "ecc-finance-billing-ops",
   "name": "Finance Billing Ops",
   "trigger": "finance billing ops",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/finance-billing-ops/SKILL.md"
  },
  {
   "id": "ecc-flox-environments",
   "name": "Flox Environments",
   "trigger": "flox environments",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/flox-environments/SKILL.md"
  },
  {
   "id": "ecc-flutter-dart-code-review",
   "name": "Flutter Dart Code Review",
   "trigger": "flutter dart code review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/flutter-dart-code-review/SKILL.md"
  },
  {
   "id": "ecc-foundation-models-on-device",
   "name": "Foundation Models On Device",
   "trigger": "foundation models on device",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/foundation-models-on-device/SKILL.md"
  },
  {
   "id": "ecc-frontend-a11y",
   "name": "Frontend A11Y",
   "trigger": "frontend a11y",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/frontend-a11y/SKILL.md"
  },
  {
   "id": "ecc-frontend-design-direction",
   "name": "Frontend Design Direction",
   "trigger": "frontend design direction",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/frontend-design-direction/SKILL.md"
  },
  {
   "id": "ecc-frontend-patterns",
   "name": "Frontend Patterns",
   "trigger": "frontend patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/frontend-patterns/SKILL.md"
  },
  {
   "id": "ecc-frontend-slides",
   "name": "Frontend Slides",
   "trigger": "frontend slides",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/frontend-slides/SKILL.md"
  },
  {
   "id": "ecc-fsharp-testing",
   "name": "Fsharp Testing",
   "trigger": "fsharp testing",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/fsharp-testing/SKILL.md"
  },
  {
   "id": "ecc-gan-style-harness",
   "name": "Gan Style Harness",
   "trigger": "gan style harness",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/gan-style-harness/SKILL.md"
  },
  {
   "id": "ecc-gateguard",
   "name": "Gateguard",
   "trigger": "gateguard",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/gateguard/SKILL.md"
  },
  {
   "id": "ecc-generating-python-installer",
   "name": "Generating Python Installer",
   "trigger": "generating python installer",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/generating-python-installer/SKILL.md"
  },
  {
   "id": "ecc-git-workflow",
   "name": "Git Workflow",
   "trigger": "git workflow",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/git-workflow/SKILL.md"
  },
  {
   "id": "ecc-github-ops",
   "name": "Github Ops",
   "trigger": "github ops",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/github-ops/SKILL.md"
  },
  {
   "id": "ecc-golang-patterns",
   "name": "Golang Patterns",
   "trigger": "golang patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/golang-patterns/SKILL.md"
  },
  {
   "id": "ecc-golang-testing",
   "name": "Golang Testing",
   "trigger": "golang testing",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/golang-testing/SKILL.md"
  },
  {
   "id": "ecc-google-workspace-ops",
   "name": "Google Workspace Ops",
   "trigger": "google workspace ops",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/google-workspace-ops/SKILL.md"
  },
  {
   "id": "ecc-growth-log",
   "name": "Growth Log",
   "trigger": "growth log",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/growth-log/SKILL.md"
  },
  {
   "id": "ecc-healthcare-cdss-patterns",
   "name": "Healthcare Cdss Patterns",
   "trigger": "healthcare cdss patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/healthcare-cdss-patterns/SKILL.md"
  },
  {
   "id": "ecc-healthcare-emr-patterns",
   "name": "Healthcare Emr Patterns",
   "trigger": "healthcare emr patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/healthcare-emr-patterns/SKILL.md"
  },
  {
   "id": "ecc-healthcare-eval-harness",
   "name": "Healthcare Eval Harness",
   "trigger": "healthcare eval harness",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/healthcare-eval-harness/SKILL.md"
  },
  {
   "id": "ecc-healthcare-phi-compliance",
   "name": "Healthcare Phi Compliance",
   "trigger": "healthcare phi compliance",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/healthcare-phi-compliance/SKILL.md"
  },
  {
   "id": "ecc-hermes-imports",
   "name": "Hermes Imports",
   "trigger": "hermes imports",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/hermes-imports/SKILL.md"
  },
  {
   "id": "ecc-hexagonal-architecture",
   "name": "Hexagonal Architecture",
   "trigger": "hexagonal architecture",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/hexagonal-architecture/SKILL.md"
  },
  {
   "id": "ecc-hipaa-compliance",
   "name": "Hipaa Compliance",
   "trigger": "hipaa compliance",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/hipaa-compliance/SKILL.md"
  },
  {
   "id": "ecc-homelab-network-readiness",
   "name": "Homelab Network Readiness",
   "trigger": "homelab network readiness",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/homelab-network-readiness/SKILL.md"
  },
  {
   "id": "ecc-homelab-network-setup",
   "name": "Homelab Network Setup",
   "trigger": "homelab network setup",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/homelab-network-setup/SKILL.md"
  },
  {
   "id": "ecc-homelab-pihole-dns",
   "name": "Homelab Pihole Dns",
   "trigger": "homelab pihole dns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/homelab-pihole-dns/SKILL.md"
  },
  {
   "id": "ecc-homelab-vlan-segmentation",
   "name": "Homelab Vlan Segmentation",
   "trigger": "homelab vlan segmentation",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/homelab-vlan-segmentation/SKILL.md"
  },
  {
   "id": "ecc-homelab-wireguard-vpn",
   "name": "Homelab Wireguard Vpn",
   "trigger": "homelab wireguard vpn",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/homelab-wireguard-vpn/SKILL.md"
  },
  {
   "id": "ecc-hookify-rules",
   "name": "Hookify Rules",
   "trigger": "hookify rules",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/hookify-rules/SKILL.md"
  },
  {
   "id": "ecc-i18n-sync",
   "name": "I18N Sync",
   "trigger": "i18n sync",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/i18n-sync/SKILL.md"
  },
  {
   "id": "ecc-inherit-legacy-style",
   "name": "Inherit Legacy Style",
   "trigger": "inherit legacy style",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/inherit-legacy-style/SKILL.md"
  },
  {
   "id": "ecc-intent-driven-development",
   "name": "Intent Driven Development",
   "trigger": "intent driven development",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/intent-driven-development/SKILL.md"
  },
  {
   "id": "ecc-inventory-demand-planning",
   "name": "Inventory Demand Planning",
   "trigger": "inventory demand planning",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/inventory-demand-planning/SKILL.md"
  },
  {
   "id": "ecc-investor-materials",
   "name": "Investor Materials",
   "trigger": "investor materials",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/investor-materials/SKILL.md"
  },
  {
   "id": "ecc-investor-outreach",
   "name": "Investor Outreach",
   "trigger": "investor outreach",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/investor-outreach/SKILL.md"
  },
  {
   "id": "ecc-ios-icon-gen",
   "name": "Ios Icon Gen",
   "trigger": "ios icon gen",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/ios-icon-gen/SKILL.md"
  },
  {
   "id": "ecc-issue-review",
   "name": "Issue Review",
   "trigger": "issue review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/issue-review/SKILL.md"
  },
  {
   "id": "ecc-iterative-retrieval",
   "name": "Iterative Retrieval",
   "trigger": "iterative retrieval",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/iterative-retrieval/SKILL.md"
  },
  {
   "id": "ecc-ito-baskets",
   "name": "Ito Baskets",
   "trigger": "ito baskets",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/ito-baskets/SKILL.md"
  },
  {
   "id": "ecc-ito-compute",
   "name": "Ito Compute",
   "trigger": "ito compute",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/ito-compute/SKILL.md"
  },
  {
   "id": "ecc-ito-inference",
   "name": "Ito Inference",
   "trigger": "ito inference",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/ito-inference/SKILL.md"
  },
  {
   "id": "ecc-ito-training",
   "name": "Ito Training",
   "trigger": "ito training",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/ito-training/SKILL.md"
  },
  {
   "id": "ecc-java-coding-standards",
   "name": "Java Coding Standards",
   "trigger": "java coding standards",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/java-coding-standards/SKILL.md"
  },
  {
   "id": "ecc-jira-integration",
   "name": "Jira Integration",
   "trigger": "jira integration",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/jira-integration/SKILL.md"
  },
  {
   "id": "ecc-jpa-patterns",
   "name": "Jpa Patterns",
   "trigger": "jpa patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/jpa-patterns/SKILL.md"
  },
  {
   "id": "ecc-knowledge-ops",
   "name": "Knowledge Ops",
   "trigger": "knowledge ops",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/knowledge-ops/SKILL.md"
  },
  {
   "id": "ecc-kotlin-coroutines-flows",
   "name": "Kotlin Coroutines Flows",
   "trigger": "kotlin coroutines flows",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/kotlin-coroutines-flows/SKILL.md"
  },
  {
   "id": "ecc-kotlin-exposed-patterns",
   "name": "Kotlin Exposed Patterns",
   "trigger": "kotlin exposed patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/kotlin-exposed-patterns/SKILL.md"
  },
  {
   "id": "ecc-kotlin-ktor-patterns",
   "name": "Kotlin Ktor Patterns",
   "trigger": "kotlin ktor patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/kotlin-ktor-patterns/SKILL.md"
  },
  {
   "id": "ecc-kotlin-patterns",
   "name": "Kotlin Patterns",
   "trigger": "kotlin patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/kotlin-patterns/SKILL.md"
  },
  {
   "id": "ecc-kotlin-testing",
   "name": "Kotlin Testing",
   "trigger": "kotlin testing",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/kotlin-testing/SKILL.md"
  },
  {
   "id": "ecc-kubernetes-patterns",
   "name": "Kubernetes Patterns",
   "trigger": "kubernetes patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/kubernetes-patterns/SKILL.md"
  },
  {
   "id": "ecc-laravel-patterns",
   "name": "Laravel Patterns",
   "trigger": "laravel patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/laravel-patterns/SKILL.md"
  },
  {
   "id": "ecc-laravel-plugin-discovery",
   "name": "Laravel Plugin Discovery",
   "trigger": "laravel plugin discovery",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/laravel-plugin-discovery/SKILL.md"
  },
  {
   "id": "ecc-laravel-security",
   "name": "Laravel Security",
   "trigger": "laravel security",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/laravel-security/SKILL.md"
  },
  {
   "id": "ecc-laravel-tdd",
   "name": "Laravel Tdd",
   "trigger": "laravel tdd",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/laravel-tdd/SKILL.md"
  },
  {
   "id": "ecc-laravel-verification",
   "name": "Laravel Verification",
   "trigger": "laravel verification",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/laravel-verification/SKILL.md"
  },
  {
   "id": "ecc-latency-critical-systems",
   "name": "Latency Critical Systems",
   "trigger": "latency critical systems",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/latency-critical-systems/SKILL.md"
  },
  {
   "id": "ecc-lead-intelligence",
   "name": "Lead Intelligence",
   "trigger": "lead intelligence",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/lead-intelligence/SKILL.md"
  },
  {
   "id": "ecc-liquid-glass-design",
   "name": "Liquid Glass Design",
   "trigger": "liquid glass design",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/liquid-glass-design/SKILL.md"
  },
  {
   "id": "ecc-living-docs-governance",
   "name": "Living Docs Governance",
   "trigger": "living docs governance",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/living-docs-governance/SKILL.md"
  },
  {
   "id": "ecc-llm-trading-agent-security",
   "name": "Llm Trading Agent Security",
   "trigger": "llm trading agent security",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/llm-trading-agent-security/SKILL.md"
  },
  {
   "id": "ecc-logistics-exception-management",
   "name": "Logistics Exception Management",
   "trigger": "logistics exception management",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/logistics-exception-management/SKILL.md"
  },
  {
   "id": "ecc-loop-design-check",
   "name": "Loop Design Check",
   "trigger": "loop design check",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/loop-design-check/SKILL.md"
  },
  {
   "id": "ecc-mailtrap-email-integration",
   "name": "Mailtrap Email Integration",
   "trigger": "mailtrap email integration",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/mailtrap-email-integration/SKILL.md"
  },
  {
   "id": "ecc-make-interfaces-feel-better",
   "name": "Make Interfaces Feel Better",
   "trigger": "make interfaces feel better",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/make-interfaces-feel-better/SKILL.md"
  },
  {
   "id": "ecc-manim-video",
   "name": "Manim Video",
   "trigger": "manim video",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/manim-video/SKILL.md"
  },
  {
   "id": "ecc-market-research",
   "name": "Market Research",
   "trigger": "market research",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/market-research/SKILL.md"
  },
  {
   "id": "ecc-marketing-campaign",
   "name": "Marketing Campaign",
   "trigger": "marketing campaign",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/marketing-campaign/SKILL.md"
  },
  {
   "id": "ecc-master-agreement-generator",
   "name": "Master Agreement Generator",
   "trigger": "master agreement generator",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/master-agreement-generator/SKILL.md"
  },
  {
   "id": "ecc-mcp-dependency-review",
   "name": "Mcp Dependency Review",
   "trigger": "mcp dependency review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/mcp-dependency-review/SKILL.md"
  },
  {
   "id": "ecc-mcp-server-patterns",
   "name": "Mcp Server Patterns",
   "trigger": "mcp server patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/mcp-server-patterns/SKILL.md"
  },
  {
   "id": "ecc-messages-ops",
   "name": "Messages Ops",
   "trigger": "messages ops",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/messages-ops/SKILL.md"
  },
  {
   "id": "ecc-ml-adoption-playbook",
   "name": "Ml Adoption Playbook",
   "trigger": "ml adoption playbook",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/ml-adoption-playbook/SKILL.md"
  },
  {
   "id": "ecc-mle-workflow",
   "name": "Mle Workflow",
   "trigger": "mle workflow",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/mle-workflow/SKILL.md"
  },
  {
   "id": "ecc-module-governance",
   "name": "Module Governance",
   "trigger": "module governance",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/module-governance/SKILL.md"
  },
  {
   "id": "ecc-module-regression",
   "name": "Module Regression",
   "trigger": "module regression",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/module-regression/SKILL.md"
  },
  {
   "id": "ecc-motion-advanced",
   "name": "Motion Advanced",
   "trigger": "motion advanced",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/motion-advanced/SKILL.md"
  },
  {
   "id": "ecc-motion-foundations",
   "name": "Motion Foundations",
   "trigger": "motion foundations",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/motion-foundations/SKILL.md"
  },
  {
   "id": "ecc-motion-patterns",
   "name": "Motion Patterns",
   "trigger": "motion patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/motion-patterns/SKILL.md"
  },
  {
   "id": "ecc-mybatis-patterns",
   "name": "Mybatis Patterns",
   "trigger": "mybatis patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/mybatis-patterns/SKILL.md"
  },
  {
   "id": "ecc-mysql-patterns",
   "name": "Mysql Patterns",
   "trigger": "mysql patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/mysql-patterns/SKILL.md"
  },
  {
   "id": "ecc-nanoclaw-repl",
   "name": "Nanoclaw Repl",
   "trigger": "nanoclaw repl",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/nanoclaw-repl/SKILL.md"
  },
  {
   "id": "ecc-nasiko-control-plane",
   "name": "Nasiko Control Plane",
   "trigger": "nasiko control plane",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/nasiko-control-plane/SKILL.md"
  },
  {
   "id": "ecc-nestjs-patterns",
   "name": "Nestjs Patterns",
   "trigger": "nestjs patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/nestjs-patterns/SKILL.md"
  },
  {
   "id": "ecc-netmiko-ssh-automation",
   "name": "Netmiko Ssh Automation",
   "trigger": "netmiko ssh automation",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/netmiko-ssh-automation/SKILL.md"
  },
  {
   "id": "ecc-network-bgp-diagnostics",
   "name": "Network Bgp Diagnostics",
   "trigger": "network bgp diagnostics",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/network-bgp-diagnostics/SKILL.md"
  },
  {
   "id": "ecc-network-config-validation",
   "name": "Network Config Validation",
   "trigger": "network config validation",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/network-config-validation/SKILL.md"
  },
  {
   "id": "ecc-network-interface-health",
   "name": "Network Interface Health",
   "trigger": "network interface health",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/network-interface-health/SKILL.md"
  },
  {
   "id": "ecc-nextjs-turbopack",
   "name": "Nextjs Turbopack",
   "trigger": "nextjs turbopack",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/nextjs-turbopack/SKILL.md"
  },
  {
   "id": "ecc-nodejs-keccak256",
   "name": "Nodejs Keccak256",
   "trigger": "nodejs keccak256",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/nodejs-keccak256/SKILL.md"
  },
  {
   "id": "ecc-nutrient-document-processing",
   "name": "Nutrient Document Processing",
   "trigger": "nutrient document processing",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/nutrient-document-processing/SKILL.md"
  },
  {
   "id": "ecc-nuxt4-patterns",
   "name": "Nuxt4 Patterns",
   "trigger": "nuxt4 patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/nuxt4-patterns/SKILL.md"
  },
  {
   "id": "ecc-openclaw-persona-forge",
   "name": "Openclaw Persona Forge",
   "trigger": "openclaw persona forge",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/openclaw-persona-forge/SKILL.md"
  },
  {
   "id": "ecc-opensource-pipeline",
   "name": "Opensource Pipeline",
   "trigger": "opensource pipeline",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/opensource-pipeline/SKILL.md"
  },
  {
   "id": "ecc-operator-approval-loop",
   "name": "Operator Approval Loop",
   "trigger": "operator approval loop",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/operator-approval-loop/SKILL.md"
  },
  {
   "id": "ecc-orch-add-feature",
   "name": "Orch Add Feature",
   "trigger": "orch add feature",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/orch-add-feature/SKILL.md"
  },
  {
   "id": "ecc-orch-build-mvp",
   "name": "Orch Build Mvp",
   "trigger": "orch build mvp",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/orch-build-mvp/SKILL.md"
  },
  {
   "id": "ecc-orch-change-feature",
   "name": "Orch Change Feature",
   "trigger": "orch change feature",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/orch-change-feature/SKILL.md"
  },
  {
   "id": "ecc-orch-fix-defect",
   "name": "Orch Fix Defect",
   "trigger": "orch fix defect",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/orch-fix-defect/SKILL.md"
  },
  {
   "id": "ecc-orch-pipeline",
   "name": "Orch Pipeline",
   "trigger": "orch pipeline",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/orch-pipeline/SKILL.md"
  },
  {
   "id": "ecc-orch-refine-code",
   "name": "Orch Refine Code",
   "trigger": "orch refine code",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/orch-refine-code/SKILL.md"
  },
  {
   "id": "ecc-osint-investigation",
   "name": "Osint Investigation",
   "trigger": "osint investigation",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/osint-investigation/SKILL.md"
  },
  {
   "id": "ecc-parallel-execution-optimizer",
   "name": "Parallel Execution Optimizer",
   "trigger": "parallel execution optimizer",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/parallel-execution-optimizer/SKILL.md"
  },
  {
   "id": "ecc-perl-patterns",
   "name": "Perl Patterns",
   "trigger": "perl patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/perl-patterns/SKILL.md"
  },
  {
   "id": "ecc-perl-security",
   "name": "Perl Security",
   "trigger": "perl security",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/perl-security/SKILL.md"
  },
  {
   "id": "ecc-perl-testing",
   "name": "Perl Testing",
   "trigger": "perl testing",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/perl-testing/SKILL.md"
  },
  {
   "id": "ecc-plan-canvas",
   "name": "Plan Canvas",
   "trigger": "plan canvas",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/plan-canvas/SKILL.md"
  },
  {
   "id": "ecc-plan-orchestrate",
   "name": "Plan Orchestrate",
   "trigger": "plan orchestrate",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/plan-orchestrate/SKILL.md"
  },
  {
   "id": "ecc-plankton-code-quality",
   "name": "Plankton Code Quality",
   "trigger": "plankton code quality",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/plankton-code-quality/SKILL.md"
  },
  {
   "id": "ecc-postgres-patterns",
   "name": "Postgres Patterns",
   "trigger": "postgres patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/postgres-patterns/SKILL.md"
  },
  {
   "id": "ecc-prediction-market-oracle-research",
   "name": "Prediction Market Oracle Research",
   "trigger": "prediction market oracle research",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/prediction-market-oracle-research/SKILL.md"
  },
  {
   "id": "ecc-prediction-market-risk-review",
   "name": "Prediction Market Risk Review",
   "trigger": "prediction market risk review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/prediction-market-risk-review/SKILL.md"
  },
  {
   "id": "ecc-prisma-patterns",
   "name": "Prisma Patterns",
   "trigger": "prisma patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/prisma-patterns/SKILL.md"
  },
  {
   "id": "ecc-product-capability",
   "name": "Product Capability",
   "trigger": "product capability",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/product-capability/SKILL.md"
  },
  {
   "id": "ecc-product-lens",
   "name": "Product Lens",
   "trigger": "product lens",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/product-lens/SKILL.md"
  },
  {
   "id": "ecc-production-audit",
   "name": "Production Audit",
   "trigger": "production audit",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/production-audit/SKILL.md"
  },
  {
   "id": "ecc-production-scheduling",
   "name": "Production Scheduling",
   "trigger": "production scheduling",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/production-scheduling/SKILL.md"
  },
  {
   "id": "ecc-project-flow-ops",
   "name": "Project Flow Ops",
   "trigger": "project flow ops",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/project-flow-ops/SKILL.md"
  },
  {
   "id": "ecc-prompt-caching-strategy",
   "name": "Prompt Caching Strategy",
   "trigger": "prompt caching strategy",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/prompt-caching-strategy/SKILL.md"
  },
  {
   "id": "ecc-prompt-optimizer",
   "name": "Prompt Optimizer",
   "trigger": "prompt optimizer",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/prompt-optimizer/SKILL.md"
  },
  {
   "id": "ecc-python-patterns",
   "name": "Python Patterns",
   "trigger": "python patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/python-patterns/SKILL.md"
  },
  {
   "id": "ecc-python-testing",
   "name": "Python Testing",
   "trigger": "python testing",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/python-testing/SKILL.md"
  },
  {
   "id": "ecc-pytorch-patterns",
   "name": "Pytorch Patterns",
   "trigger": "pytorch patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/pytorch-patterns/SKILL.md"
  },
  {
   "id": "ecc-quality-nonconformance",
   "name": "Quality Nonconformance",
   "trigger": "quality nonconformance",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/quality-nonconformance/SKILL.md"
  },
  {
   "id": "ecc-quarkus-patterns",
   "name": "Quarkus Patterns",
   "trigger": "quarkus patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/quarkus-patterns/SKILL.md"
  },
  {
   "id": "ecc-quarkus-security",
   "name": "Quarkus Security",
   "trigger": "quarkus security",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/quarkus-security/SKILL.md"
  },
  {
   "id": "ecc-quarkus-tdd",
   "name": "Quarkus Tdd",
   "trigger": "quarkus tdd",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/quarkus-tdd/SKILL.md"
  },
  {
   "id": "ecc-quarkus-verification",
   "name": "Quarkus Verification",
   "trigger": "quarkus verification",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/quarkus-verification/SKILL.md"
  },
  {
   "id": "ecc-rails-patterns",
   "name": "Rails Patterns",
   "trigger": "rails patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/rails-patterns/SKILL.md"
  },
  {
   "id": "ecc-ralphinho-rfc-pipeline",
   "name": "Ralphinho Rfc Pipeline",
   "trigger": "ralphinho rfc pipeline",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/ralphinho-rfc-pipeline/SKILL.md"
  },
  {
   "id": "ecc-react-native-patterns",
   "name": "React Native Patterns",
   "trigger": "react native patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/react-native-patterns/SKILL.md"
  },
  {
   "id": "ecc-react-patterns",
   "name": "React Patterns",
   "trigger": "react patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/react-patterns/SKILL.md"
  },
  {
   "id": "ecc-react-performance",
   "name": "React Performance",
   "trigger": "react performance",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/react-performance/SKILL.md"
  },
  {
   "id": "ecc-react-testing",
   "name": "React Testing",
   "trigger": "react testing",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/react-testing/SKILL.md"
  },
  {
   "id": "ecc-recsys-pipeline-architect",
   "name": "Recsys Pipeline Architect",
   "trigger": "recsys pipeline architect",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/recsys-pipeline-architect/SKILL.md"
  },
  {
   "id": "ecc-recursive-decision-ledger",
   "name": "Recursive Decision Ledger",
   "trigger": "recursive decision ledger",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/recursive-decision-ledger/SKILL.md"
  },
  {
   "id": "ecc-redis-patterns",
   "name": "Redis Patterns",
   "trigger": "redis patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/redis-patterns/SKILL.md"
  },
  {
   "id": "ecc-regex-vs-llm-structured-text",
   "name": "Regex Vs Llm Structured Text",
   "trigger": "regex vs llm structured text",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/regex-vs-llm-structured-text/SKILL.md"
  },
  {
   "id": "ecc-remotion-video-creation",
   "name": "Remotion Video Creation",
   "trigger": "remotion video creation",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/remotion-video-creation/SKILL.md"
  },
  {
   "id": "ecc-repo-scan",
   "name": "Repo Scan",
   "trigger": "repo scan",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/repo-scan/SKILL.md"
  },
  {
   "id": "ecc-research-ops",
   "name": "Research Ops",
   "trigger": "research ops",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/research-ops/SKILL.md"
  },
  {
   "id": "ecc-returns-reverse-logistics",
   "name": "Returns Reverse Logistics",
   "trigger": "returns reverse logistics",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/returns-reverse-logistics/SKILL.md"
  },
  {
   "id": "ecc-rules-distill",
   "name": "Rules Distill",
   "trigger": "rules distill",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/rules-distill/SKILL.md"
  },
  {
   "id": "ecc-rust-patterns",
   "name": "Rust Patterns",
   "trigger": "rust patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/rust-patterns/SKILL.md"
  },
  {
   "id": "ecc-rust-testing",
   "name": "Rust Testing",
   "trigger": "rust testing",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/rust-testing/SKILL.md"
  },
  {
   "id": "ecc-safety-guard",
   "name": "Safety Guard",
   "trigger": "safety guard",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/safety-guard/SKILL.md"
  },
  {
   "id": "ecc-santa-method",
   "name": "Santa Method",
   "trigger": "santa method",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/santa-method/SKILL.md"
  },
  {
   "id": "ecc-scientific-db-pubmed-database",
   "name": "Scientific Db Pubmed Database",
   "trigger": "scientific db pubmed database",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/scientific-db-pubmed-database/SKILL.md"
  },
  {
   "id": "ecc-scientific-db-uspto-database",
   "name": "Scientific Db Uspto Database",
   "trigger": "scientific db uspto database",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/scientific-db-uspto-database/SKILL.md"
  },
  {
   "id": "ecc-scientific-pkg-gget",
   "name": "Scientific Pkg Gget",
   "trigger": "scientific pkg gget",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/scientific-pkg-gget/SKILL.md"
  },
  {
   "id": "ecc-scientific-thinking-literature-review",
   "name": "Scientific Thinking Literature Review",
   "trigger": "scientific thinking literature review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/scientific-thinking-literature-review/SKILL.md"
  },
  {
   "id": "ecc-scientific-thinking-scholar-evaluation",
   "name": "Scientific Thinking Scholar Evaluation",
   "trigger": "scientific thinking scholar evaluation",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/scientific-thinking-scholar-evaluation/SKILL.md"
  },
  {
   "id": "ecc-search-first",
   "name": "Search First",
   "trigger": "search first",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/search-first/SKILL.md"
  },
  {
   "id": "ecc-security-bounty-hunter",
   "name": "Security Bounty Hunter",
   "trigger": "security bounty hunter",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/security-bounty-hunter/SKILL.md"
  },
  {
   "id": "ecc-security-review",
   "name": "Security Review",
   "trigger": "security review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/security-review/SKILL.md"
  },
  {
   "id": "ecc-security-scan",
   "name": "Security Scan",
   "trigger": "security scan",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/security-scan/SKILL.md"
  },
  {
   "id": "ecc-seo",
   "name": "Seo",
   "trigger": "seo",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/seo/SKILL.md"
  },
  {
   "id": "ecc-skill-comply",
   "name": "Skill Comply",
   "trigger": "skill comply",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/skill-comply/SKILL.md"
  },
  {
   "id": "ecc-skill-host-compat",
   "name": "Skill Host Compat",
   "trigger": "skill host compat",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/skill-host-compat/SKILL.md"
  },
  {
   "id": "ecc-skill-scout",
   "name": "Skill Scout",
   "trigger": "skill scout",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/skill-scout/SKILL.md"
  },
  {
   "id": "ecc-skill-stocktake",
   "name": "Skill Stocktake",
   "trigger": "skill stocktake",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/skill-stocktake/SKILL.md"
  },
  {
   "id": "ecc-social-graph-ranker",
   "name": "Social Graph Ranker",
   "trigger": "social graph ranker",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/social-graph-ranker/SKILL.md"
  },
  {
   "id": "ecc-social-publisher",
   "name": "Social Publisher",
   "trigger": "social publisher",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/social-publisher/SKILL.md"
  },
  {
   "id": "ecc-springboot-patterns",
   "name": "Springboot Patterns",
   "trigger": "springboot patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/springboot-patterns/SKILL.md"
  },
  {
   "id": "ecc-springboot-security",
   "name": "Springboot Security",
   "trigger": "springboot security",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/springboot-security/SKILL.md"
  },
  {
   "id": "ecc-springboot-tdd",
   "name": "Springboot Tdd",
   "trigger": "springboot tdd",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/springboot-tdd/SKILL.md"
  },
  {
   "id": "ecc-springboot-verification",
   "name": "Springboot Verification",
   "trigger": "springboot verification",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/springboot-verification/SKILL.md"
  },
  {
   "id": "ecc-story-lifecycle",
   "name": "Story Lifecycle",
   "trigger": "story lifecycle",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/story-lifecycle/SKILL.md"
  },
  {
   "id": "ecc-strategic-compact",
   "name": "Strategic Compact",
   "trigger": "strategic compact",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/strategic-compact/SKILL.md"
  },
  {
   "id": "ecc-swift-actor-persistence",
   "name": "Swift Actor Persistence",
   "trigger": "swift actor persistence",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/swift-actor-persistence/SKILL.md"
  },
  {
   "id": "ecc-swift-concurrency-6-2",
   "name": "Swift Concurrency 6 2",
   "trigger": "swift concurrency 6 2",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/swift-concurrency-6-2/SKILL.md"
  },
  {
   "id": "ecc-swift-protocol-di-testing",
   "name": "Swift Protocol Di Testing",
   "trigger": "swift protocol di testing",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/swift-protocol-di-testing/SKILL.md"
  },
  {
   "id": "ecc-swiftui-patterns",
   "name": "Swiftui Patterns",
   "trigger": "swiftui patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/swiftui-patterns/SKILL.md"
  },
  {
   "id": "ecc-taste",
   "name": "Taste",
   "trigger": "taste",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/taste/SKILL.md"
  },
  {
   "id": "ecc-taste-application",
   "name": "Taste Application",
   "trigger": "taste application",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/taste-application/SKILL.md"
  },
  {
   "id": "ecc-taste-distillation",
   "name": "Taste Distillation",
   "trigger": "taste distillation",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/taste-distillation/SKILL.md"
  },
  {
   "id": "ecc-tasteforge-video",
   "name": "Tasteforge Video",
   "trigger": "tasteforge video",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/tasteforge-video/SKILL.md"
  },
  {
   "id": "ecc-tdd-workflow",
   "name": "Tdd Workflow",
   "trigger": "tdd workflow",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/tdd-workflow/SKILL.md"
  },
  {
   "id": "ecc-team-agent-orchestration",
   "name": "Team Agent Orchestration",
   "trigger": "team agent orchestration",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/team-agent-orchestration/SKILL.md"
  },
  {
   "id": "ecc-team-builder",
   "name": "Team Builder",
   "trigger": "team builder",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/team-builder/SKILL.md"
  },
  {
   "id": "ecc-terminal-opener",
   "name": "Terminal Opener",
   "trigger": "terminal opener",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/terminal-opener/SKILL.md"
  },
  {
   "id": "ecc-terminal-ops",
   "name": "Terminal Ops",
   "trigger": "terminal ops",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/terminal-ops/SKILL.md"
  },
  {
   "id": "ecc-test-collaboration",
   "name": "Test Collaboration",
   "trigger": "test collaboration",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/test-collaboration/SKILL.md"
  },
  {
   "id": "ecc-tinystruct-patterns",
   "name": "Tinystruct Patterns",
   "trigger": "tinystruct patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/tinystruct-patterns/SKILL.md"
  },
  {
   "id": "ecc-token-budget-advisor",
   "name": "Token Budget Advisor",
   "trigger": "token budget advisor",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/token-budget-advisor/SKILL.md"
  },
  {
   "id": "ecc-token-card",
   "name": "Token Card",
   "trigger": "token card",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/token-card/SKILL.md"
  },
  {
   "id": "ecc-typescript-patterns",
   "name": "Typescript Patterns",
   "trigger": "typescript patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/typescript-patterns/SKILL.md"
  },
  {
   "id": "ecc-ui-demo",
   "name": "Ui Demo",
   "trigger": "ui demo",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/ui-demo/SKILL.md"
  },
  {
   "id": "ecc-ui-to-vue",
   "name": "Ui To Vue",
   "trigger": "ui to vue",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/ui-to-vue/SKILL.md"
  },
  {
   "id": "ecc-uncloud",
   "name": "Uncloud",
   "trigger": "uncloud",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/uncloud/SKILL.md"
  },
  {
   "id": "ecc-unified-memory",
   "name": "Unified Memory",
   "trigger": "unified memory",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/unified-memory/SKILL.md"
  },
  {
   "id": "ecc-unified-notifications-ops",
   "name": "Unified Notifications Ops",
   "trigger": "unified notifications ops",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/unified-notifications-ops/SKILL.md"
  },
  {
   "id": "ecc-verification-loop",
   "name": "Verification Loop",
   "trigger": "verification loop",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/verification-loop/SKILL.md"
  },
  {
   "id": "ecc-video-editing",
   "name": "Video Editing",
   "trigger": "video editing",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/video-editing/SKILL.md"
  },
  {
   "id": "ecc-videodb",
   "name": "Videodb",
   "trigger": "videodb",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/videodb/SKILL.md"
  },
  {
   "id": "ecc-visa-doc-translate",
   "name": "Visa Doc Translate",
   "trigger": "visa doc translate",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/visa-doc-translate/SKILL.md"
  },
  {
   "id": "ecc-vite-patterns",
   "name": "Vite Patterns",
   "trigger": "vite patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/vite-patterns/SKILL.md"
  },
  {
   "id": "ecc-vue-patterns",
   "name": "Vue Patterns",
   "trigger": "vue patterns",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/vue-patterns/SKILL.md"
  },
  {
   "id": "ecc-windows-desktop-e2e",
   "name": "Windows Desktop E2E",
   "trigger": "windows desktop e2e",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/windows-desktop-e2e/SKILL.md"
  },
  {
   "id": "ecc-workspace-surface-audit",
   "name": "Workspace Surface Audit",
   "trigger": "workspace surface audit",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/workspace-surface-audit/SKILL.md"
  },
  {
   "id": "ecc-x-api",
   "name": "X Api",
   "trigger": "x api",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/skills/x-api/SKILL.md"
  }
 ],
 "helpers": [
  {
   "cmd": "/aside",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/aside.md"
  },
  {
   "cmd": "/astra-review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/astra-review.md"
  },
  {
   "cmd": "/auto-update",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/auto-update.md"
  },
  {
   "cmd": "/build-fix",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/build-fix.md"
  },
  {
   "cmd": "/checkpoint",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/checkpoint.md"
  },
  {
   "cmd": "/code-review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/code-review.md"
  },
  {
   "cmd": "/cost-report",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/cost-report.md"
  },
  {
   "cmd": "/cpp-build",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/cpp-build.md"
  },
  {
   "cmd": "/cpp-review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/cpp-review.md"
  },
  {
   "cmd": "/cpp-test",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/cpp-test.md"
  },
  {
   "cmd": "/ecc-guide",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/ecc-guide.md"
  },
  {
   "cmd": "/epic-claim",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/epic-claim.md"
  },
  {
   "cmd": "/epic-decompose",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/epic-decompose.md"
  },
  {
   "cmd": "/epic-publish",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/epic-publish.md"
  },
  {
   "cmd": "/epic-review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/epic-review.md"
  },
  {
   "cmd": "/epic-sync",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/epic-sync.md"
  },
  {
   "cmd": "/epic-unblock",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/epic-unblock.md"
  },
  {
   "cmd": "/epic-validate",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/epic-validate.md"
  },
  {
   "cmd": "/evolve",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/evolve.md"
  },
  {
   "cmd": "/fastapi-review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/fastapi-review.md"
  },
  {
   "cmd": "/feature-dev",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/feature-dev.md"
  },
  {
   "cmd": "/flutter-build",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/flutter-build.md"
  },
  {
   "cmd": "/flutter-review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/flutter-review.md"
  },
  {
   "cmd": "/flutter-test",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/flutter-test.md"
  },
  {
   "cmd": "/gan-build",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/gan-build.md"
  },
  {
   "cmd": "/gan-design",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/gan-design.md"
  },
  {
   "cmd": "/go-build",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/go-build.md"
  },
  {
   "cmd": "/go-review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/go-review.md"
  },
  {
   "cmd": "/go-test",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/go-test.md"
  },
  {
   "cmd": "/gradle-build",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/gradle-build.md"
  },
  {
   "cmd": "/harness-audit",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/harness-audit.md"
  },
  {
   "cmd": "/hookify",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/hookify.md"
  },
  {
   "cmd": "/hookify-configure",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/hookify-configure.md"
  },
  {
   "cmd": "/hookify-help",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/hookify-help.md"
  },
  {
   "cmd": "/hookify-list",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/hookify-list.md"
  },
  {
   "cmd": "/instinct-export",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/instinct-export.md"
  },
  {
   "cmd": "/instinct-import",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/instinct-import.md"
  },
  {
   "cmd": "/instinct-status",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/instinct-status.md"
  },
  {
   "cmd": "/issue-review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/issue-review.md"
  },
  {
   "cmd": "/jira",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/jira.md"
  },
  {
   "cmd": "/kotlin-build",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/kotlin-build.md"
  },
  {
   "cmd": "/kotlin-review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/kotlin-review.md"
  },
  {
   "cmd": "/kotlin-test",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/kotlin-test.md"
  },
  {
   "cmd": "/learn",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/learn.md"
  },
  {
   "cmd": "/learn-eval",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/learn-eval.md"
  },
  {
   "cmd": "/loop-start",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/loop-start.md"
  },
  {
   "cmd": "/loop-status",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/loop-status.md"
  },
  {
   "cmd": "/marketing-campaign",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/marketing-campaign.md"
  },
  {
   "cmd": "/model-route",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/model-route.md"
  },
  {
   "cmd": "/multi-backend",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/multi-backend.md"
  },
  {
   "cmd": "/multi-execute",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/multi-execute.md"
  },
  {
   "cmd": "/multi-frontend",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/multi-frontend.md"
  },
  {
   "cmd": "/multi-plan",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/multi-plan.md"
  },
  {
   "cmd": "/multi-workflow",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/multi-workflow.md"
  },
  {
   "cmd": "/orch-add-feature",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/orch-add-feature.md"
  },
  {
   "cmd": "/orch-build-mvp",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/orch-build-mvp.md"
  },
  {
   "cmd": "/orch-change-feature",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/orch-change-feature.md"
  },
  {
   "cmd": "/orch-fix-defect",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/orch-fix-defect.md"
  },
  {
   "cmd": "/orch-refine-code",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/orch-refine-code.md"
  },
  {
   "cmd": "/orch-review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/orch-review.md"
  },
  {
   "cmd": "/plan",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/plan.md"
  },
  {
   "cmd": "/plan-canvas",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/plan-canvas.md"
  },
  {
   "cmd": "/plan-prd",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/plan-prd.md"
  },
  {
   "cmd": "/pm2",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/pm2.md"
  },
  {
   "cmd": "/pr",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/pr.md"
  },
  {
   "cmd": "/project-init",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/project-init.md"
  },
  {
   "cmd": "/projects",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/projects.md"
  },
  {
   "cmd": "/promote",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/promote.md"
  },
  {
   "cmd": "/prp-commit",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/prp-commit.md"
  },
  {
   "cmd": "/prp-implement",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/prp-implement.md"
  },
  {
   "cmd": "/prp-plan",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/prp-plan.md"
  },
  {
   "cmd": "/prp-pr",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/prp-pr.md"
  },
  {
   "cmd": "/prp-prd",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/prp-prd.md"
  },
  {
   "cmd": "/prune",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/prune.md"
  },
  {
   "cmd": "/python-review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/python-review.md"
  },
  {
   "cmd": "/quality-gate",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/quality-gate.md"
  },
  {
   "cmd": "/react-build",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/react-build.md"
  },
  {
   "cmd": "/react-review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/react-review.md"
  },
  {
   "cmd": "/react-test",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/react-test.md"
  },
  {
   "cmd": "/refactor-clean",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/refactor-clean.md"
  },
  {
   "cmd": "/resume-session",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/resume-session.md"
  },
  {
   "cmd": "/review-pr",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/review-pr.md"
  },
  {
   "cmd": "/rust-build",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/rust-build.md"
  },
  {
   "cmd": "/rust-review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/rust-review.md"
  },
  {
   "cmd": "/rust-test",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/rust-test.md"
  },
  {
   "cmd": "/santa-loop",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/santa-loop.md"
  },
  {
   "cmd": "/save-session",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/save-session.md"
  },
  {
   "cmd": "/security-scan",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/security-scan.md"
  },
  {
   "cmd": "/sessions",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/sessions.md"
  },
  {
   "cmd": "/setup-pm",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/setup-pm.md"
  },
  {
   "cmd": "/skill-create",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/skill-create.md"
  },
  {
   "cmd": "/skill-health",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/skill-health.md"
  },
  {
   "cmd": "/skill-host-compat",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/skill-host-compat.md"
  },
  {
   "cmd": "/test-coverage",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/test-coverage.md"
  },
  {
   "cmd": "/token-card",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/token-card.md"
  },
  {
   "cmd": "/update-codemaps",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/update-codemaps.md"
  },
  {
   "cmd": "/update-docs",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/update-docs.md"
  },
  {
   "cmd": "/vue-review",
   "src": "https://github.com/affaan-m/everything-claude-code/blob/main/commands/vue-review.md"
  }
 ]
};
(function(){var O=window.OMNI||(window.OMNI={});O.agents=(O.agents||[]).concat(OMNI_ECC.agents);O.skills=(O.skills||[]).concat(OMNI_ECC.skills);O.helpers=(O.helpers||[]).concat(OMNI_ECC.helpers);})();
