/* 369 OMNI Premium layer: 3D diamond (three.js), themes, Prompt Vault, favorites,
   command palette (Ctrl+K), chat export, code blocks with copy. Runs after the base app. */
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const gs = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : v; } catch (e) { return d; } };
  const ss = (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} };
  const jg = (k, d) => { try { return JSON.parse(gs(k, '')) || d; } catch (e) { return d; } };
  const E = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  const THEMES = {
    gold:    { name: 'Royal Gold',  sw: 'linear-gradient(135deg,#fff6d0,#d4af37,#8a6d1f)', metal: 0xd4af37, gem: 0xf2fbff, inner: 0xbfe6ff, spark: '#fff1b8' },
    diamond: { name: 'Diamond Ice', sw: 'linear-gradient(135deg,#fff,#7fd4ff,#3b86b0)',   metal: 0xdde6ee, gem: 0xe9f9ff, inner: 0x8fd8ff, spark: '#d8f4ff' },
    rose:    { name: 'Rose Gold',   sw: 'linear-gradient(135deg,#fff0ea,#e8a08e,#a8604f)', metal: 0xe6a08f, gem: 0xfff3f6, inner: 0xffc4d6, spark: '#ffe0d6' }
  };
  const FX = { full: 'Full 3D', lite: 'Lite', off: 'Off' };
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  let theme = gs('omni_theme', 'gold'); if (!THEMES[theme]) theme = 'gold';
  let fx = gs('omni_fx', reduce ? 'lite' : 'full'); if (!FX[fx]) fx = 'full';

  /* ---------- toast + clipboard + download ---------- */
  function toast(t) { const d = document.createElement('div'); d.className = 'toast'; d.textContent = t; document.body.appendChild(d); setTimeout(() => d.remove(), 1600); }
  function copy(t) { (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).catch(() => { const a = document.createElement('textarea'); a.value = t; document.body.appendChild(a); a.select(); try { document.execCommand('copy'); } catch (e) {} a.remove(); }); toast('Copied'); }
  function download(name, text) { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'text/markdown' })); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 800); }
  const toMd = () => '# 369 OMNI chat\n_' + new Date().toLocaleString() + '_\n\n' + H.map(m => '## ' + (m.role === 'user' ? 'You' : 'OMNI') + '\n\n' + m.content + '\n').join('\n');
  const go = p => { const b = document.querySelector('nav button[data-p=' + p + ']'); if (b) b.click(); };

  /* ---------- 3D diamond ---------- */
  const gems = [];
  let glOK = !!window.THREE;

  function buildEnv(renderer) {
    const T = THREE, sc = new T.Scene();
    const c = document.createElement('canvas'); c.width = 4; c.height = 256; const x = c.getContext('2d');
    const g = x.createLinearGradient(0, 0, 0, 256); g.addColorStop(0, '#2a3a4e'); g.addColorStop(.45, '#07080b'); g.addColorStop(.7, '#120d05'); g.addColorStop(1, '#3a2a0c');
    x.fillStyle = g; x.fillRect(0, 0, 4, 256);
    const dome = new T.Mesh(new T.SphereGeometry(20, 32, 16), new T.MeshBasicMaterial({ map: new T.CanvasTexture(c), side: T.BackSide })); sc.add(dome);
    const panel = (w, h, col, pos) => { const m = new T.Mesh(new T.PlaneGeometry(w, h), new T.MeshBasicMaterial({ color: new T.Color(col[0], col[1], col[2]), side: T.DoubleSide })); m.position.set(pos[0], pos[1], pos[2]); m.lookAt(0, 0, 0); sc.add(m); };
    panel(14, 5, [9, 9, 9], [0, 14, 0]);
    panel(2.5, 14, [8, 8, 9], [14, 2, 4]); panel(2.5, 14, [7, 7.5, 9], [-14, 2, -4]);
    panel(5, 5, [9, 6, 2], [9, 5, -12]); panel(5, 5, [2, 5, 9], [-9, 4, 12]);
    panel(3, 3, [1, 3, 12], [10, -2, 8]); panel(3, 3, [12, 2, 7], [-10, 0, 9]); panel(3, 3, [12, 7, 1], [2, 8, -13]); panel(3, 6, [2, 10, 8], [-12, 3, -8]);
    panel(10, 2.5, [6, 6, 6], [0, -6, 14]); panel(3, 9, [8, 7, 4], [4, 0, -15]); panel(3, 9, [4, 6, 8], [-4, 0, 15]);
    const pm = new T.PMREMGenerator(renderer); const rt = pm.fromScene(sc, 0.03); pm.dispose(); return rt.texture;
  }
  function starTex(col) {
    const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d');
    const r = x.createRadialGradient(64, 64, 0, 64, 64, 64); r.addColorStop(0, '#fff'); r.addColorStop(.18, col); r.addColorStop(1, 'rgba(0,0,0,0)');
    x.fillStyle = r; x.fillRect(0, 0, 128, 128);
    x.globalCompositeOperation = 'lighter'; x.fillStyle = col;
    x.beginPath(); x.moveTo(64, 2); x.lineTo(70, 58); x.lineTo(126, 64); x.lineTo(70, 70); x.lineTo(64, 126); x.lineTo(58, 70); x.lineTo(2, 64); x.lineTo(58, 58); x.closePath(); x.fill();
    return new THREE.CanvasTexture(c);
  }

  function makeGem(canvas, o) {
    if (!glOK) return null;
    const T = THREE; let R;
    try { R = new T.WebGLRenderer({ canvas, antialias: true, alpha: true }); } catch (e) { glOK = false; return null; }
    R.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    R.outputEncoding = T.sRGBEncoding; R.toneMapping = T.ACESFilmicToneMapping; R.toneMappingExposure = 1.3;
    const scene = new T.Scene(), cam = new T.PerspectiveCamera(30, 1, .1, 60); cam.position.set(0, .35, o.dist || 8);
    cam.lookAt(0, -.35, 0);
    scene.environment = buildEnv(R);
    const group = new T.Group(); scene.add(group);

    // brilliant-cut profile (radius, y), lathe = facets
    const prof = [[0, -1.05], [.5, -.5], [1, 0], [1, .07], [.83, .24], [.6, .46], [0, .46]].map(p => new T.Vector2(p[0], p[1]));
    const outerGeo = new T.LatheGeometry(prof, 12);
    const outerMat = new T.MeshPhysicalMaterial({ color: 0xf2fbff, metalness: .2, roughness: .02, clearcoat: 1, clearcoatRoughness: 0, envMapIntensity: 2.4, flatShading: true, transparent: true, opacity: .42, depthWrite: false });
    const innerMat = new T.MeshStandardMaterial({ color: 0xbfe6ff, metalness: 1, roughness: .04, envMapIntensity: 3.2, flatShading: true });
    const inner = new T.Mesh(new T.LatheGeometry(prof, 12), innerMat); inner.scale.set(.8, .8, .8); inner.rotation.y = Math.PI / 12;
    const outer = new T.Mesh(outerGeo, outerMat);
    const top = new T.Mesh(new T.CircleGeometry(.6, 12).rotateX(-Math.PI / 2).translate(0, .462, 0), new T.MeshStandardMaterial({ color: 0xffffff, metalness: 1, roughness: .02, envMapIntensity: 3, flatShading: true }));
    group.add(inner, outer, top);

    // gold setting: cup + girdle ring + 6 claws
    const goldMat = new T.MeshStandardMaterial({ color: 0xd4af37, metalness: 1, roughness: .2, envMapIntensity: 1.6, side: T.DoubleSide });
    const ring = new T.Mesh(new T.TorusGeometry(1.04, .055, 20, 72), goldMat); ring.rotation.x = Math.PI / 2; ring.position.y = .035;
    group.add(ring);
    for (let i = 0; i < 6; i++) {
      const a = i / 6 * Math.PI * 2, claw = new T.Mesh(new T.CapsuleGeometry(.06, .36, 6, 12), goldMat);
      claw.position.set(Math.cos(a) * .94, .22, Math.sin(a) * .94); claw.rotation.set(Math.sin(a) * .55, 0, -Math.cos(a) * .55); group.add(claw);
    }
    // pedestal under the culet
    const stem = new T.Mesh(new T.CylinderGeometry(.045, .07, .75, 20), goldMat); stem.position.y = -1.42; group.add(stem);
    const disc = new T.Mesh(new T.CylinderGeometry(.95, 1.1, .1, 48), goldMat); disc.position.y = -1.84; group.add(disc);
    const disc2 = new T.Mesh(new T.TorusGeometry(.98, .035, 12, 64), goldMat); disc2.rotation.x = Math.PI / 2; disc2.position.y = -1.79; group.add(disc2);

    // glints
    const glints = [], tex = starTex('#fff3c0');
    for (let i = 0; i < 7; i++) {
      const s = new T.Sprite(new T.SpriteMaterial({ map: tex, blending: T.AdditiveBlending, transparent: true, depthWrite: false }));
      const a = Math.random() * 6.28, r = .25 + Math.random() * .7; s.position.set(Math.cos(a) * r, .2 + Math.random() * .3, Math.sin(a) * r);
      s.userData = { ph: Math.random() * 10, sp: .8 + Math.random() * 1.4 }; group.add(s); glints.push(s);
    }
    // floating dust
    let dust = null;
    if (o.dust) {
      const n = 140, pos = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) { const a = Math.random() * 6.28, b = Math.acos(2 * Math.random() - 1), r = 2 + Math.random() * 1.8; pos[i * 3] = r * Math.sin(b) * Math.cos(a); pos[i * 3 + 1] = r * Math.cos(b) * .8; pos[i * 3 + 2] = r * Math.sin(b) * Math.sin(a); }
      const geo = new T.BufferGeometry(); geo.setAttribute('position', new T.BufferAttribute(pos, 3));
      dust = new T.Points(geo, new T.PointsMaterial({ map: starTex('#ffe9a0'), size: .16, transparent: true, blending: T.AdditiveBlending, depthWrite: false, opacity: .9 })); scene.add(dust);
    }
    const pl = new T.PointLight(0xffe2a0, 2.2, 14); scene.add(pl);

    const G = { canvas, dirty: true, last: 0, ry: .6, rx: 0, spin: .008, drag: false, px: .5, py: .5, o };
    G.setTheme = n => { const t = THEMES[n]; goldMat.color.setHex(t.metal); outerMat.color.setHex(t.gem); innerMat.color.setHex(t.inner); G.dirty = true; };
    G.visible = () => canvas.offsetParent !== null && canvas.clientWidth > 0;
    G.size = () => { const w = canvas.clientWidth, h = canvas.clientHeight || w; if (!w) return; R.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); G.dirty = true; };
    G.frame = (t, mode) => {
      if (mode === 'off') { if (!G.dirty) return; }
      else { if (!G.drag) G.spin += (.008 - G.spin) * .03; G.ry += G.spin; }
      const tx = o.follow ? (G.py - .5) * .5 : .12; G.rx += (tx - G.rx) * .08;
      group.rotation.set(G.rx, G.ry, 0);
      if (mode !== 'off') group.position.y = Math.sin(t * 1.3) * .04;
      pl.position.set(Math.cos(t * .8) * 3.2, 1.6, Math.sin(t * .8) * 3.2);
      glints.forEach(s => { const k = Math.pow(Math.max(0, Math.sin(t * s.userData.sp + s.userData.ph)), 8); const z = mode === 'off' ? .0001 : k * (o.big ? .55 : .5); s.scale.set(z, z, 1); s.material.opacity = k; });
      if (dust) { dust.visible = mode === 'full'; dust.rotation.y = t * .06; }
      R.render(scene, cam); G.dirty = false;
    };
    if (o.interact) {
      canvas.addEventListener('pointerdown', e => { G.drag = true; G.lx = e.clientX; canvas.setPointerCapture(e.pointerId); });
      canvas.addEventListener('pointermove', e => { const r = canvas.getBoundingClientRect(); G.px = (e.clientX - r.left) / r.width; G.py = (e.clientY - r.top) / r.height; if (G.drag) { const dx = e.clientX - G.lx; G.lx = e.clientX; G.ry += dx * .012; G.spin = dx * .004; G.dirty = true; } });
      const up = () => { G.drag = false; }; canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up);
      canvas.addEventListener('pointerleave', () => { G.py = .5; });
    }
    if (window.ResizeObserver) new ResizeObserver(G.size).observe(canvas); else G.size();
    G.setTheme(theme); G.size(); gems.push(G); return G;
  }
  /* real-time 24kt gold: reflection angle + specular follow the cursor, with a slow idle shimmer */
  const ptr = { x: window.innerWidth * .3, y: 0 }; let goldAt = 0;
  document.addEventListener('pointermove', e => { ptr.x = e.clientX; ptr.y = e.clientY; });
  function goldLight(t) {
    document.querySelectorAll('.vp,.gemwrap').forEach(el => {
      if (!el.offsetParent) return; const r = el.getBoundingClientRect(); if (!r.width) return;
      const lx = (ptr.x - r.left) / r.width * 100, ly = (ptr.y - r.top) / r.height * 100;
      const a = Math.atan2(ptr.y - (r.top + r.height / 2), ptr.x - (r.left + r.width / 2)) * 180 / Math.PI + 90 + Math.sin(t * .5) * 16;
      el.style.setProperty('--lx', Math.max(-30, Math.min(130, lx)).toFixed(1) + '%'); el.style.setProperty('--ly', Math.max(-30, Math.min(130, ly)).toFixed(1) + '%'); el.style.setProperty('--a', a.toFixed(1) + 'deg');
    });
  }
  function loop(ms) {
    requestAnimationFrame(loop);
    if (document.hidden) return;
    if (fx !== 'off' && ms - goldAt > (fx === 'lite' ? 60 : 16)) { goldAt = ms; goldLight(ms / 1000); }
    for (const g of gems) { if (!g.visible()) continue; if (fx === 'lite' && ms - g.last < 40) continue; g.last = ms; g.frame(ms / 1000, fx); }
  }

  /* ---------- theme + effects ---------- */
  function applyTheme(n) { theme = n; ss('omni_theme', n); document.body.dataset.theme = n; gems.forEach(g => g.setTheme(n)); drawChips(); }
  function applyFx(n) { fx = n; ss('omni_fx', n); document.body.dataset.fx = n; gems.forEach(g => g.dirty = true); drawChips(); }

  /* ---------- header ---------- */
  const hdr = document.querySelector('header'), h1 = hdr.querySelector('h1');
  h1.innerHTML = '<canvas id="gemMini" width="88" height="88"></canvas><span>369 OMNI</span>';
  const nav = hdr.querySelector('nav');
  const badge = document.createElement('span'); badge.className = 'badge'; badge.textContent = '◆ PREMIUM'; hdr.insertBefore(badge, nav.nextSibling);
  const cb = document.createElement('button'); cb.id = 'cmdBtn'; cb.textContent = 'Ctrl+K'; cb.title = 'Command palette'; hdr.appendChild(cb);

  /* ---------- Vault page ---------- */
  const nb = document.createElement('button'); nb.dataset.p = 'vault'; nb.textContent = '◆ Vault'; nav.appendChild(nb);
  const vault = document.createElement('section'); vault.className = 'p'; vault.id = 'vault';
  vault.innerHTML = `
  <div class="hero">
    <div class="gemwrap"><canvas id="gemBig"></canvas><div class="gemfall"><i></i></div><div class="gemcap">DRAG TO SPIN</div></div>
    <div class="vp">
      <h2 class="gold-text">369 PREMIUM VAULT</h2>
      <div class="s">Gold and diamond finish, 3D effects, prompt library, favorites, command palette and exports.</div>
      <div class="lbl">Finish</div><div class="row" id="themes"></div>
      <div class="lbl">3D effects</div><div class="row" id="fxs"></div>
      <div class="lbl">Insights</div><div class="stats" id="stats"></div>
      <div class="lbl">Tools</div>
      <div class="row"><button id="expMd">Export chat (.md)</button><button id="cpChat">Copy chat</button><button id="openCmd">Command palette (Ctrl+K)</button></div>
    </div>
  </div>
  <div class="two">
    <div class="vp"><h3 class="gold-text">PROMPT VAULT</h3>
      <input id="pvT" placeholder="Title"><textarea id="pvB" rows="3" placeholder="Prompt text, saved on this device"></textarea>
      <div class="row"><button id="pvSave">Save prompt</button><button id="pvLast">Save my last message</button></div><div id="pvList"></div></div>
    <div class="vp"><h3 class="gold-text">★ FAVORITES</h3><div class="s">Star any skill or tool. Starred items also appear at the top of Skills.</div><div id="favList"></div></div>
  </div>`;
  document.body.appendChild(vault);

  function drawChips() {
    $('themes').innerHTML = Object.keys(THEMES).map(k => `<button class="chip ${k === theme ? 'on' : ''}" data-theme="${k}"><i style="background:${THEMES[k].sw}"></i>${THEMES[k].name}</button>`).join('');
    $('fxs').innerHTML = Object.keys(FX).map(k => `<button class="${k === fx ? 'on' : ''}" data-fx="${k}">${FX[k]}</button>`).join('');
  }
  vault.addEventListener('click', e => {
    const t = e.target.closest('button'); if (!t) return;
    if (t.dataset.theme) applyTheme(t.dataset.theme);
    if (t.dataset.fx) applyFx(t.dataset.fx);
  });
  /* give the effect buttons the "on" look of nav buttons */
  const st = document.createElement('style'); st.textContent = '#fxs button.on{background:linear-gradient(180deg,var(--g1),var(--g3) 55%,var(--g4));color:#1a1200;font-weight:700}'; document.head.appendChild(st);

  /* stats */
  function stats() {
    const u = H.filter(m => m.role === 'user'), a = H.filter(m => m.role !== 'user');
    const words = H.reduce((n, m) => n + (m.content.trim().split(/\s+/).length || 0), 0);
    const fav = jg('omni_fav', []).length, pv = jg('omni_vault', []).length;
    const cells = [[u.length, 'Your messages'], [a.length, 'Answers'], [words, 'Words'], [Math.round(words * 1.35), 'Est. tokens'], [fav, 'Favorites'], [pv, 'Saved prompts']];
    $('stats').innerHTML = cells.map(c => `<div class="stat"><b>${c[0]}</b><span>${c[1]}</span></div>`).join('');
  }

  /* prompt vault */
  function pvDraw() {
    const L = jg('omni_vault', []);
    $('pvList').innerHTML = L.length ? L.map((p, i) => `<div class="li"><div><b>${E(p.t)}</b><small>${E(p.b)}</small></div><div class="row"><button data-use="${i}">Use</button><button data-cp="${i}">Copy</button><button data-del="${i}">✕</button></div></div>`).join('') : '<div class="s" style="margin-top:8px">Nothing saved yet. Save prompts you reuse.</div>';
  }
  function pvAdd(t, b) { b = (b || '').trim(); if (!b) return toast('Write a prompt first'); const L = jg('omni_vault', []); L.unshift({ t: (t || '').trim() || b.slice(0, 32), b }); ss('omni_vault', JSON.stringify(L.slice(0, 200))); pvDraw(); stats(); toast('Saved to vault'); }
  $('pvSave').onclick = () => { pvAdd($('pvT').value, $('pvB').value); $('pvT').value = ''; $('pvB').value = ''; };
  $('pvLast').onclick = () => { const l = [...H].reverse().find(m => m.role === 'user'); l ? pvAdd('', l.content) : toast('No message yet'); };
  $('pvList').onclick = e => {
    const b = e.target.closest('button'); if (!b) return; const L = jg('omni_vault', []);
    if (b.dataset.use != null) { go('chat'); $('msg').value = L[b.dataset.use].b; $('msg').focus(); }
    if (b.dataset.cp != null) copy(L[b.dataset.cp].b);
    if (b.dataset.del != null) { L.splice(+b.dataset.del, 1); ss('omni_vault', JSON.stringify(L)); pvDraw(); stats(); }
  };

  /* favorites */
  const favs = () => jg('omni_fav', []);
  const byName = n => SKILLS.find(a => a.name === n);
  function favCard(a) { return `<div class="card"><b>${E(a.name)}</b><br>${E(a.desc)}<div class="row"><button onclick="useSkill('${a.id}')">Use in chat</button>${a.url ? `<button onclick="window.open('${a.url}')">Open site</button>` : ''}</div></div>`; }
  function favDraw() {
    const F = favs().map(id => SKILLS.find(a => a.id === id)).filter(Boolean);
    $('favList').innerHTML = F.length ? '<div class="grid">' + F.map(favCard).join('') + '</div>' : '<div class="s" style="margin-top:8px">No favorites yet.</div>';
    let top = $('favs'); if (!top) { top = document.createElement('div'); top.id = 'favs'; $('sk').insertBefore(top, $('sk').firstChild); }
    top.innerHTML = F.length ? '<div class="cat">★ Favorites</div><div class="grid">' + F.map(favCard).join('') + '</div>' : '';
    document.querySelectorAll('#sk .star,#tl .star').forEach(s => { const on = favs().includes(s.dataset.id); s.classList.toggle('on', on); s.textContent = on ? '★' : '☆'; });
  }
  function addStars() {
    document.querySelectorAll('#sk .card, #tl .card').forEach(c => {
      if (c.querySelector('.star') || c.closest('#favs')) return;
      const a = byName((c.querySelector('b') || {}).textContent); if (!a) return;
      const s = document.createElement('button'); s.className = 'star'; s.dataset.id = a.id; s.textContent = '☆'; s.title = 'Favorite'; c.appendChild(s);
    });
  }
  document.addEventListener('click', e => {
    const s = e.target.closest && e.target.closest('.star'); if (!s) return;
    let F = favs(); F = F.includes(s.dataset.id) ? F.filter(x => x !== s.dataset.id) : F.concat(s.dataset.id); ss('omni_fav', JSON.stringify(F)); favDraw(); stats();
  });

  /* ---------- chat: formatting, copy, export ---------- */
  const log = $('log');
  const fmt = h => h
    .replace(/```([\w+-]*)\n?([\s\S]*?)```/g, (m, l, c) => '<pre><button class="cp" data-cpcode="1">Copy</button><code>' + c.replace(/\n$/, '') + '</code></pre>')
    .replace(/`([^`\n]+)`/g, '<code class="ic">$1</code>')
    .replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
  function decorate() {
    log.querySelectorAll('.m.b:not(.s):not([data-fx])').forEach(n => { n.dataset.fx = '1'; n.innerHTML = fmt(n.innerHTML) + '<button class="msgcp" data-msgcp="1">Copy</button>'; });
  }
  new MutationObserver(() => { decorate(); stats(); }).observe(log, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
  log.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.cpcode) copy(b.parentElement.querySelector('code').textContent);
    if (b.dataset.msgcp) { const c = b.parentElement.cloneNode(true); c.querySelectorAll('button').forEach(x => x.remove()); copy(c.textContent.trim()); }
  });
  const crow = document.querySelector('#chat .row');
  const eb = document.createElement('button'); eb.textContent = 'Export .md'; eb.onclick = () => H.length ? (download('369-omni-chat.md', toMd()), toast('Exported')) : toast('Nothing to export');
  crow.appendChild(eb);
  $('expMd').onclick = eb.onclick;
  $('cpChat').onclick = () => H.length ? copy(toMd()) : toast('Nothing to copy');

  /* ---------- 3D tilt on cards ---------- */
  document.addEventListener('pointermove', e => {
    if (fx !== 'full') return; const c = e.target.closest && e.target.closest('.card'); if (!c) return;
    const r = c.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
    c.style.setProperty('--ry', ((x - .5) * 12).toFixed(2) + 'deg'); c.style.setProperty('--rx', ((.5 - y) * 12).toFixed(2) + 'deg');
    c.style.setProperty('--mx', (x * 100).toFixed(1) + '%'); c.style.setProperty('--my', (y * 100).toFixed(1) + '%');
  });
  document.addEventListener('pointerout', e => { const c = e.target.closest && e.target.closest('.card'); if (c && !c.contains(e.relatedTarget)) { c.style.setProperty('--rx', '0deg'); c.style.setProperty('--ry', '0deg'); } });

  /* ---------- command palette ---------- */
  const cmd = document.createElement('div'); cmd.id = 'cmdk';
  cmd.innerHTML = '<div class="box"><input id="cmdIn" placeholder="Type a skill, tab or action…" autocomplete="off"><div id="cmdList"></div></div>'; document.body.appendChild(cmd);
  let cmdSel = 0, cmdRes = [];
  const tabs = [['Chat', 'chat'], ['Skills', 'skills'], ['Tools', 'tools'], ['Data Brain', 'brain'], ['Keys', 'keys'], ['Vault', 'vault']];
  function cmdItems() {
    const a = [];
    tabs.forEach(t => a.push({ t: 'Go to ' + t[0], h: 'tab', k: 'go tab open ' + t[0].toLowerCase(), f: () => go(t[1]) }));
    a.push({ t: 'New chat', h: 'action', k: 'new clear chat reset', f: () => { go('chat'); $('clr').click(); } });
    a.push({ t: 'Export chat as Markdown', h: 'action', k: 'export save download markdown md', f: () => eb.onclick() });
    a.push({ t: 'Copy whole chat', h: 'action', k: 'copy chat', f: () => $('cpChat').onclick() });
    a.push({ t: 'Toggle council mode', h: 'action', k: 'council merge', f: () => { $('council').checked = !$('council').checked; toast('Council ' + ($('council').checked ? 'on' : 'off')); } });
    a.push({ t: 'Toggle speak replies', h: 'action', k: 'speak voice', f: () => { $('speak').checked = !$('speak').checked; toast('Speak ' + ($('speak').checked ? 'on' : 'off')); } });
    Object.keys(THEMES).forEach(k => a.push({ t: 'Finish: ' + THEMES[k].name, h: 'theme', k: 'theme finish color ' + THEMES[k].name.toLowerCase(), f: () => applyTheme(k) }));
    Object.keys(FX).forEach(k => a.push({ t: '3D effects: ' + FX[k], h: 'effects', k: 'effects 3d motion ' + FX[k].toLowerCase(), f: () => applyFx(k) }));
    jg('omni_vault', []).forEach(p => a.push({ t: 'Prompt: ' + p.t, h: 'vault', k: 'prompt vault ' + (p.t + ' ' + p.b).toLowerCase(), f: () => { go('chat'); $('msg').value = p.b; $('msg').focus(); } }));
    SKILLS.forEach(s => a.push({ t: s.name, h: s.cat, k: (s.name + ' ' + s.cat + ' ' + s.desc + ' ' + s.kw).toLowerCase(), f: () => useSkill(s.id), fav: favs().includes(s.id) }));
    return a;
  }
  function cmdDraw() {
    const q = $('cmdIn').value.toLowerCase().split(/\s+/).filter(Boolean), all = cmdItems();
    cmdRes = all.filter(i => q.every(w => (i.t + ' ' + i.k).toLowerCase().includes(w))).sort((x, y) => (y.fav | 0) - (x.fav | 0)).slice(0, 14);
    cmdSel = Math.min(cmdSel, Math.max(0, cmdRes.length - 1));
    $('cmdList').innerHTML = cmdRes.map((r, i) => `<div class="${i === cmdSel ? 'sel' : ''}" data-i="${i}"><span>${r.fav ? '★ ' : ''}${E(r.t)}</span><small>${E(r.h)}</small></div>`).join('') || '<div><span>No match</span></div>';
  }
  function cmdOpen() { cmd.classList.add('on'); $('cmdIn').value = ''; cmdSel = 0; cmdDraw(); $('cmdIn').focus(); }
  function cmdClose() { cmd.classList.remove('on'); }
  function cmdRun(i) { const r = cmdRes[i]; if (!r) return; cmdClose(); r.f(); }
  $('cmdIn').oninput = () => { cmdSel = 0; cmdDraw(); };
  $('cmdIn').onkeydown = e => {
    if (e.key === 'ArrowDown') { cmdSel = Math.min(cmdRes.length - 1, cmdSel + 1); cmdDraw(); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { cmdSel = Math.max(0, cmdSel - 1); cmdDraw(); e.preventDefault(); }
    else if (e.key === 'Enter') { cmdRun(cmdSel); e.preventDefault(); }
    else if (e.key === 'Escape') cmdClose();
  };
  $('cmdList').onclick = e => { const d = e.target.closest('[data-i]'); if (d) cmdRun(+d.dataset.i); };
  cmd.onclick = e => { if (e.target === cmd) cmdClose(); };
  document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); cmd.classList.contains('on') ? cmdClose() : cmdOpen(); } });
  cb.onclick = cmdOpen; $('openCmd').onclick = cmdOpen;

  /* ---------- boot ---------- */
  nav.addEventListener('click', e => { if (e.target.dataset && e.target.dataset.p === 'vault') { stats(); pvDraw(); favDraw(); gems.forEach(g => g.dirty = true); } });
  document.body.dataset.theme = theme; document.body.dataset.fx = fx;
  const mini = makeGem($('gemMini'), { dist: 7.6, dust: false });
  const big = makeGem($('gemBig'), { dist: 7.4, dust: true, interact: true, follow: true, big: true });
  if (!glOK) { document.body.classList.add('nogl'); h1.querySelector('canvas').replaceWith(document.createTextNode('✦ ')); }
  drawChips(); addStars(); favDraw(); pvDraw(); stats(); decorate();
  requestAnimationFrame(loop);
  window.OMNI_PREMIUM = { applyTheme, applyFx, openPalette: cmdOpen };
})();
