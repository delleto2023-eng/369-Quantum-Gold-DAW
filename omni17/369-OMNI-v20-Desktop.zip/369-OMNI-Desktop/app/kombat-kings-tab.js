(function(){function add(){var f=document.createElement("iframe");f.src="kombat-kings/index.html";f.style.cssText="width:100%;height:85vh;border:0";
if(window.OMNI&&OMNI.registerTab){OMNI.registerTab({id:"kombat-kings",label:"369 KOMBAT KINGS",element:f});return;}
var bar=document.querySelector("[role=tablist],.tabs,.tab-bar,.tabbar,nav");var view=document.querySelector("main,[role=main],.content,.tab-content,.panels")||document.body;
var b=document.createElement("button");b.textContent="369 KOMBAT KINGS";b.className=(bar&&bar.firstElementChild&&bar.firstElementChild.className)||"";f.style.display="none";view.appendChild(f);
b.onclick=function(){Array.prototype.forEach.call(view.children,function(c){if(c!==f)c.style.display="none";});f.style.display="block";f.focus();};
if(bar){bar.appendChild(b);Array.prototype.forEach.call(bar.children,function(x){if(x!==b)x.addEventListener("click",function(){f.style.display="none";Array.prototype.forEach.call(view.children,function(c){if(c!==f)c.style.display="";});});});}else{document.body.appendChild(b);}}
document.readyState==="loading"?document.addEventListener("DOMContentLoaded",add):add();})();
