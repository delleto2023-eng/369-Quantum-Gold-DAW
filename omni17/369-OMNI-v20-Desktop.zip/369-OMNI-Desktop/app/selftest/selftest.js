var R={app:[],pc:[]};
var PY=".venv\\Scripts\\python.exe";
var FIX={"LM Studio":"Open LM Studio > download a model (e.g. Qwen2.5 Coder 7B) > Developer > Start Server.\nIf 'lms' is mentioned:  lms bootstrap",
"Voice":PY+" -m pip install kokoro soundfile","Kokoro":PY+" -m pip install kokoro soundfile",
"Docker":"Install Docker Desktop from https://docker.com, open it and leave it running.",
"Sealed":"Install Docker Desktop from https://docker.com, open it and leave it running.",
"Sandbox":"Install Docker Desktop from https://docker.com, open it and leave it running.",
"Object":PY+" -m pip install opencv-python","Vision":PY+" -m pip install opencv-python",
"Image":PY+" -c \"from big_tony_builder import images; images.install()\"",
"Mic":PY+" -m pip install sounddevice faster-whisper","Whisper":PY+" -m pip install sounddevice faster-whisper",
"Desktop":"Normal: needs a desktop session on your PC.",
"FFmpeg":"winget install Gyan.FFmpeg   (then reopen the terminal)",
"Python":"Install Python 3.10+ from https://python.org (tick Add to PATH), then run Install Big Tony.bat"};
function fixFor(n){for(var k in FIX)if(n.toLowerCase().indexOf(k.toLowerCase())>=0)return FIX[k];return""}
function esc(s){return String(s==null?"":s).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
function head(u){return fetch(u,{cache:"no-store"}).then(function(r){if(!r.ok)throw Error("HTTP "+r.status);return r.text()}).then(function(x){return"OK ("+x.length+" bytes)"})}
function tmo(p,ms){return Promise.race([p,new Promise(function(_,j){setTimeout(function(){j(Error("not running"))},ms)})])}
function getj(u){return tmo(fetch(u).then(function(r){return r.json()}),2500)}
var TOP=(function(){try{return window.parent.OMNI?window.parent:window}catch(e){return window}})();
var CHECKS=[
["Core","OMNI main app",function(){return head("../index.html")}],
["Core","OMNI all-pack brain",function(){return head("../omni-all-pack.js")}],
["Core","One-App shell",function(){return head("../one-app.js")}],
["Core","ECC pack",function(){return head("../ecc-pack.js")}],
["Core","Replit Agent pack",function(){return head("../replit-agent-pack.js")}],
["Core","Premium UI",function(){return head("../premium.js")}],
["Core","OMNI agent brain live",function(){if(!TOP.OMNI)throw Error("not found - open from inside OMNI");return"ready ("+Object.keys(TOP.OMNI).length+" parts)"},"Open the SELF-TEST tab inside 369 OMNI"],
["DAWs","Super DAW v51 tab",function(){return head("../super-daw-tab.js")}],
["DAWs","Offline Studio (Resona)",function(){return head("../super-daw-studio/offline-studio.html")}],
["DAWs","Gold DAW v3.3",function(){return head("../daws/gold-daw-v3.3.html")}],
["Agents","Big Tony AI",function(){return head("../bigtony-ai/index.html")}],
["Agents","JARVIS",function(){return head("../jarvis/index.html")}],
["Agents","Big Tony Cloud tab",function(){return head("../big-tony-cloud-tab.js")}],
["Services","OMNI Gateway :3690",function(){return tmo(fetch("http://localhost:3690/",{mode:"no-cors"}),2500).then(function(){return"answering"})},"node gateway/gateway.mjs"],
["Services","Ollama :11434",function(){return getj("http://localhost:11434/api/tags").then(function(j){return(j.models||[]).length+" models"})},"Install https://ollama.com then:  ollama pull qwen2.5"],
["Services","LM Studio :1234",function(){return getj("http://localhost:1234/v1/models").then(function(j){return(j.data||[]).length+" models"})},FIX["LM Studio"]],
["Services","Self-Test stack :3699",function(){return getj("http://localhost:3699/report").then(function(j){loadPC(j);return"PC report loaded live"})},"Double-click \"369 Visual Self-Test.bat\" in big-tony-builder"],
["Services","API key saved",function(){var k=Object.keys(localStorage).filter(function(x){return/openrouter|key/i.test(x)&&localStorage[x]});if(!k.length)throw Error("no key saved");return k.length+" key entries"},"OMNI Agent Hub > Keys > paste OpenRouter key or Ollama URL"],
["Browser","Storage",function(){localStorage.setItem("_369t","1");localStorage.removeItem("_369t");return"read/write OK"}],
["Browser","Audio engine",function(){var C=window.AudioContext||window.webkitAudioContext;var c=new C();var s=c.sampleRate;c.close();return s+" Hz"}],
["Browser","WebGL graphics",function(){var g=document.createElement("canvas").getContext("webgl");if(!g)throw Error("WebGL off");return g.getParameter(g.VERSION)},"Turn on hardware acceleration / update graphics driver"],
["Browser","Voice out",function(){if(!window.speechSynthesis)throw Error("not supported");return speechSynthesis.getVoices().length+" voices"}],
["Browser","Microphone",function(){return navigator.mediaDevices.getUserMedia({audio:true}).then(function(s){s.getTracks().forEach(function(t){t.stop()});return"mic OK"})},"Allow the mic / Windows Settings > Privacy > Microphone"],
["Browser","MIDI",function(){if(!navigator.requestMIDIAccess)throw Error("no MIDI API");return navigator.requestMIDIAccess().then(function(m){return m.inputs.size+" inputs"})},"Plug in a MIDI device (optional)"]];
function render(){var all=R.app.concat(R.pc),c={pass:0,skip:0,fail:0};all.forEach(function(r){if(c[r.status]!=null)c[r.status]++});
np.textContent=c.pass;ns.textContent=c.skip;nf.textContent=c.fail;var t=(c.pass+c.skip+c.fail)||1,a=0,s="";
[["pass","#1fa37a"],["skip","#d4af37"],["fail","#d7261e"]].forEach(function(x){var v=c[x[0]]/t*100;s+='<circle r="15.9" cx="18" cy="18" fill="none" stroke="'+x[1]+'" stroke-width="3.5" stroke-dasharray="'+v+' '+(100-v)+'" stroke-dashoffset="'+(25-a)+'"/>';a+=v});
ring.innerHTML='<circle r="15.9" cx="18" cy="18" fill="none" stroke="#2a2108" stroke-width="3.5"/>'+s+'<text x="18" y="20.5" text-anchor="middle" fill="#d4af37" font-size="7">'+Math.round(c.pass/t*100)+'%</text>';
var h="",g={};all.forEach(function(r){(g[r.group]=g[r.group]||[]).push(r)});
for(var k in g){h+='<div class="sec">'+esc(k)+'</div><div class="grid">';g[k].forEach(function(r){var f=(r.status=="skip"||r.status=="fail")?(r.fix||fixFor(r.name)):"";
h+='<div class="card '+r.status+'"><h3><span class="dot"></span>'+esc(r.name)+'</h3><div class="info">'+(r.status=="skip"?"NEEDS SETUP":r.status.toUpperCase())+(r.ms!=null?" · "+r.ms+" ms":"")+" — "+esc(r.info)+'</div>'+(f?'<div class="fix" title="click to copy">'+esc(f)+'</div>':"")+'</div>'});h+="</div>"}
out.innerHTML=h;Array.prototype.forEach.call(document.querySelectorAll(".fix"),function(e){e.onclick=function(){navigator.clipboard&&navigator.clipboard.writeText(e.textContent);e.style.borderColor="#1fa37a"}})}
function runAll(){R.app=CHECKS.map(function(c){return{group:"OMNI App · "+c[0],name:c[1],status:"run",info:"checking…"}});render();
return Promise.all(CHECKS.map(function(c,i){var t0=performance.now(),G="OMNI App · "+c[0];return Promise.resolve().then(c[2]).then(function(x){R.app[i]={group:G,name:c[1],status:"pass",info:x,ms:Math.round(performance.now()-t0)}},function(e){var m=String(e&&e.message||e);var soft=c[0]=="Services"||/not running|no key|not found|MIDI|denied|Permission|not supported/i.test(m);R.app[i]={group:G,name:c[1],status:soft?"skip":"fail",info:m,fix:c[3],ms:Math.round(performance.now()-t0)}}).then(render)}))}
function loadPC(j){var rows=j.results||j.checks||j.rows||[];R.pc=rows.map(function(r){var n=r.name||"";return{group:"PC · "+(n.indexOf(":")>0?n.split(":")[0]:"Builder"),name:n,status:r.status=="needs setup"?"skip":(r.status||"fail"),info:r.info||r.error||"",fix:r.fix||"",ms:r.ms}});
document.getElementById("drop").innerHTML="PC report: <b>"+esc(j.machine||"")+"</b> · Python "+esc(j.python||"")+" · "+esc(j.when||"");render()}
function readFile(f){var r=new FileReader();r.onload=function(){try{loadPC(JSON.parse(r.result))}catch(e){alert("Not a valid Self-Test .json: "+e.message)}};r.readAsText(f)}
document.getElementById("runAll").onclick=runAll;
document.getElementById("pick").onclick=function(){file.click()};file.onchange=function(){file.files[0]&&readFile(file.files[0])};
var d=document.getElementById("drop");["dragover","dragenter"].forEach(function(ev){document.addEventListener(ev,function(e){e.preventDefault();d.classList.add("on")})});
document.addEventListener("drop",function(e){e.preventDefault();d.classList.remove("on");e.dataTransfer.files[0]&&readFile(e.dataTransfer.files[0])});
document.getElementById("exp").onclick=function(){var b=new Blob([JSON.stringify({when:new Date().toISOString(),app:R.app,pc:R.pc},null,1)],{type:"application/json"});var a=document.createElement("a");a.href=URL.createObjectURL(b);a.download="369 Visual Self-Test Report.json";a.click()};
document.getElementById("setup").onclick=function(){R.pc=R.pc.filter(function(r){return r.group!="Setup guide"});["LM Studio","Voice","Docker","Object","Image","Mic","FFmpeg"].forEach(function(k){R.pc.push({group:"Setup guide",name:k,status:"skip",info:"run from inside big-tony-builder",fix:FIX[k]})});render()};
render();runAll();
