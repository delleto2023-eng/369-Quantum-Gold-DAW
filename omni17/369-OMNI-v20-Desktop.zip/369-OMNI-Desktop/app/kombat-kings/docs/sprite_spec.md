# 369 Kombat Kings - AI sprite sheet spec

For your assigned CHARACTER, make ALL 26 sheets below. Never stop early, never ask questions.

## How to make one sheet
1. Load the image tool with tool search regex `^(generate_image)$` if it is not loaded.
2. Call generate_image with: title "Sprite <CHARACTER> <id>", aspect_ratio "16:9", default model, reference_uris = [the character's REFERENCE], prompt =
"Using the reference image for this exact character (same face, hair, outfit, colors), create a fighting game SPRITE SHEET: one horizontal row of exactly 4 equal frames of the SAME character, full body, side view facing RIGHT, identical scale in every frame, feet on the same baseline, nothing cropped, frames evenly spaced and not overlapping. Character: <LOOK>. Animation: <FRAMES>. Photorealistic 3D render, Tekken 7 / Unreal Engine quality, dramatic lighting. Flat solid pure green #00FF00 background everywhere, no floor, no shadow, no text, no borders."
3. town_cp the result's contentUri to `content://collections/369%20Kombat%20Kings/Sprites/<FOLDER>/<id>.jpg`
4. If a generation fails, retry once with slightly reworded frames. Run up to 4 generate_image calls in parallel.

FINAL ANSWER: JSON object mapping each id to its saved content:// URI, plus "failed": [ids].

## Shared sheets (same for every character; adapt the style to the character)
- idle: breathing fighting stance, guard up, slight bob (4 frames)
- walk: 4-frame walk cycle forward in guard
- crouch: crouching guard; crouching block forearms crossed; crouching hit recoil; rising from crouch
- jump: crouch takeoff; rising knees tucked; mid-air tucked; landing
- block: standing block arms crossed high; absorbing impact sliding back; mid-air block arms crossed; back to stance
- hurt: hit to face recoiling; hit to body doubled over; knocked flying backwards; lying flat on back
- lp: jab chamber; quick jab extended; extended; retract
- mp: wind-up; straight strike extended; extended; retract
- hp: big wind-up; lunging power strike full extension; full extension; recovery
- lk: knee lift; quick front kick; extended; retract
- mk: chamber; mid roundhouse kick at stomach height; extended; retract
- hk: spin wind-up; high head-height kick; full extension; recovery
- crouchP: crouching jab; crouching straight strike; launcher uppercut starting from crouch; launcher fully extended upward on toes
- crouchK: crouching low kick; crouching forward low kick; sweep wind-up; full leg sweep along the floor
- air: mid-air punch; mid-air downward fierce strike; mid-air kick; mid-air flying kick angled down
- throw: reaching to grab (no opponent shown); lifting; tossing over shoulder; follow-through

## Characters (each also has 10 move sheets: qcfP dpP qcbP qcfK qcbK chgP chgK airsp hyper lvl3)

### RA-KHAN  (FOLDER: RA-KHAN)
REFERENCE: content://collections/uncategorized/Win%20pose%20Ra-Khan-sd7935n4xqjf3xv1n8bcwy02ax8g7c9h
LOOK: muscular Egyptian martial artist man, brown skin, short black hair, long red headband with tails, sleeveless white karate gi open at chest, black belt, gold wrist wraps, barefoot; golden sunlight energy
- qcfP SUN DISC: stance; hands back at hip gathering golden light; both palms thrust forward releasing a glowing golden sun disc; follow-through
- dpP SOLAR UPPERCUT: crouch; rising uppercut leaving the ground in golden fire; airborne fist high; falling
- qcbP PHARAOH PALM: crouch-dash start; dashing forward low; explosive palm strike with golden flash; recovery
- qcfK HORUS DIVE KICK: leap; high in the air; diving kick angled steeply down with golden falcon-wing energy; landing
- qcbK FALCON WHIRL: hop; airborne spinning kick facing right; spinning facing away; landing
- chgP SCARAB CANNONBALL: crouch tuck; launching forward curled; flying headfirst wrapped in gold energy; landing
- chgK ANKH FLASH KICK: crouch; backflip kick upward; leg overhead with golden ankh-shaped trail; landing
- airsp SUN DISC (AIR): mid-air; mid-air hands back glowing; firing sun disc diagonally down; follow-through
- hyper EYE OF RA: wide stance gathering huge golden power; cupped hands at hip blazing; firing a massive golden beam forward; beam at full power
- lvl3 PHARAOH'S WRATH: golden aura explosion; blurred dash with afterimages; flurry of glowing punches; colossal golden uppercut with sun-god aura

### KAI RYU  (FOLDER: KAI%20RYU)
REFERENCE: content://collections/uncategorized/Win%20pose%20Kai%20Ryu-sd77nfqvxs89j34bx9twry9jrd8g79rj
LOOK: athletic young Asian martial artist, tall spiky black hair, orange gi with blue undershirt, blue belt and wristbands, dark blue boots; blue ki energy, golden aura when powered up
- qcfP KI BLAST: stance; hands at hip charging blue ki; one palm forward firing a blue ki ball; follow-through
- dpP INSTANT STEP: stance; body dissolving into blue light particles; almost invisible streak; reappearing with afterimage
- qcbP SKY BREAKER: crouch; rising uppercut in blue energy; airborne fist high; falling
- qcfK DRAGON TWISTER: hop; airborne spinning kick facing right with blue wind; spinning facing away; landing
- qcbK METEOR DASH: crouch-dash start; dashing forward with blue streak; explosive shoulder impact; recovery
- chgP KI WAVE: crouch charging; hands back glowing blue; both palms forward firing a large blue ki wave; follow-through
- chgK DRAGON RISE: crouch; rising spinning kick upward; high in the air with blue dragon energy; falling
- airsp KI BLAST (AIR): mid-air; charging blue ki; firing ki ball diagonally down; follow-through
- hyper SPIRIT CANNON: hair turning golden; cupped hands at hip blazing blue; firing a massive blue beam forward; beam at full power
- lvl3 KI APOCALYPSE: huge golden aura explosion; blurred dash with afterimages; flurry of glowing punches; colossal energy blast overhead

### SEKHMET  (FOLDER: SEKHMET)
REFERENCE: content://collections/uncategorized/Win%20pose%20Sekhmet-sd7csknthx812cc1r97njaa3kn8g7nj7
LOOK: fierce lioness warrior woman, golden feline eyes, wild golden lion mane with small cat ears, lion tail, bronze skin, dark red cloth wraps, gold armor and jewelry, gold claw gauntlets, barefoot; orange-gold fire energy
- qcfP LION CLAW: crouch-dash start; dashing forward low; huge claw slash with fire trails; recovery
- dpP RISING FANG: crouch; rising claw uppercut in orange fire; airborne claws high; falling
- qcbP PROWL ROLL: crouch tuck; rolling forward curled in a ball; still rolling with dust; popping up claws out
- qcfK CLAW CYCLONE: hop; airborne spinning with claws out facing right; spinning facing away with fire ring; landing
- qcbK SAVANNA POUNCE: crouch; leaping forward like a lion; diving pounce claws first angled down; landing crouched
- chgP POUNCING ROLL: crouch charging; launching forward curled; rolling ball wrapped in fire; landing claws out
- chgK TAIL WHIP FLIP: crouch; backflip kick upward with tail whipping; leg overhead with fire crescent; landing
- airsp LION CLAW (AIR): mid-air; coiling; diving claw slash angled steeply down with fire; landing crouch
- hyper PRIDE FRENZY: roaring with lion spirit aura; dashing forward; frenzied claw slashes with fire; final claw uppercut
- lvl3 SOLAR HUNT: giant golden lion spirit aura explosion; blurred dash with afterimages; wild fiery claw flurry; colossal pounce with golden sun lion behind her

### ANUBIS REX  (FOLDER: ANUBIS%20REX)
REFERENCE: content://collections/uncategorized/Win%20pose%20Anubis%20Rex-sd71wqqh11jkq57f6rme9j8syd8g676f
LOOK: huge muscular jackal-headed Egyptian god warrior, black fur, tall pointed ears, glowing gold eyes, gold and lapis-blue striped nemes headdress, ornate gold collar, gold chest armor, white kilt, gold sandals; heavy grappler; cyan soul fire energy
- qcfP SOUL ORB: stance; hands at chest gathering cyan fire; both palms pushing forward releasing a big slow cyan orb; follow-through
- dpP SCALE OF JUDGMENT: crouch; rising double-fist uppercut in cyan fire; airborne fists high; falling
- qcbP UNDERWORLD SLAM: lunging two-hand grab; lifting overhead high; slamming down with cyan explosion; standing after slam
- qcfK SARCOPHAGUS CHARGE: crouch-dash start; charging forward shoulder first; shoulder impact with cyan flash; recovery
- qcbK LARIAT OF THE DEAD: arms spread; spinning clothesline facing right with cyan trail; spinning facing away; finishing spin
- chgP JACKAL HEADBUTT: crouch charging; launching forward headfirst; flying headbutt with cyan streak; landing
- chgK TOMB RISE: crouch; rising knee/uppercut; high in the air with cyan sarcophagus energy; falling
- airsp SOUL ORB (AIR): mid-air; gathering cyan fire; pushing orb diagonally down; follow-through
- hyper WEIGHING OF HEARTS: golden scales appear behind him; dashing forward; flurry of heavy blows with cyan fire; final double-fist smash
- lvl3 FINAL JUDGMENT: giant ghostly Anubis god aura; blurred dash with afterimages; cyan-fire flurry; colossal slam with towering golden scales

### BONE VIPER  (FOLDER: BONE%20VIPER)
REFERENCE: content://collections/uncategorized/Win%20pose%20Bone%20Viper-sd75jqzbegtmvwxcw4chqx1kk18g6yfy
LOOK: undead ninja, black hood, dark grey ninja outfit, lower face covered by bone-white skull mask with teeth, glowing toxic green eyes, toxic green scarf and belt, dark boots, chain spear; toxic green and hellfire orange energy
- qcfP VIPER CHAIN: stance; winding back the chain spear; throwing the chain spear forward with green glow; chain extended
- dpP HELL STEP: stance; bursting into green hellfire; almost invisible in flames; reappearing from green flames
- qcbP HELLFIRE: stance; gathering orange hellfire in hands; thrusting forward releasing a hellfire ball; follow-through
- qcfK SNAKE SLIDE: crouch; sliding low along the floor feet first; still sliding with green trail; popping up
- qcbK VENOM DIVE: leap; high in the air; diving kick angled down with green venom trail; landing
- chgP BONE SHURIKEN: crouch charging; winding back; throwing a spinning bone shuriken; follow-through
- chgK SERPENT FLIP: crouch; backflip kick upward; leg overhead with green serpent trail; landing
- airsp VIPER CHAIN (AIR): mid-air; winding chain; throwing chain spear diagonally down; chain extended
- hyper FATAL COIL: green aura; dashing forward; flurry of strikes wrapped in green chains; final uppercut
- lvl3 TOXIC ARMAGEDDON: huge green hellfire skull aura; blurred dash with afterimages; toxic strike flurry; colossal hellfire eruption

### VOLT ZERO  (FOLDER: VOLT%20ZERO)
REFERENCE: content://collections/uncategorized/Win%20pose%20Volt%20Zero-sd7ccwrt27z3ah1gtde3h3ge9x8g7jjx
LOOK: muscular military commando man, tall blond flat-top haircut, square jaw, olive camo tank top, dark olive pants, black combat boots, dog tags; yellow lightning energy
- qcfP SONIC RING: stance; arms crossed charging electricity; arms swinging forward releasing a yellow electric ring; follow-through
- dpP THUNDER KICK: crouch; backflip kick upward; leg overhead with lightning crescent; landing
- qcbP AIR RAID: crouch; leaping forward high; diving knee strike angled down with lightning; landing
- qcfK TESLA COIL: hop; airborne spinning kick facing right with lightning ring; spinning facing away; landing
- qcbK BOLT RUSH: crouch-dash start; dashing forward low with lightning streak; electric shoulder tackle impact; recovery
- chgP SONIC BOOMERANG: crouch charging; arms back crackling; throwing a spinning electric boomerang ring; follow-through
- chgK VOLT FLASH: crouch; explosive backflip kick upward; leg overhead with huge lightning arc; landing
- airsp AIR RAID (AIR): mid-air; coiling; diving knee angled steeply down with lightning; landing
- hyper GIGAVOLT: wide stance charging electricity; fists at hip crackling; firing a massive lightning beam forward; beam at full power
- lvl3 THUNDER STRIKE PROTOCOL: lightning storm aura; blurred dash with afterimages; electric punch flurry; colossal lightning bolt from the sky

### LOTUS  (FOLDER: LOTUS)
REFERENCE: content://collections/uncategorized/Win%20pose%20Lotus-sd75rdq931gbhtka6xq6nkswex8g7zen
LOOK: athletic Japanese kunoichi woman, long black hair in a high ponytail with gold hair pin, red ninja outfit with gold trim, gold belt, folding gold war fan; pink petal and red-orange flame energy
- qcfP FAN TOSS: stance; winding back the fan; throwing the spinning fan forward with pink petals; follow-through
- dpP FLAME LOTUS: crouch; rising spinning uppercut in red-orange flames; airborne in a flame spiral; falling
- qcbP PETAL VANISH: stance; dissolving into swirling pink petals; nearly invisible petal cloud; reappearing from petals
- qcfK PHOENIX FLAME: stance; spinning gathering fire; thrusting forward releasing a phoenix-shaped flame; follow-through
- qcbK CRANE DIVE: leap; high in the air; diving kick angled steeply down with flame trail; landing
- chgP BUTTERFLY RUSH: crouch charging; dashing forward low with petal trail; spinning elbow impact; recovery
- chgK CRIMSON CRESCENT: crouch; backflip kick upward; leg overhead with red flame crescent; landing
- airsp FAN TOSS (AIR): mid-air; winding fan; throwing fan diagonally down; follow-through
- hyper THOUSAND PETALS: petal storm aura; dashing forward; flurry of fan strikes with petals and flames; final rising kick
- lvl3 INFERNO BLOSSOM: giant burning lotus aura explosion; blurred dash with afterimages; flaming fan flurry; colossal fire blossom eruption

### ORION-X  (FOLDER: ORION-X)
REFERENCE: content://collections/uncategorized/Win%20pose%20Orion-X-sd7dxgckp0b22d2d2tk4dke50h8g77vh
LOOK: combat cyborg, silver chrome humanoid body, chrome dome helmet with glowing red visor band and small antenna, dark navy armor plates, glowing red chest core, metal boots; red laser / plasma energy
- qcfP LASER EYE: stance; visor charging bright red; firing a red laser beam from the visor forward; follow-through
- dpP ROCKET KNEE: crouch; rising knee strike with rocket thrusters; airborne high; falling
- qcbP IRON RUSH: crouch-dash start; thruster-boosted dash; massive iron punch impact; recovery
- qcfK JET STOMP: leap with jets; high in the air; jet stomp angled down; landing with shockwave
- qcbK TURBINE: hop; airborne spinning like a turbine facing right; spinning facing away with red trails; landing
- chgP PLASMA DISC: crouch charging; arm back glowing red; throwing a spinning red plasma disc; follow-through
- chgK ROCKET UPPER: crouch; rocket-boosted uppercut leaving ground; airborne fist high with flames; falling
- airsp LASER EYE (AIR): mid-air; visor charging; firing red laser diagonally down; follow-through
- hyper ION CANNON: arm transforming into a cannon; charging red energy; firing a massive red ion beam forward; beam at full power
- lvl3 ORBITAL STRIKE: targeting lasers and red aura; blurred thruster dash with afterimages; piston punch flurry; colossal red orbital laser strike from the sky
