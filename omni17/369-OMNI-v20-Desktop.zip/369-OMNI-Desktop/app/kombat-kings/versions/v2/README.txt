369 KOMBAT KINGS - DESKTOP
==========================
INSTALL (puts the game on your Desktop + apps menu, works offline):
  Windows: double-click "Install (Windows).bat"
  Mac:     right-click "Install (Mac).command" > Open (first time only)
  Linux:   run "Install (Linux).sh"
Then open "369 Kombat Kings" from your Desktop. It launches full screen like a console.

Don't want to install? Open app/index.html in Chrome or Edge.

Plug in a PS4 controller (USB or Bluetooth) and press OPTIONS. A second controller = Player 2.
EXIT: choose QUIT GAME on the title screen or pause menu (or press Esc on the title).
      The window closes itself; if not, press Alt+F4 (Windows/Linux) or Cmd+Q (Mac).
UNINSTALL: run the matching Uninstall file.
Chrome or Edge recommended (best controller, rumble and sound support).

PS4 controller (SF2 6-button layout):
  PUNCH: Square = Jab (small)   Triangle = Strong (medium)   R1 = Fierce (big)
  KICK:  Cross = Short (small)  Circle = Forward (medium)    R2 = Roundhouse (big)
  L1/L2 = special / super    OPTIONS = pause    D-pad/stick = move
Keyboard P1: WASD move | U I O = Jab Strong Fierce | J K L = Short Forward Roundhouse | P special | Esc pause
Keyboard P2: Arrows | Numpad 7 8 9 punches | Numpad 4 5 6 kicks | Numpad 0 special
