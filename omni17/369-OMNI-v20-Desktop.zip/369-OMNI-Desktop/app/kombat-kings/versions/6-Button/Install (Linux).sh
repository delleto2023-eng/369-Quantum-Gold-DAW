#\!/bin/bash
SRC="$(cd "$(dirname "$0")" && pwd)/app"
DEST="$HOME/.local/share/369kombatkings"
mkdir -p "$DEST" "$HOME/.local/share/applications"
cp "$SRC/index.html" "$SRC/icon.png" "$DEST/"
cat > "$DEST/play.sh" <<'SH'
#\!/bin/bash
D="$(cd "$(dirname "$0")" && pwd)"
for B in google-chrome google-chrome-stable chromium chromium-browser microsoft-edge brave-browser; do
  if command -v "$B" >/dev/null 2>&1; then exec "$B" --user-data-dir="$HOME/.config/369kombatkings" --kiosk --autoplay-policy=no-user-gesture-required --no-first-run --disable-session-crashed-bubble --app="file://$D/index.html"; fi
done
xdg-open "$D/index.html"
SH
chmod +x "$DEST/play.sh"
DESK="[Desktop Entry]
Type=Application
Name=369 Kombat Kings
Comment=Solid Gold Fighting Championship
Exec=$DEST/play.sh
Icon=$DEST/icon.png
Terminal=false
Categories=Game;ArcadeGame;"
echo "$DESK" > "$HOME/.local/share/applications/369-kombat-kings.desktop"
[ -d "$HOME/Desktop" ] && echo "$DESK" > "$HOME/Desktop/369-kombat-kings.desktop" && chmod +x "$HOME/Desktop/369-kombat-kings.desktop"
echo "Done\! Find 369 Kombat Kings in your apps menu or on your Desktop."
