@echo off
title Install 369 Kombat Kings
set "DEST=%LOCALAPPDATA%\369KombatKings"
echo Installing 369 Kombat Kings to %DEST% ...
if not exist "%DEST%" mkdir "%DEST%"
xcopy /E /Y /Q "%~dp0app\*" "%DEST%\" >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=New-Object -ComObject WScript.Shell; foreach($p in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){$l=$s.CreateShortcut((Join-Path $p '369 Kombat Kings.lnk'));$l.TargetPath='%DEST%\Play.bat';$l.WorkingDirectory='%DEST%';$l.IconLocation='%DEST%\icon.ico';$l.WindowStyle=7;$l.Save()}"
echo.
echo Done\! Double-click "369 Kombat Kings" on your Desktop or in the Start Menu.
pause
