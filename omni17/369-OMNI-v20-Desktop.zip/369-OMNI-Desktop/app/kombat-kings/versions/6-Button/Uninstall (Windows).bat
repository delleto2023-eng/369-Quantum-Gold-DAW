@echo off
del "%USERPROFILE%\Desktop\369 Kombat Kings.lnk" 2>nul
powershell -NoProfile -Command "Remove-Item -ErrorAction SilentlyContinue (Join-Path ([Environment]::GetFolderPath('Desktop')) '369 Kombat Kings.lnk'),(Join-Path ([Environment]::GetFolderPath('Programs')) '369 Kombat Kings.lnk')"
rmdir /S /Q "%LOCALAPPDATA%\369KombatKings"
echo 369 Kombat Kings removed.
pause
