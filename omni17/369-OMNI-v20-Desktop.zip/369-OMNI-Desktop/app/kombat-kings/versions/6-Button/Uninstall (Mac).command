#\!/bin/bash
rm -rf "$HOME/Applications/369 Kombat Kings.app" "$HOME/Desktop/369 Kombat Kings" "$HOME/Library/Application Support/369KombatKings"
echo "369 Kombat Kings removed."
