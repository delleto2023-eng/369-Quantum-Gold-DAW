#\!/bin/bash
SRC="$(cd "$(dirname "$0")" && pwd)/app"
APP="$HOME/Applications/369 Kombat Kings.app"
echo "Installing 369 Kombat Kings..."
rm -rf "$APP"; mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$SRC/index.html" "$APP/Contents/Resources/index.html"
cp "$SRC/icon.icns" "$APP/Contents/Resources/icon.icns"
cat > "$APP/Contents/Info.plist" <<PL
<?xml version="1.0" encoding="UTF-8"?><\!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict><key>CFBundleName</key><string>369 Kombat Kings</string><key>CFBundleExecutable</key><string>play</string><key>CFBundleIconFile</key><string>icon</string><key>CFBundleIdentifier</key><string>com.solidgold369.kombatkings</string><key>CFBundlePackageType</key><string>APPL</string><key>CFBundleShortVersionString</key><string>1.0</string></dict></plist>
PL
cat > "$APP/Contents/MacOS/play" <<'SH'
#\!/bin/bash
RES="$(cd "$(dirname "$0")/../Resources" && pwd)"
for B in "Google Chrome" "Microsoft Edge" "Chromium" "Brave Browser"; do
  if [ -d "/Applications/$B.app" ]; then open -na "$B" --args --user-data-dir="$HOME/Library/Application Support/369KombatKings" --kiosk --autoplay-policy=no-user-gesture-required --no-first-run --disable-session-crashed-bubble --app="file://$RES/index.html"; exit 0; fi
done
open "$RES/index.html"
SH
chmod +x "$APP/Contents/MacOS/play"
ln -sf "$APP" "$HOME/Desktop/369 Kombat Kings"
touch "$APP"
echo "Done\! Open 369 Kombat Kings from your Desktop or ~/Applications."
