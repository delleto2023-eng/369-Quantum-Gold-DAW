@echo off
set "GAME=%~dp0index.html"
set "PROFILE=%LOCALAPPDATA%\369KombatKings\profile"
for %%B in ("%ProgramFiles%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" "%LocalAppData%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe") do (
  if exist %%B ( start "" %%B --user-data-dir="%PROFILE%" --kiosk --autoplay-policy=no-user-gesture-required --no-first-run --disable-session-crashed-bubble --app="file:///%GAME%" & exit /b )
)
start "" "%GAME%"
