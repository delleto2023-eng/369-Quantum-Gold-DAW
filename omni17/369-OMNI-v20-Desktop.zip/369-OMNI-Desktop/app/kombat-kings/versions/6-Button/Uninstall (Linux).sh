#\!/bin/bash
rm -rf "$HOME/.local/share/369kombatkings" "$HOME/.config/369kombatkings" "$HOME/.local/share/applications/369-kombat-kings.desktop" "$HOME/Desktop/369-kombat-kings.desktop"
echo "369 Kombat Kings removed."
