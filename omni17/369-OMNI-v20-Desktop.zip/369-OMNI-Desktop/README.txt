369 OMNI v20 - Desktop Version
1. Unzip this whole folder anywhere (e.g. Desktop).
2. Double-click "369 OMNI Desktop.bat" - opens OMNI in its own app window (Chrome or Edge, no browser bars).
3. Optional: double-click "Make Desktop Shortcut.bat" for a 369 OMNI icon on your Desktop.
4. No Windows? Open "369 OMNI Desktop.html" in any browser.
Everything from v20 is in this one build: app/ (all tabs, DAWs, Big Tony, JARVIS, Self-Test, Kombat Kings, all skill packs) plus agent, big-tony-builder, gateway, databrain, docs, electron, fly and build.
