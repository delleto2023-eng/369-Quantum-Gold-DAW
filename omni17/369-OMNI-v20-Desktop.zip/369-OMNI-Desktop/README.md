# 369 OMNI v11

app/      UI (index.html + ECC pack)
gateway/  one OpenAI-compatible endpoint + key broker (Node)
agent/    Big Tony Python agent (optional; needs Python 3.10+)
docs/     READMEs and attribute catalog
electron/ desktop wrapper    build/  icon + NSIS installer script

Dev run:   npm install && npm start
Installer: npm install && npx electron-builder --win --dir, then compile build/installer.nsi with makensis
Keys: menu OMNI > Edit API keys. Gateway is local-only unless a file named "lan" exists in the data folder.

## v12 - Everything combined into ONE agent
- 618 skills in 14 groups, all routed automatically by one brain: Big Tony core, Dev Agents, AI Tool clones, Omni Gateway 17,
  Ultimate v11 (agents + 36 skills), Everything Claude Code (71 sub-agents, 314 skills, 98 commands - now truly wired into routing),
  369 Knowledge (Tesla/geometry, wealth plan, astrology lore, Solomon Library, Gold DAW, Casino & Combat Kings, JARVIS).
- New Debate Arena tab (2-6 skills argue 1-3 rounds, Metatron judges and merges).
- databrain/server.py (real TabPFN if installed, else kNN) on :3691.  fly/ = Fly.io deploy for Gateway + Data Brain.
- Quick use without installing: open app/index.html in a browser.

## v14.0.0
- 369 Super DAW Studio v51 Complete merged: full app in app/super-daw-studio/app (369 SUPER DAW v51 tab), all launchers, installers builder, FL Studio VST3/AU plugin source and Completed Songs in app/super-daw-studio/.

## v20.0.0
- Base44 Harness (18 skills) — fills the old "Bass 44" slot
- Ponytail agent skills (full DietrichGebert/ponytail repo, 6 skills) in agent/skills/v20/ponytail
- Matt Pocock Skills (full mattpocock/skills repo, 39 skills) in agent/skills/v20/matt-pocock-skills
- 369 KOMBAT KINGS tab: v4 game playable inside OMNI; 6-Button, v2, v3, v4 kept in app/kombat-kings/versions; screenshots + sprite_spec.md
