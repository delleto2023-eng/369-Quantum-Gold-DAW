#!/usr/bin/env bash
# One-click start for Mac/Linux: sets up everything on first run, then launches Big Tony.
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  echo "First run: setting up..."
  python3 -m venv .venv && ./.venv/bin/pip install -q -r requirements.txt
fi
[ -f .env ] || { cp .env.example .env; echo "Created .env - add your ANTHROPIC_API_KEY (or set AGENT_PROVIDER=ollama), then run again."; ${EDITOR:-nano} .env; }
./.venv/bin/python main.py doctor
./.venv/bin/python main.py test || echo "Some checks failed - see above."
./.venv/bin/python main.py "$@"
