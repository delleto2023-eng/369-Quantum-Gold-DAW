@echo off
REM One-click start for Windows: sets up everything on first run, then launches Big Tony.
cd /d "%~dp0"
if not exist .venv (
  echo First run: setting up...
  py -3 -m venv .venv || python -m venv .venv
  .venv\Scripts\pip install -q -r requirements.txt
)
if not exist .env (
  copy .env.example .env >nul
  echo Created .env - add your ANTHROPIC_API_KEY or set AGENT_PROVIDER=ollama, then run again.
  notepad .env
)
.venv\Scripts\python main.py doctor
.venv\Scripts\python main.py test
.venv\Scripts\python main.py %*
pause
