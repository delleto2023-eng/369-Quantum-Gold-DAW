---
name: mix-doctor
agent: tony_mix
description: Abbey Road Mix Doctor: 3 master versions
phase: 9
triggers: mix doctor, mix, abbey road, balance, eq, three versions, 3 versions, master versions
tools: loudness_meter, master_track
inputs: track
outputs: 3 masters: streaming, club, audiophile
success: 3 masters exist with measured LUFS
est_minutes: 5
---
1. loudness_meter on the mix.
2. master_track spotify balanced (streaming), club loud (club) and healing warm (audiophile).
3. Report all 3 with LUFS and true peak.
