---
name: obsidian-vault
agent: librarian
description: Export the project graph as an Obsidian vault
phase: 9
triggers: obsidian, vault, notes, second brain, export graph
tools: obsidian_export, graph_build, release_notes
inputs: built graph
outputs: vault/ folder with one note per node and an index
success: vault has an index note and every note has [[links]]
est_minutes: 3
---
1. graph_build if the graph is missing or old.
2. obsidian_export to vault/.
3. release_notes explaining: open the folder as a vault in Obsidian, then use Graph view.
4. Report the vault path and number of notes.
