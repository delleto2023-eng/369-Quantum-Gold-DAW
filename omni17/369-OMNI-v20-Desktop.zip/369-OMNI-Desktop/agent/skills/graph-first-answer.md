---
name: graph-first-answer
agent: navigator
description: Answer project questions from the graph, opening files only when needed
phase: 6
triggers: how does, where is, what calls, explain the code, find in project, depends on, architecture
tools: graph_query, graph_report, read_file
inputs: question about the project
outputs: answer with file:line references
success: answer cites nodes from graph_query; files opened only where the graph pointed; tokens saved reported
est_minutes: 3
---
1. graph_query with the question (budget 1500 tokens; raise only if needed).
2. If the answer is clear, reply with file:line references from the graph.
3. Only if the graph points to a file you truly need, read_file that one file.
4. Report how many tokens the graph saved.
