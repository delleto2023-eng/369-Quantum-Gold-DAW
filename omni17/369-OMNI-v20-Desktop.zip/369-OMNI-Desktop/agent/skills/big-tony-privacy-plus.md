---
name: big-tony-privacy-plus
description: Big Tony Builder privacy plus tools - all features unlocked, no credits or pricing.
---

# Big Tony Builder - Privacy Plus

Call these with `from big_tony_builder import TOOLS` or the CLI `python -m big_tony_builder <tool> key=value`.

## sanitize
Privacy Mode sanitization layer: masks PII, keys and your trade-secret terms before any prompt leaves the device.

## restore


## encrypt
End-to-end encryption (AES-256-GCM via `cryptography`; falls back to an HMAC-authenticated stream cipher).

## decrypt


## EncryptedVault / Incognito
PIN-locked encrypted chat store with encrypted keyword search; Incognito mode keeps chats in memory only and wipes on exit.
