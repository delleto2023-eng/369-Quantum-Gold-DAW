---
name: big-tony-chat
description: Self-hosted LibreChat-style chat for every AI provider - switch models mid-chat, no-code Agent Builder and marketplace, MCP tools, code interpreter, web search, artifacts (HTML/React/Mermaid), image generation, chat with files (RAG), speech, conversation search, multi-user login and admin panel.
---
Start: python -m big_tony_builder.chat serve (http://localhost:3080), or Start Big Tony Chat.bat / start_big_tony_chat.sh. Add --public for a link anyone can open.
First account = admin. Admin panel: users (make admin, disable), sign-ups on/off, API keys, custom OpenAI-compatible endpoints, MCP servers (stdio), default model.
Built-in agents: Big Tony, Researcher, Coder, Data Analyst, Doc Chat, 369 Studio Producer, Voice Notes, Diagrammer. Agent Builder: instructions, provider/model, tools
(web_search, web_fetch, code_interpreter, file_search, generate_image, mcp or mcp:<server>, bt:<Big Tony tool pattern>), skills, starters, sharing; import/export JSON.
Chat: attach files (txt, md, pdf, docx, code, audio/video -> transcribed), mic input, read aloud, fork from any message, regenerate, export Markdown/JSON, read-only share links.
Replies stream word by word (tool steps show live). Sign in with Google or GitHub: Admin panel > Sign-in providers (paste the OAuth client id/secret; callback URL shown there).
