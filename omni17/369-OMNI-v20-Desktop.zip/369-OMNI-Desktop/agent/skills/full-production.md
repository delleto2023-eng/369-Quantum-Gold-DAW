---
name: full-production
agent: tony_beats
description: Tony full production: drums, chords and arrangement in one go
phase: 6
triggers: full production, full beat, produce, production, 808, hat rolls, drums and chords
tools: forge_song, chord_progression, song_structure
inputs: genre, bpm, key, mood
outputs: song WAV, chord MIDI, section map
success: WAV, MIDI and section map all exist; BPM and key reported
est_minutes: 5
---
1. song_structure for the form and length.
2. forge_song for drums, 808 and pad in the genre.
3. chord_progression for the key and mood as MIDI.
4. Report files, BPM, key and sections; hand to Tony Mix.
