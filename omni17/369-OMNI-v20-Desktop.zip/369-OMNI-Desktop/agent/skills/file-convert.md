---
name: file-convert
agent: file_studio
description: Convert files between formats safely
phase: 9
triggers: convert, format, change format, to mp3, to wav, to png, to csv, to json, to html
tools: convert_file, shield_scan
inputs: file, target format
outputs: converted copy next to the original
success: Shield scan ran; converted file exists; original kept
est_minutes: 2
---
1. shield_scan the file.
2. convert_file to the target format.
3. Report the new file; keep the original.
