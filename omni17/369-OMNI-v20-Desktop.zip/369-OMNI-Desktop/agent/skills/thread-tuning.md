---
name: thread-tuning
agent: model_smith
description: benchmark and tune CPU threads and caches for speed
phase: 9
triggers: speed, faster, threads, tokens per second, benchmark, slow
tools: model_benchmark, llama_server_start, llama_server_stop, set_fact
inputs: running server
outputs: fastest command saved as fact
success: before and after tokens per second reported; best command saved
est_minutes: 15
---
1. model_benchmark with the current server to get a baseline.
2. Restart with -t set to all CPU threads, then to half (the video saw -t 6 beat -t 12: 24.1 vs 13.6 t/s).
3. For MoE, try --moe-cache-mib 2048 (helps generation, not prefill) if VRAM allows.
4. Keep the fastest stable setting; save it with set_fact key=local_model_cmd.
5. Report the before and after tokens/s.
