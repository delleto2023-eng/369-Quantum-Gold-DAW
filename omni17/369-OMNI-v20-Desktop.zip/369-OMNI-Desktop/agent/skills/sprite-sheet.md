---
name: sprite-sheet
agent: sprite_artist
description: Draw a fighter sprite sheet for 369 Kombat Kings
phase: 6
triggers: sprite, sprites, sprite sheet, fighter, character art, kombat, animation frames
tools: sprite_sheet
inputs: fighter name, colors
outputs: arcade/sprites/<name>_sheet.png + frame map
success: sheet and frame map exist; 6 poses x 4 frames
est_minutes: 3
---
1. sprite_sheet with the fighter's name and colors.
2. Report the sheet and frame map paths.
3. Hand to the App Creator to drop into the game.
