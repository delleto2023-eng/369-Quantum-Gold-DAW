---
name: big-tony-table
description: Google Tabletop-style shared group space - build live polls, itineraries, expense splitters, brackets, seating charts, chore games, spinner wheels, checklists and Pickle Pong that a whole group edits at once from an invite link.
---
Start: python -m big_tony_builder.tabletop serve  (http://localhost:3690). Make a space (blank or a template: road trip, potluck, rec league,
wedding, weekly meals, school pickup, office party, chores, game night), copy the invite link into the group chat.
Ask in plain words with @tony: "make a poll for dinner: tacos, pizza", "plan a road trip: Atlanta, Nashville", "split expenses between me, Sam, Ty",
"bracket with A, B, C, D, E" (byes handled), "seating chart 3 tables: ...", "chores: dishes, trash", "spinner wheel: ...", "pong game".
Change tools mid-use: "turn pong into pickle pong", "make the ball faster", "move Bo to Table 2", "add sushi to the poll", "allow multiple picks",
"close the poll", "set reward to pizza night", "rename poll to Friday dinner", "remove wheel".
Anything else goes to LM Studio (or a connected model) which designs the tool; offline it saves as a note.
From code: tabletop_create_space, tabletop_ask, tabletop_act, tabletop_template, tabletop_add_item.
