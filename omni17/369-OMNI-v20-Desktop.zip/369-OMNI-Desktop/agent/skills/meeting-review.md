---
name: meeting-review
agent: meeting_reviewer
description: Turn a meeting transcript into notes
phase: 9
triggers: meeting notes, transcript, recap, action items, decisions, meeting review
tools: read_file, write_file, workspace_post
inputs: transcript file
outputs: notes/<meeting>.md
success: summary, decisions, action items with owners and open questions present
est_minutes: 5
---
1. read_file the transcript.
2. Write summary, decisions, action items (owner + due) and open questions.
3. write_file to notes/<meeting>.md.
4. workspace_post the action items.
