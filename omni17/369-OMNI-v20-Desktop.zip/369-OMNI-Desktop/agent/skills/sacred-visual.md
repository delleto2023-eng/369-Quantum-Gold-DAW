---
name: sacred-visual
agent: director
description: sacred-geometry artwork or animated visualizer
phase: 6
triggers: sacred, geometry, metatron, flower of life, visualizer, artwork, cover
tools: sacred_geometry, still_to_shot, film_look, assemble_sequence
inputs: pattern, optional audio
outputs: geometry/<pattern>.png, film/<name>.mp4
success: image renders; video length 9, 18 or 27 s or matches audio
est_minutes: 10
---
1. sacred_geometry to render the pattern (flower_of_life, metatrons_cube, vortex_369, golden_spiral...) in gold.
2. For motion, still_to_shot with slow-zoom-in for 9, 18 or 27 seconds (or match the audio length).
3. film_look gold-luxury; add audio with assemble_sequence if given.
4. Report image and video paths.
