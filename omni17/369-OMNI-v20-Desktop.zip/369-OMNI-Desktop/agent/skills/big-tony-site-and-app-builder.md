---
name: big-tony-site-and-app-builder
description: Big Tony Builder site and app builder tools - all features unlocked, no credits or pricing.
---

# Big Tony Builder - Site And App Builder

Call these with `from big_tony_builder import TOOLS` or the CLI `python -m big_tony_builder <tool> key=value`.

## build_website
AI Builder: generates a full multi-page website from a brief (copy by AI), with forms, bookings, user accounts and an admin panel
served by the included Python backend (`server.py`).

## build_app
AI Builder (apps): turns a description into a single-file working web app with local data storage.

## publish_site
Cloud hosting / custom domain: deploys with the Netlify, Vercel, GitHub Pages or Cloudflare CLI you have installed.

## Workspace / Receptionist
Account dashboard for teams and clients (users, roles, clients, projects, usage, bookings). AI Receptionist trained on your site and docs answers 24/7, books appointments, ships a chat widget.
