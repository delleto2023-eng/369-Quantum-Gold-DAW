---
name: big-tony-public-links
description: Put Big Tony Table and Big Tony Cloud on a free public https link so people outside your Wi-Fi can join.
---
Table alone: python -m big_tony_builder.tabletop serve --public --pin 1234
Cloud + Table together: python -m big_tony_builder.cloud serve --root D:/BigTonyCloud --public  (Table lives at /table/)
Uses a Cloudflare quick tunnel (cloudflared downloads itself, no account), falls back to localhost.run over ssh. The link changes each start; it reopens itself if it drops. Guests join only by invite link; only you (cloud login or host PIN) can make new spaces. Invite link copy button uses the public link automatically.
