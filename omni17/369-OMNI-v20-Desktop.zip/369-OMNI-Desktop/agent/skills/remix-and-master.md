---
name: remix-and-master
agent: mastering_engineer
description: Remix and master tracks to streaming targets
phase: 9
triggers: remix, slowed, reverb, sped up, nightcore, 8d, bass boosted, master, mastering, lufs, spotify, apple music, loud
tools: remix_song, master_track, loudness_meter
inputs: track, target, styles
outputs: studio/masters/*.wav, studio/remixes/*.wav
success: loudness measured after mastering and within 1 LU of target; remix files exist
est_minutes: 5
---
1. loudness_meter on the original.
2. remix_song for any requested styles (up to 6).
3. master_track to the target (default Spotify, balanced).
4. Report before and after LUFS and true peak.
