---
name: build-app
agent: coder
description: build, run and test a small app or script
phase: 6
triggers: app, code, script, build, program, website, tool, bug, fix
tools: write_file, run_python, run_shell
inputs: requirement
outputs: apps/<name>/ with README
success: runs without errors; tested at least 3 cases; README explains launch
est_minutes: 30
---
1. Restate the requirement in one line and choose the simplest stack.
2. write_file the code under apps/<name>/.
3. Run it and fix errors until it works (test at least 3 cases).
4. Add a README with how to run it.
5. Report the folder and how to launch it.
