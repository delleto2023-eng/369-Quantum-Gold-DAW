---
name: big-tony-desktop
description: Windows automation and workspace awareness: active window, open windows, running apps, system info, clipboard, screenshots, read the screen (vision model or OCR), open apps/files/links, focus/close windows, type, hotkeys, click, find files, sort folders, volume, notifications, lock/sleep/restart.
---
Risky actions (close_app, organize_folder, run_command, power restart/shutdown/sleep) need confirm=True after the user agrees. desktop_workspace() gives the full picture; add include_screen=True to read the screen.
