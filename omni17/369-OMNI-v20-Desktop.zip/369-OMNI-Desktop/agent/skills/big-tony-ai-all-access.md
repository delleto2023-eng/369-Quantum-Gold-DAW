---
name: big-tony-ai-all-access
description: Big Tony Builder ai all access tools - all features unlocked, no credits or pricing.
---

# Big Tony Builder - Ai All Access

Call these with `from big_tony_builder import TOOLS` or the CLI `python -m big_tony_builder <tool> key=value`.

## ask
Ask one model. private=True routes through Privacy Mode (sanitized prompt, local model preferred).

## compare
Compare multiple responses side by side before choosing an answer.

## best_answer
Big Tony collective: asks every model, then a judge merges the best answer.

## auto_route
Switch between models based on the task.

## available_models


## research_agent
Research Agent: searches the web, reads sources, writes a cited report with [n] references.

## web_search
DuckDuckGo HTML search (no key). Returns [{title,url,snippet}].

## article_writer
AI Article Writer: outline -> SEO article in Markdown with headings, meta description and FAQ.

## presentation_builder
Presentation Builder: generates a gold-themed HTML slide deck (arrow keys to navigate).
