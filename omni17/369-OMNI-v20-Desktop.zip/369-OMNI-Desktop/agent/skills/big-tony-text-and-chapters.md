---
name: big-tony-text-and-chapters
description: Big Tony Builder v2 text and chapters tools - all unlocked, no pricing.
---

# Big Tony Builder - Text And Chapters

## text_path
Text Path: text that travels along an arc, wave, circle or straight path.

## beat_text_animation
Music Beat Text Animation: words pop on screen exactly on the music beats.

## video_chapters
Video Chapters: chapter timestamps + titles (auto from scenes/transcript), embedded chapter markers and an on-screen progress bar.

## subtitle_extractor
Subtitle Extractor: pulls every subtitle track out of MKV / MOV / MP4 files to .srt.
