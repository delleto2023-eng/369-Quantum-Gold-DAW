---
name: big-tony-design
description: Build web pages that don't look AI-generated and audit/redesign existing ones (Hallmark-style): 12 themes, job-first layout, slop linter with floor/reflex/finish tiers.
---
design_build_page(name, job='book|buy|subscribe|download|contact|listen|join|donate|portfolio', headline, lede, sections, facts (real only), action_url, out='index.html').
design_sloplint(page) -> floor (must fix), reflex (AI habits), finish (craft). design_audit(path) reports only. design_redesign(path, theme, mode='full|polish') keeps every link, field, handler and heading or refuses.
Themes: pharaoh-gold, limestone, ledger, cobalt, atelier, furrow, ribbon, broadside, studio-mono, jewel, hedgerow, trap-casino. design_screenshots at 8 widths with Playwright.
