---
name: collective-answer
agent: collective
description: Ask Big Tony's whole AI collective and merge the answers
phase: 3
triggers: ask all ai, collective, every model, all models, second opinion, compare models, big tony collective
tools: collective_ask, collective_members
inputs: question
outputs: one merged answer naming the members
success: at least one member answered; members named; disagreements flagged
est_minutes: 2
---
1. collective_members to see who is ready.
2. collective_ask with the question.
3. Say which members answered and flag disagreements.
4. If nobody is ready, say which key to add in .env.
