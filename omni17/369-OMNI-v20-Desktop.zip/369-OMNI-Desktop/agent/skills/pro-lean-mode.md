---
name: pro-lean-mode
agent: model_smith
description: Pro (lean) mode: make a smaller plan go further
phase: 3
triggers: pro plan, pro mode, lean, save tokens, save usage, usage limit, cheaper, budget, 20 plan
tools: set_plan, usage_report, graph_build, graph_query
inputs: current task
outputs: team in pro mode, knowledge graph built
success: set_plan pro confirmed; knowledge graph exists; usage reported before and after
est_minutes: 3
---
1. usage_report to see what has been used so far.
2. set_plan pro: 9 steps, 27 tool calls, shorter answers, no extra review passes, lighter model.
3. graph_build the project if there is no knowledge graph, so agents query the graph instead of rereading files.
4. Work in batches: one clear request per step, reuse earlier results from the workspace.
5. usage_report again and say how much was saved.
