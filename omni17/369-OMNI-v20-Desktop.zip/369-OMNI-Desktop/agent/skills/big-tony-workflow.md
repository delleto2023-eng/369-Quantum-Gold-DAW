---
name: big-tony-workflow
description: Big Tony Builder v2 workflow tools - all unlocked, no pricing.
---

# Big Tony Builder - Workflow

## compress_video
Video Compressor: shrinks file size while keeping resolution and frame rate (target size or platform preset).

## auto_resize
Auto Resize for every platform at once (16:9, 9:16, 4:5, 1:1) with subject tracking.

## keyboard_shortcuts
Keyboard Shortcut Presets: Big Tony, Premiere, Final Cut, CapCut, FL Studio maps; customise, import and export.

## assets_backup_sync
Assets Backup & Sync: mirrors your projects and assets to any synced folder (OneDrive, Google Drive, Dropbox, USB, NAS) - changed files only, optional encryption.

## dual_monitor_preview
Dual-monitor preview: opens a full-screen preview window on your second screen while you edit on the first.
