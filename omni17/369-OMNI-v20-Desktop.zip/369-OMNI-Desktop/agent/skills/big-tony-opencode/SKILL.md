---
name: big-tony-opencode
description: Use Big Tony inside OpenCode, Claude Code or Cursor with free models (NVIDIA free keys, LM Studio, Ollama) through Big Tony's MCP server.
---
python -m big_tony_builder.opencode setup <project>  -> opencode.json (LM Studio, Ollama, NVIDIA providers + big-tony MCP), .opencode/skills and .claude/skills (every Big Tony skill), AGENTS.md, .mcp.json.
Then: npm i -g opencode-ai, set NVIDIA_API_KEY (build.nvidia.com) or start LM Studio, run opencode. The harness and Big Tony Chat also have an 'nvidia' provider.
