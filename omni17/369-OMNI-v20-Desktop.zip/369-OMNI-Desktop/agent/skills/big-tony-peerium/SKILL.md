---
name: big-tony-peerium
description: Peer-to-peer compute mesh across your own computers (inspired by Huawei's Peerium architecture) - no master machine, shared global memory with RAM/disk tiers, jobs routed to the best machine (GPU, model, FFmpeg, RAM), work stealing, Nested BSP supersteps, peer swarm answers voted by peers, shared answer cache.
---
On each machine: Start Big Tony Mesh.bat (or python -m big_tony_builder.peerium --pin 369369). Same PIN on the same Wi-Fi = they find each other; or --join http://<ip>:3711.
peerium_status(); peerium_put/get(key) shared memory; peerium_run('image_generate', {'prompt':...}, needs={'gpu':True}); peerium_map('tool', items);
peerium_swarm_ask(question); peerium_cached_chat(prompt). Python: Node.bsp(job, step_fn, state, steps) for superstep programs; Node.submit/result for stealable jobs.
Safety: every request signed with the PIN; risky tools (commands, power, deleting, typing, clicking, installs) can't be run over the mesh.
