---
name: knowledge-graph-build
agent: cartographer
description: Map a project into a knowledge graph so the team stops rereading files
phase: 3
triggers: knowledge graph, graph, map project, map my project, index, graphify, codebase map
tools: graph_build, graph_report, workspace_post
inputs: project folder
outputs: graph-out/graph.json, GRAPH_REPORT.md, graph.html
success: graph.json and GRAPH_REPORT.md exist; report lists key concepts; second build re-parses only changed files
est_minutes: 3
---
1. graph_build on the project folder (default: the whole workspace).
2. graph_report and read the key concepts, communities and suggested questions.
3. workspace_post a 3-line summary so every agent sees it.
4. Rebuild after big changes; it only re-parses files that changed.
