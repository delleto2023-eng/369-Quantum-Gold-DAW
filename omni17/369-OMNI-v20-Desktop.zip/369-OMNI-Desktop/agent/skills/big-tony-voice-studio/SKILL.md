---
name: big-tony-voice-studio
description: Free local ElevenLabs-style voice studio: text-to-speech, voice design from a description, voice cloning (with consent), video dubbing with original timing, dictation, audiobooks (M4B chapters), multi-voice stories.
---
Install a voice engine once: pip install kokoro soundfile (best), or espeak-ng; cloning: pip install TTS (XTTS-v2) or F5-TTS.
voice_speak(text, voice='Ava - warm narrator'); voice_design('deep, slow, warm older narrator', name='Pharaoh'); voice_clone(sample, 'My voice', consent=True);
voice_dub(video, 'es'); voice_audiobook('book.epub', voice='Pharaoh'); voice_story('Narrator: ...\nKeeper: ...', cast={'Keeper':'Tony - deep boss'}); voice_dictate(15).
