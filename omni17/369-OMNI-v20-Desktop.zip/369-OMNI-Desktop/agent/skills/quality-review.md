---
name: quality-review
agent: guardian
description: review deliverables before release
phase: 9
triggers: review, check, verify, qa, test, pass
tools: check_outline, list_files, media_info
inputs: deliverables, original request
outputs: PASS or fix list
success: outline PASS; every promised file exists and plays; matches request
est_minutes: 5
---
1. check_outline on the plan in plans/ - it must say PASS.
2. list_files and confirm every promised file exists.
3. media_info on audio/video to confirm it plays and the length is right.
4. Compare against the original request: everything asked for is there.
5. Reply PASS, or a numbered fix list for Big Tony to send back.
