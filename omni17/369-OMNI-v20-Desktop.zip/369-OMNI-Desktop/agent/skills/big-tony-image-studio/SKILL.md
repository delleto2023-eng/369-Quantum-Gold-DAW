---
name: big-tony-image-studio
description: Free local text-to-image with MOSS-Image (5B, Apache-2.0) - cinematic scenes, portraits, anime, posters with accurate text via JSON layouts, prompt enhancer, hard-test suite, speed benchmark and blind comparisons.
---
Setup once: image_install() (PyTorch + diffusers). First image downloads the model; keep it on an SSD.
image_generate(prompt, size='square|big-square|portrait|story|landscape|wide|cinema', model='sft|base', steps=50, cfg=3, seed, count, mode='auto|gpu|component|sequential|low', backend='auto|diffusers|comfyui|sdcpp', lora).
16 GB Mac: mode='low' (auto picks it). Faster: steps=28, or a running ComfyUI. No PyTorch: stable-diffusion.cpp with GGUF (set MOSS_GGUF, MOSS_VAE, MOSS_TE, MOSS_TOKENIZER).
Text in images: image_poster(title, subtitle, art) or image_layout(caption, items with pixel boxes) -> pass the layout to image_generate. image_enhance(idea, as_layout=True) designs one for you.
Tests: image_test_suite(), image_benchmark(); image_compare({'test':{'MOSS':path,'Other':path}}) makes a blind vote page. image_gradio() opens the official app.
Weak spots: tiny text, exact data charts, complicated spatial instructions - check those results.
