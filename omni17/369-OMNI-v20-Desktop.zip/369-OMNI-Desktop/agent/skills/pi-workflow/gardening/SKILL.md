---
name: gardening
description: Tidy memory and notes: merge duplicates, archive stale items, compress.
---

Read the memory/notes folder, merge duplicates, move stale items to archive/, write a short report.
