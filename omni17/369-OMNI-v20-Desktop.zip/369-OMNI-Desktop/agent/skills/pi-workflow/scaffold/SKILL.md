---
name: scaffold
description: Start a brand new project: vision, plan, tasks, repo.
---

Ask the goal, write VISION.md, PLAN.md, TASKS.md, create folders, git init, first runnable hello-world, run it.
