---
name: review
description: One pass review for correctness and simplicity, ending in a severity-ranked verdict.
---

Read the diff, list issues as BLOCKER / MAJOR / MINOR with file:line and a fix, then one verdict: ship / fix first.
