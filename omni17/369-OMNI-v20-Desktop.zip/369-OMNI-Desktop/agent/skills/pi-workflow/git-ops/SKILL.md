---
name: git-ops
description: Safe git: read state first, never rewrite published history, scan for secrets before committing.
---

git status/diff first; grep for keys (sk-, AKIA, -----BEGIN) before commit; small commits with clear messages; never force-push main.
