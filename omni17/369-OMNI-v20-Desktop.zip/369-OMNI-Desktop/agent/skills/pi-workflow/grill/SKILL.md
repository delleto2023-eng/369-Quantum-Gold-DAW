---
name: grill
description: Adversarial questioning of a design or plan that feels shaky.
---

Ask the 10 hardest questions about failure modes, scale, cost of change and edge cases; save answers to .agent/grill/.
