---
name: plan
description: Turn a task into ordered steps and per-step specs before writing code. Not for doing the work (use build).
---

1. Read the relevant files (graph or grep first).
2. Write PLAN.md: goal, constraints, steps, each with files touched and a check.
3. Write TASKS.md as a checklist.
4. Stop and show the plan.
