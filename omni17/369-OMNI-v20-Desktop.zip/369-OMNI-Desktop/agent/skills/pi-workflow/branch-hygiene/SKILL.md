---
name: branch-hygiene
description: Create feature branches, open PRs, clean up merged branches.
---

git switch -c feat/<name>; push; open PR (gh pr create); after merge delete local and remote branch.
