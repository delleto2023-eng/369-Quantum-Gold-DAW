---
name: debug
description: Hypothesis-first bug hunt ending in a root cause and regression test. Use when something is broken.
---

1. Reproduce. 2. List hypotheses. 3. Test the cheapest one with evidence (logs, prints, bash). 4. Fix root cause. 5. Add a regression test. 6. Write a short note.
