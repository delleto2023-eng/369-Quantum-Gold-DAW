---
name: investigate-bug
description: Eight-step defect investigation for hard bugs.
---

Reproduce, isolate, read the stack, bisect (git bisect), find root cause, write failing test, fix, verify all tests.
