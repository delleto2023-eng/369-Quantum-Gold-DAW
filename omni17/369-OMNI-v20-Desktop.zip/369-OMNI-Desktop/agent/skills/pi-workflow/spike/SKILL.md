---
name: spike
description: Throwaway script to test if a risky idea can work. Ends PROCEED / PIVOT / KILL.
---

Write the smallest script that tests the riskiest assumption, run it, report the verdict with evidence. Delete or move the spike after.
