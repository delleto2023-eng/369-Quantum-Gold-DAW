---
name: script-and-prompts
agent: scribe
description: write a script, lyrics or shot prompts
phase: 3
triggers: script, lyrics, prompt, prompts, story, write, caption
tools: write_file, film_prompt
inputs: brief or idea
outputs: scripts/<name>.md
success: 3-act structure; casual voice; one prompt per shot for video
est_minutes: 10
---
1. Read any brief or research files mentioned.
2. Structure in 3 acts (setup, rise, release); keep the user's casual voice.
3. For video, write one film_prompt per shot.
4. Save to scripts/<name>.md.
