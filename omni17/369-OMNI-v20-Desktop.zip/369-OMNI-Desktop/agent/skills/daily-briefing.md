---
name: daily-briefing
agent: morning_briefer
description: Morning or weekly briefing from calendar, mail and team updates
phase: 6
triggers: briefing, morning briefing, weekly briefing, my day, my week, schedule, agenda
tools: briefing_build, calendar_read, inbox_scan
inputs: calendar and email settings
outputs: briefings/<kind>_<date>.md
success: briefing saved; schedule, mail and team updates sections present
est_minutes: 2
---
1. briefing_build (morning, or weekly for the week ahead).
2. If calendar or email are not set up, say which .env value to add.
3. Lead with what needs attention.
