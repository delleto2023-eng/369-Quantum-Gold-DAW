---
name: replit-what-s-an-artifact
description: Artifacts are publishable outputs on Replit — web apps, mobile apps, slide decks, animations, data visualizations, 3D games, and designs you can publish and share.
source: https://docs.replit.com/features/projects-and-artifacts/artifacts.md
---

# What's an Artifact?

Replit-Agent ability: What's an Artifact?.
1. Restate the user's goal for What's an Artifact? in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Artifacts are publishable outputs on Replit — web apps, mobile apps, slide decks, animations, data visualizations, 3D games, and designs you can publish and share.
