---
name: replit-app-storage-python-sdk
description: Learn how to use the official Python SDK to manage files in Replit App Storage.
source: https://docs.replit.com/features/sdks/object-storage-python-sdk.md
---

# App Storage Python SDK

Replit-Agent ability: App Storage Python SDK.
1. Restate the user's goal for App Storage Python SDK in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Learn how to use the official Python SDK to manage files in Replit App Storage.
