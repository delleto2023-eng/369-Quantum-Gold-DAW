---
name: replit-agent-customization
description: Teach Agent your team's conventions with workspace-wide custom instructions and skills, managed centrally in Workspace Settings.
source: https://docs.replit.com/features/agent/agent-customization.md
---

# Agent Customization

Replit-Agent ability: Agent Customization.
1. Restate the user's goal for Agent Customization in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Teach Agent your team's conventions with workspace-wide custom instructions and skills, managed centrally in Workspace Settings.
