---
name: replit-seo-rating
description: Measure and improve your published app's search engine optimization with Replit's SEO rating and Agent.
source: https://docs.replit.com/features/publishing/seo-rating.md
---

# SEO Rating

Replit-Agent ability: SEO Rating.
1. Restate the user's goal for SEO Rating in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Measure and improve your published app's search engine optimization with Replit's SEO rating and Agent.
