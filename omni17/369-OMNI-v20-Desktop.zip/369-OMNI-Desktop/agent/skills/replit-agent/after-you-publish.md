---
name: replit-after-you-publish
description: What happens when you select Publish: the publishing stages, updating your live app, and where to manage it.
source: https://docs.replit.com/features/publishing/after-you-publish.md
---

# After you publish

Replit-Agent ability: After you publish.
1. Restate the user's goal for After you publish in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: What happens when you select Publish: the publishing stages, updating your live app, and where to manage it.
