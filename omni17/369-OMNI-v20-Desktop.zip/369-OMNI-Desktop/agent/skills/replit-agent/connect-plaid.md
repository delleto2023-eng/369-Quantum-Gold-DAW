---
name: replit-connect-plaid
description: Set up the Plaid connector so builders can use Agent to build apps that connect financial accounts with Plaid Link for balances, transactions, and investment data.
source: https://docs.replit.com/features/integrations/plaid-connector.md
---

# Connect Plaid

Replit-Agent ability: Connect Plaid.
1. Restate the user's goal for Connect Plaid in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Set up the Plaid connector so builders can use Agent to build apps that connect financial accounts with Plaid Link for balances, transactions, and investment data.
