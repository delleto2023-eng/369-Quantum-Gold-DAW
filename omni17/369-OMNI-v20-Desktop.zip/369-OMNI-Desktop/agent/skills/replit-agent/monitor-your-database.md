---
name: replit-monitor-your-database
description: Use the Monitoring tab to see which queries are running against your production database right now, and which ones are slowing your app down.
source: https://docs.replit.com/features/data-and-storage/monitor-your-database.md
---

# Monitor your database

Replit-Agent ability: Monitor your database.
1. Restate the user's goal for Monitor your database in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Use the Monitoring tab to see which queries are running against your production database right now, and which ones are slowing your app down.
