---
name: replit-missions-routines-and-tasks
description: Choose a mission for a goal, a Routine for recurring work, or a task for a specific change to your project.
source: https://docs.replit.com/features/chats-and-routines/missions-routines-and-tasks.md
---

# Missions, Routines, and Tasks

Replit-Agent ability: Missions, Routines, and Tasks.
1. Restate the user's goal for Missions, Routines, and Tasks in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Choose a mission for a goal, a Routine for recurring work, or a task for a specific change to your project.
