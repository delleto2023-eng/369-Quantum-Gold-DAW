---
name: replit-sign-in-providers
description: Set up custom OAuth credentials for Google, GitHub, Apple, and X sign-in on apps that use Clerk Auth.
source: https://docs.replit.com/features/auth-and-identity/sign-in-providers.md
---

# Sign-in providers

Replit-Agent ability: Sign-in providers.
1. Restate the user's goal for Sign-in providers in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Set up custom OAuth credentials for Google, GitHub, Apple, and X sign-in on apps that use Clerk Auth.
