---
name: replit-data-recovery
description: Restore your development database to a checkpoint, or bring your production database back to an earlier point in time or a daily backup.
source: https://docs.replit.com/features/data-and-storage/data-recovery.md
---

# Data recovery

Replit-Agent ability: Data recovery.
1. Restate the user's goal for Data recovery in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Restore your development database to a checkpoint, or bring your production database back to an earlier point in time or a daily backup.
