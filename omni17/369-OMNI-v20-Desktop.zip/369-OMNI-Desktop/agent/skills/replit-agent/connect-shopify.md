---
name: replit-connect-shopify
description: Connect Shopify so Agent can provision a Shopify store, build a custom storefront, and manage your products and inventory from inside Replit.
source: https://docs.replit.com/features/integrations/shopify.md
---

# Connect Shopify

Replit-Agent ability: Connect Shopify.
1. Restate the user's goal for Connect Shopify in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Connect Shopify so Agent can provision a Shopify store, build a custom storefront, and manage your products and inventory from inside Replit.
