---
name: replit-migrate-from-replit-auth-to-clerk
description: Use Agent to move an existing Replit Auth app to Clerk Auth while preserving your app's user data.
source: https://docs.replit.com/features/auth-and-identity/migrate-auth-to-clerk.md
---

# Migrate from Replit Auth to Clerk

Replit-Agent ability: Migrate from Replit Auth to Clerk.
1. Restate the user's goal for Migrate from Replit Auth to Clerk in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Use Agent to move an existing Replit Auth app to Clerk Auth while preserving your app's user data.
