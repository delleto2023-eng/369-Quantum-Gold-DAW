---
name: replit-black-box-pen-tests
description: Run a Level 3 security scan that reviews source code and tests the running app through browser and network interactions.
source: https://docs.replit.com/features/security/black-box-pen-tests.md
---

# Black-box pen tests

Replit-Agent ability: Black-box pen tests.
1. Restate the user's goal for Black-box pen tests in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Run a Level 3 security scan that reviews source code and tests the running app through browser and network interactions.
