---
name: replit-app-storage-javascript-sdk
description: Learn how to use the official JavaScript SDK to manage files in Replit App Storage.
source: https://docs.replit.com/features/sdks/object-storage-javascript-sdk.md
---

# App Storage JavaScript SDK

Replit-Agent ability: App Storage JavaScript SDK.
1. Restate the user's goal for App Storage JavaScript SDK in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Learn how to use the official JavaScript SDK to manage files in Replit App Storage.
