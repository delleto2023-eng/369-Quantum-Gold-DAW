---
name: replit-replit-in-claude
description: Use Replit as a connector inside Claude to create and update Replit Apps without leaving your conversation.
source: https://docs.replit.com/features/platforms/claude.md
---

# Replit in Claude

Replit-Agent ability: Replit in Claude.
1. Restate the user's goal for Replit in Claude in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Use Replit as a connector inside Claude to create and update Replit Apps without leaving your conversation.
