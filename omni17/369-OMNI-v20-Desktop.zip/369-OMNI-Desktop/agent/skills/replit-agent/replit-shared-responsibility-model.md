---
name: replit-replit-shared-responsibility-model
description: Understand how security, compliance, and operational responsibilities are split between Replit and you when you build, ship, and run apps on Replit.
source: https://docs.replit.com/features/security/shared-responsibility-model.md
---

# Replit shared responsibility model

Replit-Agent ability: Replit shared responsibility model.
1. Restate the user's goal for Replit shared responsibility model in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Understand how security, compliance, and operational responsibilities are split between Replit and you when you build, ship, and run apps on Replit.
