---
name: replit-how-publish-updates-your-production-database
description: Learn how Replit compares, validates, and applies your development database schema changes to production when you publish your app.
source: https://docs.replit.com/features/data-and-storage/publish-database-changes.md
---

# How Publish updates your production database

Replit-Agent ability: How Publish updates your production database.
1. Restate the user's goal for How Publish updates your production database in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Learn how Replit compares, validates, and applies your development database schema changes to production when you publish your app.
