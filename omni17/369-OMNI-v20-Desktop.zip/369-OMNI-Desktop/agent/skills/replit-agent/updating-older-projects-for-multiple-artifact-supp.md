---
name: replit-updating-older-projects-for-multiple-artifact-supp
description: Add a second artifact to an older Replit project with a one-time structural update that preserves your URL, data, and deployment.
source: https://docs.replit.com/features/projects-and-artifacts/updating-projects-for-multiple-artifacts.md
---

# Updating older projects for multiple artifact support

Replit-Agent ability: Updating older projects for multiple artifact support.
1. Restate the user's goal for Updating older projects for multiple artifact support in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Add a second artifact to an older Replit project with a one-time structural update that preserves your URL, data, and deployment.
