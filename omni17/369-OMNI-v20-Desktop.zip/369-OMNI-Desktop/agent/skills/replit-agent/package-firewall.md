---
name: replit-package-firewall
description: Package Firewall blocks malicious and compromised packages at install time, before any code reaches your app. On by default, powered by Socket.
source: https://docs.replit.com/features/security/package-firewall.md
---

# Package Firewall

Replit-Agent ability: Package Firewall.
1. Restate the user's goal for Package Firewall in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Package Firewall blocks malicious and compromised packages at install time, before any code reaches your app. On by default, powered by Socket.
