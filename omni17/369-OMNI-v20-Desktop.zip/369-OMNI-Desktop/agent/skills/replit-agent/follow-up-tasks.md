---
name: replit-follow-up-tasks
description: Review, start, and bulk manage Agent follow-up task suggestions after a task finishes.
source: https://docs.replit.com/features/agent/follow-up-tasks.md
---

# Follow-up tasks

Replit-Agent ability: Follow-up tasks.
1. Restate the user's goal for Follow-up tasks in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Review, start, and bulk manage Agent follow-up task suggestions after a task finishes.
