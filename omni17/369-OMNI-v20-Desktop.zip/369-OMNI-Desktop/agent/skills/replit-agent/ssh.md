---
name: replit-ssh
description: Learn how to set up and use SSH to connect your local development environment to Replit Apps for secure remote access and file synchronization.
source: https://docs.replit.com/features/workspace-tools/ssh.md
---

# SSH

Replit-Agent ability: SSH.
1. Restate the user's goal for SSH in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Learn how to set up and use SSH to connect your local development environment to Replit Apps for secure remote access and file synchronization.
