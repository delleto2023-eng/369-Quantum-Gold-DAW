---
name: replit-monitoring-agent
description: Use Monitoring Agent to investigate production alerts, attempt fixes, and automatically republish them. Ask Agent about your published app's logs and metrics.
source: https://docs.replit.com/features/publishing/monitoring-agent.md
---

# Monitoring Agent

Replit-Agent ability: Monitoring Agent.
1. Restate the user's goal for Monitoring Agent in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Use Monitoring Agent to investigate production alerts, attempt fixes, and automatically republish them. Ask Agent about your published app's logs and metrics.
