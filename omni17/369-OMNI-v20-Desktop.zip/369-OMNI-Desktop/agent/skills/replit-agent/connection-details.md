---
name: replit-connection-details
description: Find your database's connection string, understand how credentials stay secure, and connect external tools.
source: https://docs.replit.com/features/data-and-storage/connection-details.md
---

# Connection details

Replit-Agent ability: Connection details.
1. Restate the user's goal for Connection details in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Find your database's connection string, understand how credentials stay secure, and connect external tools.
