---
name: replit-security
description: Learn why security matters when you publish from Replit, where Security tools live, and which page to use for project or workspace reviews.
source: https://docs.replit.com/features/security/overview.md
---

# Security

Replit-Agent ability: Security.
1. Restate the user's goal for Security in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Learn why security matters when you publish from Replit, where Security tools live, and which page to use for project or workspace reviews.
