---
name: replit-who-can-access-your-app
description: Control who can open your published app: public, password protected, workspace only, or invite only. No code changes required.
source: https://docs.replit.com/features/publishing/private-deployments.md
---

# Who can access your app

Replit-Agent ability: Who can access your app.
1. Restate the user's goal for Who can access your app in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Control who can open your published app: public, password protected, workspace only, or invite only. No code changes required.
