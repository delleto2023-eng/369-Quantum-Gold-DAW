---
name: replit-plan-with-replit
description: Ask Replit to plan, let it plan proactively, or use the optional /plan shortcut to explore approaches before building.
source: https://docs.replit.com/features/agent/plan-mode.md
---

# Plan with Replit

Replit-Agent ability: Plan with Replit.
1. Restate the user's goal for Plan with Replit in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Ask Replit to plan, let it plan proactively, or use the optional /plan shortcut to explore approaches before building.
