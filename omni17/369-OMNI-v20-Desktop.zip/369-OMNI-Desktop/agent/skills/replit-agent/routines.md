---
name: replit-routines
description: Schedule recurring work from a chat and receive the results in the same thread.
source: https://docs.replit.com/features/chats-and-routines/routines.md
---

# Routines

Replit-Agent ability: Routines.
1. Restate the user's goal for Routines in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Schedule recurring work from a chat and receive the results in the same thread.
