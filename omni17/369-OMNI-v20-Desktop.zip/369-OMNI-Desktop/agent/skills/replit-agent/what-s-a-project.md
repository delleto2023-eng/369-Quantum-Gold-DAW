---
name: replit-what-s-a-project
description: Learn what projects are on Replit — the container for everything you build, from web apps and mobile apps to slide decks and animated videos.
source: https://docs.replit.com/features/projects-and-artifacts/projects.md
---

# What's a Project?

Replit-Agent ability: What's a Project?.
1. Restate the user's goal for What's a Project? in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Learn what projects are on Replit — the container for everything you build, from web apps and mobile apps to slide decks and animated videos.
