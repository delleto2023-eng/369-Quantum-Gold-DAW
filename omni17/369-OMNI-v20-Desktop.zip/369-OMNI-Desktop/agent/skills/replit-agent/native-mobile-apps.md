---
name: replit-native-mobile-apps
description: Learn how to build a native mobile app with Agent, test it on your phone, and submit to App Review for App Store publishing.
source: https://docs.replit.com/features/artifact-types/building-mobile-apps.md
---

# Native Mobile Apps

Replit-Agent ability: Native Mobile Apps.
1. Restate the user's goal for Native Mobile Apps in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Learn how to build a native mobile app with Agent, test it on your phone, and submit to App Review for App Store publishing.
