---
name: replit-performance-agent
description: Scan your app for slow requests and database bottlenecks with Performance Agent, then fix the issues with Agent and republish.
source: https://docs.replit.com/features/publishing/performance-agent.md
---

# Performance Agent

Replit-Agent ability: Performance Agent.
1. Restate the user's goal for Performance Agent in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Scan your app for slow requests and database bottlenecks with Performance Agent, then fix the issues with Agent and republish.
