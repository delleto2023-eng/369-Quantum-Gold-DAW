---
name: replit-open-in-replit
description: Learn how to create an Open in Replit button that lets visitors start building from your app or website.
source: https://docs.replit.com/features/integrations/open-in-replit.md
---

# Open in Replit

Replit-Agent ability: Open in Replit.
1. Restate the user's goal for Open in Replit in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Learn how to create an Open in Replit button that lets visitors start building from your app or website.
