---
name: replit-replit-ai-integrations
description: Learn how to use AI models from OpenAI, Anthropic, Google, and more without needing your own API key.
source: https://docs.replit.com/features/integrations/replit-ai-integrations.md
---

# Replit AI Integrations

Replit-Agent ability: Replit AI Integrations.
1. Restate the user's goal for Replit AI Integrations in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Learn how to use AI models from OpenAI, Anthropic, Google, and more without needing your own API key.
