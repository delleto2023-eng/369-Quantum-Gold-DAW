---
name: replit-the-graphical-command-line-interface
description: Learn how to use CLUI, Replit's interactive command bar that lets you perform various actions across Settings, Workspace, and through Shortcuts.
source: https://docs.replit.com/features/workspace-tools/clui-graphical-cli.md
---

# The Graphical Command Line Interface

Replit-Agent ability: The Graphical Command Line Interface.
1. Restate the user's goal for The Graphical Command Line Interface in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Learn how to use CLUI, Replit's interactive command bar that lets you perform various actions across Settings, Workspace, and through Shortcuts.
