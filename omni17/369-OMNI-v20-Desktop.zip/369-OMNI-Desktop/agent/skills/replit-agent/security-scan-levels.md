---
name: replit-security-scan-levels
description: Compare Security Center Levels 1, 2, and 3 to choose dependency checks, an Agent source-code review, or a black-box test of your running app.
source: https://docs.replit.com/features/security/security-scan-levels.md
---

# Security scan levels

Replit-Agent ability: Security scan levels.
1. Restate the user's goal for Security scan levels in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Compare Security Center Levels 1, 2, and 3 to choose dependency checks, an Agent source-code review, or a black-box test of your running app.
