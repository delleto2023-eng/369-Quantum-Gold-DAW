---
name: replit-remix-an-app
description: Create your own copy of a public Replit App or template to explore, customize, and build on in your workspace.
source: https://docs.replit.com/features/projects-and-artifacts/remix-an-app.md
---

# Remix an app

Replit-Agent ability: Remix an app.
1. Restate the user's goal for Remix an app in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Create your own copy of a public Replit App or template to explore, customize, and build on in your workspace.
