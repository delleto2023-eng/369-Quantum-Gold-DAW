---
name: replit-workspace-settings
description: Find Workspace settings, manage delegated controls, and learn how account policies, Workspace exceptions, and Workspace managed settings work together.
source: https://docs.replit.com/features/collaboration/workspace-settings.md
---

# Workspace Settings

Replit-Agent ability: Workspace Settings.
1. Restate the user's goal for Workspace Settings in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Find Workspace settings, manage delegated controls, and learn how account policies, Workspace exceptions, and Workspace managed settings work together.
