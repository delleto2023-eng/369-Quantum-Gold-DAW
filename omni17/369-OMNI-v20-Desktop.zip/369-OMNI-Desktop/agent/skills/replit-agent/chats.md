---
name: replit-chats
description: Use chats to ask questions, explore information, run Routines, update your projects, and describe useful outcomes.
source: https://docs.replit.com/features/chats-and-routines/chats.md
---

# Chats

Replit-Agent ability: Chats.
1. Restate the user's goal for Chats in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Use chats to ask questions, explore information, run Routines, update your projects, and describe useful outcomes.
