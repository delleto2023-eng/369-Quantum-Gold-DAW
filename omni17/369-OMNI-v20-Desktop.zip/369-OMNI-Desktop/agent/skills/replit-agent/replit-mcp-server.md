---
name: replit-replit-mcp-server
description: Use Replit from ChatGPT, Claude, Slack, or any MCP client to create, update, and publish Replit Apps.
source: https://docs.replit.com/platforms/mcp-server.md
---

# Replit MCP Server

Replit-Agent ability: Replit MCP Server.
1. Restate the user's goal for Replit MCP Server in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Use Replit from ChatGPT, Claude, Slack, or any MCP client to create, update, and publish Replit Apps.
