---
name: replit-machine-configuration
description: Set the power and cost of the servers that run your published app: CPU, memory, and the maximum number of machines.
source: https://docs.replit.com/features/publishing/machine-configuration.md
---

# Machine configuration

Replit-Agent ability: Machine configuration.
1. Restate the user's goal for Machine configuration in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Set the power and cost of the servers that run your published app: CPU, memory, and the maximum number of machines.
