---
name: replit-development-and-production-databases
description: Understand your app's two databases: the development database you build with and the production database that serves your published app.
source: https://docs.replit.com/features/data-and-storage/development-and-production.md
---

# Development and production databases

Replit-Agent ability: Development and production databases.
1. Restate the user's goal for Development and production databases in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Understand your app's two databases: the development database you build with and the production database that serves your published app.
