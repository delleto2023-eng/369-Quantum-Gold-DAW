---
name: replit-preview
description: Learn how to use Preview to view and interact with your web app as you build.
source: https://docs.replit.com/features/editor/preview.md
---

# Preview

Replit-Agent ability: Preview.
1. Restate the user's goal for Preview in one line and plan the steps (Plan first, then Build).
2. Do it with OMNI's own tools (write_file, app_scaffold, shell, gateway models, Big Tony Builder engines) - free/open-source first.
3. Test the result in a real browser/preview (App Testing loop): click through flows, fix what breaks, re-test.
4. Save a checkpoint (versions/ archive) so it can be rolled back.
5. Report what was built, how to open it, and anything still needing a key.
Capability: Learn how to use Preview to view and interact with your web app as you build.
