---
name: big-tony-text-and-captions
description: Big Tony Builder text and captions tools - all features unlocked, no credits or pricing.
---

# Big Tony Builder - Text And Captions

Call these with `from big_tony_builder import TOOLS` or the CLI `python -m big_tony_builder <tool> key=value`.

## speech_to_text
Speech to Text / Auto Captions: transcribes to SRT with faster-whisper or openai-whisper if installed,
else through the OMNI model router.

## dynamic_subtitles
Dynamic Subtitles: animated word-by-word captions (karaoke highlight / pop / glow) burned into the video.

## smart_text_correction
Smart Text Correction: fixes speech-to-text caption errors (personal dictionary + common fixes + optional AI pass), batch.

## text_titles
Titles & text animations (gold serif, neon, typewriter, lower third).

## ai_copywriting
AI Copywriting: ideas, scripts, titles, descriptions, hashtags, hooks.

## ai_thumbnail
AI Thumbnail Creator: picks the sharpest, most expressive frame(s) and adds a bold gold title.
