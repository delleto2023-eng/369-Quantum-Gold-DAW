---
name: dev-ship
agent: dev_agent
description: Fix and ship a 369 app
phase: 9
triggers: dev agent, ship it, build the app, fix the code, run build
tools: button_doctor, run_build, read_file
inputs: app path
outputs: fixed app + build status
success: no dead buttons; build status reported
est_minutes: 9
---
1. read_file the app.
2. button_doctor and fix issues.
3. run_build status (gh needed).
