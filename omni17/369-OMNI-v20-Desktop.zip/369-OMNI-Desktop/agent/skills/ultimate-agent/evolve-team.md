---
name: evolve-team
agent: evo
description: Review runs and improve the team
phase: 9
triggers: evolve, improve the agents, what went wrong, self improve, upgrade skills
tools: recall, remember, write_file
inputs: recent runs
outputs: evolution log
success: 3 concrete improvements logged
est_minutes: 5
---
1. recall recent results.
2. Find 3 improvements.
3. write_file evolution/log.md and remember them.
