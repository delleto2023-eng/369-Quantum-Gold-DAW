---
name: omni-one-voice
agent: omni
description: Answer any message as 369 OMNI
phase: 3
triggers: omni, one voice, answer as one, ask omni, big tony command center
tools: omni_answer, model_pick
inputs: message
outputs: one merged answer
success: answer given in one voice; skills and model named
est_minutes: 2
---
1. model_pick for the message.
2. omni_answer with mode auto.
3. Reply in one voice.
