---
name: usage-check
agent: model_smith
description: Check token use and recommend Pro or Max mode
phase: 9
triggers: usage, tokens, how much used, limit, running out, credits, cost
tools: usage_report, set_plan, agent_signals
inputs: none
outputs: usage summary and a mode recommendation
success: input/output tokens and calls reported; recommendation given (pro or max)
est_minutes: 3
---
1. usage_report.
2. agent_signals to spot agents or tools that keep failing (wasted calls).
3. Recommend pro mode if usage is heavy or a limit is close, max mode for big one-off builds.
4. Offer to switch with set_plan.
