---
name: sacred-plan
agent: metatron
description: Lay a goal onto the 3-6-9 structure
phase: 3
triggers: metatron, sacred plan, 369 plan, structure this, blueprint
tools: outline_369, remember
inputs: goal
outputs: 3-6-9 plan
success: plan has Plan, Create, Complete with owners
est_minutes: 3
---
1. Split the goal into Plan, Create, Complete.
2. outline_369 for proportions if visual.
3. remember the plan.
