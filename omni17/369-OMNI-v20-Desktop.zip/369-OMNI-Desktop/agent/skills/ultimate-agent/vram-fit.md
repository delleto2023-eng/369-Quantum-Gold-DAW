---
name: vram-fit
agent: model_smith
description: choose model size, quant and offload for a given GPU
phase: 6
triggers: which model, fit, vram, quant, quantization, moe, offload
tools: model_fit, model_catalog, model_catalog_add, write_file
inputs: VRAM, RAM, candidate models
outputs: plans/model_choice.md
success: each candidate has a plan; chosen model is FULL GPU or MOE OFFLOAD
est_minutes: 5
---
1. Rough tiers (Q4, MoE offload, 32k context): 4 GB -> small MoE (about 3B active) with experts in RAM; 6-8 GB -> 30-35B MoE like Qwen3.6-35B-A3B; 12 GB -> 30B+ MoE with more layers on GPU; 16 GB -> about 27B dense at IQ3_S (about 12 GB) or bigger MoE.
2. MoE models: keep attention and shared layers on GPU and push expert weights to RAM (--n-cpu-moe or -ot exps=CPU). Needs RAM of at least weights_gb.
3. Always use -ctk q8_0 -ctv q8_0 to halve KV cache memory.
4. Bigger model or lower quant? Prefer the bigger model at 3-4 bits over a smaller one at 8 bits; avoid going under about 3 bits.
5. Little spare VRAM: drop -ub 1024 and --moe-cache-mib. Short on RAM: add --load-mode mmap (slow).
6. NVFP4 models (Edge0) run best on RTX 50-series; on older cards prefer a GGUF conversion if one exists.
7. When a new model shows up in a video or model card, save it with model_catalog_add (mark unverified claims).
8. Write the decision with model_fit numbers to plans/model_choice.md.
