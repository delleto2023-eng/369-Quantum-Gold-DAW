---
name: data-predict
agent: data_brain
description: Offline predictions from a CSV
phase: 9
triggers: predict, forecast, csv, data brain, trend, projection
tools: data_load, data_predict
inputs: CSV, y column
outputs: prediction with confidence
success: prediction plus R2 and confidence reported
est_minutes: 3
---
1. data_load to see the columns.
2. data_predict with the y column (and x if given).
3. Report the number, R2 and confidence.
