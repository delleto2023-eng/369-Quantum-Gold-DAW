---
name: vision-plan
agent: visionary
description: turn any goal into a 3, 6 or 9 step plan
phase: 3
triggers: plan, outline, roadmap, strategy, big project, steps
tools: outline_369, recall
inputs: goal
outputs: plans/<goal>_369.md, 3D cube files
success: outline_369 says PASS; every step names an agent; last steps are guardian then publisher
est_minutes: 5
---
1. Recall memory for related past work and preferences.
2. Choose the smallest number of steps that fits: 3 (simple), 6 (medium) or 9 (big).
3. For each step name: the agent, the skill (if any), the input, and the expected output file.
4. Order the steps Plan -> Create -> Complete; the last steps are always guardian review then publisher.
5. Use outline_369 to save it as a 3-6-9 outline (3D Metatron's Cube) and return it; it must say PASS.
