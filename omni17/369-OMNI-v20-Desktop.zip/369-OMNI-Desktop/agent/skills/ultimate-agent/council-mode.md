---
name: council-mode
agent: omni
description: Council mode: 3 skills draft, OMNI merges
phase: 6
triggers: council, council mode, second opinion, three drafts, hard question
tools: council_run, omni_answer
inputs: question
outputs: merged council answer
success: 3 drafts written and merged
est_minutes: 3
---
1. council_run on the question.
2. Check the merged answer covers every draft.
3. Reply in one voice.
