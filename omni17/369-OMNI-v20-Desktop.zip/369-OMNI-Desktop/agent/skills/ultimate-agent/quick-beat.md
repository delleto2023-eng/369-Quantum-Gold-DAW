---
name: quick-beat
agent: tony_jr
description: Tony Jr fast beat sketch
phase: 6
triggers: quick beat, fast beat, tony jr, sketch a beat
tools: forge_song, song_structure
inputs: genre, bpm
outputs: sketch WAV
success: sketch WAV exists
est_minutes: 2
---
1. song_structure for a short form.
2. forge_song with 1 loop.
3. Hand to Tony Mix if keeping it.
