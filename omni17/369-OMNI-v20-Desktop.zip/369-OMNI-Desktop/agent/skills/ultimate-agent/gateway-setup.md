---
name: gateway-setup
agent: tool_clones
description: Set up OMNI's model gateway
phase: 3
triggers: openrouter, ollama url, gateway, keys tab, api key
tools: gateway_route, gateway_status
inputs: key or URL
outputs: omni/gateway.json
success: gateway_status says Ready
est_minutes: 1
---
1. gateway_status.
2. gateway_route with the OpenRouter key or Ollama URL.
3. gateway_status again to confirm.
