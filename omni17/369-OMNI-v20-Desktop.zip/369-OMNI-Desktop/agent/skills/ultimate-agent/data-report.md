---
name: data-report
agent: data_brain
description: Summarize a CSV
phase: 6
triggers: data report, analyze csv, stats, summarize spreadsheet
tools: data_load, data_report
inputs: CSV
outputs: data/<name>_report.md
success: report saved with every number column
est_minutes: 2
---
1. data_load.
2. data_report.
3. Point out the biggest trend.
