---
name: big-tony-assist-analyze-export
description: Big Tony Builder assist analyze export tools - all features unlocked, no credits or pricing.
---

# Big Tony Builder - Assist Analyze Export

Call these with `from big_tony_builder import TOOLS` or the CLI `python -m big_tony_builder <tool> key=value`.

## ai_mate
AI Mate: editing assistant - checks media for conflicting/unsafe parameters and gives tips (unlimited, no conversation cap).

## media_analysis
AI Media Analysis: scenes, loudness peaks, highlight scores, keywords and edit suggestions with timestamps.
Adds an LLM description/keywords when the model router is available.

## asset_library
Creative asset library: indexes your own music, SFX, stock clips, images, templates and LUTs
(e.g. the 369 Netlabel Archive and Crown Kits) so every tool can pull from it.

## multi_source_recording
Multi-Source Recording: screen + webcam (picture-in-picture) + mic in one take. Returns the ffmpeg command
for this OS and runs it when `seconds` is given.

## screen_recorder


## export
Export in multiple formats, up to 4K, never watermarked.

## probe

