---
name: max-power-mode
agent: model_smith
description: Max (power) mode: full 3-6-9 limits for big builds
phase: 6
triggers: max plan, max mode, power mode, full power, go deep, best quality, 200 plan
tools: set_plan, usage_report, model_catalog
inputs: current task
outputs: team in max mode
success: set_plan max confirmed; self-checks back on; usage reported
est_minutes: 3
---
1. set_plan max: 27 steps, 81 tool calls, self-checks on, deep memory recall, strongest model.
2. Use the full 3-6-9 cycle: outline, create with every needed specialist, Guardian review.
3. For long jobs, still keep the knowledge graph fresh so power goes into the work, not rereading.
4. usage_report at the end.
