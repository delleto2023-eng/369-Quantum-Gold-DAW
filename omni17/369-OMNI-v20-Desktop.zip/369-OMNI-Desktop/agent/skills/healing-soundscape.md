---
name: healing-soundscape
agent: sound_alchemist
description: a healing-frequency track (optionally under a beat)
phase: 6
triggers: healing, frequency, hz, 432, 528, 963, binaural, isochronic, tone, meditation
tools: tone_generate, audio_mix, audio_normalize
inputs: frequency, mode, optional beat
outputs: audio/<name>_mastered.wav
success: wav exists; normalized to -14 LUFS; default length 369 s
est_minutes: 5
---
1. Pick the frequency from the request (default 432 Hz; 528 for repair, 963 for unity).
2. tone_generate in the requested mode; default length 369 seconds (6:09).
3. If there is a beat, audio_mix the tone at volume 0.3 under it.
4. audio_normalize the result. Report the final file.
