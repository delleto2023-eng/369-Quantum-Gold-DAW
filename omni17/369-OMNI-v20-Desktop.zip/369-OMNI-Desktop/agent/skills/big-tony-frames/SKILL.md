---
name: big-tony-frames
description: Make videos from HTML (HyperFrames-style): quick 15-second ads, or custom compositions with timed clips, GSAP/CSS motion, catalog blocks, rendered to MP4.
---
Quick ad: frames_make_ad(product, message, seconds=15, vertical=True, images=[...], music=path) -> storyboard, voiceover, MP4 (no browser needed).
Custom: frames_new_composition(path, blocks=[('fade-title',{'text':'Launch day','start':0,'dur':3}),('end-card',{'text':'369','start':12,'dur':3})]) -> frames_lint -> frames_render (Playwright + FFmpeg, frame-accurate).
Rules: stage needs data-composition-id/width/height; clips need data-start/data-duration; GSAP timelines paused and registered on window.__timelines; no Math.random or timers.
