---
name: button-doctor-build
agent: button_doctor
description: Find dead buttons and run or check GitHub builds
phase: 9
triggers: button doctor, broken buttons, dead buttons, bugs, run build, installers, github, workflow
tools: button_doctor, run_build
inputs: DAW HTML file, repo
outputs: bug report, build status
success: dead buttons listed by label; script syntax checked; build status shown
est_minutes: 5
---
1. button_doctor on the DAW HTML.
2. Report dead buttons, swallowed errors and syntax.
3. run_build (approval) to start or check the installers or publish workflow.
4. Hand fixes to the coder.
