---
name: best_answer
agent: big_tony
description: Big Tony collective - asks every model, then a judge merges the best answer.
phase: 6
triggers: answer, asks, best, collective, judge, merges, model, then, tony
tools: best_answer
inputs: prompt, models, judge
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Big Tony collective: asks every model, then a judge merges the best answer.

Run: big_tony_builder.TOOLS['best_answer'](...)  or  python -m big_tony_builder best_answer key=value
