---
name: ai_copywriting
agent: big_tony
description: AI Copywriting - ideas, scripts, titles, descriptions, hashtags, hooks.
phase: 6
triggers: copywriting, descriptions, hashtags, hooks, ideas, scripts, titles
tools: ai_copywriting
inputs: topic, kind, platform, tone
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Copywriting: ideas, scripts, titles, descriptions, hashtags, hooks.

Run: big_tony_builder.TOOLS['ai_copywriting'](...)  or  python -m big_tony_builder ai_copywriting key=value
