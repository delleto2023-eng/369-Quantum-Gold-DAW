---
name: sanitize
agent: big_tony
description: Privacy Mode sanitization layer - masks PII, keys and your trade-secret terms before any prompt leaves the device.
phase: 6
triggers: before, device, keys, layer, leaves, masks, mode, privacy, prompt, sanitization
tools: sanitize
inputs: text, extra_terms
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Privacy Mode sanitization layer: masks PII, keys and your trade-secret terms before any prompt leaves the device.

Run: big_tony_builder.TOOLS['sanitize'](...)  or  python -m big_tony_builder sanitize key=value
