---
name: dynamic_subtitles
agent: big_tony
description: Dynamic Subtitles - animated word-by-word captions (karaoke highlight / pop / glow) burned into the video.
phase: 6
triggers: animated, burned, captions, dynamic, glow, highlight, karaoke, subtitles, video, word
tools: dynamic_subtitles
inputs: video, srt, out, style, position
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Dynamic Subtitles: animated word-by-word captions (karaoke highlight / pop / glow) burned into the video.

Run: big_tony_builder.TOOLS['dynamic_subtitles'](...)  or  python -m big_tony_builder dynamic_subtitles key=value
