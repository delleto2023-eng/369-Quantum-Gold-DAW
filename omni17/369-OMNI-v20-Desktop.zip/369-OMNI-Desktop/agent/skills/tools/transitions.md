---
name: transitions
agent: big_tony
description: Transitions - 40+ (fade, wipe, slide, circle, dissolve, pixelize, radial, zoom, smooth...).
phase: 6
triggers: circle, dissolve, fade, pixelize, radial, slide, smooth, transitions, wipe, zoom
tools: transitions
inputs: clip_a, clip_b, out, kind, duration
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Transitions: 40+ (fade, wipe, slide, circle, dissolve, pixelize, radial, zoom, smooth...).

Run: big_tony_builder.TOOLS['transitions'](...)  or  python -m big_tony_builder transitions key=value
