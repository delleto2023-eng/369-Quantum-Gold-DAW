---
name: ai_mate
agent: big_tony
description: AI Mate - editing assistant - checks media for conflicting/unsafe parameters and gives tips (unlimited, no conversation cap).
phase: 6
triggers: assistant, checks, conflicting, conversation, editing, gives, mate, media, parameters, tips
tools: ai_mate
inputs: question, project
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Mate: editing assistant - checks media for conflicting/unsafe parameters and gives tips (unlimited, no conversation cap).

Run: big_tony_builder.TOOLS['ai_mate'](...)  or  python -m big_tony_builder ai_mate key=value
