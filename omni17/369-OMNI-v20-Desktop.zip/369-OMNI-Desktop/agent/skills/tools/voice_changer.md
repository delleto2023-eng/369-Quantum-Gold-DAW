---
name: voice_changer
agent: big_tony
description: Voice Changer - robot, chipmunk, deep, monster, female, male, radio, telephone, echo/cave, alien, whisper, megaphone, big tony.
phase: 6
triggers: alien, cave, changer, chipmunk, deep, echo, female, male, megaphone, monster
tools: voice_changer
inputs: audio, out, voice
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Voice Changer: robot, chipmunk, deep, monster, female, male, radio, telephone, echo/cave, alien, whisper, megaphone, big tony.

Run: big_tony_builder.TOOLS['voice_changer'](...)  or  python -m big_tony_builder voice_changer key=value
