---
name: ai_thumbnail
agent: big_tony
description: AI Thumbnail Creator - picks the sharpest, most expressive frame(s) and adds a bold gold title.
phase: 6
triggers: adds, bold, creator, expressive, frame, gold, most, picks, sharpest, thumbnail
tools: ai_thumbnail
inputs: video, out, title, count
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Thumbnail Creator: picks the sharpest, most expressive frame(s) and adds a bold gold title.

Run: big_tony_builder.TOOLS['ai_thumbnail'](...)  or  python -m big_tony_builder ai_thumbnail key=value
