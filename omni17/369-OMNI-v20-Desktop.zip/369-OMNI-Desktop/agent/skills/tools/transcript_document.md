---
name: transcript_document
agent: big_tony
description: Exports the transcript as an editable numbered document for text-based editing.
phase: 6
triggers: based, document, editable, editing, exports, numbered, text, transcript
tools: transcript_document
inputs: video, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Exports the transcript as an editable numbered document for text-based editing.

Run: big_tony_builder.TOOLS['transcript_document'](...)  or  python -m big_tony_builder transcript_document key=value
