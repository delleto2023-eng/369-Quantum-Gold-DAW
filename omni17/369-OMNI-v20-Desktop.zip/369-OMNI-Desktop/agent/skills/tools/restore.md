---
name: restore
agent: big_tony
description: restore
phase: 6
triggers: restore
tools: restore
inputs: text, mapping
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
restore

Run: big_tony_builder.TOOLS['restore'](...)  or  python -m big_tony_builder restore key=value
