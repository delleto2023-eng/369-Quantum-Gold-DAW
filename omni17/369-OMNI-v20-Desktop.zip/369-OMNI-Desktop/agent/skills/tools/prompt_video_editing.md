---
name: prompt_video_editing
agent: big_tony
description: Prompt Video Editing - type what you want ("make it vertical, brighter, add gold glow, remove silence, add captions") and Big Tony runs the tools.
phase: 6
triggers: brighter, captions, editing, glow, gold, make, prompt, remove, runs, silence
tools: prompt_video_editing
inputs: video, prompt, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Prompt Video Editing: type what you want ("make it vertical, brighter, add gold glow, remove silence, add captions") and Big Tony runs the tools.

Run: big_tony_builder.TOOLS['prompt_video_editing'](...)  or  python -m big_tony_builder prompt_video_editing key=value
