---
name: instant_mode
agent: big_tony
description: Instant Mode - drop in clips/photos, get a finished beat-synced, graded, captioned edit in one click.
phase: 6
triggers: beat, captioned, click, clips, drop, edit, finished, graded, instant, mode
tools: instant_mode
inputs: media, music, style, ratio, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Instant Mode: drop in clips/photos, get a finished beat-synced, graded, captioned edit in one click.

Run: big_tony_builder.TOOLS['instant_mode'](...)  or  python -m big_tony_builder instant_mode key=value
