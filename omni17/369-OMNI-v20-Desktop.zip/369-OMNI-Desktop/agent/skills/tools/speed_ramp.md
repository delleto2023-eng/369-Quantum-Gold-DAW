---
name: speed_ramp
agent: big_tony
description: Speed Ramping - smooth speed curves (presets - hero, bullet, montage, jumper, flash in/out) or custom points [(t,speed)].
phase: 6
triggers: bullet, curves, custom, flash, hero, jumper, montage, points, presets, ramp
tools: speed_ramp
inputs: video, out, preset, points
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Speed Ramping: smooth speed curves (presets: hero, bullet, montage, jumper, flash in/out) or custom points [(t,speed)].

Run: big_tony_builder.TOOLS['speed_ramp'](...)  or  python -m big_tony_builder speed_ramp key=value
