---
name: make_lut
agent: big_tony
description: Original .cube colour LUT (36 named looks; seed adds variations).
phase: 6
triggers: adds, colour, cube, looks, make, named, original, seed, variations
tools: make_lut
inputs: look, out, size, seed
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Original .cube colour LUT (36 named looks; seed adds variations).

Run: big_tony_builder.TOOLS['make_lut'](...)  or  python -m big_tony_builder make_lut key=value
