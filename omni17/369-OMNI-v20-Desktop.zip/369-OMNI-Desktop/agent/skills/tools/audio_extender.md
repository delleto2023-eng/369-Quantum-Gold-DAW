---
name: audio_extender
agent: big_tony
description: AI Audio Extender - lengthens music naturally by looping at matching beat points with crossfades (no pitch change).
phase: 6
triggers: audio, beat, change, crossfades, extender, lengthens, looping, matching, music, naturally
tools: audio_extender
inputs: audio, seconds, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Audio Extender: lengthens music naturally by looping at matching beat points with crossfades (no pitch change).

Run: big_tony_builder.TOOLS['audio_extender'](...)  or  python -m big_tony_builder audio_extender key=value
