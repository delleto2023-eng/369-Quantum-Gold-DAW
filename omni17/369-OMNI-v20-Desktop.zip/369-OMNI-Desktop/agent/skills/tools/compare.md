---
name: compare
agent: big_tony
description: Compare multiple responses side by side before choosing an answer.
phase: 6
triggers: answer, before, choosing, compare, multiple, responses, side
tools: compare
inputs: prompt, models
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Compare multiple responses side by side before choosing an answer.

Run: big_tony_builder.TOOLS['compare'](...)  or  python -m big_tony_builder compare key=value
