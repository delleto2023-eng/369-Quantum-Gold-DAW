---
name: web_search
agent: big_tony
description: DuckDuckGo HTML search (no key). Returns [{title,url,snippet}].
phase: 6
triggers: duckduckgo, html, returns, search, snippet, title
tools: web_search
inputs: q, n
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
DuckDuckGo HTML search (no key). Returns [{title,url,snippet}].

Run: big_tony_builder.TOOLS['web_search'](...)  or  python -m big_tony_builder web_search key=value
