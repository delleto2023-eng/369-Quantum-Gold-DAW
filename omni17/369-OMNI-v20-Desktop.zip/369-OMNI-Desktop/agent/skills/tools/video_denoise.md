---
name: video_denoise
agent: big_tony
description: AI Video Denoise with presets (light / medium / strong / film-grain-safe).
phase: 6
triggers: denoise, film, grain, light, medium, presets, safe, strong, video
tools: video_denoise
inputs: video, out, preset
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Video Denoise with presets (light / medium / strong / film-grain-safe).

Run: big_tony_builder.TOOLS['video_denoise'](...)  or  python -m big_tony_builder video_denoise key=value
