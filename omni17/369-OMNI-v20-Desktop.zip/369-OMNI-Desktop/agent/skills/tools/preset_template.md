---
name: preset_template
agent: big_tony
description: Preset Templates - one-click styled edits - gold_promo, vlog, trailer, lyric, slideshow, reel.
phase: 6
triggers: click, edits, gold, lyric, preset, promo, reel, slideshow, styled, template
tools: preset_template
inputs: clips, template, out, title, music
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Preset Templates: one-click styled edits - gold_promo, vlog, trailer, lyric, slideshow, reel.

Run: big_tony_builder.TOOLS['preset_template'](...)  or  python -m big_tony_builder preset_template key=value
