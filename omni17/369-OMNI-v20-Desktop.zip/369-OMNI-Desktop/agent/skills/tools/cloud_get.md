---
name: cloud_get
agent: big_tony
description: cloud get
phase: 6
triggers: cloud
tools: cloud_get
inputs: root, stack, rel, out, pin
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
cloud get

Run: big_tony_builder.TOOLS['cloud_get'](...)  or  python -m big_tony_builder cloud_get key=value
