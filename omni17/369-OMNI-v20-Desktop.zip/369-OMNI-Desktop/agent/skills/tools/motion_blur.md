---
name: motion_blur
agent: big_tony
description: Motion Blur - natural cinematic blur on fast moves, cuts, zooms and pans in one click.
phase: 6
triggers: blur, cinematic, click, cuts, fast, motion, moves, natural, pans, zooms
tools: motion_blur
inputs: video, out, amount
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Motion Blur: natural cinematic blur on fast moves, cuts, zooms and pans in one click.

Run: big_tony_builder.TOOLS['motion_blur'](...)  or  python -m big_tony_builder motion_blur key=value
