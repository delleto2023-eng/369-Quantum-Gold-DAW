---
name: smart_bgm
agent: big_tony
description: Smart BGM Generation - analyses the video's pace and mood, generates matching background music and mixes it with ducking.
phase: 6
triggers: analyses, background, ducking, generates, generation, matching, mixes, mood, music, pace
tools: smart_bgm
inputs: video, out, mood
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Smart BGM Generation: analyses the video's pace and mood, generates matching background music and mixes it with ducking.

Run: big_tony_builder.TOOLS['smart_bgm'](...)  or  python -m big_tony_builder smart_bgm key=value
