---
name: text_based_editing
agent: big_tony
description: AI Text-Based Editing - transcribe, then edit the video like a document - delete words/lines and the matching video is cut.
phase: 6
triggers: based, delete, document, edit, editing, like, lines, matching, text, then
tools: text_based_editing
inputs: video, transcript_srt, delete_phrases, keep_lines, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Text-Based Editing: transcribe, then edit the video like a document - delete words/lines and the matching video is cut.

Run: big_tony_builder.TOOLS['text_based_editing'](...)  or  python -m big_tony_builder text_based_editing key=value
