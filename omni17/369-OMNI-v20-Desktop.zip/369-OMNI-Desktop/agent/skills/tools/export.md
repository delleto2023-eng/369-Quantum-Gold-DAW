---
name: export
agent: big_tony
description: Export in multiple formats, up to 4K, never watermarked.
phase: 6
triggers: export, formats, multiple, never, watermarked
tools: export
inputs: video, fmt, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Export in multiple formats, up to 4K, never watermarked.

Run: big_tony_builder.TOOLS['export'](...)  or  python -m big_tony_builder export key=value
