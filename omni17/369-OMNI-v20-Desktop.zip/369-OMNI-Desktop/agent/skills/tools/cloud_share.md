---
name: cloud_share
agent: big_tony
description: Create a share link token (expires) for a file.
phase: 6
triggers: cloud, create, expires, file, link, share, token
tools: cloud_share
inputs: root, stack, rel, hours
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Create a share link token (expires) for a file.

Run: big_tony_builder.TOOLS['cloud_share'](...)  or  python -m big_tony_builder cloud_share key=value
