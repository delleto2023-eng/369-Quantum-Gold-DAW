---
name: idea_to_video
agent: big_tony
description: AI Idea to Video - concept -> story script (via OMNI model router) -> scenes -> video.
phase: 6
triggers: concept, idea, model, omni, router, scenes, script, story, video
tools: idea_to_video
inputs: idea, out, ratio, scenes
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Idea to Video: concept -> story script (via OMNI model router) -> scenes -> video.

Run: big_tony_builder.TOOLS['idea_to_video'](...)  or  python -m big_tony_builder idea_to_video key=value
