---
name: build_app
agent: big_tony
description: AI Builder (apps) - turns a description into a single-file working web app with local data storage.
phase: 6
triggers: apps, build, builder, data, description, file, local, single, storage, turns
tools: build_app
inputs: brief, out, model
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Builder (apps): turns a description into a single-file working web app with local data storage.

Run: big_tony_builder.TOOLS['build_app'](...)  or  python -m big_tony_builder build_app key=value
