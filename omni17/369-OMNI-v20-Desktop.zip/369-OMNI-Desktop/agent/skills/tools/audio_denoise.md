---
name: audio_denoise
agent: big_tony
description: AI Voice Enhancement - rumble cut, denoise, de-ess, presence boost, compression, broadcast loudness (-14 LUFS).
phase: 6
triggers: audio, boost, broadcast, compression, denoise, enhancement, loudness, lufs, presence, rumble
tools: audio_denoise
inputs: media, out, strength
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Voice Enhancement: rumble cut, denoise, de-ess, presence boost, compression, broadcast loudness (-14 LUFS).

Run: big_tony_builder.TOOLS['audio_denoise'](...)  or  python -m big_tony_builder audio_denoise key=value
