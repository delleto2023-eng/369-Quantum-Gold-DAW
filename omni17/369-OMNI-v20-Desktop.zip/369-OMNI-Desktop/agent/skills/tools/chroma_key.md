---
name: chroma_key
agent: big_tony
description: Green Screen / Chroma Key - replaces a green/blue screen with any video or image.
phase: 6
triggers: blue, chroma, green, image, replaces, screen, video
tools: chroma_key
inputs: foreground, background, out, key_color, similarity, blend
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Green Screen / Chroma Key: replaces a green/blue screen with any video or image.

Run: big_tony_builder.TOOLS['chroma_key'](...)  or  python -m big_tony_builder chroma_key key=value
