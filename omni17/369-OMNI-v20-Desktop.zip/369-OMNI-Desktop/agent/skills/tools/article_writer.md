---
name: article_writer
agent: big_tony
description: AI Article Writer - outline -> SEO article in Markdown with headings, meta description and FAQ.
phase: 6
triggers: article, description, headings, markdown, meta, outline, writer
tools: article_writer
inputs: topic, words, tone, seo_keywords, model
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Article Writer: outline -> SEO article in Markdown with headings, meta description and FAQ.

Run: big_tony_builder.TOOLS['article_writer'](...)  or  python -m big_tony_builder article_writer key=value
