---
name: frame_interpolation
agent: big_tony
description: AI Video Interpolation - motion-compensated frame interpolation for buttery 60/120 fps or smooth slow motion.
phase: 6
triggers: buttery, compensated, frame, interpolation, motion, slow, smooth, video
tools: frame_interpolation
inputs: video, out, fps, slowmo
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Video Interpolation: motion-compensated frame interpolation for buttery 60/120 fps or smooth slow motion.

Run: big_tony_builder.TOOLS['frame_interpolation'](...)  or  python -m big_tony_builder frame_interpolation key=value
