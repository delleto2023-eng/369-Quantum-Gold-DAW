---
name: portrait_mode
agent: big_tony
description: Portrait tools - skin smoothing + soft background blur with centre-weighted subject focus.
phase: 6
triggers: background, blur, centre, focus, mode, portrait, skin, smoothing, soft, subject
tools: portrait_mode
inputs: video, out, skin_smooth, bg_blur
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Portrait tools: skin smoothing + soft background blur with centre-weighted subject focus.

Run: big_tony_builder.TOOLS['portrait_mode'](...)  or  python -m big_tony_builder portrait_mode key=value
