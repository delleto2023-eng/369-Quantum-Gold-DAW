---
name: probe
agent: big_tony
description: probe
phase: 6
triggers: probe
tools: probe
inputs: path
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
probe

Run: big_tony_builder.TOOLS['probe'](...)  or  python -m big_tony_builder probe key=value
