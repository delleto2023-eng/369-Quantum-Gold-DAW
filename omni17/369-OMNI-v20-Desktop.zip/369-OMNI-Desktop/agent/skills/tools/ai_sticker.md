---
name: ai_sticker
agent: big_tony
description: AI Sticker Generator - describe a sticker, get a transparent PNG (image model when connected; offline gold badge sticker).
phase: 6
triggers: badge, connected, describe, generator, gold, image, model, offline, sticker, transparent
tools: ai_sticker
inputs: prompt, out, size
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Sticker Generator: describe a sticker, get a transparent PNG (image model when connected; offline gold badge sticker).

Run: big_tony_builder.TOOLS['ai_sticker'](...)  or  python -m big_tony_builder ai_sticker key=value
