---
name: assets_backup_sync
agent: big_tony
description: Assets Backup & Sync - mirrors your projects and assets to any synced folder (OneDrive, Google Drive, Dropbox, USB, NAS) - changed files only, optional encryption.
phase: 6
triggers: assets, backup, changed, drive, dropbox, encryption, files, folder, google, mirrors
tools: assets_backup_sync
inputs: source, backup_dir, encrypt_pin
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Assets Backup & Sync: mirrors your projects and assets to any synced folder (OneDrive, Google Drive, Dropbox, USB, NAS) - changed files only, optional encryption.

Run: big_tony_builder.TOOLS['assets_backup_sync'](...)  or  python -m big_tony_builder assets_backup_sync key=value
