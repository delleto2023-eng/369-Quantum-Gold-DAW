---
name: video_extender
agent: big_tony
description: AI Video Extender - extend a clip forward/backward. Uses the generative backend when connected,
phase: 6
triggers: backend, backward, clip, connected, extend, extender, forward, generative, video
tools: video_extender
inputs: video, out, seconds, direction, method, prompt
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Video Extender: extend a clip forward/backward. Uses the generative backend when connected,
otherwise motion-interpolated slow-motion, boomerang or held frame with gentle zoom.

Run: big_tony_builder.TOOLS['video_extender'](...)  or  python -m big_tony_builder video_extender key=value
