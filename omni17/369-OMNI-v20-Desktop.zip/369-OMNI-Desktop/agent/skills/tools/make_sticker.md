---
name: make_sticker
agent: big_tony
description: Original sticker/element PNG with transparency. 20 shapes x 7 jewel palettes x unlimited seeds.
phase: 6
triggers: element, jewel, make, original, palettes, seeds, shapes, sticker, transparency, unlimited
tools: make_sticker
inputs: kind, palette, seed, size, out, text
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Original sticker/element PNG with transparency. 20 shapes x 7 jewel palettes x unlimited seeds.

Run: big_tony_builder.TOOLS['make_sticker'](...)  or  python -m big_tony_builder make_sticker key=value
