---
name: make_track
agent: big_tony
description: Original music track (intro / verse / hook / bridge / outro) from genre + seed. Returns path (.mp3 or .wav).
phase: 6
triggers: bridge, genre, hook, intro, make, music, original, outro, path, returns
tools: make_track
inputs: genre, seed, seconds, mood, key_hz, out, stems_dir
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Original music track (intro / verse / hook / bridge / outro) from genre + seed. Returns path (.mp3 or .wav).

Run: big_tony_builder.TOOLS['make_track'](...)  or  python -m big_tony_builder make_track key=value
