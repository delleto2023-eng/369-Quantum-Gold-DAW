---
name: smart_scene_cut
agent: big_tony
description: Smart Scene Cut - auto-clips the most notable moments into a highlights reel.
phase: 6
triggers: auto, clips, highlights, moments, most, notable, reel, scene, smart
tools: smart_scene_cut
inputs: video, out, top, min_len
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Smart Scene Cut: auto-clips the most notable moments into a highlights reel.

Run: big_tony_builder.TOOLS['smart_scene_cut'](...)  or  python -m big_tony_builder smart_scene_cut key=value
