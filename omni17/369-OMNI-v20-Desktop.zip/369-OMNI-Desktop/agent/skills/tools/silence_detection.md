---
name: silence_detection
agent: big_tony
description: Silence Detection - finds pauses and (optionally) cuts them out for jump-cut edits.
phase: 6
triggers: cuts, detection, edits, finds, jump, optionally, pauses, silence, them
tools: silence_detection
inputs: media, out, threshold_db, min_silence, remove
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Silence Detection: finds pauses and (optionally) cuts them out for jump-cut edits.

Run: big_tony_builder.TOOLS['silence_detection'](...)  or  python -m big_tony_builder silence_detection key=value
