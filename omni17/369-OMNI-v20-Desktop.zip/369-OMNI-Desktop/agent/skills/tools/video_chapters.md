---
name: video_chapters
agent: big_tony
description: Video Chapters - chapter timestamps + titles (auto from scenes/transcript), embedded chapter markers and an on-screen progress bar.
phase: 6
triggers: auto, chapter, chapters, embedded, markers, progress, scenes, screen, timestamps, titles
tools: video_chapters
inputs: video, chapters, out, bar
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Video Chapters: chapter timestamps + titles (auto from scenes/transcript), embedded chapter markers and an on-screen progress bar.

Run: big_tony_builder.TOOLS['video_chapters'](...)  or  python -m big_tony_builder video_chapters key=value
