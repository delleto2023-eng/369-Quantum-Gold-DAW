---
name: detect_beats
agent: big_tony
description: Beat detection (onset energy) - used by Auto Beat Sync.
phase: 6
triggers: auto, beat, beats, detect, detection, energy, onset, sync, used
tools: detect_beats
inputs: audio
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Beat detection (onset energy) - used by Auto Beat Sync.

Run: big_tony_builder.TOOLS['detect_beats'](...)  or  python -m big_tony_builder detect_beats key=value
