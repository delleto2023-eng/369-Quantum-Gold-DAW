---
name: research_agent
agent: big_tony
description: Research Agent - searches the web, reads sources, writes a cited report with [n] references.
phase: 6
triggers: agent, cited, reads, references, report, research, searches, sources, writes
tools: research_agent
inputs: question, depth, model
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Research Agent: searches the web, reads sources, writes a cited report with [n] references.

Run: big_tony_builder.TOOLS['research_agent'](...)  or  python -m big_tony_builder research_agent key=value
