---
name: text_to_video
agent: big_tony
description: AI Text to Video - splits a script into scenes, renders cinematic title scenes with voiceover + music.
phase: 6
triggers: cinematic, music, renders, scenes, script, splits, text, title, video, voiceover
tools: text_to_video
inputs: script, out, ratio, style, seconds_per_scene, voiceover, music, bg_images
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Text to Video: splits a script into scenes, renders cinematic title scenes with voiceover + music.

Run: big_tony_builder.TOOLS['text_to_video'](...)  or  python -m big_tony_builder text_to_video key=value
