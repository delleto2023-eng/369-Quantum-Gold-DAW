---
name: social_content_planner
agent: big_tony
description: Social Content Planner - plan/schedule videos for YouTube, TikTok, Instagram, X, Facebook; exports a calendar (.ics) and best-time suggestions.
phase: 6
triggers: best, calendar, content, exports, facebook, instagram, plan, planner, schedule, social
tools: social_content_planner
inputs: posts, plan_file, add, platform, when, caption, video, ics_out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Social Content Planner: plan/schedule videos for YouTube, TikTok, Instagram, X, Facebook; exports a calendar (.ics) and best-time suggestions.

Run: big_tony_builder.TOOLS['social_content_planner'](...)  or  python -m big_tony_builder social_content_planner key=value
