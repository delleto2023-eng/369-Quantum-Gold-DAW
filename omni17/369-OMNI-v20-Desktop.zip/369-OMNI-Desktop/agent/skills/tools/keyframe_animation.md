---
name: keyframe_animation
agent: big_tony
description: Keyframing - animate zoom / position over time. keyframes=[(t,zoom,cx,cy)] with cx,cy in 0..1.
phase: 6
triggers: animate, animation, keyframe, keyframes, keyframing, over, position, time, zoom
tools: keyframe_animation
inputs: video, keyframes, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Keyframing: animate zoom / position over time. keyframes=[(t,zoom,cx,cy)] with cx,cy in 0..1.

Run: big_tony_builder.TOOLS['keyframe_animation'](...)  or  python -m big_tony_builder keyframe_animation key=value
