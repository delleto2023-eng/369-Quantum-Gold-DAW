---
name: audio_stretch
agent: big_tony
description: Audio Stretch - fits music to an exact length without changing pitch.
phase: 6
triggers: audio, changing, exact, fits, length, music, pitch, stretch, without
tools: audio_stretch
inputs: audio, seconds, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Audio Stretch: fits music to an exact length without changing pitch.

Run: big_tony_builder.TOOLS['audio_stretch'](...)  or  python -m big_tony_builder audio_stretch key=value
