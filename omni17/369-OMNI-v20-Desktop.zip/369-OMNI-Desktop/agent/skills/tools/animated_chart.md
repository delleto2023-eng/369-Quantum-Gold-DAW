---
name: animated_chart
agent: big_tony
description: Animated Charts - bar / line / pie charts that grow on screen, gold themed. data={label -value}.
phase: 6
triggers: animated, chart, charts, data, gold, grow, label, line, screen, themed
tools: animated_chart
inputs: data, out, kind, title, seconds, ratio
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Animated Charts: bar / line / pie charts that grow on screen, gold themed. data={label:value}.

Run: big_tony_builder.TOOLS['animated_chart'](...)  or  python -m big_tony_builder animated_chart key=value
