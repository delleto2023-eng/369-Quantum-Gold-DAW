---
name: ai_copilot
agent: big_tony
description: AI Mate - editing assistant - checks media for conflicting/unsafe parameters and gives tips (unlimited, no conversation cap).
phase: 6
triggers: assistant, checks, conflicting, conversation, copilot, editing, gives, mate, media, parameters
tools: ai_copilot
inputs: question, project
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Mate: editing assistant - checks media for conflicting/unsafe parameters and gives tips (unlimited, no conversation cap).

Run: big_tony_builder.TOOLS['ai_copilot'](...)  or  python -m big_tony_builder ai_copilot key=value
