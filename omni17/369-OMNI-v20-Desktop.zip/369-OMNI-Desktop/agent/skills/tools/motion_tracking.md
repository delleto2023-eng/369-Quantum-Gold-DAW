---
name: motion_tracking
agent: big_tony
description: Motion / Planar Tracking - pins an image/text overlay to a moving region (tracked from the start box).
phase: 6
triggers: image, motion, moving, overlay, pins, planar, region, start, text, tracked
tools: motion_tracking
inputs: video, x, y, w, h, overlay, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Motion / Planar Tracking: pins an image/text overlay to a moving region (tracked from the start box).

Run: big_tony_builder.TOOLS['motion_tracking'](...)  or  python -m big_tony_builder motion_tracking key=value
