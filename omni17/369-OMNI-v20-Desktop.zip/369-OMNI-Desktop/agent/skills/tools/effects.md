---
name: effects
agent: big_tony
description: Effects & filters - glow, VHS, glitch, film grain, light leak, mirror, old film, blur, shake, gold shimmer...
phase: 6
triggers: blur, effects, film, filters, glitch, glow, gold, grain, leak, light
tools: effects
inputs: video, effect, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Effects & filters: glow, VHS, glitch, film grain, light leak, mirror, old film, blur, shake, gold shimmer...

Run: big_tony_builder.TOOLS['effects'](...)  or  python -m big_tony_builder effects key=value
