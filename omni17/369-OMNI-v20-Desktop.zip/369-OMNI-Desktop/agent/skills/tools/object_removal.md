---
name: object_removal
agent: big_tony
description: AI Object Removal - removes a logo/object/person from a region (delogo inpaint or blur-fill).
phase: 6
triggers: blur, delogo, fill, inpaint, logo, object, person, region, removal, removes
tools: object_removal
inputs: video, x, y, w, h, out, method
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Object Removal: removes a logo/object/person from a region (delogo inpaint or blur-fill).

Run: big_tony_builder.TOOLS['object_removal'](...)  or  python -m big_tony_builder object_removal key=value
