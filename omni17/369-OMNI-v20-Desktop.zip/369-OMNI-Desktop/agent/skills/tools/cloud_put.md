---
name: cloud_put
agent: big_tony
description: Upload a file into a stack (quota enforced; encrypted at rest if the cloud has encryption on).
phase: 6
triggers: cloud, encrypted, encryption, enforced, file, quota, rest, stack, upload
tools: cloud_put
inputs: root, stack, src, dest_rel, pin
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Upload a file into a stack (quota enforced; encrypted at rest if the cloud has encryption on).

Run: big_tony_builder.TOOLS['cloud_put'](...)  or  python -m big_tony_builder cloud_put key=value
