---
name: auto_captions
agent: big_tony
description: Speech to Text / Auto Captions - transcribes to SRT with faster-whisper or openai-whisper if installed,
phase: 6
triggers: auto, captions, faster, installed, openai, speech, text, transcribes, whisper
tools: auto_captions
inputs: media, out, language
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Speech to Text / Auto Captions: transcribes to SRT with faster-whisper or openai-whisper if installed,
else through the OMNI model router.

Run: big_tony_builder.TOOLS['auto_captions'](...)  or  python -m big_tony_builder auto_captions key=value
