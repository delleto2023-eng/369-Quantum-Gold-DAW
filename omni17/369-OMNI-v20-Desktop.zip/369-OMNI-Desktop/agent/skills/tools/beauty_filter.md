---
name: beauty_filter
agent: big_tony
description: AI Video Beauty Filter - skin smoothing, even tone, brighten eyes/face, soft glow.
phase: 6
triggers: beauty, brighten, even, eyes, face, filter, glow, skin, smoothing, soft
tools: beauty_filter
inputs: video, out, smooth, brighten, slim
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Video Beauty Filter: skin smoothing, even tone, brighten eyes/face, soft glow.

Run: big_tony_builder.TOOLS['beauty_filter'](...)  or  python -m big_tony_builder beauty_filter key=value
