---
name: stabilize
agent: big_tony
description: Video Stabilization - two-pass vidstab when available, else deshake.
phase: 6
triggers: available, deshake, pass, stabilization, stabilize, video, vidstab
tools: stabilize
inputs: video, out, strength
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Video Stabilization: two-pass vidstab when available, else deshake.

Run: big_tony_builder.TOOLS['stabilize'](...)  or  python -m big_tony_builder stabilize key=value
