---
name: skin_tone_protection
agent: big_tony
description: AI Color Palette - matches the colour style of a reference still (any film frame) or a built-in look,
phase: 6
triggers: built, color, colour, film, frame, look, matches, palette, protection, reference
tools: skin_tone_protection
inputs: video, reference_image, look, out, protect_skin, strength
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Color Palette: matches the colour style of a reference still (any film frame) or a built-in look,
with a skin-tone protection blend.

Run: big_tony_builder.TOOLS['skin_tone_protection'](...)  or  python -m big_tony_builder skin_tone_protection key=value
