---
name: background_remover
agent: big_tony
description: AI Background Remover (portrait cutout) - uses rembg/mediapipe if installed, else smart chroma/colour key.
phase: 6
triggers: background, chroma, colour, cutout, installed, mediapipe, portrait, rembg, remover, smart
tools: background_remover
inputs: media, out, color, replace_with
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Background Remover (portrait cutout): uses rembg/mediapipe if installed, else smart chroma/colour key.

Run: big_tony_builder.TOOLS['background_remover'](...)  or  python -m big_tony_builder background_remover key=value
