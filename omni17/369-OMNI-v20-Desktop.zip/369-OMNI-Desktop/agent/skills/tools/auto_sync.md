---
name: auto_sync
agent: big_tony
description: Auto Synchronization - aligns a separately recorded audio track to the camera audio by waveform cross-correlation.
phase: 6
triggers: aligns, audio, auto, camera, correlation, cross, recorded, separately, sync, synchronization
tools: auto_sync
inputs: video, external_audio, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Auto Synchronization: aligns a separately recorded audio track to the camera audio by waveform cross-correlation.

Run: big_tony_builder.TOOLS['auto_sync'](...)  or  python -m big_tony_builder auto_sync key=value
