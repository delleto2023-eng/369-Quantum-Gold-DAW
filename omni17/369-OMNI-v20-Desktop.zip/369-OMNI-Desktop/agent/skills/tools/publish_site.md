---
name: publish_site
agent: big_tony
description: Cloud hosting / custom domain - deploys with the Netlify, Vercel, GitHub Pages or Cloudflare CLI you have installed.
phase: 6
triggers: cloud, cloudflare, custom, deploys, domain, github, have, hosting, installed, netlify
tools: publish_site
inputs: folder, provider
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Cloud hosting / custom domain: deploys with the Netlify, Vercel, GitHub Pages or Cloudflare CLI you have installed.

Run: big_tony_builder.TOOLS['publish_site'](...)  or  python -m big_tony_builder publish_site key=value
