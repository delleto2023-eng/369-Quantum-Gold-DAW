---
name: voice_enhancer
agent: big_tony
description: AI Voice Enhancement - rumble cut, denoise, de-ess, presence boost, compression, broadcast loudness (-14 LUFS).
phase: 6
triggers: boost, broadcast, compression, denoise, enhancement, enhancer, loudness, lufs, presence, rumble
tools: voice_enhancer
inputs: media, out, strength
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Voice Enhancement: rumble cut, denoise, de-ess, presence boost, compression, broadcast loudness (-14 LUFS).

Run: big_tony_builder.TOOLS['voice_enhancer'](...)  or  python -m big_tony_builder voice_enhancer key=value
