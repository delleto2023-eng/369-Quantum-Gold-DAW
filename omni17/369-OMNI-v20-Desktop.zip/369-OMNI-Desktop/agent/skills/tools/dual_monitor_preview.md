---
name: dual_monitor_preview
agent: big_tony
description: Dual-monitor preview - opens a full-screen preview window on your second screen while you edit on the first.
phase: 6
triggers: dual, edit, first, full, monitor, opens, preview, screen, second, while
tools: dual_monitor_preview
inputs: video
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Dual-monitor preview: opens a full-screen preview window on your second screen while you edit on the first.

Run: big_tony_builder.TOOLS['dual_monitor_preview'](...)  or  python -m big_tony_builder dual_monitor_preview key=value
