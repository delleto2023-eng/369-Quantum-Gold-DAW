---
name: make_overlay
agent: big_tony
description: Original overlay clip (use in screen/add blend mode) - light leaks, dust, flares, gold dust, scanlines.
phase: 6
triggers: blend, clip, dust, flares, gold, leaks, light, make, mode, original
tools: make_overlay
inputs: kind, seed, seconds, size, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Original overlay clip (use in screen/add blend mode) - light leaks, dust, flares, gold dust, scanlines.

Run: big_tony_builder.TOOLS['make_overlay'](...)  or  python -m big_tony_builder make_overlay key=value
