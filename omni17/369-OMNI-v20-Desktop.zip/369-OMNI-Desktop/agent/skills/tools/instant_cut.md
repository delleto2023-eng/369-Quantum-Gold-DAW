---
name: instant_cut
agent: big_tony
description: Instant Cutter - lossless, no re-encode trim/cut for huge files (seconds, not minutes).
phase: 6
triggers: cutter, encode, files, huge, instant, lossless, minutes, seconds, trim
tools: instant_cut
inputs: video, start, end, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Instant Cutter: lossless, no re-encode trim/cut for huge files (seconds, not minutes).

Run: big_tony_builder.TOOLS['instant_cut'](...)  or  python -m big_tony_builder instant_cut key=value
