---
name: make_sfx
agent: big_tony
description: Original sound effect. 30 kinds x unlimited seeds.
phase: 6
triggers: effect, kinds, make, original, seeds, sound, unlimited
tools: make_sfx
inputs: kind, seed, out, seconds
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Original sound effect. 30 kinds x unlimited seeds.

Run: big_tony_builder.TOOLS['make_sfx'](...)  or  python -m big_tony_builder make_sfx key=value
