---
name: color_mask
agent: big_tony
description: Color Mask - adjust only the areas matching a chosen colour (hue/sat/brightness) - rest of the frame untouched.
phase: 6
triggers: adjust, areas, brightness, chosen, color, colour, frame, mask, matching, only
tools: color_mask
inputs: video, target_color, out, similarity, hue_shift, saturation, brightness
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Color Mask: adjust only the areas matching a chosen colour (hue/sat/brightness) - rest of the frame untouched.

Run: big_tony_builder.TOOLS['color_mask'](...)  or  python -m big_tony_builder color_mask key=value
