---
name: audio_ducking
agent: big_tony
description: audio ducking
phase: 6
triggers: audio, ducking
tools: audio_ducking
inputs: video, music, out, volume
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
audio ducking

Run: big_tony_builder.TOOLS['audio_ducking'](...)  or  python -m big_tony_builder audio_ducking key=value
