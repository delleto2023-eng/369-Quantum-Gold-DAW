---
name: text_to_speech
agent: big_tony
description: Text to Speech - offline voiceover (espeak-ng / macOS say / Windows SAPI) or a connected voice model.
phase: 6
triggers: connected, espeak, macos, model, offline, sapi, speech, text, voice, voiceover
tools: text_to_speech
inputs: text, out, voice, speed
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Text to Speech: offline voiceover (espeak-ng / macOS say / Windows SAPI) or a connected voice model.

Run: big_tony_builder.TOOLS['text_to_speech'](...)  or  python -m big_tony_builder text_to_speech key=value
