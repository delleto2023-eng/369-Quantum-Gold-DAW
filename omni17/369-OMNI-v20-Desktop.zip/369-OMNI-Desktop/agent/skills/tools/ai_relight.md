---
name: ai_relight
agent: big_tony
description: AI Relight - fixes dark, backlit or uneven scenes - lifts shadows, balances exposure, keeps highlights natural.
phase: 6
triggers: backlit, balances, dark, exposure, fixes, highlights, keeps, lifts, natural, relight
tools: ai_relight
inputs: video, out, strength
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Relight: fixes dark, backlit or uneven scenes - lifts shadows, balances exposure, keeps highlights natural.

Run: big_tony_builder.TOOLS['ai_relight'](...)  or  python -m big_tony_builder ai_relight key=value
