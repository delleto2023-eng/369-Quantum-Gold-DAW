---
name: lens_correction
agent: big_tony
description: Lens Correction - removes fisheye/barrel distortion (GoPro, DJI, phone wide presets).
phase: 6
triggers: barrel, correction, distortion, fisheye, gopro, lens, phone, presets, removes, wide
tools: lens_correction
inputs: video, out, k1, k2, preset
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Lens Correction: removes fisheye/barrel distortion (GoPro, DJI, phone wide presets).

Run: big_tony_builder.TOOLS['lens_correction'](...)  or  python -m big_tony_builder lens_correction key=value
