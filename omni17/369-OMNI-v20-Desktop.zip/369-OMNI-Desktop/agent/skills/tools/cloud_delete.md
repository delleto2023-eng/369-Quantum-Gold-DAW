---
name: cloud_delete
agent: big_tony
description: cloud delete
phase: 6
triggers: cloud, delete
tools: cloud_delete
inputs: root, stack, rel
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
cloud delete

Run: big_tony_builder.TOOLS['cloud_delete'](...)  or  python -m big_tony_builder cloud_delete key=value
