---
name: apply_lut
agent: big_tony
description: LUTs - apply any .cube / .3dl colour LUT (with strength blend).
phase: 6
triggers: apply, blend, colour, cube, luts, strength
tools: apply_lut
inputs: video, lut_file, out, strength
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
LUTs: apply any .cube / .3dl colour LUT (with strength blend).

Run: big_tony_builder.TOOLS['apply_lut'](...)  or  python -m big_tony_builder apply_lut key=value
