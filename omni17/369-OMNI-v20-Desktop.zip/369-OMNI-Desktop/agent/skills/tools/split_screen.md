---
name: split_screen
agent: big_tony
description: Split Screen - 2-9 clips in grid / side-by-side / stacked layouts.
phase: 6
triggers: clips, grid, layouts, screen, side, split, stacked
tools: split_screen
inputs: videos, out, layout, ratio
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Split Screen: 2-9 clips in grid / side-by-side / stacked layouts.

Run: big_tony_builder.TOOLS['split_screen'](...)  or  python -m big_tony_builder split_screen key=value
