---
name: text_path
agent: big_tony
description: Text Path - text that travels along an arc, wave, circle or straight path.
phase: 6
triggers: along, circle, path, straight, text, travels, wave
tools: text_path
inputs: video, text, out, path, start, duration
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Text Path: text that travels along an arc, wave, circle or straight path.

Run: big_tony_builder.TOOLS['text_path'](...)  or  python -m big_tony_builder text_path key=value
