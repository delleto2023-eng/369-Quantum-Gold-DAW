---
name: image_sequence_to_video
agent: big_tony
description: Image Sequence to Video with adjustable frame rate (folder or pattern like frames/img_%04d.png).
phase: 6
triggers: adjustable, folder, frame, frames, image, like, pattern, rate, sequence, video
tools: image_sequence_to_video
inputs: folder_or_pattern, out, fps
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Image Sequence to Video with adjustable frame rate (folder or pattern like frames/img_%04d.png).

Run: big_tony_builder.TOOLS['image_sequence_to_video'](...)  or  python -m big_tony_builder image_sequence_to_video key=value
