---
name: face_mosaic
agent: big_tony
description: AI Face Mosaic - auto blurs/pixelates faces (OpenCV face detection if installed; else tracked subject box).
phase: 6
triggers: auto, blurs, detection, face, faces, installed, mosaic, opencv, pixelates, subject
tools: face_mosaic
inputs: video, out, style, boxes
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Face Mosaic: auto blurs/pixelates faces (OpenCV face detection if installed; else tracked subject box).

Run: big_tony_builder.TOOLS['face_mosaic'](...)  or  python -m big_tony_builder face_mosaic key=value
