---
name: eye_contact
agent: big_tony
description: AI Eye Contact - redirects gaze to the camera via a connected gaze model (e.g. LivePortrait); offline it returns the clip unchanged and says so.
phase: 6
triggers: camera, clip, connected, contact, gaze, liveportrait, model, offline, redirects, returns
tools: eye_contact
inputs: video, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Eye Contact: redirects gaze to the camera via a connected gaze model (e.g. LivePortrait); offline it returns the clip unchanged and says so.

Run: big_tony_builder.TOOLS['eye_contact'](...)  or  python -m big_tony_builder eye_contact key=value
