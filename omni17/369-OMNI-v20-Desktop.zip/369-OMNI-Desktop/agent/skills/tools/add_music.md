---
name: add_music
agent: big_tony
description: add music
phase: 6
triggers: music
tools: add_music
inputs: video, music, out, volume, duck
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
add music

Run: big_tony_builder.TOOLS['add_music'](...)  or  python -m big_tony_builder add_music key=value
