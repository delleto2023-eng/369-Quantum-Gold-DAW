---
name: image_to_prompt
agent: big_tony
description: Image to Prompt - reverse-engineers an AI prompt from an image (vision model when connected; offline colour/composition analysis).
phase: 6
triggers: analysis, colour, composition, connected, engineers, image, model, offline, prompt, reverse
tools: image_to_prompt
inputs: image
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Image to Prompt: reverse-engineers an AI prompt from an image (vision model when connected; offline colour/composition analysis).

Run: big_tony_builder.TOOLS['image_to_prompt'](...)  or  python -m big_tony_builder image_to_prompt key=value
