---
name: compress_video
agent: big_tony
description: Video Compressor - shrinks file size while keeping resolution and frame rate (target size or platform preset).
phase: 6
triggers: compress, compressor, file, frame, keeping, platform, preset, rate, resolution, shrinks
tools: compress_video
inputs: video, out, target_mb, platform
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Video Compressor: shrinks file size while keeping resolution and frame rate (target size or platform preset).

Run: big_tony_builder.TOOLS['compress_video'](...)  or  python -m big_tony_builder compress_video key=value
