---
name: asset_library
agent: big_tony
description: Creative asset library - indexes your own music, SFX, stock clips, images, templates and LUTs
phase: 6
triggers: asset, clips, creative, images, indexes, library, luts, music, stock, templates
tools: asset_library
inputs: folder, out_json
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Creative asset library: indexes your own music, SFX, stock clips, images, templates and LUTs
(e.g. the 369 Netlabel Archive and Crown Kits) so every tool can pull from it.

Run: big_tony_builder.TOOLS['asset_library'](...)  or  python -m big_tony_builder asset_library key=value
