---
name: search_vault
agent: big_tony
description: Search the vault by words (genre, mood, colour, shape, look) - returns ready-to-build asset recipes.
phase: 6
triggers: asset, build, colour, genre, look, mood, ready, recipes, returns, search
tools: search_vault
inputs: query, limit
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Search the vault by words (genre, mood, colour, shape, look) - returns ready-to-build asset recipes.

Run: big_tony_builder.TOOLS['search_vault'](...)  or  python -m big_tony_builder search_vault key=value
