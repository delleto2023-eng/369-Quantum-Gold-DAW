---
name: smart_text_correction
agent: big_tony
description: Smart Text Correction - fixes speech-to-text caption errors (personal dictionary + common fixes + optional AI pass), batch.
phase: 6
triggers: batch, caption, common, correction, dictionary, errors, fixes, optional, pass, personal
tools: smart_text_correction
inputs: srt, out, dictionary, use_ai
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Smart Text Correction: fixes speech-to-text caption errors (personal dictionary + common fixes + optional AI pass), batch.

Run: big_tony_builder.TOOLS['smart_text_correction'](...)  or  python -m big_tony_builder smart_text_correction key=value
