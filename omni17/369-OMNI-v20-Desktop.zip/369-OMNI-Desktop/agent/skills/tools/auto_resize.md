---
name: auto_resize
agent: big_tony
description: Auto Resize for every platform at once (16 -9, 9 -16, 4 -5, 1 -1) with subject tracking.
phase: 6
triggers: auto, once, platform, resize, subject, tracking
tools: auto_resize
inputs: video, platforms, out_dir
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Auto Resize for every platform at once (16:9, 9:16, 4:5, 1:1) with subject tracking.

Run: big_tony_builder.TOOLS['auto_resize'](...)  or  python -m big_tony_builder auto_resize key=value
