---
name: cloud_setup
agent: big_tony
description: Create the cloud with N stacks of size_gb each. Checks the drive has the space. reserve=True pre-allocates
phase: 6
triggers: allocates, checks, cloud, create, drive, each, reserve, setup, size, space
tools: cloud_setup
inputs: root, stacks, size_gb, pin, names, reserve, encrypt
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Create the cloud with N stacks of size_gb each. Checks the drive has the space. reserve=True pre-allocates
the space as a placeholder file per stack so nothing else can take it (released automatically as you fill it).

Run: big_tony_builder.TOOLS['cloud_setup'](...)  or  python -m big_tony_builder cloud_setup key=value
