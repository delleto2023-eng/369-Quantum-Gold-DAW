---
name: ai_sound_effects
agent: big_tony
description: AI Sound Effects - auto-places matching SFX on scene cuts (whoosh), loud peaks (impact) and the intro (riser).
phase: 6
triggers: auto, cuts, effects, impact, intro, loud, matching, peaks, places, riser
tools: ai_sound_effects
inputs: video, out, kind
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Sound Effects: auto-places matching SFX on scene cuts (whoosh), loud peaks (impact) and the intro (riser).

Run: big_tony_builder.TOOLS['ai_sound_effects'](...)  or  python -m big_tony_builder ai_sound_effects key=value
