---
name: presentation_builder
agent: big_tony
description: Presentation Builder - generates a gold-themed HTML slide deck (arrow keys to navigate).
phase: 6
triggers: arrow, builder, deck, generates, gold, html, keys, navigate, presentation, slide
tools: presentation_builder
inputs: topic, slides, out, model
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Presentation Builder: generates a gold-themed HTML slide deck (arrow keys to navigate).

Run: big_tony_builder.TOOLS['presentation_builder'](...)  or  python -m big_tony_builder presentation_builder key=value
