---
name: multi_source_recording
agent: big_tony
description: Multi-Source Recording - screen + webcam (picture-in-picture) + mic in one take. Returns the ffmpeg command
phase: 6
triggers: command, ffmpeg, multi, picture, recording, returns, screen, source, take, webcam
tools: multi_source_recording
inputs: out, seconds, screen, camera, mic
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Multi-Source Recording: screen + webcam (picture-in-picture) + mic in one take. Returns the ffmpeg command
for this OS and runs it when `seconds` is given.

Run: big_tony_builder.TOOLS['multi_source_recording'](...)  or  python -m big_tony_builder multi_source_recording key=value
