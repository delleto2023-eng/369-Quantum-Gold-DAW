---
name: ai_vocal_remover
agent: big_tony
description: AI Vocal Remover / stem split - uses Demucs/Spleeter if installed, else centre-channel cancel (instrumental) + mid (vocal).
phase: 6
triggers: cancel, centre, channel, demucs, installed, instrumental, remover, spleeter, split, stem
tools: ai_vocal_remover
inputs: audio, out_dir
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Vocal Remover / stem split: uses Demucs/Spleeter if installed, else centre-channel cancel (instrumental) + mid (vocal).

Run: big_tony_builder.TOOLS['ai_vocal_remover'](...)  or  python -m big_tony_builder ai_vocal_remover key=value
