---
name: reframe_360
agent: big_tony
description: 360 Video Reframing - equirectangular 360 -> flat shot with chosen angle, FOV and optional smooth pan.
phase: 6
triggers: angle, chosen, equirectangular, flat, optional, reframe, reframing, shot, smooth, video
tools: reframe_360
inputs: video, out, yaw, pitch, fov, ratio, pan_speed
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
360 Video Reframing: equirectangular 360 -> flat shot with chosen angle, FOV and optional smooth pan.

Run: big_tony_builder.TOOLS['reframe_360'](...)  or  python -m big_tony_builder reframe_360 key=value
