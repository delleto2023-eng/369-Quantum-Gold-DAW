---
name: lip_sync
agent: big_tony
description: AI Lip Sync / translation - translates the transcript (model router), voices it, and syncs it to the clip.
phase: 6
triggers: clip, model, router, sync, syncs, transcript, translates, translation, voices
tools: lip_sync
inputs: video, new_audio, out, translate_to, transcript
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Lip Sync / translation: translates the transcript (model router), voices it, and syncs it to the clip.
True mouth re-animation runs through a connected lip-sync model (Wav2Lip/SadTalker) when available;
otherwise the dub is time-fitted to the original speech length.

Run: big_tony_builder.TOOLS['lip_sync'](...)  or  python -m big_tony_builder lip_sync key=value
