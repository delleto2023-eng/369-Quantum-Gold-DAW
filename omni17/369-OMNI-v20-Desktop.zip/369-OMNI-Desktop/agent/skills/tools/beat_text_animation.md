---
name: beat_text_animation
agent: big_tony
description: Music Beat Text Animation - words pop on screen exactly on the music beats.
phase: 6
triggers: animation, beat, beats, exactly, music, screen, text, words
tools: beat_text_animation
inputs: video, words, music, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Music Beat Text Animation: words pop on screen exactly on the music beats.

Run: big_tony_builder.TOOLS['beat_text_animation'](...)  or  python -m big_tony_builder beat_text_animation key=value
