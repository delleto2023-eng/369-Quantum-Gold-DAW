---
name: ai_music_generator
agent: big_tony
description: AI Music Generator - royalty-free procedural backing tracks (trap, lofi, cinematic, ambient, house) tuned to 432 Hz.
phase: 6
triggers: ambient, backing, cinematic, free, generator, house, lofi, music, procedural, royalty
tools: ai_music_generator
inputs: out, seconds, mood, bpm, key_hz
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Music Generator: royalty-free procedural backing tracks (trap, lofi, cinematic, ambient, house) tuned to 432 Hz.
Routes to a connected music model when available.

Run: big_tony_builder.TOOLS['ai_music_generator'](...)  or  python -m big_tony_builder ai_music_generator key=value
