---
name: image_enhancer
agent: big_tony
description: AI Image Enhancer - restore blurry/old/low-res photos - upscale, denoise, sharpen, auto colour (Real-ESRGAN if installed).
phase: 6
triggers: auto, blurry, colour, denoise, enhancer, esrgan, image, installed, photos, real
tools: image_enhancer
inputs: image, out, scale
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Image Enhancer: restore blurry/old/low-res photos - upscale, denoise, sharpen, auto colour (Real-ESRGAN if installed).

Run: big_tony_builder.TOOLS['image_enhancer'](...)  or  python -m big_tony_builder image_enhancer key=value
