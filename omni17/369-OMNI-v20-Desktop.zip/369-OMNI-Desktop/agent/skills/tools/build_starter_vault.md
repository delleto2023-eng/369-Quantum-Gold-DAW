---
name: build_starter_vault
agent: big_tony
description: Builds the downloadable starter library on disk + catalogue.json.
phase: 6
triggers: build, builds, catalogue, disk, downloadable, json, library, starter, vault
tools: build_starter_vault
inputs: out_dir, music_per_genre, music_seconds, sfx_per_kind, stickers, backgrounds
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Builds the downloadable starter library on disk + catalogue.json.

Run: big_tony_builder.TOOLS['build_starter_vault'](...)  or  python -m big_tony_builder build_starter_vault key=value
