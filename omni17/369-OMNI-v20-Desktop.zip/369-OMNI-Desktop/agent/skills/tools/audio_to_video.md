---
name: audio_to_video
agent: big_tony
description: Audio to Video - visuals synchronised to the audio (spectrum / waves / circle / cover-art pulse).
phase: 6
triggers: audio, circle, cover, pulse, spectrum, synchronised, video, visuals, waves
tools: audio_to_video
inputs: audio, out, ratio, mode, title, image
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Audio to Video: visuals synchronised to the audio (spectrum / waves / circle / cover-art pulse).

Run: big_tony_builder.TOOLS['audio_to_video'](...)  or  python -m big_tony_builder audio_to_video key=value
