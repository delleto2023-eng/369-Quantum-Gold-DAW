---
name: decrypt
agent: big_tony
description: decrypt
phase: 6
triggers: decrypt
tools: decrypt
inputs: blob, passphrase
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
decrypt

Run: big_tony_builder.TOOLS['decrypt'](...)  or  python -m big_tony_builder decrypt key=value
