---
name: build_website
agent: big_tony
description: AI Builder - generates a full multi-page website from a brief (copy by AI), with forms, bookings, user accounts and an admin panel
phase: 6
triggers: accounts, admin, bookings, brief, build, builder, copy, forms, full, generates
tools: build_website
inputs: brief, out_dir, pages, with_forms, with_booking, with_accounts, model
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Builder: generates a full multi-page website from a brief (copy by AI), with forms, bookings, user accounts and an admin panel
served by the included Python backend (`server.py`).

Run: big_tony_builder.TOOLS['build_website'](...)  or  python -m big_tony_builder build_website key=value
