---
name: get_asset
agent: big_tony
description: Fetch-or-build any vault asset on demand - get_asset('music','trap',42) / ('sfx','bling',3) / ('lut','pharaoh_gold') / ('sticker','crown',1,palette='ruby').
phase: 6
triggers: asset, bling, build, crown, demand, fetch, gold, music, palette, pharaoh
tools: get_asset
inputs: kind, style, seed, out_dir, kw
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Fetch-or-build any vault asset on demand: get_asset('music','trap',42) / ('sfx','bling',3) / ('lut','pharaoh_gold') / ('sticker','crown',1,palette='ruby').

Run: big_tony_builder.TOOLS['get_asset'](...)  or  python -m big_tony_builder get_asset key=value
