---
name: auto_reframe
agent: big_tony
description: Auto Reframe / Camera Tracking - crops to 16 -9, 9 -16, 1 -1, 4 -3, 21 -9 while following the main subject
phase: 6
triggers: auto, camera, crops, following, main, reframe, subject, tracking, while
tools: auto_reframe
inputs: video, ratio, out, track
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Auto Reframe / Camera Tracking: crops to 16:9, 9:16, 1:1, 4:3, 21:9 while following the main subject
(motion-weighted centre per scene, smoothed).

Run: big_tony_builder.TOOLS['auto_reframe'](...)  or  python -m big_tony_builder auto_reframe key=value
