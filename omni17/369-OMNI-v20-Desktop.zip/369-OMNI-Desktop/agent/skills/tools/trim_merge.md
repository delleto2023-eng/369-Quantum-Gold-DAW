---
name: trim_merge
agent: big_tony
description: Basic editing - trim, cut, split, merge, crop, rotate, speed - conformed and joined.
phase: 6
triggers: basic, conformed, crop, editing, joined, merge, rotate, speed, split, trim
tools: trim_merge
inputs: clips, out, trims
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Basic editing: trim, cut, split, merge, crop, rotate, speed - conformed and joined.

Run: big_tony_builder.TOOLS['trim_merge'](...)  or  python -m big_tony_builder trim_merge key=value
