---
name: ai_image
agent: big_tony
description: AI Image (text to image) - routes to a connected image model; offline fallback renders a gold gradient art card.
phase: 6
triggers: card, connected, fallback, gold, gradient, image, model, offline, renders, routes
tools: ai_image
inputs: prompt, out, size
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Image (text to image): routes to a connected image model; offline fallback renders a gold gradient art card.

Run: big_tony_builder.TOOLS['ai_image'](...)  or  python -m big_tony_builder ai_image key=value
