---
name: video_mask
agent: big_tony
description: Video Mask / Pen Tool / AI Smart Masking - circle, rectangle, linear or pen-drawn polygon masks with feather; apply blur, color, or reveal a layer.
phase: 6
triggers: apply, blur, circle, color, drawn, feather, layer, linear, mask, masking
tools: video_mask
inputs: video, shape, out, feather, invert, x, y, w, h, points, effect
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Video Mask / Pen Tool / AI Smart Masking: circle, rectangle, linear or pen-drawn polygon masks with feather; apply blur, color, or reveal a layer.

Run: big_tony_builder.TOOLS['video_mask'](...)  or  python -m big_tony_builder video_mask key=value
