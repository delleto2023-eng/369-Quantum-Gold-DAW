---
name: keyboard_shortcuts
agent: big_tony
description: Keyboard Shortcut Presets - Big Tony, Premiere, Final Cut, CapCut, FL Studio maps; customise, import and export.
phase: 6
triggers: capcut, customise, export, final, import, keyboard, maps, premiere, presets, shortcut
tools: keyboard_shortcuts
inputs: preset, custom, export_to, import_from
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Keyboard Shortcut Presets: Big Tony, Premiere, Final Cut, CapCut, FL Studio maps; customise, import and export.

Run: big_tony_builder.TOOLS['keyboard_shortcuts'](...)  or  python -m big_tony_builder keyboard_shortcuts key=value
