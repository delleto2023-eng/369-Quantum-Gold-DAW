---
name: cloud_resize
agent: big_tony
description: cloud resize
phase: 6
triggers: cloud, resize
tools: cloud_resize
inputs: root, stack, size_gb
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
cloud resize

Run: big_tony_builder.TOOLS['cloud_resize'](...)  or  python -m big_tony_builder cloud_resize key=value
