---
name: cloud_ls
agent: big_tony
description: cloud ls
phase: 6
triggers: cloud
tools: cloud_ls
inputs: root, stack, rel
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
cloud ls

Run: big_tony_builder.TOOLS['cloud_ls'](...)  or  python -m big_tony_builder cloud_ls key=value
