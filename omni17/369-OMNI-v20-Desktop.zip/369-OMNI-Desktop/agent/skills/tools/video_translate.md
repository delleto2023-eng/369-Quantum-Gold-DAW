---
name: video_translate
agent: big_tony
description: AI Video Translator - transcribe -> translate -> dubbed voice (clone when connected) -> lip-sync -> translated subtitles.
phase: 6
triggers: clone, connected, dubbed, subtitles, sync, transcribe, translate, translated, translator, video
tools: video_translate
inputs: video, language, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Video Translator: transcribe -> translate -> dubbed voice (clone when connected) -> lip-sync -> translated subtitles.

Run: big_tony_builder.TOOLS['video_translate'](...)  or  python -m big_tony_builder video_translate key=value
