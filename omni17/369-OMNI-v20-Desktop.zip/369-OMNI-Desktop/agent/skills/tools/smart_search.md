---
name: smart_search
agent: big_tony
description: AI Smart Search - search your footage by words spoken, scene keywords or file names (uses media analysis + transcripts).
phase: 6
triggers: analysis, file, footage, keywords, media, names, scene, search, smart, spoken
tools: smart_search
inputs: folder, query
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Smart Search: search your footage by words spoken, scene keywords or file names (uses media analysis + transcripts).

Run: big_tony_builder.TOOLS['smart_search'](...)  or  python -m big_tony_builder smart_search key=value
