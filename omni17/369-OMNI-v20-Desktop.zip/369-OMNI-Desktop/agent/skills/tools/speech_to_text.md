---
name: speech_to_text
agent: big_tony
description: Speech to Text / Auto Captions - transcribes to SRT with faster-whisper or openai-whisper if installed,
phase: 6
triggers: auto, captions, faster, installed, openai, speech, text, transcribes, whisper
tools: speech_to_text
inputs: media, out, language
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Speech to Text / Auto Captions: transcribes to SRT with faster-whisper or openai-whisper if installed,
else through the OMNI model router.

Run: big_tony_builder.TOOLS['speech_to_text'](...)  or  python -m big_tony_builder speech_to_text key=value
