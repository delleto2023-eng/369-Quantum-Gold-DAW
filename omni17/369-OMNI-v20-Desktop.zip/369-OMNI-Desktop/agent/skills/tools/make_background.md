---
name: make_background
agent: big_tony
description: Original looping motion background (12 kinds x seeds), H.264 MP4.
phase: 6
triggers: background, kinds, looping, make, motion, original, seeds
tools: make_background
inputs: kind, seed, seconds, size, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Original looping motion background (12 kinds x seeds), H.264 MP4.

Run: big_tony_builder.TOOLS['make_background'](...)  or  python -m big_tony_builder make_background key=value
