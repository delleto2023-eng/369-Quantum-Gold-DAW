---
name: audio_visualizer
agent: big_tony
description: audio visualizer
phase: 6
triggers: audio, visualizer
tools: audio_visualizer
inputs: audio, out, mode, title
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
audio visualizer

Run: big_tony_builder.TOOLS['audio_visualizer'](...)  or  python -m big_tony_builder audio_visualizer key=value
