---
name: available_models
agent: big_tony
description: available models
phase: 6
triggers: available, models
tools: available_models
inputs: 
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
available models

Run: big_tony_builder.TOOLS['available_models'](...)  or  python -m big_tony_builder available_models key=value
