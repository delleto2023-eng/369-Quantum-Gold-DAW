---
name: ask
agent: big_tony
description: Ask one model. private=True routes through Privacy Mode (sanitized prompt, local model preferred).
phase: 6
triggers: local, mode, model, preferred, privacy, private, prompt, routes, sanitized, through
tools: ask
inputs: prompt, model, system, private
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Ask one model. private=True routes through Privacy Mode (sanitized prompt, local model preferred).

Run: big_tony_builder.TOOLS['ask'](...)  or  python -m big_tony_builder ask key=value
