---
name: auto_route
agent: big_tony
description: Switch between models based on the task.
phase: 6
triggers: auto, based, between, models, route, switch, task
tools: auto_route
inputs: prompt
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Switch between models based on the task.

Run: big_tony_builder.TOOLS['auto_route'](...)  or  python -m big_tony_builder auto_route key=value
