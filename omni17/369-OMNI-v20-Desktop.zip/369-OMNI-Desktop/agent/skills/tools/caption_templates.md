---
name: caption_templates
agent: big_tony
description: 60 dynamic caption styles (karaoke, pop, highlight box, emoji-free bold, outline, glow).
phase: 6
triggers: bold, caption, dynamic, emoji, free, glow, highlight, karaoke, outline, styles
tools: caption_templates
inputs: 
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
60 dynamic caption styles (karaoke, pop, highlight box, emoji-free bold, outline, glow).

Run: big_tony_builder.TOOLS['caption_templates'](...)  or  python -m big_tony_builder caption_templates key=value
