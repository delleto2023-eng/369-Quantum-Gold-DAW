---
name: green_screen
agent: big_tony
description: Green Screen / Chroma Key - replaces a green/blue screen with any video or image.
phase: 6
triggers: blue, chroma, green, image, replaces, screen, video
tools: green_screen
inputs: foreground, background, out, key_color, similarity, blend
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Green Screen / Chroma Key: replaces a green/blue screen with any video or image.

Run: big_tony_builder.TOOLS['green_screen'](...)  or  python -m big_tony_builder green_screen key=value
