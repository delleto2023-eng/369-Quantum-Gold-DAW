---
name: auto_beat_sync
agent: big_tony
description: Auto Beat Sync - cuts your clips/photos to the beat of the music.
phase: 6
triggers: auto, beat, clips, cuts, music, photos, sync
tools: auto_beat_sync
inputs: clips, music, out, ratio, every
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Auto Beat Sync: cuts your clips/photos to the beat of the music.

Run: big_tony_builder.TOOLS['auto_beat_sync'](...)  or  python -m big_tony_builder auto_beat_sync key=value
