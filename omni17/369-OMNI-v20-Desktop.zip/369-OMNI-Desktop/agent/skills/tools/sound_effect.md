---
name: sound_effect
agent: big_tony
description: sound effect
phase: 6
triggers: effect, sound
tools: sound_effect
inputs: kind, out, seconds
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
sound effect

Run: big_tony_builder.TOOLS['sound_effect'](...)  or  python -m big_tony_builder sound_effect key=value
