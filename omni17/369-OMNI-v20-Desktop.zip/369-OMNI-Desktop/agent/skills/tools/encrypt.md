---
name: encrypt
agent: big_tony
description: End-to-end encryption (AES-256-GCM via `cryptography`; falls back to an HMAC-authenticated stream cipher).
phase: 6
triggers: authenticated, back, cipher, cryptography, encrypt, encryption, falls, hmac, stream
tools: encrypt
inputs: data, passphrase
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
End-to-end encryption (AES-256-GCM via `cryptography`; falls back to an HMAC-authenticated stream cipher).

Run: big_tony_builder.TOOLS['encrypt'](...)  or  python -m big_tony_builder encrypt key=value
