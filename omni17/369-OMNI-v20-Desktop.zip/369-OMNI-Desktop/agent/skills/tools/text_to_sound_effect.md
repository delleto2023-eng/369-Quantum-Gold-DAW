---
name: text_to_sound_effect
agent: big_tony
description: AI Sound Effect Generator - text prompt -> custom SFX (model when connected; offline keyword-driven synthesis/layering).
phase: 6
triggers: connected, custom, driven, effect, generator, keyword, layering, model, offline, prompt
tools: text_to_sound_effect
inputs: prompt, out, seconds
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Sound Effect Generator: text prompt -> custom SFX (model when connected; offline keyword-driven synthesis/layering).

Run: big_tony_builder.TOOLS['text_to_sound_effect'](...)  or  python -m big_tony_builder text_to_sound_effect key=value
