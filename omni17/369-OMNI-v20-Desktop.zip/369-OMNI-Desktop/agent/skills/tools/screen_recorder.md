---
name: screen_recorder
agent: big_tony
description: screen recorder
phase: 6
triggers: recorder, screen
tools: screen_recorder
inputs: out, seconds
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
screen recorder

Run: big_tony_builder.TOOLS['screen_recorder'](...)  or  python -m big_tony_builder screen_recorder key=value
