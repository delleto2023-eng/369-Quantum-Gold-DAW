---
name: multi_clip_edit
agent: big_tony
description: Adjustment Layer / Multi-Clip Editing - apply the same effect or grade to many clips at once.
phase: 6
triggers: adjustment, apply, clip, clips, edit, editing, effect, grade, layer, many
tools: multi_clip_edit
inputs: clips, filters, out_dir
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Adjustment Layer / Multi-Clip Editing: apply the same effect or grade to many clips at once.

Run: big_tony_builder.TOOLS['multi_clip_edit'](...)  or  python -m big_tony_builder multi_clip_edit key=value
