---
name: cloud_status
agent: big_tony
description: cloud status
phase: 6
triggers: cloud, status
tools: cloud_status
inputs: root
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
cloud status

Run: big_tony_builder.TOOLS['cloud_status'](...)  or  python -m big_tony_builder cloud_status key=value
