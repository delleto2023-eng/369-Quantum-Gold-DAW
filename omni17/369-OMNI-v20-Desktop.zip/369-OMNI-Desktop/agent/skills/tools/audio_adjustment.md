---
name: audio_adjustment
agent: big_tony
description: Audio Adjustment - auto-levels uneven sound, boosts quiet recordings, clarifies voices and cleans noise in one go.
phase: 6
triggers: adjustment, audio, auto, boosts, clarifies, cleans, levels, noise, quiet, recordings
tools: audio_adjustment
inputs: media, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Audio Adjustment: auto-levels uneven sound, boosts quiet recordings, clarifies voices and cleans noise in one go.

Run: big_tony_builder.TOOLS['audio_adjustment'](...)  or  python -m big_tony_builder audio_adjustment key=value
