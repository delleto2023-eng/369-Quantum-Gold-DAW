---
name: text_titles
agent: big_tony
description: Titles & text animations (gold serif, neon, typewriter, lower third).
phase: 6
triggers: animations, gold, lower, neon, serif, text, third, titles, typewriter
tools: text_titles
inputs: video, text, out, style, start, duration, position
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Titles & text animations (gold serif, neon, typewriter, lower third).

Run: big_tony_builder.TOOLS['text_titles'](...)  or  python -m big_tony_builder text_titles key=value
