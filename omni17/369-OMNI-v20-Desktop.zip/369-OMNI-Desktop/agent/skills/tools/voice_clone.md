---
name: voice_clone
agent: big_tony
description: AI Voice Cloning - routed to a connected voice model (e.g. ElevenLabs/XTTS via the OMNI router).
phase: 6
triggers: clone, cloning, connected, elevenlabs, model, omni, routed, router, voice, xtts
tools: voice_clone
inputs: sample_audio, text, out
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Voice Cloning: routed to a connected voice model (e.g. ElevenLabs/XTTS via the OMNI router).
Offline fallback: TTS pitch/formant matched to the sample's average pitch.

Run: big_tony_builder.TOOLS['voice_clone'](...)  or  python -m big_tony_builder voice_clone key=value
