---
name: title_templates
agent: big_tony
description: 120 original animated title presets (font x color x animation x position), usable with text_titles / dynamic_subtitles.
phase: 6
triggers: animated, animation, color, dynamic, font, original, position, presets, subtitles, templates
tools: title_templates
inputs: 
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
120 original animated title presets (font x color x animation x position), usable with text_titles / dynamic_subtitles.

Run: big_tony_builder.TOOLS['title_templates'](...)  or  python -m big_tony_builder title_templates key=value
