---
name: media_analysis
agent: big_tony
description: AI Media Analysis - scenes, loudness peaks, highlight scores, keywords and edit suggestions with timestamps.
phase: 6
triggers: analysis, edit, highlight, keywords, loudness, media, peaks, scenes, scores, suggestions
tools: media_analysis
inputs: video, out_json
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Media Analysis: scenes, loudness peaks, highlight scores, keywords and edit suggestions with timestamps.
Adds an LLM description/keywords when the model router is available.

Run: big_tony_builder.TOOLS['media_analysis'](...)  or  python -m big_tony_builder media_analysis key=value
