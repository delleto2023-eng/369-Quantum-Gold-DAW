---
name: smart_short_clips
agent: big_tony
description: Smart Short Clips - finds the best moments, reframes vertical, adds dynamic subtitles and music.
phase: 6
triggers: adds, best, clips, dynamic, finds, moments, music, reframes, short, smart
tools: smart_short_clips
inputs: video, out_dir, count, length, ratio, music, subtitles_srt
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Smart Short Clips: finds the best moments, reframes vertical, adds dynamic subtitles and music.

Run: big_tony_builder.TOOLS['smart_short_clips'](...)  or  python -m big_tony_builder smart_short_clips key=value
