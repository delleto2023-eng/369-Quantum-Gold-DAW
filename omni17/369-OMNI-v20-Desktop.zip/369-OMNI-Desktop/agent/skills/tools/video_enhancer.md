---
name: video_enhancer
agent: big_tony
description: AI Video Enhancer - deblur/sharpen, detail recovery, upscale (1080p/2k/4k) and auto colour correction.
phase: 6
triggers: auto, colour, correction, deblur, detail, enhancer, recovery, sharpen, upscale, video
tools: video_enhancer
inputs: video, out, target, sharpen, auto_color
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
AI Video Enhancer: deblur/sharpen, detail recovery, upscale (1080p/2k/4k) and auto colour correction.

Run: big_tony_builder.TOOLS['video_enhancer'](...)  or  python -m big_tony_builder video_enhancer key=value
