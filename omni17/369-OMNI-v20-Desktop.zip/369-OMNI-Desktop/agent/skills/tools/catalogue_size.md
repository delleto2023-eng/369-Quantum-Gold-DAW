---
name: catalogue_size
agent: big_tony
description: How many distinct assets the vault can produce (seeds 0-9999 per recipe).
phase: 6
triggers: assets, catalogue, distinct, many, produce, recipe, seeds, size, vault
tools: catalogue_size
inputs: 
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
How many distinct assets the vault can produce (seeds 0-9999 per recipe).

Run: big_tony_builder.TOOLS['catalogue_size'](...)  or  python -m big_tony_builder catalogue_size key=value
