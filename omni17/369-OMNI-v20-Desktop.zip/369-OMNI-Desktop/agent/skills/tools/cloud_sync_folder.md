---
name: cloud_sync_folder
agent: big_tony
description: One-way sync of a local folder into a stack (changed files only).
phase: 6
triggers: changed, cloud, files, folder, local, only, stack, sync
tools: cloud_sync_folder
inputs: root, stack, folder, dest
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
One-way sync of a local folder into a stack (changed files only).

Run: big_tony_builder.TOOLS['cloud_sync_folder'](...)  or  python -m big_tony_builder cloud_sync_folder key=value
