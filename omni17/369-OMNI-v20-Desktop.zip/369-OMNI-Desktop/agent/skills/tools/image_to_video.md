---
name: image_to_video
agent: big_tony
description: Image to Video - animated camera move (zoom/pan) + style template + optional music.
phase: 6
triggers: animated, camera, image, move, music, optional, style, template, video, zoom
tools: image_to_video
inputs: image, out, seconds, style, ratio, motion, music
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Image to Video: animated camera move (zoom/pan) + style template + optional music.

Run: big_tony_builder.TOOLS['image_to_video'](...)  or  python -m big_tony_builder image_to_video key=value
