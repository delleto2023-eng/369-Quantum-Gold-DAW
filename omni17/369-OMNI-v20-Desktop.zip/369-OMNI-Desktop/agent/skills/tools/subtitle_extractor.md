---
name: subtitle_extractor
agent: big_tony
description: Subtitle Extractor - pulls every subtitle track out of MKV / MOV / MP4 files to .srt.
phase: 6
triggers: extractor, files, pulls, subtitle, track
tools: subtitle_extractor
inputs: video, out_dir
outputs: file path or result object
success: output exists and is reported to the user
est_minutes: 1
---
Subtitle Extractor: pulls every subtitle track out of MKV / MOV / MP4 files to .srt.

Run: big_tony_builder.TOOLS['subtitle_extractor'](...)  or  python -m big_tony_builder subtitle_extractor key=value
