---
name: jarvis-voice
agent: jarvis
description: JARVIS mode: speak, listen and send live alerts
phase: 3
triggers: voice, talk, speak, say it, read it out, hey bt2, jarvis, alert me, listen
tools: speak, listen, alert
inputs: text or a spoken command
outputs: spoken reply or alert
success: reply spoken or a clear note that voice is not set up
est_minutes: 1
---
1. listen if the user wants to talk; otherwise use the text.
2. speak a short reply.
3. alert when a job finishes or fails.
4. If voice is not set up, say to install pyttsx3 or espeak (and SpeechRecognition for the mic).
