---
name: big-tony-companion
description: Big Tony as an embodied desktop companion (Brahma SOL-style): 3D-look golden head that floats and roams on top of your windows, talks with an offline neural voice, hears you, knows your workspace, runs Windows tasks, forges new skills, and recovers from errors with the Ultron Protocol.
---
Start: Start Big Tony Companion.bat (or python -m big_tony_builder.companion [--voice 'Ava - warm narrator'] [--mute] [--stay]).
Click = type, double-click = talk, drag = move, right-click = menu (talk, type, what am I doing, forge a skill, Ultron incidents, voice on/off, roam on/off, quit).
Local first: start LM Studio or Ollama. Best voice: pip install kokoro soundfile. Mic: pip install sounddevice soundfile faster-whisper.
