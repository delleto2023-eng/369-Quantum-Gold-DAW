---
name: shield-scan
agent: shield
description: Scan files with 369 Shield before they enter the studio
phase: 9
triggers: virus, malware, scan, safe, shield, quarantine, suspicious
tools: shield_scan
inputs: file or folder
outputs: quarantine/ for blocked files
success: every file checked; each blocked file has a reason
est_minutes: 2
---
1. shield_scan the file or folder.
2. List each blocked file and why.
3. Never open or run anything blocked.
