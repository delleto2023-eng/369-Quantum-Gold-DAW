---
name: inbox-triage
agent: inbox_keeper
description: Read-only inbox triage with reply ideas in the user's voice
phase: 3
triggers: inbox, email, unread, triage, mail, reply ideas
tools: inbox_scan, voice_profile, remember
inputs: IMAP settings
outputs: prioritized list with reply ideas
success: unread mail listed by priority; nothing sent or deleted
est_minutes: 3
---
1. inbox_scan unread.
2. Group: needs reply, FYI, promos.
3. For needs-reply, suggest a one-line reply after checking voice_profile.
4. Never send, delete or archive.
