---
name: big-tony-picture-and-masks
description: Big Tony Builder v2 picture and masks tools - all unlocked, no pricing.
---

# Big Tony Builder - Picture And Masks

## ai_relight
AI Relight: fixes dark, backlit or uneven scenes - lifts shadows, balances exposure, keeps highlights natural.

## frame_interpolation
AI Video Interpolation: motion-compensated frame interpolation for buttery 60/120 fps or smooth slow motion.

## eye_contact
AI Eye Contact: redirects gaze to the camera via a connected gaze model (e.g. LivePortrait); offline it returns the clip unchanged and says so.

## image_enhancer
AI Image Enhancer: restore blurry/old/low-res photos - upscale, denoise, sharpen, auto colour (Real-ESRGAN if installed).

## beauty_filter
AI Video Beauty Filter: skin smoothing, even tone, brighten eyes/face, soft glow.

## face_mosaic
AI Face Mosaic: auto blurs/pixelates faces (OpenCV face detection if installed; else tracked subject box).

## lens_correction
Lens Correction: removes fisheye/barrel distortion (GoPro, DJI, phone wide presets).

## motion_blur
Motion Blur: natural cinematic blur on fast moves, cuts, zooms and pans in one click.

## video_mask
Video Mask / Pen Tool / AI Smart Masking: circle, rectangle, linear or pen-drawn polygon masks with feather; apply blur, color, or reveal a layer.

## adjustment_layer
Adjustment Layer / Multi-Clip Editing: apply the same effect or grade to many clips at once.

## image_sequence_to_video
Image Sequence to Video with adjustable frame rate (folder or pattern like frames/img_%04d.png).

## animated_chart
Animated Charts: bar / line / pie charts that grow on screen, gold themed. data={label:value}.

## preset_template
Preset Templates: one-click styled edits - gold_promo, vlog, trailer, lyric, slideshow, reel.
