---
name: big-tony-vault
description: Big Tony Vault - original royalty-free music, SFX, LUTs, stickers, backgrounds, overlays, title and caption templates generated on demand.
---
# Big Tony Vault
## make_track
Original music track (intro / verse / hook / bridge / outro) from genre + seed. Returns path (.mp3 or .wav).

## make_sfx
Original sound effect. 30 kinds x unlimited seeds.

## make_lut
Original .cube colour LUT (36 named looks; seed adds variations).

## make_sticker
Original sticker/element PNG with transparency. 20 shapes x 7 jewel palettes x unlimited seeds.

## make_background
Original looping motion background (12 kinds x seeds), H.264 MP4.

## make_overlay
Original overlay clip (use in screen/add blend mode) - light leaks, dust, flares, gold dust, scanlines.

## title_templates
120 original animated title presets (font x color x animation x position), usable with text_titles / dynamic_subtitles.

## caption_templates
60 dynamic caption styles (karaoke, pop, highlight box, emoji-free bold, outline, glow).

## catalogue_size
How many distinct assets the vault can produce (seeds 0-9999 per recipe).

## get_asset
Fetch-or-build any vault asset on demand: get_asset('music','trap',42) / ('sfx','bling',3) / ('lut','pharaoh_gold') / ('sticker','crown',1,palette='ruby').

## search_vault
Search the vault by words (genre, mood, colour, shape, look) - returns ready-to-build asset recipes.

## build_starter_vault
Builds the downloadable starter library on disk + catalogue.json.
