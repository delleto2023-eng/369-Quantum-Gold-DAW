---
name: big-tony-voice-gladia
description: Give Big Tony / Claude ears: transcribe audio, video or YouTube links with Gladia (speakers, 100+ languages, translation, summary, subtitles), live mic transcription, and turn recordings into action items and insights.
---
Set GLADIA_API_KEY. gladia_transcribe(path_or_url, out_dir='transcripts', translate_to=['es'], sentiment=True, chapters=True, redact_pii=False, vocabulary=['Big Tony','369'])
Saves .txt (speaker script), .json, .srt, .vtt. gladia_script(result, {0:'Delleto',1:'Jontay'}) names the speakers.
gladia_insights(result) -> summary, action items (who/what/when), decisions, open questions, key quotes, topics, follow-up email; gladia_insights(result, ask='what did Jontay say about the starterpack?').
gladia_live(seconds=60) for live mic (pip install websockets sounddevice). No key or offline: falls back to local faster-whisper.
CLI: python -m big_tony_builder.gladia song_session.wav --insights --translate es
