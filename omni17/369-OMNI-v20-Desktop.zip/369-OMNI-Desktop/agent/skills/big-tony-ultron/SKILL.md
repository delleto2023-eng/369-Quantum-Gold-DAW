---
name: big-tony-ultron
description: Ultron Protocol: controlled error analysis and recovery for tool runs - classifies the failure, installs missing packages from a safe list, retries network/timeouts with backoff, patches forged skills and re-tests, and logs every incident. Never edits core files; can't fix everything.
---
ultron_run('tool_name', **args) -> {ok, result|error, recovery[]}; ultron_incidents(20). The companion runs every tool under it automatically.
