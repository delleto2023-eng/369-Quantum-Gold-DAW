---
name: sound-pack-import
agent: sample_doctor
description: Import and sort a drum kit, then fix samples
phase: 6
triggers: drum kit, sound pack, samples, import kit, root note, normalize sample, sort sounds
tools: sort_sound_pack, sample_doctor, shield_scan
inputs: zip or folder of sounds
outputs: sounds/packs/<name>/<category>/
success: Shield scan ran; sounds sorted by category with counts; fixed samples named with their note
est_minutes: 5
---
1. sort_sound_pack (it Shield-scans first).
2. Report counts per category and anything blocked.
3. sample_doctor on melodic samples or 808s to find the root note.
4. Tell BT2 the pack is ready.
