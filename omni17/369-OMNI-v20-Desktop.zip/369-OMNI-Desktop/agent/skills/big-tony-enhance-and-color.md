---
name: big-tony-enhance-and-color
description: Big Tony Builder enhance and color tools - all features unlocked, no credits or pricing.
---

# Big Tony Builder - Enhance And Color

Call these with `from big_tony_builder import TOOLS` or the CLI `python -m big_tony_builder <tool> key=value`.

## video_enhancer
AI Video Enhancer: deblur/sharpen, detail recovery, upscale (1080p/2k/4k) and auto colour correction.

## video_denoise
AI Video Denoise with presets (light / medium / strong / film-grain-safe).

## color_palette
AI Color Palette: matches the colour style of a reference still (any film frame) or a built-in look,
with a skin-tone protection blend.

## color_mask
Color Mask: adjust only the areas matching a chosen colour (hue/sat/brightness) - rest of the frame untouched.

## apply_lut
LUTs: apply any .cube / .3dl colour LUT (with strength blend).

## portrait_mode
Portrait tools: skin smoothing + soft background blur with centre-weighted subject focus.

## object_removal
AI Object Removal: removes a logo/object/person from a region (delogo inpaint or blur-fill).

## chroma_key
Green Screen / Chroma Key: replaces a green/blue screen with any video or image.

## background_remover
AI Background Remover (portrait cutout): uses rembg/mediapipe if installed, else smart chroma/colour key.

## effects
Effects & filters: glow, VHS, glitch, film grain, light leak, mirror, old film, blur, shake, gold shimmer...

## transitions
Transitions: 40+ (fade, wipe, slide, circle, dissolve, pixelize, radial, zoom, smooth...).
