---
name: knowledge-learn
agent: knowledge_keeper
description: Teach Big Tony's Brain from links, text and corrections
phase: 3
triggers: learn this, teach big tony, learn from, remember this link, knowledge, correction, correct that
tools: kb_add_link, kb_add_text, kb_search, kb_correct
inputs: link, text or correction
outputs: learned facts in Big Tony's Brain
success: facts learned and listed; corrections saved; source named
est_minutes: 3
---
1. kb_add_link for links or kb_add_text for text.
2. List the facts learned, labeled fact, research or belief.
3. kb_correct for anything the user says is wrong.
4. kb_search to confirm the answer now uses the correction.
