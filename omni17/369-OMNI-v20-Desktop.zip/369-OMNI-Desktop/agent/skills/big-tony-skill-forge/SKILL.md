---
name: big-tony-skill-forge
description: Skill Forge: create a new Big Tony ability from a plain-words description. The model writes the tool, it is safety-checked, tested in an isolated run, auto-fixed up to 3 times, then installed for every agent.
---
forge_skill('download a YouTube video's audio as mp3', name='yt_audio'); forge_list(); forge_remove(name). Forged tools appear as forged_<function> and load at every start (~/.bigtony/forged).
