---
name: big-tony-cut-and-reframe
description: Big Tony Builder cut and reframe tools - all features unlocked, no credits or pricing.
---

# Big Tony Builder - Cut And Reframe

Call these with `from big_tony_builder import TOOLS` or the CLI `python -m big_tony_builder <tool> key=value`.

## smart_short_clips
Smart Short Clips: finds the best moments, reframes vertical, adds dynamic subtitles and music.

## smart_scene_cut
Smart Scene Cut: auto-clips the most notable moments into a highlights reel.

## auto_reframe
Auto Reframe / Camera Tracking: crops to 16:9, 9:16, 1:1, 4:3, 21:9 while following the main subject
(motion-weighted centre per scene, smoothed).

## camera_tracking
Auto Reframe / Camera Tracking: crops to 16:9, 9:16, 1:1, 4:3, 21:9 while following the main subject
(motion-weighted centre per scene, smoothed).

## reframe_360
360 Video Reframing: equirectangular 360 -> flat shot with chosen angle, FOV and optional smooth pan.

## planar_tracking
Motion / Planar Tracking: pins an image/text overlay to a moving region (tracked from the start box).

## keyframe_animation
Keyframing: animate zoom / position over time. keyframes=[(t,zoom,cx,cy)] with cx,cy in 0..1.

## speed_ramp
Speed Ramping: smooth speed curves (presets: hero, bullet, montage, jumper, flash in/out) or custom points [(t,speed)].

## stabilize
Video Stabilization: two-pass vidstab when available, else deshake.

## trim_merge
Basic editing: trim, cut, split, merge, crop, rotate, speed - conformed and joined.

## split_screen
Split Screen: 2-9 clips in grid / side-by-side / stacked layouts.

## auto_beat_sync
Auto Beat Sync: cuts your clips/photos to the beat of the music.

## silence_detection
Silence Detection: finds pauses and (optionally) cuts them out for jump-cut edits.
