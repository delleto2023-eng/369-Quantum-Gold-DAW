---
name: gmcli
description: Gmail: search, read, draft, and label email.
---

gmcli('search', 'from:x newer_than:7d') / gmcli('read', msg_id=...) / gmcli('draft', to=..., subject=..., body=...) / gmcli('label', msg_id=..., labels=[...]). Make drafts, never send without the user saying so.
