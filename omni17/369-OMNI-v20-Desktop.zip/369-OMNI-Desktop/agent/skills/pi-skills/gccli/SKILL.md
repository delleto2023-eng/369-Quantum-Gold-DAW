---
name: gccli
description: Google Calendar: list events, check availability, create events.
---

gccli('list', start=ISO, end=ISO) / gccli('freebusy', ...) / gccli('create', summary=..., start=..., end=..., attendees=[...]). Needs GOOGLE_ACCESS_TOKEN. Confirm before inviting anyone.
