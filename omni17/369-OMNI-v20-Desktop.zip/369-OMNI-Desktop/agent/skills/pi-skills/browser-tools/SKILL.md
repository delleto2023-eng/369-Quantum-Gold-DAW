---
name: browser-tools
description: Drive a real browser: open pages, click, fill, screenshot. Use to test web apps or read pages that need JavaScript.
---

browser_tools(url, actions=[{'do':'click','selector':'#go'},{'do':'fill','selector':'input','value':'hi'}]). Needs: pip install playwright && playwright install chromium. Always screenshot after changes and look at it.
