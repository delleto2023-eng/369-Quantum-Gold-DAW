---
name: gdcli
description: Google Drive: search, download and share files.
---

gdcli('search', query) / gdcli('download', file_id=..., out=path) / gdcli('share', file_id=..., email=..., role='reader'). Confirm before sharing.
