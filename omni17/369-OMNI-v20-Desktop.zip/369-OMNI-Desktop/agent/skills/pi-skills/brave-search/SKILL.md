---
name: brave-search
description: Web search and page text extraction. Use for current facts, docs, news.
---

Call big_tony_builder.pi_skills.brave_search(query, n=8, fetch_top=2). BRAVE_API_KEY is optional; without it DuckDuckGo is used. Cite the URL for every fact.
