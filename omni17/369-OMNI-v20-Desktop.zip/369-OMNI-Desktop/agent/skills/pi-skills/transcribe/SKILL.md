---
name: transcribe
description: Speech-to-text for audio or video files.
---

transcribe(path). Uses Groq Whisper with GROQ_API_KEY, else local faster-whisper/whisper. For video, extract audio first with ffmpeg (-vn -ac 1 -ar 16000).
