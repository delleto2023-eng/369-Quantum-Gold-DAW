---
name: vscode
description: Show diffs and open files in VS Code.
---

vscode('diff', a=old, b=new) to compare; vscode('open', path=..., line=N). Falls back to a text diff.
