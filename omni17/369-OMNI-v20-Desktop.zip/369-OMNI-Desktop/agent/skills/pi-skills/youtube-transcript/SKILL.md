---
name: youtube-transcript
description: Fetch a YouTube video's transcript to summarize or learn from it.
---

youtube_transcript(url). Use it before answering questions about a video; feed results into knowledge-learn to grow Big Tony's brain.
