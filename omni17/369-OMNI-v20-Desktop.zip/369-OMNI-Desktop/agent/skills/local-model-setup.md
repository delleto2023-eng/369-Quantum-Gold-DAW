---
name: local-model-setup
agent: model_smith
description: run the best open-weight model your GPU can handle and switch the team to it
phase: 9
triggers: local model, gpu, vram, offline ai, llama, llama.cpp, run locally, own computer
tools: hardware_scan, model_catalog, model_fit, llama_server_command, llama_server_start, llama_server_status, model_benchmark, use_local_brain
inputs: hardware
outputs: running llama-server, team on local brain
success: server lists the model; benchmark recorded; tokens per second reported
est_minutes: 30
---
1. hardware_scan for VRAM, RAM and CPU threads.
2. model_catalog, then model_fit for each candidate by name (it uses reported peak memory when known, like Edge0-145B's 29 GB), and at Q4_K_M and IQ3_S for GGUFs. Use your real VRAM/RAM.
3. Pick the biggest model whose plan is FULL GPU or MOE OFFLOAD (see the vram-fit skill).
4. llama_server_command with spare_vram_gb = VRAM minus the fit estimate; ram_short=true if RAM is tight.
5. llama_server_start (approval), then llama_server_status until it lists the model (loading can take minutes).
6. model_benchmark; if gen_tokens_per_s is under 8, follow thread-tuning or drop one quant step.
7. Needs llama.cpp 1.0 or newer (stable API, 150+ architectures); if the model's architecture is rejected, update llama.cpp first.
8. use_local_brain provider=openai (approval). Report model, quant, plan and tokens/s.
