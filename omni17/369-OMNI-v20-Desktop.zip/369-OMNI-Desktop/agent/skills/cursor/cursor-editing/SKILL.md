---
name: cursor-editing
description: Cursor-style code editing - exact edits, multi-edits, patches, renames, inline Cmd+K edits, smart apply, Tab completion, notebooks, checkpoints and undo.
---
- edit_file / search_replace: exact find-and-replace or full write (always checkpointed)
- multi_edit: many edits in one file, all-or-nothing
- insert_lines / replace_lines: line-based edits
- apply_patch: unified diff across many files (create, delete, rename), all-or-nothing
- rename_symbol: whole-word rename across the project
- move_file: move or rename a file
- inline_edit(path, instruction, start, end): Cmd+K rewrite of a selection by the model
- smart_apply / reapply: merge a rough edit with '... existing code ...' gaps into the full file
- tab_complete(path, line): suggest the next code (fill-in-the-middle on LM Studio)
- edit_notebook: replace, insert or delete Jupyter cells
- checkpoint / list_checkpoints / restore_checkpoint / undo / review_changes: Cursor-style checkpoints and review diff
Always read_file before editing, read_lints after, and review_changes before calling it done.
