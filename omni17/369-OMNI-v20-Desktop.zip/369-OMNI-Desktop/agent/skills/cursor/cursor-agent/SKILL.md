---
name: cursor-agent
description: Cursor-style coding: search, read, edit, run, verify, with rules. Use for any coding task in a project.
---

1. fetch_rules(file=...) for project rules (.cursor/rules, AGENTS.md).
2. explore(question) or codebase_search / grep_search / file_search to find code.
3. read_file before edit_file (exact search/replace).
4. run_terminal_cmd to run tests; read_lints after edits.
5. browser to check web UI; generate_image for mockups.
6. todo_write for multi-step work; ask_question only when truly stuck.
