---
name: cursor-rules
description: Write project rules Big Tony follows automatically.
---

Create .cursor/rules/<name>.mdc with frontmatter: description, globs (e.g. *.py), alwaysApply true/false. Body = the rule. fetch_rules loads them.
