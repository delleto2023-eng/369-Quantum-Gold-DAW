---
name: cursor-run-modes
description: Control how shell commands run: allowlist, auto-review, or run-everything.
---

Set BIG_TONY_RUN_MODE. auto-review (default) blocks destructive commands until approve=True; allowlist runs only listed commands; run-everything runs all.
