---
name: lyrics-and-flow
agent: tony_lyricist
description: Write hooks and verses with delivery cues
phase: 3
triggers: lyrics, hook, verse, rhymes, topline, flow, bars, write a song
tools: voice_profile, write_file
inputs: topic, mood, structure
outputs: lyrics/<title>.md
success: hook plus verses written; stresses and breaths marked; in the user's voice
est_minutes: 5
---
1. voice_profile to match how the user talks.
2. Write the hook first (4 to 8 lines), then verses.
3. Mark stresses with CAPS and breaths with /.
4. write_file to lyrics/<title>.md.
