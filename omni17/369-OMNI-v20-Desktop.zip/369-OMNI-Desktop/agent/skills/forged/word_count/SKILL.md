---
name: word_count
description: count words in text
tools: forged_word_count
---
Forged by Skill Forge on 2026-11-17.
Call forged_word_count(...). Source: /tmp/claude/tmptnj8_88s/word_count.py
