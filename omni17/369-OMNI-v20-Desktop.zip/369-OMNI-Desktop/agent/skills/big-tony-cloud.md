---
name: big-tony-cloud
description: Big Tony Cloud - personal cloud with storage stacks (default 2 x 300 GB), quotas, PIN login, encryption, share links, sync and web UI.
---
# Big Tony Cloud
Tools: cloud_setup, cloud_status, cloud_put, cloud_get, cloud_ls, cloud_delete, cloud_share, cloud_sync_folder, cloud_resize.
