---
name: big-tony-harness
description: How the Big Tony Harness works: tools, AGENTS.md, skills, templates, sessions, steering, providers, modes.
---

Run: python -m big_tony_builder.harness (interactive), -p "task" (print), --mode json, --mode rpc.
Commands: /model provider [model], /tree, /branch ID, /label ID NAME, /compact, /export file.html, /skills, /tools, /reload, /skill:NAME, /TEMPLATE args.
Project files: AGENTS.md (every folder up to root), .bigtony/SYSTEM.md or APPEND_SYSTEM.md, .bigtony/skills, .bigtony/prompts, .bigtony/extensions/*.py with register(h).
