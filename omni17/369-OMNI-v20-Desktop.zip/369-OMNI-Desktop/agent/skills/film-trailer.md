---
name: film-trailer
agent: director
description: turn stills (and a beat) into a graded cinematic trailer
phase: 6
triggers: trailer, video, film, cinematic, shots, movie
tools: list_files, media_info, golden_timing, make_shot_list, still_to_shot, film_look, assemble_sequence
inputs: images, optional audio
outputs: film/sequence.mp4, shot list csv
success: final mp4 exists and media_info shows video; length matches audio if given; graded
est_minutes: 15
---
1. list_files to find images and audio.
2. If there is audio, media_info for its length; split it across shots with golden_timing.
3. Plan with make_shot_list: open wide, end close; vary moves (dolly-in, pan, tilt-up, slow-zoom-out).
4. Render each shot with still_to_shot; grade with film_look (default gold-luxury, letterbox true).
5. assemble_sequence in order with the audio. Report the file and shot list.
