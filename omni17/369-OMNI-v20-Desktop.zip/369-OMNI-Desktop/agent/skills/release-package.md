---
name: release-package
agent: publisher
description: package and document finished work
phase: 9
triggers: release, package, zip, export, ship, publish, deliver
tools: package_zip, release_notes, remember
inputs: project folder, guardian PASS
outputs: exports/<name>.zip, exports/<name>.md
success: guardian said PASS; zip and notes exist; release remembered
est_minutes: 5
---
1. Confirm the guardian said PASS.
2. package_zip the project folder.
3. release_notes with: what it is, files included, how to use it.
4. remember the release (what, where, date).
5. Report the ZIP path.
