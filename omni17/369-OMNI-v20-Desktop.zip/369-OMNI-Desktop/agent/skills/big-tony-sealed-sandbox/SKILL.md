---
name: big-tony-sealed-sandbox
description: Run untrusted code sealed in Docker: no network, read-only system, memory/CPU/process limits, non-root, auto-removed. Python, Node, Bash.
---
sandbox_run_sealed(code, lang='python', timeout=30, memory='512m', network=False, files=[...]). Big Tony Chat's code tool uses it automatically when Docker Desktop is running (Admin > Code sandbox: auto / required / off).
