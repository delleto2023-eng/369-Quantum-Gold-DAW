---
name: big-tony-rea
description: Reverse-engineer apps and sites you own or may examine (REA-style): find how a feature works with evidence, then build your own version.
---
rea_identify(path) picks the analyzer. JS/Electron (folder/.asar): modules, IPC, preload bridges, routes, network calls, source maps. Websites: tech stack, forms, scripts, API hints. HAR captures: API map + rea_har_to_tools generates a Python client. PE/ELF/APK/model/SQLite inspectors; rea_native_decompile hands off to rizin/objdump/Ghidra.
rea_study_feature(target, 'search', build_for='my app') -> evidence + explanation + build plan. Lawful use only; never copy proprietary code.
