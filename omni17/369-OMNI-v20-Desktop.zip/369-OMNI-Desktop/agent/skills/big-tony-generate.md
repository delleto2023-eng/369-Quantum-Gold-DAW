---
name: big-tony-generate
description: Big Tony Builder generate tools - all features unlocked, no credits or pricing.
---

# Big Tony Builder - Generate

Call these with `from big_tony_builder import TOOLS` or the CLI `python -m big_tony_builder <tool> key=value`.

## image_to_video
Image to Video: animated camera move (zoom/pan) + style template + optional music.

## text_to_video
AI Text to Video: splits a script into scenes, renders cinematic title scenes with voiceover + music.

## idea_to_video
AI Idea to Video: concept -> story script (via OMNI model router) -> scenes -> video.

## audio_to_video
Audio to Video: visuals synchronised to the audio (spectrum / waves / circle / cover-art pulse).

## video_extender
AI Video Extender: extend a clip forward/backward. Uses the generative backend when connected,
otherwise motion-interpolated slow-motion, boomerang or held frame with gentle zoom.

## ai_image
AI Image (text to image): routes to a connected image model; offline fallback renders a gold gradient art card.

## ai_music_generator
AI Music Generator: royalty-free procedural backing tracks (trap, lofi, cinematic, ambient, house) tuned to 432 Hz.
Routes to a connected music model when available.
