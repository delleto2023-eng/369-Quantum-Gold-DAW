---
name: studio-session
agent: bt2
description: Run a studio session with BT2 action tags
phase: 6
triggers: bpm, tempo, key, play, stop, session, studio, project, title
tools: studio_command, forge_song
inputs: bpm, key, idea
outputs: studio/project.json and songs
success: tempo and key set; every new file path reported
est_minutes: 3
---
1. studio_command with [[status]].
2. Set [[bpm:..]] [[key:..]] [[title:..]] from the request.
3. [[song:description]] or forge_song for new music.
4. [[play:file]] to audition; report every file path.
