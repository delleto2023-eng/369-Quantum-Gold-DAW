---
name: big-tony-audio-v2
description: Big Tony Builder v2 audio v2 tools - all unlocked, no pricing.
---

# Big Tony Builder - Audio V2

## text_to_sound_effect
AI Sound Effect Generator: text prompt -> custom SFX (model when connected; offline keyword-driven synthesis/layering).

## smart_bgm
Smart BGM Generation: analyses the video's pace and mood, generates matching background music and mixes it with ducking.

## audio_extender
AI Audio Extender: lengthens music naturally by looping at matching beat points with crossfades (no pitch change).

## voice_changer
Voice Changer: robot, chipmunk, deep, monster, female, male, radio, telephone, echo/cave, alien, whisper, megaphone, big tony.

## audio_adjustment
Audio Adjustment: auto-levels uneven sound, boosts quiet recordings, clarifies voices and cleans noise in one go.

## auto_sync
Auto Synchronization: aligns a separately recorded audio track to the camera audio by waveform cross-correlation.
