---
name: big-tony-self-test
description: Check every part of Big Tony on your own computer and get a pass / needs-setup / fail report with fixes.
---
Run Big Tony Self-Test.bat (or python -m big_tony_builder.selftest). Opens 'Big Tony Self-Test.html' in your home folder; send the .json next to it to get any FAIL fixed. Safe: never clicks, types, deletes or installs.
