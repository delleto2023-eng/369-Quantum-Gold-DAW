---
name: big-tony-instant-on
description: Instant-On (inspired by Tohoku/AISIN's no-RAM MRAM AI chip): persistent memory-mapped store that survives restarts, state snapshots and instant resume, keep local models warm, time-to-first-answer and boot profiling, offline Tiny YOLOv3 object detection from images or webcam.
---
instant_remember/recall(key); instant_snapshot(name, state) then instant_resume(name); instant_keep_warm(model); instant_first_answer_time(); instant_boot_profile(); instant_detect(image='photo.jpg' or camera=0, save='out.jpg') (pip install opencv-python; downloads Tiny YOLOv3 once).
