---
name: app-create
agent: app_creator
description: Create and test a single-file app
phase: 3
triggers: make an app, create an app, app creator, prototype, mini game, web app
tools: app_scaffold, button_doctor
inputs: idea
outputs: apps/<name>/index.html
success: app opens; button_doctor finds no dead buttons
est_minutes: 5
---
1. app_scaffold with the closest kind (tool, game, player).
2. Edit it toward the idea with write_file.
3. button_doctor on it and fix anything flagged.
4. Report how to open it.
