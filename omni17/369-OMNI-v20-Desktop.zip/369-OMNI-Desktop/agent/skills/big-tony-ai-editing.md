---
name: big-tony-ai-editing
description: Big Tony Builder v2 ai editing tools - all unlocked, no pricing.
---

# Big Tony Builder - Ai Editing

## text_based_editing
AI Text-Based Editing: transcribe, then edit the video like a document - delete words/lines and the matching video is cut.

## transcript_document
Exports the transcript as an editable numbered document for text-based editing.

## prompt_video_editing
Prompt Video Editing: type what you want ("make it vertical, brighter, add gold glow, remove silence, add captions") and Big Tony runs the tools.

## instant_mode
Instant Mode: drop in clips/photos, get a finished beat-synced, graded, captioned edit in one click.

## instant_cut
Instant Cutter: lossless, no re-encode trim/cut for huge files (seconds, not minutes).

## smart_search
AI Smart Search: search your footage by words spoken, scene keywords or file names (uses media analysis + transcripts).

## social_content_planner
Social Content Planner: plan/schedule videos for YouTube, TikTok, Instagram, X, Facebook; exports a calendar (.ics) and best-time suggestions.

## video_translate
AI Video Translator: transcribe -> translate -> dubbed voice (clone when connected) -> lip-sync -> translated subtitles.

## image_to_prompt
Image to Prompt: reverse-engineers an AI prompt from an image (vision model when connected; offline colour/composition analysis).

## ai_sticker
AI Sticker Generator: describe a sticker, get a transparent PNG (image model when connected; offline gold badge sticker).
