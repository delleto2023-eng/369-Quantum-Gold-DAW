---
name: big-tony-audio
description: Big Tony Builder audio tools - all features unlocked, no credits or pricing.
---

# Big Tony Builder - Audio

Call these with `from big_tony_builder import TOOLS` or the CLI `python -m big_tony_builder <tool> key=value`.

## voice_enhancer
AI Voice Enhancement: rumble cut, denoise, de-ess, presence boost, compression, broadcast loudness (-14 LUFS).

## ai_sound_effects
AI Sound Effects: auto-places matching SFX on scene cuts (whoosh), loud peaks (impact) and the intro (riser).

## sound_effect


## add_music


## audio_ducking


## audio_stretch
Audio Stretch: fits music to an exact length without changing pitch.

## detect_beats
Beat detection (onset energy) - used by Auto Beat Sync.

## voice_clone
AI Voice Cloning: routed to a connected voice model (e.g. ElevenLabs/XTTS via the OMNI router).
Offline fallback: TTS pitch/formant matched to the sample's average pitch.

## text_to_speech
Text to Speech: offline voiceover (espeak-ng / macOS say / Windows SAPI) or a connected voice model.

## ai_vocal_remover
AI Vocal Remover / stem split: uses Demucs/Spleeter if installed, else centre-channel cancel (instrumental) + mid (vocal).

## audio_visualizer


## lip_sync
AI Lip Sync / translation: translates the transcript (model router), voices it, and syncs it to the clip.
True mouth re-animation runs through a connected lip-sync model (Wav2Lip/SadTalker) when available;
otherwise the dub is time-fitted to the original speech length.
