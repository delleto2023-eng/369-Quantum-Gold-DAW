---
name: song-forge
agent: song_forge
description: Make beats with Song Forge and turn hums into MIDI
phase: 6
triggers: make a beat, make a song, beat, trap, drill, amapiano, afrobeat, lofi, gospel, reggaeton, hum, melody, midi
tools: forge_song, hum_to_midi
inputs: genre, bpm, key, or a hummed WAV
outputs: studio/songs/*.wav, .mid
success: WAV exists with BPM, key and length reported; MIDI saved for hums
est_minutes: 3
---
1. Pick the genre template from the request.
2. forge_song with BPM and key (or the template defaults).
3. For a hummed recording, hum_to_midi and report notes, key and BPM.
4. Hand to the mastering engineer if the user wants it release-ready.
