---
name: lmstudio-engine
description: Run Big Tony fully local on LM Studio - start the server, load or download models, chat, stream, autocomplete, embeddings, structured JSON.
---
1. Open LM Studio > Developer > Start Server (or lmstudio_start_server). Default http://localhost:1234; set LMSTUDIO_URL for another machine.
2. lmstudio_status to see loaded models; lmstudio_load_model('qwen2.5-coder-14b-instruct') or lmstudio_download_model(name).
3. The harness uses LM Studio automatically whenever its server is running (/model lmstudio to switch back to it).
4. inline_edit, smart_apply and tab_complete use LM Studio first, then any connected API key.
5. lmstudio_embed powers local meaning search; lmstudio_chat(..., json_schema=...) returns structured JSON.
Good picks: Qwen2.5-Coder (code), Llama 3.1/3.3 (chat), nomic-embed-text (embeddings).
