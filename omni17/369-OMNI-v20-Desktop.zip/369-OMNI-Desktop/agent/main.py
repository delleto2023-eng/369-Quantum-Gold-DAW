"""369 Ultimate Agent - just talk to Big Tony; he picks the agents and skills.
  python main.py            chat with the whole team
  python main.py doctor     check setup
Chat commands: /agents  /skills  /tools  /facts  /ask <agent> <task>  /doctor  /quit
"""
import argparse, os, sys
from pathlib import Path


def load_env(path=".env"):
    if Path(path).exists():
        for line in Path(path).read_text().splitlines():
            line = line.split("#", 1)[0].strip()
            if "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


def main():
    os.chdir(Path(__file__).parent)
    load_env()
    from agent.system import build_system, doctor
    from agent.loop import compact_history
    from agent.catalog import describe

    ap = argparse.ArgumentParser()
    ap.add_argument("command", nargs="?", default="chat", choices=["chat", "doctor", "test", "catalog"])
    ap.add_argument("--provider"); ap.add_argument("--model")
    ap.add_argument("--auto-approve", action="store_true", help="skip approval prompts (not recommended)")
    ap.add_argument("--max-steps", type=int, default=27)
    ap.add_argument("--plan", choices=["pro", "max"], help="pro = lean usage-saving mode, max = full power")
    a = ap.parse_args()
    if a.command == "doctor":
        print(doctor()); return
    if a.command == "test":
        import subprocess
        sys.exit(subprocess.call([sys.executable, "-m", "unittest", "-v", "tests/test_369.py"]))

    if a.command == "catalog":
        from agent.attributes_doc import write_catalog
        print(write_catalog()); return
    if a.plan:
        os.environ["AGENT_PLAN"] = a.plan
    sysm = build_system(a.provider, a.model, a.auto_approve, a.max_steps)
    boss, memory, library, guard = sysm["boss"], sysm["memory"], sysm["library"], sysm["guard"]
    print(f"{boss.name} and the team are ready ({sysm['brain'].provider}:{sysm['brain'].model}).")
    print(f"Team: {', '.join(boss.team)} | Skills: {len(library.skills)} | Workspace: {guard.workspace}")
    print("Just say what you want. Commands: /plan pro|max /usage /agents /skills /tools /facts /workspace /signals /ask <agent> <task> /doctor /quit\n")
    history = []
    while True:
        try:
            task = input("you> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not task:
            continue
        if task in ("/quit", "/exit"):
            break
        if task == "/agents":
            from agent.team import load_config
            for triad, members in load_config()["triads"].items():
                print(triad); print("\n".join(f"  - {k}: {boss.team[k].role.split('.')[0]}" for k in members))
            continue
        if task == "/skills":
            library.reload(); print(library.catalog()); continue
        if task == "/tools":
            print(describe()); print("\n".join(t.card() for t in sysm["tools"].tools.values())); continue
        if task == "/facts":
            print(memory.facts()); continue
        if task == "/doctor":
            print(doctor()); continue
        if task.startswith("/plan"):
            from agent.plans import apply_plan
            parts = task.split()
            print(apply_plan(sysm, parts[1]) if len(parts) > 1 else f"Plan mode: {guard.plan} (use /plan pro or /plan max)"); continue
        if task == "/usage":
            print(sysm["tools"].tools["usage_report"].fn()); continue
        if task == "/workspace":
            print(sysm["mind"].workspace.render(9) or "(empty)"); continue
        if task == "/signals":
            import json as _j; print(_j.dumps(sysm["mind"].signals.stats(), indent=1)); continue
        action, msg = sysm["mind"].boundary.check(task)
        if action != "ok":
            print(f"\n{boss.name}> {msg}\n")
            if action == "end":
                break
            continue
        guard.tool_calls_used = 0
        if task.startswith("/ask "):
            parts = task.split(" ", 2)
            if len(parts) < 3 or parts[1] not in boss.team:
                print(f"Usage: /ask <{'|'.join(boss.team)}> <task>"); continue
            answer, _ = boss.team[parts[1]].run(parts[2])
            print(f"\n{parts[1].title()}> {answer}\n"); continue
        answer, history = boss.run(task, history)
        history = compact_history(sysm["brain"], history, **sysm.get("compact", {}))
        print(f"\n{boss.name}> {answer}\n")


if __name__ == "__main__":
    main()
