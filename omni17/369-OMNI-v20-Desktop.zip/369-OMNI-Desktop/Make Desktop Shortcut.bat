@echo off
set "T=%~dp0369 OMNI Desktop.bat"
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\369 OMNI.lnk');$s.TargetPath='%T%';$s.WorkingDirectory='%~dp0';$s.WindowStyle=7;$s.Save()"
echo Shortcut "369 OMNI" added to your Desktop.
pause
