@echo off
title 369 OMNI Desktop
set "APP=%~dp0app\index.html"
set "PROF=%LOCALAPPDATA%\369-OMNI-Desktop"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
if exist "%CHROME%" ( start "" "%CHROME%" --app="file:///%APP:\=/%" --user-data-dir="%PROF%" --allow-file-access-from-files --autoplay-policy=no-user-gesture-required --start-maximized & exit /b )
if exist "%EDGE%" ( start "" "%EDGE%" --app="file:///%APP:\=/%" --user-data-dir="%PROF%" --allow-file-access-from-files --autoplay-policy=no-user-gesture-required --start-maximized & exit /b )
start "" "%APP%"
